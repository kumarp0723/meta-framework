"""Provider fixtures; integration uses installed development adapters and a pinned Framework bundle."""
import os
from pathlib import Path
import sys

import pytest
import yaml
from pyspark.sql import SparkSession

from mdpf_runtime.pipeline import MetadataFramework
from mdpf_onboarding.config import UniqueLoader, validate_config
from mdpf_onboarding.metadata_generator import contract_model
from mdpf_onboarding.sql_renderer import render_sql


PROVIDER_ROOT = Path(__file__).resolve().parent
FEE_DIR = PROVIDER_ROOT / 'datasets' / 'fee'


@pytest.fixture(scope='session')
def spark():
    os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'
    os.environ['PYSPARK_PYTHON'] = sys.executable
    session = (SparkSession.builder.master('local[1]').appName('provider-dmi-tests')
               .config('spark.ui.enabled', 'false')
               .config('spark.sql.shuffle.partitions', '1')
               .config('spark.sql.session.timeZone', 'UTC').getOrCreate())
    session.sparkContext.setLogLevel('ERROR')
    yield session
    session.stop()


@pytest.fixture(scope='session')
def fee_dir():
    return FEE_DIR


@pytest.fixture(scope='session')
def fee_config():
    return validate_config(yaml.load((FEE_DIR / 'onboarding.yaml').read_text(), Loader=UniqueLoader))


@pytest.fixture(scope='session')
def fee_model(fee_config):
    return contract_model(fee_config)


@pytest.fixture(scope='session')
def ci_adapters():
    import mdpf_test_support
    return mdpf_test_support


@pytest.fixture(scope='session')
def framework_entrypoints(tmp_path_factory):
    """Extract validated launcher bytes from the required versioned Framework ZIP."""
    import hashlib
    from importlib.metadata import version
    import runpy
    bundle = os.environ.get('MDPF_FRAMEWORK_BUNDLE')
    if not bundle:
        pytest.fail('Required integration artifact missing: set MDPF_FRAMEWORK_BUNDLE to the approved Framework ZIP.')
    bundle = Path(bundle)
    assets, _ = runpy.run_path(str(PROVIDER_ROOT / 'scripts/package_release.py'))['framework_assets'](
        bundle, hashlib.sha256(bundle.read_bytes()).hexdigest(), version('mdpf-runtime'))
    root = tmp_path_factory.mktemp('framework-launchers')
    for name, data in assets.items():
        if name.startswith('entrypoints/'):
            path = root / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(data)
    return root / 'entrypoints'


@pytest.fixture
def execution_case(fee_model, fee_dir, ci_adapters, spark, tmp_path):
    db = ci_adapters.CatalogDb()
    close = db.close
    try:
        db.deploy(render_sql(fee_model, (fee_dir / 'onboarding.yaml').read_bytes()))
        # Only the SQLite test catalog is activated here. Generation remains DRAFT.
        db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE'")
        db.test_warehouse = ci_adapters.WarehouseDb(fee_model)
        storage = ci_adapters.SparkTestStorage(tmp_path)
        landing = fee_model['datasets']['DMI_FEE_FEE_LANDING']['row']['physical_object_name']['DEV']
        path = storage.path(landing.replace('{YYYYMMDD}', '20261015'))
        path.parent.mkdir(parents=True, exist_ok=True)
        # Local CSV fixture is materialized as a Parquet landing delivery.
        from mdpf_onboarding.schema_discovery import read_sample
        read_sample(spark,str(fee_dir / 'samples/fee_input.csv')).write.parquet(str(path))
        fw = MetadataFramework(db, 'DMI_FEE', spark=spark, main_db=db.test_warehouse)
        fw.storage = storage
        yield fw, db, path
    finally:
        close()
