"""DMI_FEE STAGE launcher; business code remains in the provider wheel."""
import logging
logging.basicConfig(format='%(asctime)s %(levelname)s %(name)s %(message)s')
logging.getLogger('mdpf_runtime').setLevel(logging.INFO)
from mdpf_runtime.dataflow import execute_task
from provider_dmi.fee import custom_fee_transform


def main(argv=None, *, spark=None):
    """Run the fixed STAGE task; forward workflow arguments without catching errors."""
    return execute_task(
        pipeline_code="DMI_FEE", task_code="DMI_FEE_STAGE_LOAD",
        custom_steps={"CUSTOM_FEE_TRANSFORM": custom_fee_transform},
        spark=spark, argv=argv,
    )


if __name__ == "__main__":
    result = main(spark=globals().get("spark"))

