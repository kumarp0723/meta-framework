# DMI_FEE walkthrough

This is the production source of DMI_FEE. Its configuration uses Parquet landing,
the reviewed twelve business columns, a `CLIENT_NO` trim and four DQ policies.
Utility Parquet landing examples with CSV samples remain separate regression fixtures. Make production changes
here, not in a utility example.

Read the [developer guide](../../../common-utilities/framework/DEVELOPER_GUIDE.md)
first. This walkthrough assumes the existing three-repository layout.

## What you need

| Environment | What you can do |
|---|---|
| Local Python 3.10+ / Java 17 | Install packages, review YAML and run local tests using Spark/SQLite/OCI adapters |
| Prepared OCI Spark notebook | Read the uploaded YAML/samples and generate artifacts |
| ATP and ADW | Install the framework in ATP, deploy MAIN DDL in ADW, activate metadata and execute the pipeline |
| Data Flow or AIDP | Run the supplied task entry points after installing packages, storage access and scheduler bindings |

The complete example needs infrastructure. Local tests do not provision it. Use
the [local setup commands](../../../common-utilities/framework/DEVELOPER_GUIDE.md#local-setup-and-checks)
or [standalone provider setup](../../../common-utilities/framework/DEVELOPER_GUIDE.md#standalone-provider-checkout)
for an independent checkout. All provider tests use installed packages, including the development-only `mdpf-test-support`,
and a required approved Framework bundle. No sibling utility source checkout is needed.
Missing required test dependencies fail; use `-m 'not integration'` only to select a smaller run deliberately.

## Review the source

| File | What to change |
|---|---|
| [datasets/fee/onboarding.yaml](datasets/fee/onboarding.yaml) | Business columns, environment bindings, paths, task plans and DQ rules |
| [src/provider_dmi/fee.py](src/provider_dmi/fee.py) | Reusable `custom_fee_transform()` implementation |
| [entrypoints/dataflow/stage.py](entrypoints/dataflow/stage.py) / [entrypoints/aidp/stage.ipynb](entrypoints/aidp/stage.ipynb) | STAGE startup and `CUSTOM_FEE_TRANSFORM` registration |
| [datasets/fee/samples](datasets/fee/samples/) | Synthetic input and expected output |
| [datasets/fee/tests](datasets/fee/tests/) / [tests](tests/) | Dataset, transformation, launcher and packaging checks |
| [scripts/package_release.py](scripts/package_release.py) | Assemble a reviewed release |

Review the DEV/STAGE/PROD namespaces, buckets, ADW owners and output prefix in
the YAML. Supplied values are illustrative. Use a new metadata `release_version`
and destination when the example's `1.0` already exists. Software versions and
metadata release versions are independent.

## Prepare OCI and the databases

Install the paired utility wheels and `provider-dmi==1.0` on the selected runtime.
Use its platform-provided Spark/Java and restart Python sessions after replacing
same-version wheels. Configure both [database connections](../../../common-utilities/framework/REFERENCE.md#separate-atp-and-adw-connections):
`MDPF_DB_*` for ATP, `MDPF_MAIN_DB_*` for ADW. Store credentials through the approved
secret mechanism. Both are required for execution; only MAIN opens ADW.

A DBA completes [fresh ATP installation](../../../common-utilities/framework/README.md#fresh-atp-installation)
once. That creates the control schemas, eight sequences and the `MDPF_RUNTIME`
application account. Keep metadata deployment/activation in an ATP ADMIN session.
Provision the ADW owner and business-table access separately; use an ADW runtime
login, not the ATP account as a fallback.

SDK access and Spark bucket access are separate. Configure both before generation;
SDK access alone does not let Spark read a sample. See [OCI permissions](../../../common-utilities/framework/OPERATIONS.md#oci-permissions).

## Upload and generate

This example starts directly from the provider YAML. The optional bulk builder
is a different starting point; you do not need it for this walkthrough.

1. Upload `datasets/fee/onboarding.yaml` to this illustrative input location:
   `oci://mdpf-dev-artifacts@devns/onboarding/providers/dmi/fee/1.0/input/onboarding.yaml`.
2. Upload `fee_input.csv` and `fee_output.csv` from `datasets/fee/samples/` into
   that input prefix's `samples/` folder. This preserves the YAML's relative references.
3. In the prepared OCI Spark notebook, generate:

```python
from mdpf_onboarding.onboard import generate

CONFIG = 'oci://mdpf-dev-artifacts@devns/onboarding/providers/dmi/fee/1.0/input/onboarding.yaml'
metadata_sql_uri = generate(CONFIG, spark=spark)
print(metadata_sql_uri)
```

Replace the URI and reviewed bindings for your environment. Generation reads the
two CSV samples against the explicit schema; the actual landing delivery is still
Parquet. No binary Parquet sample is required for this example.

Expect three artifacts under the separate
`onboarding/providers/dmi/fee/1.0/generated/` prefix:

| Artifact | Purpose |
|---|---|
| `dmi_fee.yaml` | Complete reusable configuration |
| `dmi_fee_metadata_draft.sql` | Create a DRAFT release in ATP |
| `dmi_fee_main_ddl.sql` | Reviewed MAIN table proposal for ADW |

Download and review all three. Generation does not contact Oracle or deploy SQL.
The input YAML and samples stay in source; the provider wheel contains Python code.

## Deploy and activate

**ADW session:** the DBA reviews the target owner, business types, capacity, audit
columns, keys and runtime grants. In SQLcl/SQL*Plus, from the downloaded directory:

```sql
VARIABLE target_env VARCHAR2(10)
EXEC :target_env := 'DEV';
@dmi_fee_main_ddl.sql
```

For an existing target, review the proposal against its real schema instead of
rerunning CREATE. Generated DDL does not add target keys or grants. Review the
[ADW target notes](../../../common-utilities/generator/REFERENCE.md#dmi_fee-contract-and-bootstrap-replacement).
Oracle DDL commits independently.

**ATP ADMIN session:** deploy only the metadata SQL here:

```sql
VARIABLE target_env VARCHAR2(10)
EXEC :target_env := 'DEV';
@dmi_fee_metadata_draft.sql
SELECT config_release_id, release_version, release_status
FROM METADATA.CONFIG_RELEASE WHERE pipeline_code='DMI_FEE';
```

Expect the new release to be DRAFT. With both database settings available, run
the optional read-only target check from notebook Python:

```python
from mdpf_runtime.db import OracleDb
from mdpf_onboarding.oracle_gate import verify_main_targets

atp = OracleDb()
try:
    print(verify_main_targets(atp, pipeline_code='DMI_FEE', release_version='1.0'))
finally:
    atp.close()
```

For the unchanged DEV bindings, expect `['DMI_MAIN_DEV.DMI_FEE']`. This checks
visible target compatibility, not every grant or live transaction behavior.

After approval, activate in the **ATP** deployment session. This initial example
uses metadata version `1.0`; adapt it to the version you reviewed:

```sql
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
VARIABLE release_id NUMBER
BEGIN
  SELECT config_release_id INTO :release_id FROM METADATA.CONFIG_RELEASE
   WHERE pipeline_code='DMI_FEE' AND release_version='1.0';
END;
/
UPDATE METADATA.CONFIG_RELEASE SET release_status='APPROVED'
 WHERE config_release_id=:release_id AND release_status='DRAFT';
UPDATE METADATA.CONFIG_RELEASE SET release_status='RETIRED', effective_to=SYSTIMESTAMP
 WHERE pipeline_code='DMI_FEE' AND release_status='ACTIVE'
   AND config_release_id<>:release_id;
UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE'
 WHERE config_release_id=:release_id AND release_status='APPROVED';
COMMIT;
```

Expect exactly one ACTIVE release for DMI_FEE. Retire a previous ACTIVE and
activate its replacement in the same transaction. Review in-flight batches first;
they retain their original metadata release. Approved start dates are frozen.

## Deliver the Parquet source

For `cycle_date=2026-10-15`, place **one Parquet object** at the configured DEV path:

```text
oci://dev-landing@devns/dmi/inbound/fee/ingest_date=20261015/fee_20261015.parquet
```

IDMC owns upstream acquisition/conversion. If the prepared demo has no delivery
yet, create Parquet parts from the uploaded input CSV using Spark:

```python
from mdpf_onboarding.schema_discovery import read_sample

sample_uri = CONFIG.rsplit('/', 1)[0] + '/samples/fee_input.csv'
demo_parts = 'oci://dev-raw@devns/dmi/demo/fee_20261015_parts'
read_sample(spark, sample_uri).write.mode('errorifexists').parquet(demo_parts)
```

Use a new scratch prefix and reviewed bucket bindings. This requires Spark write
access to that scratch location. In OCI Object Storage, copy/upload the actual
`part-*.parquet` object from that folder to the exact landing key above; the person
preparing the demo needs landing write access. Do not copy the folder or `_SUCCESS`
marker as the delivery. The CSVs used for onboarding do not create the daily
landing object automatically.

RAW/STAGE outputs are Spark folders ending in `.parquet`, containing part files:
`dmi/fee/ingest_date=20261015/batch_id=<batch_id>/fee_20261015/` in their
respective buckets. The date comes from the batch cycle date, not the worker clock.

## Run the three tasks

Use one platform for the workflow. Select these task entry points:

| Task | Task code | Entry point |
|---|---|---|
| RAW | `DMI_FEE_RAW_LOAD` | Shared `framework/entrypoints/<platform>/raw.*` |
| STAGE | `DMI_FEE_STAGE_LOAD` | Provider `entrypoints/<platform>/stage.*` |
| MAIN | `DMI_FEE_MAIN_LOAD` | Shared `framework/entrypoints/<platform>/main.*` |

Use `.py` under `dataflow` or `.ipynb` under `aidp`. The provider STAGE launcher
imports the installed `provider_dmi` wheel and registers `CUSTOM_FEE_TRANSFORM`.
It returns `DMI_FEE_FEE_STAGE`. The function has no task-context restriction and
can be reused with compatible frames/parameters. Shared launchers cannot execute
this custom STAGE plan without registration.

Publish the selected script/notebook through the [manual platform handoff](../../../common-utilities/README.md#deployment-handoff).
Set dependencies RAW → STAGE → MAIN, each on predecessor success. Configure retries
in the scheduler; preserve the workflow key and supply a new attempt identity.

**Data Flow / ActiveBatch**

- Shared RAW/MAIN scripts require `--pipeline-code DMI_FEE`. Their task names default
  from the layer; use `--task-code` only for a reviewed override.
- The fixed provider STAGE script takes no pipeline/task selection flags.
- Pass one stable `--execution-key` across all tasks. RAW also needs
  `--cycle-date 2026-10-15` and `--execution-mode MANUAL` or `SCHEDULED`.
- Every actual Data Flow attempt needs its real OCID via `DATAFLOW_RUN_ID` or
  `--run-id`. Do not invent run IDs. Downstream tasks omit cycle/mode overrides.

**AIDP**

- Set `pipeline_code=DMI_FEE` on shared RAW/MAIN notebooks. Provider STAGE fixes its task.
- Bind resolved `job_run_id`, `task_run_id` and positive `execution_count` for every task.
- RAW needs cycle date and mode. Downstream tasks reuse them from the batch.
- A single job defaults to `AIDP:<job_run_id>` as its workflow key. Separate phase
  jobs must share a resolved `workflow_execution_key`.

For delayed processing and failure handling, use [operations](../../../common-utilities/framework/OPERATIONS.md#two-phase-scheduling).
A failed MAIN requires operator review before retry; a new workflow key is not recovery.

## Verify the result

**ATP session:**

```sql
SET DEFINE ON
ACCEPT inspected_batch NUMBER PROMPT 'Enter the printed batch ID: '
VARIABLE batch_id NUMBER
EXEC :batch_id := &inspected_batch;
SELECT batch_id, config_release_id, execution_key, status
FROM RUNTIME.BATCH WHERE pipeline_code='DMI_FEE' ORDER BY batch_id;
SELECT task_run_id, attempt_number, status, input_count, output_count
FROM RUNTIME.TASK_RUN WHERE batch_id=:batch_id ORDER BY task_run_id;
SELECT result_status, expected_value, actual_value
FROM RUNTIME.POLICY_RESULT WHERE task_run_id IN
 (SELECT task_run_id FROM RUNTIME.TASK_RUN WHERE batch_id=:batch_id);
```

Bind `:batch_id` to the printed internal batch ID. Use the same value in a separate
**ADW session**:

```sql
SET DEFINE ON
ACCEPT inspected_batch NUMBER PROMPT 'Enter the same printed batch ID: '
VARIABLE batch_id NUMBER
EXEC :batch_id := &inspected_batch;
SELECT COUNT(*) rows_loaded, SUM(fee_tran_am) fee_total
FROM DMI_MAIN_DEV.DMI_FEE WHERE batch_id=:batch_id;
SELECT ln_no, client_no, created_at, updated_at
FROM DMI_MAIN_DEV.DMI_FEE WHERE batch_id=:batch_id ORDER BY row_number;
```

For the supplied two-row data: all three attempts complete with two input/output
rows; the batch completes; all four policy results pass. ADW has two rows, total
FEE_TRAN_AM **15.25**, and CLIENT_NO values `C001`/`C002` with spaces trimmed.
RAW/STAGE folders and framework audit fields are populated. After RAW alone,
RUNNING is expected if later tasks have not run yet. The [diagnostic script](../../../common-utilities/framework/sql/03_inspect.sql)
provides further checks; copy its commented ADW queries into an ADW session.

## Assemble a release

From `data-pipelines/providers/dmi/`, after review, download the three generated
artifacts into a local directory outside source control:

```bash
python -m pip wheel --no-deps --wheel-dir dist .
GENERATED_DIR="/path/to/reviewed/generated"
FRAMEWORK_BUNDLE="/path/to/approved/mdpf_runtime-1.0-release.zip"
FRAMEWORK_SHA256="REPLACE_WITH_APPROVED_64_CHARACTER_SHA256"
python scripts/package_release.py \
  --generated-dir "$GENERATED_DIR" \
  --framework-bundle "$FRAMEWORK_BUNDLE" \
  --framework-sha256 "$FRAMEWORK_SHA256" \
  --output dist/review/provider_dmi-1.0-release.zip
```

Use your approved bundle/checksum and a new output path. Keep one provider wheel
in `dist/`. The packager checks dependency versions, artifact hashes, generated
business metadata, deterministic SQL and provider source/wheel consistency. If
DDL generation used a baseline, pass that same explicit-schema YAML with
`--baseline-config /path/to/baseline.yaml`. Altered/stale SQL and existing output
ZIPs are rejected. Obtain the trusted checksum from the approved release record.

The release contains both runtime wheels, six common and two provider launchers,
input YAML/samples, generated artifacts and a manifest. It is not a Data Flow
dependency archive. Packages/configuration are deployed separately through the
platform handoff. The included sample bundle is for review, not proof of live deployment.
CI/CD, registry publishing and automated job creation remain deferred.
