"""Production-owned DMI_FEE transformation, shared by AIDP and Data Flow callers."""
from pyspark.sql import functions as F


def custom_fee_transform(frames, context, params):
    """Trim the configured CLIENT_NO column and return the generated STAGE key.

    The pinned task plan supplies {"column": "CLIENT_NO"}. DIRECT_MAP, DQ and
    persistence remain framework steps after this handler. Input frames/context
    are not mutated. Missing inputs/parameters and Spark errors propagate.
    """
    column = params["column"]
    df = frames["DMI_FEE_FEE_RAW"]
    return {"DMI_FEE_FEE_STAGE": df.withColumn(column, F.trim(F.col(column)))}
