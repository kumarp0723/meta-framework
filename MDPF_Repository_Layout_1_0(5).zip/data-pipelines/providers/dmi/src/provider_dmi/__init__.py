"""DMI provider business code. The framework owns execution and persistence."""

__version__ = "1.0"
