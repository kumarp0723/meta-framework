# DMI / FEE

The canonical production input configuration is [onboarding.yaml](onboarding.yaml).
It preserves the reviewed 12-column DMI_FEE schema, trim step and four policies.
Review its illustrative infrastructure values before generating deployment SQL.

`samples/` contains synthetic input and expected output. `tests/` pins this business
contract and exercises generation/execution using local test adapters. The Python
handler lives at `src/provider_dmi/fee.py` relative to the provider root.

See the [provider instructions](../../README.md) for setup, packaging and both
platform entry APIs. Utility examples remain independent reference fixtures.
