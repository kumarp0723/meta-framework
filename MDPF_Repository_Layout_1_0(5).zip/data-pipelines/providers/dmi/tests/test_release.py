"""Release assembly validates contracts/provenance and preserves immutable outputs."""
import hashlib
import json
import os
from pathlib import Path
import runpy
import zipfile

import pytest
import yaml

from mdpf_onboarding.config import main_ddl_uri, output_uri, sample_uri, yaml_uri
from mdpf_onboarding.sql_renderer import render_main_ddl, render_sql
from mdpf_onboarding.onboard import complete_config


ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def release_args():
    path = os.environ.get('MDPF_FRAMEWORK_BUNDLE')
    if not path:
        pytest.fail('Required packaging artifact missing: set MDPF_FRAMEWORK_BUNDLE to the approved Framework ZIP.')
    bundle = Path(path)
    return dict(framework_bundle=bundle, framework_sha256=hashlib.sha256(bundle.read_bytes()).hexdigest())


@pytest.fixture
def generated(fee_dir, fee_config, fee_model, tmp_path):
    original = (fee_dir / 'onboarding.yaml').read_bytes()
    input_uri = 'oci://mdpf-dev-artifacts@devns/onboarding/providers/dmi/fee/1.0/input/onboarding.yaml'
    samples = {item['sample_csv']: sample_uri(input_uri, item['sample_csv'])
               for item in fee_config['inputs'] + fee_config['outputs']}
    complete = yaml.safe_dump(complete_config(fee_model, samples), sort_keys=False, allow_unicode=True).encode()
    directory = tmp_path / 'generated'
    directory.mkdir()
    for uri, data in ((yaml_uri(fee_config), complete),
                      (output_uri(fee_config), render_sql(fee_model, original).encode()),
                      (main_ddl_uri(fee_config), render_main_ddl(fee_model, original).encode())):
        (directory / uri.rsplit('/', 1)[1]).write_bytes(data)
    return directory


def test_release_contains_all_assets_and_matching_hashes(generated, tmp_path, release_args):
    build = runpy.run_path(str(ROOT / 'scripts/package_release.py'))['build_release']
    output = build(generated, tmp_path / 'release.zip', **release_args)
    with zipfile.ZipFile(output) as archive:
        assert archive.testzip() is None
        manifest = json.loads(archive.read('release-manifest.json'))
        assert manifest['dependencies'] == {'mdpf-runtime': '1.0', 'provider-dmi': '1.0'}
        assert manifest['metadata_release'] == '1.0'
        for task in manifest['tasks']:
            owner = 'provider' if task['task_code'] == 'DMI_FEE_STAGE_LOAD' else 'common'
            assert all(name.startswith(owner + '/') for name in task['entrypoints'].values())
        assert {entry['path'] for entry in manifest['artifacts']} == set(archive.namelist()) - {'release-manifest.json'}
        assert len([p for p in archive.namelist() if p.endswith(('.py', '.ipynb'))]) == 8
        for entry in manifest['artifacts']:
            assert hashlib.sha256(archive.read(entry['path'])).hexdigest() == entry['sha256']
    original = output.read_bytes()
    with pytest.raises(FileExistsError):
        build(generated, output, **release_args)
    assert output.read_bytes() == original


@pytest.mark.parametrize('kind', ['metadata', 'ddl'])
def test_release_rejects_mismatched_generated_sql(generated, tmp_path, fee_config, kind, release_args):
    uri = output_uri(fee_config) if kind == 'metadata' else main_ddl_uri(fee_config)
    path = generated / uri.rsplit('/', 1)[1]
    path.write_text(path.read_text().replace('DMI_FEE', 'WRONG_TABLE'))
    build = runpy.run_path(str(ROOT / 'scripts/package_release.py'))['build_release']
    output = tmp_path / 'release.zip'
    with pytest.raises(ValueError, match='generated SQL'):
        build(generated, output, **release_args)
    assert not output.exists()


def test_release_rejects_wrong_generated_contract(generated, tmp_path, fee_config, release_args):
    path = generated / yaml_uri(fee_config).rsplit('/', 1)[1]
    config = yaml.safe_load(path.read_text())
    config['outputs'][0]['target_table'] = 'WRONG_TABLE'
    path.write_text(yaml.safe_dump(config))
    build = runpy.run_path(str(ROOT / 'scripts/package_release.py'))['build_release']
    output = tmp_path / 'release.zip'
    with pytest.raises(ValueError, match='business contract'):
        build(generated, output, **release_args)
    assert not output.exists()


def test_release_rejects_unapproved_bundle_hash(generated, tmp_path, release_args):
    build = runpy.run_path(str(ROOT / 'scripts/package_release.py'))['build_release']
    release_args['framework_sha256'] = '0' * 64
    with pytest.raises(ValueError, match='approved pin'):
        build(generated, tmp_path / 'release.zip', **release_args)
    assert not (tmp_path / 'release.zip').exists()


@pytest.mark.parametrize('change', ['artifact', 'version'])
def test_release_rejects_tampered_framework_bundle(generated, tmp_path, release_args, change):
    with zipfile.ZipFile(release_args['framework_bundle']) as archive:
        contents = {name: archive.read(name) for name in archive.namelist()}
    if change == 'artifact':
        contents['entrypoints/dataflow/raw.py'] += b'\n# Tampered\n'
        match = 'artifact SHA256'
    else:
        manifest = json.loads(contents['release-manifest.json'])
        manifest['version'] = '999.0'
        contents['release-manifest.json'] = json.dumps(manifest).encode()
        match = 'dependency pin'
    path = tmp_path / 'tampered.zip'
    with zipfile.ZipFile(path, 'w') as archive:
        for name, data in contents.items(): archive.writestr(name, data)
    release_args = dict(framework_bundle=path, framework_sha256=hashlib.sha256(path.read_bytes()).hexdigest())
    build = runpy.run_path(str(ROOT / 'scripts/package_release.py'))['build_release']
    with pytest.raises(ValueError, match=match):
        build(generated, tmp_path / 'release.zip', **release_args)
    assert not (tmp_path / 'release.zip').exists()


def test_release_accepts_reviewed_comparison_ddl(generated, tmp_path, fee_config, fee_model, release_args):
    from copy import deepcopy
    from mdpf_onboarding.metadata_generator import contract_model
    previous=deepcopy(fee_config)
    previous['pipeline']['release_version']='0.9'
    baseline=tmp_path/'baseline.yaml';baseline.write_text(yaml.safe_dump(previous))
    path=generated/main_ddl_uri(fee_config).rsplit('/',1)[1]
    path.write_text(render_main_ddl(fee_model,b'input',baseline=contract_model(previous)))
    build=runpy.run_path(str(ROOT/'scripts/package_release.py'))['build_release']
    with pytest.raises(ValueError,match='generated SQL'):
        build(generated,tmp_path/'without-baseline.zip',**release_args)
    assert build(generated,tmp_path/'comparison.zip',baseline_config=baseline,**release_args).is_file()
