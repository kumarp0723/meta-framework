"""Business transformation checks using the installed provider module."""
import pytest

from mdpf_runtime.schema import convert_frame
from mdpf_onboarding.schema_discovery import explicit_columns, read_sample, validate_sample
from provider_dmi.fee import custom_fee_transform


RAW, STAGE = 'DMI_FEE_FEE_RAW', 'DMI_FEE_FEE_STAGE'


def test_trim_preserves_nulls_other_columns_and_input(spark):
    raw = spark.createDataFrame([(1, '  C001  '), (2, None), (3, '   '), (4, 'C 002')],
                               'ID int, CLIENT_NO string')
    frames, context = {RAW: raw}, {'batch_id': 17, 'task_code': 'ANOTHER_PROCESS'}
    result = custom_fee_transform(frames, context, {'column': 'CLIENT_NO'})
    assert list(result) == [STAGE]
    assert [tuple(r) for r in result[STAGE].orderBy('ID').collect()] == [
        (1, 'C001'), (2, None), (3, ''), (4, 'C 002')]
    assert raw.first().CLIENT_NO == '  C001  '
    assert list(frames) == [RAW] and context == {'batch_id': 17, 'task_code': 'ANOTHER_PROCESS'}


def test_provider_samples_match_transformed_typed_contract(spark, fee_config, fee_dir):
    source, target = fee_config['inputs'][0], fee_config['outputs'][0]
    raw = read_sample(spark, str(fee_dir / source['sample_csv']))
    expected = read_sample(spark, str(fee_dir / target['sample_csv']))
    source_columns = explicit_columns(source['columns'], source=True)
    target_columns = explicit_columns(target['columns'], source=False)
    validate_sample(raw, source_columns, source=True)
    validate_sample(expected, target_columns, source=False)
    transformed = custom_fee_transform({RAW: raw}, {}, {'column': 'CLIENT_NO'})[STAGE]
    actual = convert_frame(transformed, target_columns).orderBy('LN_NO').collect()
    assert actual == convert_frame(expected, target_columns).orderBy('LN_NO').collect()
    assert str(actual[0].FEE_TRAN_AM) == '12.50'
    assert str(actual[0].MSP_CYCLE_DATE) == '2026-10-15'
    assert raw.first().CLIENT_NO == '  C001  '


@pytest.mark.parametrize('frames,params', [({}, {'column': 'CLIENT_NO'}), ({}, {})])
def test_missing_required_input_or_parameter_propagates(frames, params):
    with pytest.raises(KeyError):
        custom_fee_transform(frames, {}, params)
