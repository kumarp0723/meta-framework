# common-utilities

Two runtime packages support every provider. One development package supports local tests:

| Folder | Distribution / import | Purpose |
|---|---|---|
| [framework](framework/README.md) | `mdpf-runtime` / `mdpf_runtime` | Execute metadata-selected tasks and record their history |
| `test-support/` | `mdpf-test-support` / `mdpf_test_support` | Local test adapters and the pinned SQL fixture; development only |
| [generator](generator/README.md) | `mdpf-onboarding` / `mdpf_onboarding` | Build input YAML, then generate complete YAML and SQL |

Python imports use `mdpf_runtime` and `mdpf_onboarding`; the install names are
`mdpf-runtime` and `mdpf-onboarding` (hyphens and underscores normalize for pip).
When replacing the earlier wheel, update external `from mdpf...` imports to
`from mdpf_runtime...`, uninstall the old distribution with `python -m pip uninstall mdpf`,
install the paired wheels and restart Python sessions. There is no old-import alias.
All versions remain `1.0`.

Start with the [developer guide](framework/DEVELOPER_GUIDE.md#local-setup-and-checks).
Keep these sibling directories in this repository. Provider production code belongs
in [data-pipelines](../data-pipelines/README.md); examples here remain reference fixtures.

## Shared launchers

Each launcher runs one task. The scheduler orders the tasks and controls retries.
The shared launchers register built-in steps only; custom plans use provider launchers.

| Task | Data Flow script | AIDP notebook |
|---|---|---|
| RAW | [raw.py](framework/entrypoints/dataflow/raw.py) | [raw.ipynb](framework/entrypoints/aidp/raw.ipynb) |
| STAGE | [stage.py](framework/entrypoints/dataflow/stage.py) | [stage.ipynb](framework/entrypoints/aidp/stage.ipynb) |
| MAIN | [main.py](framework/entrypoints/dataflow/main.py) | [main.ipynb](framework/entrypoints/aidp/main.ipynb) |

Data Flow shared scripts require `--pipeline-code`; `--task-code` overrides the
usual `<PIPELINE>_<RAW|STAGE|MAIN>_LOAD` name. AIDP uses `pipeline_code` and
`task_code` widgets. Remaining workflow/date/attempt settings go to the platform
adapter. See [platform arguments](framework/REFERENCE.md#run-from-data-flow--activebatch)
and [AIDP bindings](framework/REFERENCE.md#run-the-supplied-dmi-example).

Launchers have no DMI defaults or dynamic imports from YAML. A task needing a custom
handler fails before reading data if that handler is not registered. Install the
provider wheel for provider-owned launchers; keep business logic out of notebooks.

## Framework artifact bundle

From `common-utilities/`, after building a single Framework wheel in `framework/dist/`:

```bash
python framework/scripts/package_release.py --output framework/dist/review/mdpf_runtime-1.0-release.zip
```

Use a new output path on each run. The script checks source/wheel consistency and
creates a ZIP with the wheel, six launchers and `release-manifest.json`. It prints
the ZIP checksum. Keep the approved ZIP and trusted checksum together; provider
packaging needs both. Registry publication remains future work.

The distribution includes wheels and bundles; a fresh Git clone does not. Build
commands and tests are in the [developer guide](framework/DEVELOPER_GUIDE.md#local-setup-and-checks).
Keep generated outputs outside source control. The test-support wheel is installed
only for development and never included in platform release bundles. The package checksum files describe
the distribution, not a required Git inventory.

## Deployment handoff

Extract the selected release ZIP. Its manifest lists the task entry points and
wheels. Install dependencies using the platform's supported method and publish the
entry point to a versioned execution location:

| Platform | Manual handoff |
|---|---|
| Data Flow | Upload the `.py` script to OCI Object Storage; use that URI as the application's `file_uri`. Prepare a compatible dependency archive for `archive_uri`. Configure arguments and scheduler dependencies. |
| AIDP | Import the `.ipynb` into a versioned workspace path. Select it as the notebook task source, install packages on its compute, and bind task parameters. |

For example, publish a RAW script as
`oci://artifacts@namespace/mdpf/1.0/entrypoints/dataflow/raw.py` or import its
notebook as `/Shared/mdpf/1.0/raw.ipynb`. Replace those illustrative locations.
A repository file path is not a platform execution location. No extra wrapper is
needed; publish the supplied launcher itself. Pin the launcher version with its wheel.

The release ZIP is an artifact container, not a Data Flow dependency archive or a
job-creation request. Review [create_run.json](framework/examples/dataflow/create_run.json)
and [runtime dependencies](framework/examples/dataflow/requirements.txt) as examples.
The [DMI_FEE walkthrough](../data-pipelines/providers/dmi/README.md#run-the-three-tasks)
shows the shared RAW/MAIN and custom STAGE selection.

References: [Data Flow application fields](https://docs.oracle.com/en-us/iaas/tools/python/latest/api/data_flow/models/oci.data_flow.models.CreateApplicationDetails.html),
[dependency archives](https://docs.oracle.com/en-us/iaas/Content/data-flow/using/third-party-provide-archive.htm),
[AIDP notebook tasks](https://docs.oracle.com/en/cloud/paas/ai-data-platform/aidug/configure-tasks.html).
