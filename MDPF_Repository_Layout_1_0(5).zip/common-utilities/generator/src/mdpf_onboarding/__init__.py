"""OCI onboarding for MDPF 1.0 Spark tasks and Oracle metadata."""
import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())
__version__ = '1.0'
