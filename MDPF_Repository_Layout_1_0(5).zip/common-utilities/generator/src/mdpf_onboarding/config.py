"""Strict YAML/configuration and OCI object URI validation; no external I/O."""
import re
import json
from copy import deepcopy

import yaml

from mdpf_runtime.storage import object_address
from .schema_discovery import explicit_columns, validate_overrides
from .metadata_generator import dataset_codes, physical_locations, relationship, resolve_steps


class UniqueLoader(yaml.SafeLoader):
    pass


def _mapping(loader, node):
    result = {}
    for key, value in node.value:
        name = loader.construct_object(key, deep=True)
        if not isinstance(name, str) or name in result:
            raise ValueError(f'YAML keys must be unique strings: {name!r}')
        result[name] = loader.construct_object(value, deep=True)
    return result


UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)


def keys(obj, required, optional, label):
    if not isinstance(obj, dict) or set(required)-set(obj) or set(obj)-set(required)-set(optional):
        raise ValueError(f'{label}: required keys {sorted(required)}; optional keys {sorted(optional)}.')


def text(value, label, limit):
    if not isinstance(value, str) or not value.strip() or len(value.encode('utf-8')) > limit or any(ord(c)<32 for c in value):
        raise ValueError(f'{label} must be nonempty text, at most {limit} UTF-8 bytes, without control characters.')
    return value


def validate_upstream(value):
    """Check per-feed IDMC source information, without external I/O.

    Additional source-specific keys remain ordinary JSON. connection_reference
    names an existing IDMC connection; credentials must stay outside metadata.
    """
    if not isinstance(value, dict) or not value:
        raise ValueError('upstream_config must be a nonempty JSON mapping when supplied.')
    for name in ('type', 'connection_reference'):
        text(value.get(name), 'upstream_config.'+name, 200)
    for name in ('directory', 'file_pattern', 'object_name', 'original_oci_uri'):
        if name in value:
            text(value[name], 'upstream_config.'+name, 2000)
    try:
        json.dumps(value, allow_nan=False, sort_keys=True)
    except (TypeError, ValueError) as exc:
        raise ValueError('upstream_config must contain JSON-compatible values.') from exc
    return value


def expand_parameters(config):
    """Copy configuration while expanding only pipeline identity and samples_root tokens.

    Reject unresolved/recursive references and expanded key collisions. No I/O."""
    if not isinstance(config, dict):
        raise ValueError('config must be a mapping.')
    pipeline = config.get('pipeline', {})
    values = {f'pipeline.{k}': pipeline.get(k) for k in ('code', 'release_version')} if isinstance(pipeline, dict) else {}
    token = re.compile(r'\$\{([^{}]+)\}')
    def string(value):
        def replace(match):
            name = match[1]
            replacement = values.get(name)
            if not isinstance(replacement, str) or '${' in replacement:
                raise ValueError(f'Unknown or recursive parameter reference: {name}')
            return replacement
        result = token.sub(replace, value)
        if '${' in result:
            raise ValueError(f'Unresolved parameter reference: {value}')
        return result
    if 'samples_root' in config:
        if not isinstance(config['samples_root'], str):
            raise ValueError('samples_root must be a full OCI prefix.')
        values['samples_root'] = string(config['samples_root'])
    def walk(value):
        if isinstance(value, str):
            return string(value)
        if isinstance(value, list):
            return [walk(v) for v in value]
        if isinstance(value, dict):
            result = {}
            for key, item in value.items():
                name = string(key) if isinstance(key, str) else key
                if name in result:
                    raise ValueError(f'Parameter expansion creates duplicate key: {name}')
                result[name] = walk(item)
            return result
        return value
    return walk(config)


def validate_config(config):
    """Return an expanded/normalized copy of the supported onboarding YAML contract.

    Check all environments, generated locations, task plans, DQ and output URI
    shapes before sample I/O. Unknown keys and invalid combinations raise ValueError.
    This validates configuration syntax/contracts, not bucket existence or access."""
    from mdpf_runtime.schema import sql_identifier
    c = expand_parameters(config)
    if 'template_status' in c:
        raise ValueError('Incomplete template: fill placeholders and samples, remove template_status, then generate again.')
    keys(c, {'pipeline','inputs','outputs','storage','environments','sql_output'}, {'inference','task_overrides','created_by','dq_rules','samples_root'}, 'config')
    if 'samples_root' in c:
        oci_uri(c['samples_root'].rstrip('/'))
    keys(c['pipeline'], {'code','name','release_version'}, {'direction'}, 'pipeline')
    if c['pipeline'].setdefault('direction', 'INBOUND') not in ('INBOUND', 'OUTBOUND'):
        raise ValueError('pipeline.direction must be INBOUND or OUTBOUND.')
    for field, length in [('code',100),('name',200),('release_version',50)]:
        text(c['pipeline'][field], 'pipeline.'+field, length)
    sql_identifier(c['pipeline']['code'])
    for role in ('inputs','outputs'):
        if not isinstance(c[role], list) or not c[role]:
            raise ValueError(f'{role} must be a nonempty list.')
        seen = set()
        for item in c[role]:
            required = {'code','sample_csv'} | ({'source_system','landing_key_prefix','file_name'} if role=='inputs' else {'target_table'})
            optional = {'columns'} | ({'bucket_ref', 'source_format', 'upstream_config'} if role=='inputs' else set())
            keys(item, required, optional, role)
            sql_identifier(text(item['code'], role+'.code', 100))
            if item['code'] in seen:
                raise ValueError(f'Duplicate {role} code: {item["code"]}')
            seen.add(item['code'])
            text(item['sample_csv'], 'sample_csv', 2000)
            if role == 'inputs' and item.setdefault('source_format', 'PARQUET') != 'PARQUET':
                raise ValueError('Landing source_format must be PARQUET.')
            if 'columns' in item:
                explicit_columns(item['columns'], source=False)
            if role=='inputs':
                if 'upstream_config' in item:
                    validate_upstream(item['upstream_config'])
                text(item['source_system'], 'source_system', 200)
                item.setdefault('bucket_ref','landing')
                text(item['bucket_ref'], 'bucket_ref', 100)
            else:
                sql_identifier(item['target_table'])
    shape = relationship(c)
    roots = {(i['source_system'],i['bucket_ref'],i['landing_key_prefix']) for i in c['inputs']}
    if len(roots) != 1:
        raise ValueError('Combined RAW requires one source_system, landing bucket reference and landing_key_prefix.')
    keys(c['storage'], {'raw_key_prefix','stage_key_prefix','raw_path_template','stage_path_template'}, {'quarantine_key_prefix'}, 'storage')
    keys(c['environments'], {'DEV','STAGE','PROD'}, set(), 'environments')
    for name, env in c['environments'].items():
        keys(env, {'namespace','buckets','oracle_main_owner'}, set(), name)
        sql_identifier(env['oracle_main_owner'])
        if not isinstance(env['buckets'], dict) or not {'landing','raw','stage'} <= set(env['buckets']):
            raise ValueError(f'{name} requires landing/raw/stage bucket references.')
    inf = c.setdefault('inference', {})
    keys(inf, set(), {'varchar_growth_percent','default_nullable','column_overrides'}, 'inference')
    growth = inf.setdefault('varchar_growth_percent',25)
    if isinstance(growth,bool) or not isinstance(growth,(int,float)) or not 0<=growth<=1000:
        raise ValueError('varchar_growth_percent must be between 0 and 1000.')
    if inf.setdefault('default_nullable','Y') not in ('Y','N'):
        raise ValueError('default_nullable must be Y or N.')
    overrides = inf.setdefault('column_overrides',{})
    if not isinstance(overrides,dict) or any(not isinstance(v,dict) for v in overrides.values()):
        raise ValueError('column_overrides must map LANDING/MAIN dataset codes to column overrides.')
    codes = dataset_codes(c)
    landing_codes = {p['landing'] for p in codes['inputs']}
    allowed = landing_codes | {p['main'] for p in codes['outputs']}
    if set(overrides)-allowed:
        raise ValueError('Use LANDING/MAIN dataset codes for overrides; paired RAW/STAGE schemas are copied automatically.')
    for name, columns in overrides.items():
        validate_overrides(columns, source=False)
    for role, suffix in (('inputs','landing'), ('outputs','main')):
        for item, names in zip(c[role], codes[role]):
            if 'columns' in item and overrides.get(names[suffix]):
                raise ValueError('Use explicit columns or inference overrides for a dataset, not both.')
    rules = c.setdefault('dq_rules', [])
    if not isinstance(rules, list):
        raise ValueError('dq_rules must be a list.')
    stages = {n['stage'] for n in codes['outputs']}
    mains = {n['main'] for n in codes['outputs']}
    raws = {n['raw'] for n in codes['inputs']}
    seen_rules = set()
    for rule in rules:
        keys(rule, {'check'}, {'datasets','column','min','max','values','source_dataset','severity'}, 'dq_rules entry')
        count_rule = rule['check'] == 'ROW_COUNT'
        if count_rule:
            if 'column' in rule or 'datasets' not in rule:
                raise ValueError('ROW_COUNT requires explicit datasets and source_dataset; column is not allowed.')
        else:
            if 'column' not in rule:
                raise ValueError('Column DQ requires column.')
            sql_identifier(rule['column'])
            rule.setdefault('datasets', sorted(stages))
        targets = rule['datasets']
        if (not isinstance(targets, list) or not targets or
                any(not isinstance(n, str) or n not in stages | mains for n in targets) or
                len(set(targets)) != len(targets)):
            raise ValueError('dq_rules.datasets requires unique generated STAGE/MAIN dataset codes.')
        severity = rule.setdefault('severity', 'FAIL')
        if severity not in ('FAIL', 'WARN'):
            raise ValueError('DQ severity must be FAIL or WARN.')
        from mdpf_runtime.dq import validate_dq_parameters
        parameters = {k: v for k, v in rule.items() if k not in ('datasets','column','severity')}
        validate_dq_parameters(parameters)
        if 'values' in parameters:
            rule['values'] = parameters['values']
        for name in targets:
            if count_rule:
                if rule['source_dataset'] not in (raws if name in stages else stages):
                    raise ValueError('ROW_COUNT source_dataset must be an adjacent-layer input dataset.')
                if name in stages and len(raws) != 1:
                    raise ValueError('ROW_COUNT supports row-preserving mappings; joins/aggregation need a separate contract.')
                if name in mains and severity != 'FAIL':
                    raise ValueError('MAIN ROW_COUNT reconciliation cannot be WARN.')
            elif name not in stages:
                raise ValueError('Business column DQ belongs to STAGE; MAIN enforces Oracle constraints and insert reconciliation.')
            identity = (name, rule.get('column'), rule['check'])
            if identity in seen_rules:
                raise ValueError(f'Duplicate DQ rule: {identity}')
            seen_rules.add(identity)
    c.setdefault('created_by','MDPF_ONBOARD')
    text(c['created_by'],'created_by',100)
    roles = {'RAW','STAGE','MAIN'}
    task_options = c.setdefault('task_overrides',{})
    if not isinstance(task_options,dict) or set(task_options)-roles:
        raise ValueError('task_overrides keys must be RAW, STAGE or MAIN.')
    custom_roles=set()
    for role, opt in task_options.items():
        plan=resolve_steps(opt,role)
        if 'task_code' in opt:
            sql_identifier(text(opt['task_code'],'task_code',100))
        if any(kind=='CUSTOM_PYTHON' for _,kind,_ in plan):
            custom_roles.add(role)
    required_role = 'STAGE' if shape=='MANY_TO_ONE' else 'MAIN' if shape=='ONE_TO_MANY' else None
    if required_role and required_role not in custom_roles:
        raise ValueError(f'{shape} requires declared {required_role} custom steps for explicit frame combination/routing.')
    task_codes = [task_options.get(role, {}).get('task_code', f"{c['pipeline']['code']}_{role}_LOAD")
                  for role in ('RAW', 'STAGE', 'MAIN')]
    for code in task_codes:
        text(code, 'task_code', 100)
    if len(set(task_codes)) != len(task_codes):
        raise ValueError('RAW, STAGE and MAIN must use distinct task codes.')
    physical_locations(c,codes)  # Validate every environment before reading samples.
    output_uri(c)
    main_ddl_uri(c)
    yaml_uri(c)
    return c


def oci_uri(value):
    """Exact object URI only; samples and artifacts never use local path fallback."""
    text(value,'OCI URI',2000)
    namespace,bucket,key=object_address(value)
    if (not key or not all(re.fullmatch(r'[A-Za-z0-9_.-]+',s) for s in (namespace,bucket)) or
            any(c.isspace() or c in '*[]{}\\' for c in key) or
            any(p in ('','.','..') for p in key.split('/'))):
        raise ValueError('Use an exact oci://bucket@namespace/object-key without wildcards or path traversal.')
    return value


def incomplete_template(config):
    """Validate the known settings and mark missing sample/schema fields for editing.

    This is a planning artifact only. Normal generation refuses the marker. No
    sample access, Spark session, SQL, DDL or activation occurs here.
    """
    candidate = deepcopy(config)
    candidate.pop('template_status', None)
    missing = set()
    for role in ('inputs','outputs'):
        for index, item in enumerate(candidate[role]):
            sample = item.get('sample_csv')
            if not sample or '<' in sample:
                missing.add((role,index))
                item['sample_csv'] = 'oci://placeholder@placeholder/sample.csv'
            if 'columns' in item and '<' in str(item['columns']):
                del item['columns']
    candidate = validate_config(candidate)
    for role in ('inputs','outputs'):
        for index, item in enumerate(candidate[role]):
            if (role,index) in missing:
                item['sample_csv'] = '<REQUIRED_SAMPLE_URI>'
            item.setdefault('columns', [dict(column_name='<REQUIRED_COLUMN>',
                data_type='<VARCHAR2|NUMBER|DATE>',
                length_precision_scale='<REQUIRED_FOR_VARCHAR2_OR_NUMBER>',
                is_nullable='<Y|N>', is_pii='N')])
    return {'template_status':'INCOMPLETE', **candidate}


def sample_uri(config_uri, value, samples_root=None):
    """Resolve one full or YAML-relative CSV/Parquet reference to an exact OCI object URI.

    samples_root overrides the YAML directory for relative samples. Validation does
    not read the object; local paths, traversal and wildcard samples are rejected."""
    if '://' in value:
        result=value
    else:
        if value.startswith('/'):
            raise ValueError('Sample paths must be relative to the OCI YAML, or full OCI URIs.')
        result=(samples_root.rstrip('/') if samples_root else config_uri.rsplit('/',1)[0])+'/'+value
    result=oci_uri(result)
    if not result.lower().endswith(('.csv', '.parquet')):
        raise ValueError('Sample must reference one exact OCI .csv or .parquet file.')
    return result


def output_uri(config):
    out=config['sql_output']
    keys(out,{'namespace','bucket','path','filename'},
         {'overwrite','generate_main_ddl','main_ddl_filename','yaml_filename'},'sql_output')
    if not isinstance(out.setdefault('overwrite',False),bool):
        raise ValueError('sql_output.overwrite must be boolean.')
    if not isinstance(out.setdefault('generate_main_ddl',True),bool):
        raise ValueError('sql_output.generate_main_ddl must be boolean.')
    for name in ('namespace','bucket','path','filename'):
        text(out[name],'sql_output.'+name,1000)
    if out['path'] != out['path'].strip('/'):
        raise ValueError('sql_output.path must not have surrounding slashes.')
    if '/' in out['filename'] or not out['filename'].lower().endswith('.sql'):
        raise ValueError('sql_output.filename must be a .sql filename without directories.')
    return oci_uri(f"oci://{out['bucket']}@{out['namespace']}/{out['path']}/{out['filename']}")


def main_ddl_uri(config):
    prefix,filename=output_uri(config).rsplit('/',1)
    stem=re.sub(r'_metadata(?:_draft)?$','',filename[:-4])
    filename=config['sql_output'].get('main_ddl_filename',stem+'_main_ddl.sql')
    return artifact_uri(prefix,filename,('.sql',))


def artifact_uri(prefix, filename, suffixes):
    if not isinstance(filename,str) or '/' in filename or not filename.lower().endswith(suffixes):
        raise ValueError(f'Artifact filename must end with {suffixes}, without directories.')
    return oci_uri(prefix+'/'+filename)


def yaml_uri(config):
    prefix=output_uri(config).rsplit('/',1)[0]
    return artifact_uri(prefix,config['sql_output'].get('yaml_filename',config['pipeline']['code'].lower()+'.yaml'),('.yaml','.yml'))
