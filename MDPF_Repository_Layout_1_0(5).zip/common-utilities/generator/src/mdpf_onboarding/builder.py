"""Build one onboarding input YAML from a shared OCI profile; no sample reads."""
from copy import deepcopy
import logging

import yaml

from mdpf_runtime.storage import object_address
from .config import UniqueLoader, keys, oci_uri, sample_uri, text, validate_config, incomplete_template
from .onboard import object_client

logger = logging.getLogger(__name__)

def load_profile(profile_uri, *, client=None):
    """Read one OCI profile and validate shared settings using a representative config.

    Return the profile dictionary. No sample contents are read and no YAML is saved;
    a supplied client is reused, otherwise Resource Principal authentication is used."""
    profile_uri = oci_uri(profile_uri)
    if not profile_uri.lower().endswith(('.yaml', '.yml')):
        raise ValueError('Profile must be an OCI .yaml or .yml object.')
    client = client if client is not None else object_client()
    data = client.get_object(*object_address(profile_uri)).data.content
    profile = yaml.load(data.decode('utf-8-sig'), Loader=UniqueLoader)
    keys(profile, {'samples_root', 'artifacts_root', 'landing_key_prefix',
                   'storage', 'environments'}, set(), 'shared profile')
    keys(profile['storage'], {'raw_key_prefix', 'stage_key_prefix'}, {'quarantine_key_prefix','raw_path_template','stage_path_template'}, 'profile.storage')
    text(profile['landing_key_prefix'], 'landing_key_prefix', 1000)
    for name, value in profile['storage'].items():
        text(value, name, 1000)
    for field in ('samples_root', 'artifacts_root'):
        if not isinstance(profile[field], str):
            raise ValueError(f'{field} must be a full OCI prefix.')
        profile[field] = oci_uri(profile[field].rstrip('/'))
    build_config(profile, pipeline_code='PROFILE_CHECK', dataset_code='DATASET',
                 source_system='PROFILE', input_sample_csv='input.csv',
                 output_sample_csv='output.csv')
    return profile


def build_config(profile, *, pipeline_code, dataset_code, source_system,
                 input_sample_csv=None, output_sample_csv=None, release_version='1.0',
                 file_name=None, target_table=None, source_format='PARQUET',
                 pipeline_direction='INBOUND', upstream_config=None, template_only=False):
    """Build and validate one input/output pipeline config from an in-memory profile.

    Use source/feed paths; copy environment settings without mutating
    the profile. Return a config dictionary. No external reads or writes occur."""
    if not isinstance(release_version, str) or '/' in release_version:
        raise ValueError('release_version must be text without directories.')
    if source_format != 'PARQUET':
        raise ValueError('Landing source_format must be PARQUET.')
    namespace, bucket, root = object_address(profile['artifacts_root'])
    source, feed = source_system.lower(), dataset_code.lower()
    prefix = f'{root}/{source}/{feed}/{release_version}'
    # Only the shared profile's source token is substituted here. Runtime date
    # and batch tokens remain intact for the framework to resolve.
    storage = {name: value.replace('{source}', source).rstrip('/')
               for name, value in profile['storage'].items()}
    for role in ('raw', 'stage'):
        storage.setdefault(role+'_path_template', storage[role+'_key_prefix']+
            '/{feed}/ingest_date={YYYYMMDD}/batch_id={batch_id}/{feed}_{YYYYMMDD}')
    config = {
        'pipeline': {'code': pipeline_code, 'name': f'{pipeline_code} pipeline',
                     'release_version': release_version, 'direction':pipeline_direction},
        'samples_root': profile['samples_root'],
        'inputs': [{
            'code': dataset_code, 'source_system': source_system,
            'sample_csv': (sample_uri(profile['samples_root'] + '/config.yaml',
                                     input_sample_csv, profile['samples_root']) if input_sample_csv else None),
            'source_format':source_format,
            'landing_key_prefix': profile['landing_key_prefix'].replace('{source}',source).rstrip('/') + '/' + feed+'/ingest_date={YYYYMMDD}',
            'file_name': file_name or dataset_code.lower() + '_{YYYYMMDD}.' + source_format.lower(),
        }],
        'outputs': [{
            'code': dataset_code,
            'sample_csv': (sample_uri(profile['samples_root'] + '/config.yaml',
                                     output_sample_csv, profile['samples_root']) if output_sample_csv else None),
            'target_table': target_table or dataset_code,
        }],
        'storage': storage,
        'environments': deepcopy(profile['environments']),
        'sql_output': {'namespace': namespace, 'bucket': bucket,
                       'path': prefix + '/generated',
                       'filename': pipeline_code.lower() + '_metadata_draft.sql',
                       'overwrite': False, 'generate_main_ddl': True},
    }
    if upstream_config is not None:
        config['inputs'][0]['upstream_config'] = deepcopy(upstream_config)
    if not isinstance(template_only,bool):
        raise ValueError('template_only must be boolean.')
    return incomplete_template(config) if template_only else validate_config(config)


def config_uri(profile, config):
    """Input YAML destination, separate from the downstream generated artifacts."""
    pipeline = config['pipeline']
    filename = 'config_template.yaml' if config.get('template_status') == 'INCOMPLETE' else 'config.yaml'
    source = config['inputs'][0]['source_system'].lower()
    feed = config['inputs'][0]['code'].lower()
    return oci_uri(f"{profile['artifacts_root']}/{source}/{feed}/"
                   f"{pipeline['release_version']}/input/{filename}")


def save_config(profile, config, *, client=None, template_only=False):
    """Validate and conditionally create one OCI input YAML; return its exact URI.

    Existing objects are never overwritten; SDK precondition/access errors propagate.
    This API does not check sample existence; build_catalog() performs those HEADs."""
    if not isinstance(template_only,bool):
        raise ValueError('template_only must be boolean.')
    config = incomplete_template(config) if template_only else validate_config(config)
    uri = config_uri(profile, config)
    client = client if client is not None else object_client()
    content = yaml.safe_dump(config, sort_keys=False, allow_unicode=True).encode('utf-8')
    client.put_object(*object_address(uri), content,
                      content_type='application/yaml', if_none_match='*')
    logger.info('CONFIG_CREATED pipeline=%s destination=%s', config['pipeline']['code'], uri)
    return uri
