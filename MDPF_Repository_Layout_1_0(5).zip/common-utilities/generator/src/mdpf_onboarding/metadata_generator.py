"""Three-task metadata, release-local IDs and Oracle SQL rendering."""
from copy import deepcopy
import json
import re

from mdpf_runtime import schema as mdpf_schema
from mdpf_runtime.schema import sql_identifier, spark_type
from mdpf_runtime.storage import object_address

from . import __version__
from .schema_discovery import explicit_columns, validate_conversion

ID_COLUMNS = dict(SOURCE_CONFIG='source_config_id', DATASET='dataset_id',
    DATASET_COLUMN='dataset_column_id', TASK='task_id', TASK_DATASET='task_dataset_id',
    TASK_STEP='task_step_id', POLICY_DEFINITION='policy_id')
TABLES = ('CONFIG_RELEASE', *ID_COLUMNS)


def relationship(config):
    inputs, outputs = len(config['inputs']), len(config['outputs'])
    if inputs > 1 and outputs > 1:
        raise ValueError('Multiple inputs and multiple outputs together are not supported.')
    return 'MANY_TO_ONE' if inputs > 1 else 'ONE_TO_MANY' if outputs > 1 else 'ONE_TO_ONE'


def resolve_steps(options, role, *, mapping=False):
    """Use the complete supplied recipe, or generate the standard built-in plan."""
    from mdpf_runtime.steps import BUILTINS
    if not isinstance(options, dict) or set(options)-{'task_code', 'task_steps'}:
        raise ValueError(f'{role}: only task_code and optional task_steps are supported; '
                         'replace YAML custom_steps/output_is_typed with a complete task_steps sequence.')
    reader = 'READ_SOURCE' if role == 'RAW' else 'READ_PARQUET'
    sink = 'LOAD_MAIN' if role == 'MAIN' else 'WRITE_PARQUET'
    defaults = [reader] + (['DIRECT_MAP'] if mapping else []) + (['VALIDATE_DQ'] if role != 'RAW' else []) + [sink]
    entries = options.get('task_steps', defaults)
    if not isinstance(entries, list) or not entries:
        raise ValueError('task_steps must be a nonempty list when provided.')
    resolved = []
    for entry in entries:
        if isinstance(entry, str):
            if entry not in BUILTINS:
                raise ValueError('Use exact BUILTIN names; declare a custom step with {code: NAME, parameters: {}}.')
            code, params = entry, {}
        elif isinstance(entry, dict) and 'code' in entry and not set(entry)-{'code','parameters'}:
            code, params = entry['code'], entry.get('parameters', {})
        else:
            raise ValueError('A step must be a BUILTIN name or a code/parameters mapping.')
        identifier(code)
        kind = 'BUILTIN' if code in BUILTINS else 'CUSTOM_PYTHON'
        if not isinstance(params, dict) or (kind == 'BUILTIN' and params):
            raise ValueError('Custom parameters must be a JSON object; BUILTIN parameters must be empty.')
        json.dumps(params, allow_nan=False)
        resolved.append((code, kind, params))
    codes = [code for code, _, _ in resolved]
    if len(set(codes)) != len(codes):
        raise ValueError('Step codes must be unique within a task.')
    if (codes[0] != reader or codes[-1] != sink or
            any(c in {'READ_SOURCE','READ_PARQUET','WRITE_PARQUET','LOAD_MAIN'} for c in codes[1:-1])):
        raise ValueError(f'{role} requires {reader} first and {sink} as its only final sink.')
    if role != 'RAW' and (len(codes) < 3 or codes[-2] != 'VALIDATE_DQ'):
        raise ValueError('VALIDATE_DQ must immediately precede the STAGE/MAIN sink.')
    return resolved


def identifier(value, limit=100):
    sql_identifier(value)
    if len(value.encode('utf-8'))>limit:
        raise ValueError(f'Generated identifier exceeds {limit} bytes: {value}')
    return value


def dataset_codes(config):
    p = config['pipeline']['code']
    return dict(inputs=[dict(landing=identifier(f"{p}_{i['code']}_LANDING"),raw=identifier(f"{p}_{i['code']}_RAW")) for i in config['inputs']],
        outputs=[dict(stage=identifier(f"{p}_{o['code']}_STAGE"),main=identifier(f"{p}_{o['code']}_MAIN")) for o in config['outputs']])


def physical_locations(config, codes):
    def key(value, *, filename=False, dated=False, batched=False):
        if not isinstance(value,str) or not value or value!=value.strip('/') or any(c.isspace() for c in value):
            raise ValueError('Object keys must be nonempty, without surrounding slashes or whitespace.')
        test=value.replace('{YYYYMMDD}','20000101') if filename or dated else value
        if batched:
            test=test.replace('{batch_id}', '1')
        if any(c in test for c in '*[]{}?#') or any(x in ('','.','..') for x in test.split('/')):
            raise ValueError('Unsupported object key or token; use {YYYYMMDD}, and {batch_id} in output templates only.')
        if filename and ('/' in value or len(value.encode('utf-8'))>500 or not test.lower().endswith('.parquet')):
            raise ValueError('file_name must be an exact .parquet filename/template, without directories.')
        return value
    def output_key(layer, feed):
        template = config['storage'][layer+'_path_template']
        if not isinstance(template, str) or '{batch_id}' not in template:
            raise ValueError('Output folder templates require {batch_id}.')
        if '.' in template.rsplit('/', 1)[-1]:
            raise ValueError('Output dataset folders must be extensionless.')
        return key(template.replace('{feed}', feed.lower()), dated=True, batched=True)
    def uri(env,bucket_ref,path):
        namespace, bucket = env['namespace'], env['buckets'].get(bucket_ref)
        if any(not isinstance(v,str) or not re.fullmatch(r'[A-Za-z0-9_.-]+',v) for v in (namespace,bucket)):
            raise ValueError('Invalid namespace, bucket name, or missing bucket reference.')
        result=f'oci://{bucket}@{namespace}/{path}'
        object_address(result)
        if len(result.encode('utf-8'))>1000:
            raise ValueError('OCI location exceeds the metadata 1000-byte field.')
        return result
    locations={}
    for name, env in config['environments'].items():
        loc={}
        for i,names in zip(config['inputs'],codes['inputs']):
            prefix=key(i['landing_key_prefix'],dated=True);filename=key(i['file_name'],filename=True)
            suffix = '.parquet'
            if not filename.lower().endswith(suffix):
                raise ValueError('file_name extension must match source_format.')
            loc['SOURCE:'+i['code']]=uri(env,i['bucket_ref'],prefix)
            loc[names['landing']]=uri(env,i['bucket_ref'],prefix+'/'+filename)
            loc[names['raw']]=uri(env,'raw',output_key('raw',i['code']))
        for o,names in zip(config['outputs'],codes['outputs']):
            loc[names['stage']]=uri(env,'stage',output_key('stage',o['code']))
            loc[names['main']]=sql_identifier(env['oracle_main_owner']+'.'+o['target_table'],qualified=True)
        outputs=[loc[n['raw']] for n in codes['inputs']]+[loc[n['stage']] for n in codes['outputs']]
        landings=[loc[n['landing']].replace('{YYYYMMDD}','20000101') for n in codes['inputs']]
        if len(set(landings))!=len(landings):
            raise ValueError(f'{name}: duplicate landing delivery URI.')
        expanded=[p.replace('{YYYYMMDD}','20000101').replace('{batch_id}','1') for p in outputs]
        for j,path in enumerate(expanded):
            for other in expanded[j+1:]+landings:
                if path==other or path.startswith(other+'/') or other.startswith(path+'/'):
                    raise ValueError(f'{name}: overlapping data locations: {path}, {other}')
        targets=[loc[n['main']] for n in codes['outputs']]
        if len(set(targets))!=len(targets):
            raise ValueError(f'{name}: Oracle outputs must use distinct target tables.')
        if 'quarantine_key_prefix' in config['storage']:
            prefix = uri(env, 'quarantine', key(config['storage']['quarantine_key_prefix']))
            roots = [uri(env, i['bucket_ref'], key(i['landing_key_prefix'],dated=True)).split('{',1)[0].rstrip('/') for i in config['inputs']]
            roots += [p.split('{',1)[0].rstrip('/') for p in outputs]
            if any(prefix == other or prefix.startswith(other+'/') or other.startswith(prefix+'/') for other in roots):
                raise ValueError(f'{name}: quarantine must not overlap landing/RAW/STAGE paths.')
            loc['QUARANTINE'] = prefix
        locations[name]=loc
    return locations


def needs_map(source, target):
    a={c['column_name']:spark_type(c) for c in source}
    b={c['column_name']:spark_type(c) for c in target}
    return a!=b


def build_metadata(config, profiles, *, validate_samples=True):
    """Build release-local datasets/tasks/policies and validate sample contracts.

    profiles maps generated LANDING/MAIN codes to (Spark frame, column definitions).
    Return config/tables/datasets/tasks/warnings. validate_samples=False is reserved
    for explicit baseline compilation; this function never publishes or executes SQL."""
    codes=dataset_codes(config);locations=physical_locations(config,codes)
    options={role:config['task_overrides'].get(role,{}) for role in ('RAW','STAGE','MAIN')}
    plans={role:resolve_steps(opt,role) for role,opt in options.items()}
    custom={role:any(kind=='CUSTOM_PYTHON' for _,kind,_ in plan) for role,plan in plans.items()}
    rows={table:[] for table in TABLES};registry={table:{} for table in ID_COLUMNS}
    datasets, tasks, warnings = {}, [], []
    def add(table, logical, **values):
        if logical in registry[table]:raise ValueError(f'Duplicate {table} identity: {logical}')
        number=len(rows[table])+1
        registry[table][logical]=number
        row={ID_COLUMNS[table]:number,**values};rows[table].append(row)
        return row
    def location(logical):return {env:values[logical] for env,values in locations.items()}
    def dataset(code, columns, layer, storage, source_object=None):
        row=add('DATASET',code,dataset_code=code,dataset_name=code,source_object_code=source_object,
                physical_object_name=location(code),layer=layer,storage_type=storage)
        datasets[code]=dict(row=row,columns=deepcopy(columns))
        for column in columns:
            add('DATASET_COLUMN',code+':'+column['column_name'],dataset_id=row['dataset_id'],**column)
    rows['CONFIG_RELEASE'].append(dict(pipeline_code=config['pipeline']['code'],pipeline_name=config['pipeline']['name'],
        pipeline_direction=config['pipeline'].get('direction','INBOUND'),
        release_version=config['pipeline']['release_version'],release_desc='Generated by MDPF SQL Generator '+__version__,
        release_status='DRAFT',created_by=config['created_by']))
    first = config['inputs'][0]
    source_config = add('SOURCE_CONFIG','RAW',source_system_name=first['source_system'],source_type='FILE',
        ingestion_mode='SINGLE_FILE',landing_path=location('SOURCE:'+first['code']),
        file_pattern=first['file_name'] if len(config['inputs']) == 1 else None,
        expected_input_count=len(config['inputs']))
    if 'quarantine_key_prefix' in config['storage']:
        source_config['quarantine_path'] = location('QUARANTINE')
    for item,names in zip(config['inputs'],codes['inputs']):
        columns=profiles[names['landing']][1]
        dataset(names['landing'],columns,'RAW','PARQUET',item['code'])
        if 'upstream_config' in item:
            datasets[names['landing']]['row']['upstream_config'] = json.dumps(
                item['upstream_config'], sort_keys=True, allow_nan=False, separators=(',', ':'))
        dataset(names['raw'],columns,'RAW','PARQUET')
    for names in codes['outputs']:
        columns=profiles[names['main']][1]
        dataset(names['stage'],columns,'STAGE','PARQUET')
        dataset(names['main'],columns,'GOLD','ADB_TABLE')
    p=config['pipeline']['code']
    def task(role,inputs,outputs, *, source_id=None):
        opt=options[role]
        default=f'{p}_{role}_LOAD'
        code=identifier(opt.get('task_code',default))
        row=add('TASK',code,task_code=code,task_name=code,
            task_type='INGESTION' if source_id else 'TRANSFORMATION',source_config_id=source_id,
            close_batch_on_success='Y' if role=='MAIN' else 'N')
        for ds_role, names in [('INPUT',inputs),('OUTPUT',outputs)]:
            for order,name in enumerate(names,1):
                add('TASK_DATASET',code+':'+ds_role+':'+name,task_id=row['task_id'],
                    dataset_id=registry['DATASET'][name],dataset_role=ds_role,is_required='Y',is_enabled='Y',usage_sequence=order)
        sequence=plans[role]
        for order,(step,kind,params) in enumerate(sequence,1):
            add('TASK_STEP',code+':'+step,task_id=row['task_id'],step_code=step,step_name=step,
                step_sequence_number=order*10,step_type=kind,parameter_json=json.dumps(params,sort_keys=True,ensure_ascii=False,allow_nan=False),
                is_required='Y',on_failure_action='FAIL_TASK')
        tasks.append(dict(role=role,row=row,inputs=inputs,outputs=outputs,steps=[s[0] for s in sequence]))
    task('RAW',[n['landing'] for n in codes['inputs']],[n['raw'] for n in codes['inputs']],
         source_id=source_config['source_config_id'])
    stage_options=options['STAGE']
    stage_custom=custom['STAGE'] or custom['RAW']
    source_frame,source_columns=profiles[codes['inputs'][0]['landing']]
    mapping=stage_custom or any(
        needs_map(source_columns,datasets[n['stage']]['columns']) for n in codes['outputs'])
    if mapping and 'task_steps' not in stage_options:
        plans['STAGE']=resolve_steps(stage_options,'STAGE',mapping=True)
    stage_maps=any(code=='DIRECT_MAP' for code,_,_ in plans['STAGE'])
    if validate_samples:
        stage_frames={}
        for names in codes['outputs']:
            target=datasets[names['stage']]['columns']
            if stage_custom:
                # Samples validate final contracts, not the custom implementation.
                stage_frames[names['stage']]=validate_conversion(profiles[names['main']][0],target)
            elif stage_maps:
                stage_frames[names['stage']]=validate_conversion(source_frame,target)
            else:
                mdpf_schema.validate_frame(source_frame,target,'Stage sample without DIRECT_MAP')
                stage_frames[names['stage']]=source_frame
        for names in codes['outputs']:
            mdpf_schema.validate_frame(stage_frames[names['stage']],datasets[names['main']]['columns'],'MAIN sample',oracle=True)
    task('STAGE',[n['raw'] for n in codes['inputs']],[n['stage'] for n in codes['outputs']])
    task('MAIN',[n['stage'] for n in codes['outputs']],[n['main'] for n in codes['outputs']])
    for rule in config.get('dq_rules', []):
        for name in rule['datasets']:
            count_rule = rule['check'] == 'ROW_COUNT'
            column_id = None if count_rule else registry['DATASET_COLUMN'].get(name + ':' + rule['column'])
            if not count_rule and column_id is None:
                raise ValueError(f'DQ column does not exist: {name}.{rule["column"]}')
            from mdpf_runtime.dq import validate_dq_parameters
            column = None if count_rule else next(c for c in datasets[name]['columns'] if c['column_name'] == rule['column'])
            parameters = {k:v for k,v in rule.items() if k not in ('datasets','column','severity')}
            validate_dq_parameters(parameters, column)
            code = identifier(f'{name}_ROW_COUNT' if count_rule else f'{name}_{rule["column"]}_{rule["check"]}')
            warning = rule['severity'] == 'WARN'
            add('POLICY_DEFINITION', code, policy_code=code,
                policy_name=f'{name} ROW_COUNT' if count_rule else f'{name}.{rule["column"]} {rule["check"]}', policy_type='RECONCILIATION' if count_rule else 'DQ',
                policy_scope_type='DATASET' if count_rule else 'DATASET_COLUMN', dataset_id=registry['DATASET'][name],
                dataset_column_id=column_id, policy_severity='WARN' if warning else 'ERROR', threshold_value='0',
                parameter_json=json.dumps(parameters, sort_keys=True, allow_nan=False),
                failure_action='WARN' if warning else 'FAIL_TASK', is_enabled='Y')
    for role in config['task_overrides']:
        if custom[role]:
            warnings.append(f'{role}: custom handler behavior/registration is not tested by sample discovery; return all configured output keys and contracts.')
    warnings.append('Column limits come from explicit contracts or samples plus headroom; review production bounds and Oracle targets before activation.')
    return dict(config=config,tables=rows,datasets=datasets,tasks=tasks,warnings=warnings)


def contract_model(config):
    """Use the same metadata builder for the baseline, without reading any samples."""
    codes=dataset_codes(config);profiles={}
    for role,suffix in (('inputs','landing'),('outputs','main')):
        for item,names in zip(config[role],codes[role]):
            if 'columns' not in item:
                raise ValueError('Comparison requires complete explicit columns in both YAML files; use generated YAML.')
            profiles[names[suffix]]=(None,explicit_columns(item['columns'],source=False))
    return build_metadata(config,profiles,validate_samples=False)


def _comparison_rows(model):
    """Generated metadata keyed by logical identities, not release-local numeric IDs."""
    tables=model['tables']
    datasets={r['dataset_id']:r['dataset_code'] for r in tables['DATASET']}
    tasks={r['task_id']:r['task_code'] for r in tables['TASK']}
    columns={r['dataset_column_id']:datasets[r['dataset_id']]+'.'+r['column_name'] for r in tables['DATASET_COLUMN']}
    sources={r['source_config_id']:'RAW_SOURCE' for r in tables['SOURCE_CONFIG']}
    references={'dataset_id':('dataset',datasets),'task_id':('task',tasks),
        'dataset_column_id':('column',columns),'source_config_id':('source',sources)}
    result={}
    for table,rows in tables.items():
        normalized={}
        for row in rows:
            if table=='CONFIG_RELEASE':identity=row['pipeline_code']
            elif table=='SOURCE_CONFIG':identity=sources[row['source_config_id']]
            elif table=='DATASET':identity=row['dataset_code']
            elif table=='DATASET_COLUMN':identity=columns[row['dataset_column_id']]
            elif table=='TASK':identity=row['task_code']
            elif table=='TASK_STEP':identity=tasks[row['task_id']]+':'+row['step_code']
            elif table=='TASK_DATASET':identity=tasks[row['task_id']]+':'+row['dataset_role']+':'+datasets[row['dataset_id']]
            elif table=='POLICY_DEFINITION':identity=row['policy_code']
            else:raise ValueError(f'Unsupported generated metadata table: {table}')
            values={}
            for key,value in row.items():
                if key in ('config_release_id',ID_COLUMNS.get(table)):
                    continue
                if table=='CONFIG_RELEASE' and key in ('release_version','release_desc','release_status','created_by','effective_from','created_timestamp'):
                    continue
                if key in references:
                    key,lookup=references[key]
                    value=lookup[value] if value is not None else None
                if table=='DATASET_COLUMN' and key=='length_precision_scale':
                    if row['data_type']=='VARCHAR2':
                        length,unit=mdpf_schema.string_limit(row);value=f'{length} {unit}'
                    elif row['data_type']=='NUMBER':
                        kind=spark_type(row);value=f'{kind.precision},{kind.scale}'
                if key in ('parameter_json','upstream_config'):
                    if value is None:value={}
                    elif isinstance(value,str):value=json.loads(value.strip() or '{}')
                    if not isinstance(value,dict):raise ValueError('Comparison '+key+' must be an object.')
                values[key]=value
            if identity in normalized:raise ValueError(f'Duplicate logical {table} identity: {identity}')
            normalized[identity]=values
        result[table]=normalized
    return result


def schema_changes(model,baseline):
    """Compare resolved release models by logical identities; return readable differences.

    Ignore release-local IDs and normalize contract representations. This reads no
    baseline samples and performs no deployment or automatic migration."""
    current,previous=_comparison_rows(model),_comparison_rows(baseline)
    changes=[]
    def display(value):
        return value if isinstance(value,str) else json.dumps(value,sort_keys=True,ensure_ascii=False,allow_nan=False)
    for table in TABLES:
        before,after=previous.get(table,{}),current.get(table,{})
        for identity in sorted(before.keys()-after.keys()):changes.append(f'{table} {identity}: removed.')
        for identity in sorted(after.keys()-before.keys()):changes.append(f'{table} {identity}: added.')
        for identity in sorted(before.keys() & after.keys()):
            for field in sorted(before[identity].keys() | after[identity].keys()):
                old,new=before[identity].get(field),after[identity].get(field)
                if old!=new:changes.append(f'{table} {identity}: {field} {display(old)} -> {display(new)}')
    return changes or ['No release metadata changes.']
