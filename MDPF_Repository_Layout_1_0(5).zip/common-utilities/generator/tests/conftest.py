"""CI-only DDL/OCI adapters; no deployable database or storage backend."""
import os
from pathlib import Path
import sys

import pytest
from mdpf_test_support import CatalogDb, MemoryOCI, SparkTestStorage, WarehouseDb
import yaml
from pyspark.sql import SparkSession

from mdpf_runtime.pipeline import MetadataFramework
from mdpf_onboarding.config import validate_config
from mdpf_onboarding.metadata_generator import build_metadata, dataset_codes
from mdpf_onboarding.sql_renderer import render_sql
from mdpf_onboarding.schema_discovery import discover,read_sample

ROOT=Path(__file__).resolve().parents[1]


@pytest.fixture(scope='session')
def spark():
    os.environ['SPARK_LOCAL_IP']='127.0.0.1'
    os.environ['PYSPARK_PYTHON']=sys.executable
    session=(SparkSession.builder.master('local[1]').appName('mdpf-onboard-ci')
        .config('spark.ui.enabled','false').config('spark.sql.shuffle.partitions','1')
        .config('spark.sql.session.timeZone','UTC').getOrCreate())
    session.sparkContext.setLogLevel('ERROR')
    yield session
    session.stop()


def example_model(spark,name):
    path=ROOT/'examples'/(name+'.yaml');config=validate_config(yaml.safe_load(path.read_text()));profiles={}
    codes=dataset_codes(config)
    for role in ['inputs','outputs']:
        for item,names in zip(config[role],codes[role]):
            code=names['landing' if role=='inputs' else 'main']
            df=read_sample(spark,str(path.parent/item['sample_csv']))
            columns=discover(df,source=role=='inputs',overrides=config['inference']['column_overrides'].get(code,{}))
            profiles[code]=(df,columns)
    return build_metadata(config,profiles)


@pytest.fixture(scope='session')
def models(spark):
    return {name:example_model(spark,name) for name in ['one_to_one','many_to_one','one_to_many']}


@pytest.fixture
def oci_setup(spark,tmp_path,monkeypatch):
    import mdpf_onboarding.onboard as onboard
    client=MemoryOCI();uri='oci://onboarding@devns/config/one_to_one.yaml'
    config=yaml.safe_load((ROOT/'examples/one_to_one.yaml').read_text())
    config['sql_output']['generate_main_ddl']=False  # Baseline OCI tests exercise metadata-only mode.
    samples={onboard.sample_uri(uri,i['sample_csv']):ROOT/'examples'/i['sample_csv']
             for i in config['inputs']+config['outputs']}
    actual=read_sample
    monkeypatch.setattr(onboard,'read_sample',lambda session,path:actual(session,str(samples[path])))
    return config,uri,client,samples


def prepare_execution(model,tmp_path,spark):
    db=CatalogDb();db.deploy(render_sql(model,b'fixture'))
    db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE'")
    db.test_warehouse = WarehouseDb(model)
    storage=SparkTestStorage(tmp_path)
    codes=dataset_codes(model['config'])
    for item,names in zip(model['config']['inputs'],codes['inputs']):
        path=model['datasets'][names['landing']]['row']['physical_object_name']['DEV'].replace('{YYYYMMDD}','20261015')
        target=storage.path(path);target.parent.mkdir(parents=True,exist_ok=True)
        from mdpf_runtime.schema import convert_frame
        sample=read_sample(spark,str(ROOT/'examples'/item['sample_csv']))
        convert_frame(sample,model['datasets'][names['landing']]['columns']).write.parquet(str(target))
    fw=MetadataFramework(db,model['config']['pipeline']['code'],spark=spark,main_db=db.test_warehouse);fw.storage=storage
    return fw,db


