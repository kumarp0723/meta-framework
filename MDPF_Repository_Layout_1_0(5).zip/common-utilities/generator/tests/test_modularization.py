"""Compatibility and transaction checks for the six-module refactor."""
import pytest
from mdpf_test_support import framework_ddl

from conftest import ROOT, prepare_execution


def test_canonical_module_imports_and_removed_compatibility_exports():
    from mdpf_runtime import pipeline, steps
    from mdpf_onboarding import onboard, metadata_generator, sql_renderer, oracle_gate
    assert callable(sql_renderer.render_sql) and callable(sql_renderer.render_main_ddl)
    assert callable(oracle_gate.verify_main_targets)
    assert not hasattr(metadata_generator, 'render_sql')
    assert not hasattr(metadata_generator, 'verify_main_targets')
    assert not hasattr(onboard, 'expand_parameters')
    assert not hasattr(pipeline, '_json_object')
    assert not hasattr(steps, 'validate_dq_parameters')


def test_control_ddl_matches_pinned_generator_fixture():
    companion = ROOT.parent / 'framework/sql/01_framework.sql'
    assert companion.read_bytes() == framework_ddl().encode('utf-8')


def test_completion_event_failure_preserves_adw_and_rolls_back_atp_success_evidence(models, spark, tmp_path, monkeypatch):
    from mdpf_runtime import runtime
    from test_enhancements import enhanced_model, row_rule, task_codes, MAIN, STAGE

    model = enhanced_model(models, spark, [row_rule(MAIN, STAGE)])
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('completion-event-failure', '2026-10-15')['batch_id']
        raw, stage, main = task_codes(model)
        fw.execute_task(batch, raw)
        fw.execute_task(batch, stage)
        insert_event = runtime.insert_event

        def fail_completion(db, batch, run_id, code, message, details=None, error_code=None):
            if code == 'BATCH_COMPLETED':
                raise RuntimeError('Injected completion-event failure')
            return insert_event(db, batch, run_id, code, message, details, error_code)

        monkeypatch.setattr(runtime, 'insert_event', fail_completion)
        with pytest.raises(RuntimeError, match='completion-event failure'):
            fw.execute_task(batch, main)
        failed = db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_id=3")
        assert failed['status'] == 'FAILED'
        assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n'] == 2
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        assert db.one('SELECT COUNT(*) n FROM RUNTIME.POLICY_RESULT')['n'] == 0
        assert db.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE task_run_id=:id AND event_code IN ('MAIN_TABLE_LOADED','TASK_COMPLETED','BATCH_COMPLETED')",
                      id=failed['task_run_id'])['n'] == 0
        assert db.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE task_run_id=:id AND event_code='TASK_FAILED'",
                      id=failed['task_run_id'])['n'] == 1
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE WHERE task_run_id=:id',
                      id=failed['task_run_id'])['n'] == 1
        monkeypatch.setattr(runtime, 'insert_event', insert_event)
        # Explicit operator recovery in this test; never automatic framework cleanup.
        with fw.main_db.transaction():
            fw.main_db.execute('DELETE FROM DMI_MAIN_DEV.LOAN WHERE BATCH_ID=:b',b=batch)
        retry = fw.execute_task(batch, main, main_retry_reviewed_run_id=failed['task_run_id'])
        assert retry['attempt_number'] == 2 and retry['original_task_run_id'] == failed['task_run_id']
        assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n'] == 2
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
    finally:
        db.close()
