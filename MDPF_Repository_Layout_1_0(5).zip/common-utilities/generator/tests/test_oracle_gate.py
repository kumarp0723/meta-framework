from copy import deepcopy, copy

import pytest

from mdpf_onboarding.oracle_gate import verify_main_targets


class OracleCatalog:
    """A dictionary-view fixture, not an Oracle connection."""
    def __init__(self):
        self.present=True;self.calls=[];self.charset='AL32UTF8'
        self.expected=[dict(column_sequence=1,column_name='NAME',data_type='VARCHAR2',length_precision_scale='50 CHAR',is_nullable='Y'),
            dict(column_sequence=2,column_name='AMOUNT',data_type='NUMBER',length_precision_scale='8,2',is_nullable='Y'),
            dict(column_sequence=3,column_name='AS_OF_DATE',data_type='DATE',length_precision_scale=None,is_nullable='Y')]
        self.actual={}
        self.column('NAME','VARCHAR2',data_length=400,char_length=100,char_used='C')
        self.column('AMOUNT','NUMBER',data_precision=18,data_scale=2)
        self.column('AS_OF_DATE','DATE')
        for name in ['BATCH_ID','TASK_RUN_ID','ROW_NUMBER']:self.column(name,'NUMBER',data_precision=19,data_scale=0,nullable='N')
        for name in ('CREATED_AT','UPDATED_AT'):self.column(name,'TIMESTAMP WITH TIME ZONE',data_scale=6,nullable='N')
    def column(self,name,kind,**extra):
        self.actual[name]=dict(column_name=name,data_type=kind,data_length=22,char_length=0,char_used=None,
            data_precision=None,data_scale=None,nullable='Y',data_default=None,identity_column='NO',virtual_column='NO',user_generated='YES',generation_type=None,**{})
        self.actual[name].update(extra)
    def one(self,sql,**params):
        self.calls.append(sql);assert sql.startswith('SELECT ')
        if 'NLS_DATABASE_PARAMETERS' in sql:return {'value':self.charset}
        if 'CONFIG_RELEASE' in sql:return {'config_release_id':10}
        if 'ALL_TABLES' in sql:return {'table_name':'TARGET'} if self.present else None
        raise AssertionError(sql)
    def execute(self,sql,**params):
        self.calls.append(sql);assert sql.startswith('SELECT ')
        if 'METADATA.DATASET WHERE' in sql:return [dict(dataset_id=1,physical_object_name='BIZ.TARGET')]
        if 'DATASET_COLUMN' in sql:return deepcopy(self.expected)
        if 'ALL_TAB_COLS' in sql:return deepcopy(list(self.actual.values()))
        raise AssertionError(sql)


def check(db):return verify_main_targets(db,pipeline_code='P',release_version='1.0',main_db=copy(db))


def test_wider_target_compatible_and_read_only():
    db=OracleCatalog();assert check(db)==['BIZ.TARGET']
    assert all(s.startswith('SELECT') for s in db.calls)


@pytest.mark.parametrize('change',[
    lambda d:d.actual.pop('BATCH_ID'),
    lambda d:d.actual.pop('NAME'),
    lambda d:d.actual['NAME'].update(char_length=49),
    lambda d:d.actual['NAME'].update(char_used='B',data_length=100),
    lambda d:d.actual['NAME'].update(nullable='N'),
    lambda d:d.actual['NAME'].update(virtual_column='YES'),
    lambda d:d.actual['NAME'].update(data_type='CLOB'),
    lambda d:d.actual['AMOUNT'].update(data_scale=1),
    lambda d:d.actual['AMOUNT'].update(data_precision=5,data_scale=2),
    lambda d:d.actual['AMOUNT'].update(data_precision=38,data_scale=-2),
    lambda d:d.actual['BATCH_ID'].update(data_precision=18),
    lambda d:d.actual['BATCH_ID'].update(identity_column='YES',generation_type='ALWAYS'),
    lambda d:setattr(d,'present',False),
    lambda d:d.column('SOURCE_SYSTEM','VARCHAR2',nullable='N'),
    lambda d:d.column('SOURCE_SYSTEM','VARCHAR2',nullable='N',data_default='NULL'),
])
def test_incompatible_targets_block_gate(change):
    db=OracleCatalog();change(db)
    with pytest.raises(ValueError):check(db)


@pytest.mark.parametrize('extra',[
    dict(nullable='Y'),dict(nullable='N',data_default="'DMI'"),
    dict(nullable='N',identity_column='YES',generation_type='ALWAYS'),
    dict(nullable='N',virtual_column='YES')])
def test_extra_columns_can_be_omitted_when_supported(extra):
    db=OracleCatalog();db.column('EXTRA','VARCHAR2',**extra)
    assert check(db)==['BIZ.TARGET']


def test_unbounded_number_and_byte_contract_compatible():
    db=OracleCatalog();db.actual['AMOUNT'].update(data_precision=None,data_scale=None)
    db.expected[0]['length_precision_scale']='50 BYTE'
    assert check(db)==['BIZ.TARGET']


def test_invalid_expected_metadata_fails():
    db=OracleCatalog();db.expected[0]['column_name']='ROW_NUMBER'
    with pytest.raises(ValueError,match='reserved'):check(db)


def test_char_length_alone_does_not_prove_byte_capacity():
    db=OracleCatalog();db.expected[0]['length_precision_scale']='1001 CHAR'
    db.actual['NAME'].update(char_length=4000,data_length=4000)
    with pytest.raises(ValueError,match='character/byte'):check(db)


def test_char_contract_fits_sufficient_utf8_byte_target():
    db=OracleCatalog();db.actual['NAME'].update(char_used='B',data_length=200)
    assert check(db)==['BIZ.TARGET']


def test_non_utf8_requires_explicit_dba_review():
    db=OracleCatalog();db.charset='WE8MSWIN1252'
    with pytest.raises(ValueError,match='AL32UTF8'):check(db)


@pytest.mark.parametrize('kind,scale,valid', [
    ('TIMESTAMP(6) WITH TIME ZONE', 6, True),
    ('TIMESTAMP(9) WITH TIME ZONE', 9, True),
    ('TIMESTAMP(6) WITH TIME ZONE', None, True),
    ('TIMESTAMP(3) WITH TIME ZONE', 3, False),
    ('TIMESTAMP(3) WITH TIME ZONE', None, False),
    ('TIMESTAMP(6)', 6, False),
    ('TIMESTAMP(6) WITH LOCAL TIME ZONE', 6, False),
    ('DATE', None, False),
])
def test_main_audit_timestamp_types_and_precision(kind, scale, valid):
    db = OracleCatalog()
    db.actual['CREATED_AT'].update(data_type=kind, data_scale=scale)
    if valid:
        assert check(db) == ['BIZ.TARGET']
    else:
        with pytest.raises(ValueError):
            check(db)


@pytest.mark.parametrize('field', ['CREATED_AT', 'UPDATED_AT'])
def test_missing_audit_timestamp_blocks_target_gate(field):
    db = OracleCatalog(); db.actual.pop(field)
    with pytest.raises(ValueError, match='missing column'):
        check(db)
