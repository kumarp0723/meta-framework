from copy import deepcopy

import pytest

from conftest import prepare_execution
from test_templates import handlers
from mdpf_onboarding.sql_renderer import render_sql


@pytest.mark.parametrize('problem',['null','zero','duplicate_input','duplicate_output','unmatched','wrong_schema','swapped_pairs'])
def test_bad_raw_pairs_fail_before_io(models,spark,tmp_path,problem):
    model=models['many_to_one'];fw,db=prepare_execution(model,tmp_path,spark)
    batch=fw.start_batch('bad-pairs','2026-10-15','MANUAL')['batch_id']
    if problem in ('null','zero'):
        value=None if problem=='null' else 0
        db.execute("UPDATE METADATA.TASK_DATASET SET usage_sequence=:v WHERE task_id=1 AND dataset_role='OUTPUT' AND usage_sequence=2",v=value)
    elif problem.startswith('duplicate'):
        role='INPUT' if problem=='duplicate_input' else 'OUTPUT'
        db.execute("UPDATE METADATA.TASK_DATASET SET usage_sequence=1 WHERE task_id=1 AND dataset_role=:role",role=role)
    elif problem=='unmatched':
        db.execute("UPDATE METADATA.TASK_DATASET SET usage_sequence=3 WHERE task_id=1 AND dataset_role='OUTPUT' AND usage_sequence=2")
    elif problem=='swapped_pairs':
        db.execute("UPDATE METADATA.TASK_DATASET SET usage_sequence=3-usage_sequence WHERE task_id=1 AND dataset_role='OUTPUT'")
    else:
        ds=model['tables']['DATASET'][1]['dataset_id']
        db.execute("UPDATE METADATA.DATASET_COLUMN SET length_precision_scale='999 CHAR' WHERE dataset_id=:d AND column_sequence=1",d=ds)
    fw.storage.read_parquet=lambda *args:pytest.fail('Invalid metadata must fail before source I/O')
    with pytest.raises(ValueError,match='RAW|LANDING'):fw.execute_task(batch,model['tasks'][0]['row']['task_code'])
    assert db.one('SELECT status FROM RUNTIME.TASK_RUN')['status']=='FAILED'
    assert db.one('SELECT COUNT(*) n FROM RUNTIME.INGESTION_ITEM')['n']==0
    assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n']==1
    db.close()


def test_partial_raw_write_repair_and_release_pinning(models,spark,tmp_path):
    model=models['many_to_one'];fw,db=prepare_execution(model,tmp_path,spark)
    batch=fw.start_batch('partial-raw','2026-10-15','MANUAL')['batch_id']
    original=fw.storage.write_parquet;calls=[]
    def fail_second(path,frame):
        calls.append(path)
        if len(calls)==2:raise RuntimeError('Simulated second RAW output failure')
        original(path,frame)
    fw.storage.write_parquet=fail_second
    with pytest.raises(RuntimeError,match='second RAW'):fw.execute_task(batch,model['tasks'][0]['row']['task_code'])
    failed=db.one('SELECT * FROM RUNTIME.TASK_RUN')
    assert failed['status']=='FAILED' and len(calls)==2
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='RUNNING'
    assert {r['status'] for r in db.execute('SELECT status FROM RUNTIME.INGESTION_ITEM')}=={'FAILED'}
    first=fw.storage.read_parquet(spark,calls[0])
    assert first.select('_run_id').distinct().first()[0]==failed['task_run_id']
    # New ACTIVE metadata cannot change the original batch's paths/schemas on Repair.
    fresh=deepcopy(model);fresh['tables']['CONFIG_RELEASE'][0]['release_version']='1.1'
    for row in fresh['tables']['DATASET']:
        if row['storage_type'] == 'PARQUET':
            row['physical_object_name']={env:path.replace('/demo_join/','/new_release/') for env,path in row['physical_object_name'].items()}
    db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='RETIRED', effective_to=SYSTIMESTAMP")
    db.deploy(render_sql(fresh,b'new revision'),release=901)
    db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE' WHERE config_release_id=901")
    fw.storage.write_parquet=original
    assert fw.start_batch('partial-raw')['config_release_id']==900
    fixed=fw.execute_task(batch,model['tasks'][0]['row']['task_code'])
    assert fixed['attempt_number']==2 and fixed['original_task_run_id']==failed['task_run_id']
    assert fixed['config_release_id']==900 and fixed['input_count']==4 and fixed['output_count']==4
    for path in calls:
        frame=fw.storage.read_parquet(spark,path)
        assert frame.select('_batch_id','_run_id').distinct().first().asDict()=={'_batch_id':batch,'_run_id':fixed['task_run_id']}
    receipts=db.execute('SELECT dataset_id,source_item_key,status FROM RUNTIME.INGESTION_ITEM ORDER BY ingestion_item_id')
    assert len(receipts)==4 and len({r['source_item_key'] for r in receipts})==2
    assert [r['source_item_key'] for r in receipts[:2]]==[r['source_item_key'] for r in receipts[2:]]
    for task in model['tasks'][1:]:fw.execute_task(batch,task['row']['task_code'],custom_steps=handlers())
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='COMPLETED'
    assert db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id',id=failed['task_run_id'])==failed
    assert db.one('SELECT status FROM OPERATIONS.WORK_QUEUE')['status']=='OPEN'
    db.close()


def test_multi_target_main_rollback_and_repair(models,spark,tmp_path):
    model=models['one_to_many'];fw,db=prepare_execution(model,tmp_path,spark)
    batch=fw.start_batch('multi-main','2026-10-15','MANUAL')['batch_id']
    for task in model['tasks'][:2]:fw.execute_task(batch,task['row']['task_code'],custom_steps=handlers())
    main=model['tasks'][2]['row']['task_code'];original=fw.main_db.insert_many
    def broken(table,columns,records,types):
        count=original(table,columns,records,types)
        if table.endswith('LOAN_STATUS'):raise RuntimeError('Oracle MAIN failure')
        return count
    fw.main_db.insert_many=broken
    with pytest.raises(RuntimeError,match='MAIN failure'):fw.execute_task(batch,main,custom_steps=handlers())
    tables=[d['row']['physical_object_name']['DEV'] for d in model['datasets'].values() if d['row']['storage_type']=='ADB_TABLE']
    assert all(fw.main_db.one(f'SELECT COUNT(*) n FROM {table}')['n']==0 for table in tables)
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='RUNNING'
    fw.main_db.insert_many=original
    failed=db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_id=3')
    repaired=fw.execute_task(batch,main,custom_steps=handlers(),main_retry_reviewed_run_id=failed['task_run_id'])
    assert repaired['attempt_number']==2 and all(fw.main_db.one(f'SELECT COUNT(*) n FROM {table}')['n']==2 for table in tables)
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='COMPLETED'
    assert db.one('SELECT status FROM OPERATIONS.WORK_QUEUE')['status']=='OPEN'
    db.close()
