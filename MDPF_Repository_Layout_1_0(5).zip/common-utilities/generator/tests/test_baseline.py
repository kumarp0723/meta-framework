"""Configuration round trips, conservative schema proposals and OCI publication."""
from copy import deepcopy
import re

import pytest
import yaml

from conftest import CatalogDb
from mdpf_onboarding.onboard import complete_config, generate, main
from mdpf_onboarding.config import expand_parameters, main_ddl_uri, output_uri, sample_uri, validate_config, yaml_uri
from mdpf_onboarding.metadata_generator import contract_model, schema_changes
from mdpf_onboarding.sql_renderer import render_main_ddl
from mdpf_onboarding.schema_discovery import explicit_columns, validate_sample
from test_main_ddl import ddl_statements


def frozen(model):
    paths={item['sample_csv']:'oci://samples@ns/'+item['sample_csv']
           for item in model['config']['inputs']+model['config']['outputs']}
    return complete_config(model,paths)


def test_limited_tokens_and_collision_rejection(oci_setup):
    config,_,_,_=oci_setup
    config['samples_root']='oci://samples@ns/${pipeline.code}'
    config['inputs'][0]['sample_csv']='${samples_root}/input.csv'
    config['sql_output'].update(path='${pipeline.code}/${pipeline.release_version}',filename='${pipeline.code}.sql')
    result=validate_config(config)
    assert result['inputs'][0]['sample_csv']=='oci://samples@ns/DEMO_LOAN/input.csv'
    assert output_uri(result).endswith('/DEMO_LOAN/1.0/DEMO_LOAN.sql')
    assert config['inputs'][0]['file_name'].endswith('_{YYYYMMDD}.parquet')
    for bad in ('${unknown}','${environments.DEV.namespace}','${pipeline.code'):
        with pytest.raises(ValueError):expand_parameters({'x':bad})
    with pytest.raises(ValueError,match='duplicate key'):
        expand_parameters({'pipeline':{'code':'X'},'x':{'${pipeline.code}':1,'X':2}})


def test_parameterized_artifact_names_and_sample_root(oci_setup):
    config,uri,_,_=oci_setup
    config['sql_output'].update(main_ddl_filename='target_changes.sql',yaml_filename='current.yml')
    config=validate_config(config)
    assert main_ddl_uri(config).endswith('/target_changes.sql')
    assert yaml_uri(config).endswith('/current.yml')
    assert sample_uri(uri,'a.csv','oci://separate@ns/root')=='oci://separate@ns/root/a.csv'
    for field,name in [('yaml_filename','../bad.yaml'),('yaml_filename','bad.sql'),('main_ddl_filename','bad.yaml')]:
        bad=deepcopy(config);bad['sql_output'][field]=name
        with pytest.raises(ValueError):validate_config(bad)


def test_complete_yaml_is_valid_relocatable_and_deterministic(models):
    config=frozen(models['one_to_one'])
    assert validate_config(config)==config
    assert config['inference']['column_overrides']=={}
    assert all(i['columns'] and i['sample_csv'].startswith('oci://') for i in config['inputs']+config['outputs'])
    baseline=contract_model(config)
    assert schema_changes(models['one_to_one'],baseline)==['No release metadata changes.']
    assert frozen(models['one_to_one'])==config


def test_explicit_contracts_prevent_silent_schema_drift(spark,models):
    columns=explicit_columns(frozen(models['one_to_one'])['outputs'][0]['columns'],source=False)
    with pytest.raises(ValueError,match='Sample schema columns'):
        validate_sample(spark.createDataFrame([('X',)],['NEW_COLUMN']),columns,source=False)
    string=[dict(column_name='VALUE',data_type='VARCHAR2',length_precision_scale='3 CHAR',is_nullable='Y')]
    with pytest.raises(ValueError,match='length constraint'):
        validate_sample(spark.createDataFrame([('TOO_LONG',)],['VALUE']),explicit_columns(string,source=True),source=True)


def test_explicit_columns_and_overrides_are_not_competing_authorities(models):
    config=frozen(models['one_to_one'])
    config['inference']['column_overrides']={'DEMO_LOAN_LOAN_MAIN':{'LOAN_ID':{'is_nullable':'N'}}}
    with pytest.raises(ValueError,match='not both'):validate_config(config)


@pytest.mark.parametrize('columns', [[],[{'column_name':'A'}],
    [{'column_name':'A','data_type':'DATE','is_pii':'YES'}],
    [{'column_name':'A','data_type':'VARCHAR2','length_precision_scale':'3 CHAR'}]*2])
def test_invalid_explicit_columns(columns):
    with pytest.raises(ValueError):explicit_columns(columns,source=False)


def test_baseline_errors_stop_before_sample_io(models,oci_setup,monkeypatch):
    import mdpf_onboarding.onboard as module
    _,uri,client,_=oci_setup
    config=frozen(models['one_to_one']);config['pipeline']['release_version']='1.1'
    client.objects[uri]=yaml.safe_dump(config).encode()
    baseline='oci://artifacts@ns/old.yaml'
    monkeypatch.setattr(module,'read_sample',lambda *a:pytest.fail('Baseline error must precede sample IO'))
    with pytest.raises(ValueError,match='Cannot read or validate baseline_yaml'):generate(uri,baseline_yaml=baseline,client=client)
    for mutation,pattern in [(lambda c:c['pipeline'].update(code='WRONG'),'same pipeline'),
                             (lambda c:c['pipeline'].update(release_version='1.1'),'new release_version'),
                             (lambda c:c['inputs'][0].pop('columns'),'complete explicit columns')]:
        previous=frozen(models['one_to_one']);mutation(previous)
        client.objects[baseline]=yaml.safe_dump(previous).encode()
        with pytest.raises(ValueError,match=pattern):generate(uri,baseline_yaml=baseline,client=client)
    assert not client.puts


def test_initial_roundtrip_then_comparison_uses_no_baseline_samples(oci_setup,spark,monkeypatch,capsys):
    config,uri,client,_=oci_setup
    config['sql_output']['generate_main_ddl']=True
    client.objects[uri]=yaml.safe_dump(config).encode()
    generate(uri,spark=spark,client=client)
    prior=yaml_uri(config)
    complete=yaml.safe_load(client.objects[prior]);complete['pipeline']['release_version']='1.1'
    complete['sql_output']['path']+='-1.1'
    for col in complete['outputs'][0]['columns']:
        if col['column_name']=='LOAN_ID':col['length_precision_scale']='40 CHAR'
    client.objects[uri]=yaml.safe_dump(complete).encode()
    generate(uri,baseline_yaml=prior,spark=spark,client=client)
    assert 'ALTER TABLE' in client.objects[main_ddl_uri(complete)].decode()
    assert 'MODIFY (LOAN_ID VARCHAR2(40 CHAR))' in client.objects[main_ddl_uri(complete)].decode()
    output=capsys.readouterr().out
    assert 'Mode: INITIAL SETUP' in output and 'Mode: COMPARISON' in output and '20 CHAR -> 40 CHAR' in output
    assert client.gets==[uri,uri,prior]
    assert yaml.safe_load(client.objects[yaml_uri(complete)])['outputs'][0]['columns']==complete['outputs'][0]['columns']


def test_artifacts_cannot_overwrite_config_or_baseline(oci_setup):
    config,uri,client,_=oci_setup
    prefix,filename=uri.rsplit('/',1)
    config['sql_output'].update(namespace='devns',bucket='onboarding',path='config',yaml_filename=filename)
    client.objects[uri]=yaml.safe_dump(config).encode()
    with pytest.raises(ValueError,match='distinct'):generate(uri,client=client)
    assert not client.puts


def test_safe_alter_and_manual_review_are_environment_correct(models):
    config=frozen(models['one_to_one']);baseline=contract_model(config)
    current=deepcopy(baseline)
    main=next(v for v in current['datasets'].values() if v['row']['storage_type']=='ADB_TABLE')
    main['columns'][0]['length_precision_scale']='40 CHAR'
    main['columns'].append(dict(column_sequence=99,column_name='NEW_VALUE',data_type='DATE',length_precision_scale=None,is_nullable='Y',is_pii='N'))
    main['columns'].append(dict(column_sequence=100,column_name='REQUIRED_NEW',data_type='DATE',length_precision_scale=None,is_nullable='N',is_pii='N'))
    main['columns']=[c for c in main['columns'] if c['column_name']!='CLIENT_ID']
    script=render_main_ddl(current,b'config',baseline=baseline)
    db=CatalogDb()
    try:
        for env in ('DEV','STAGE','PROD'):
            statements=ddl_statements(db,script,env)
            assert len(statements)==2
            assert all(s.startswith('ALTER TABLE '+main['row']['physical_object_name'][env]) for s in statements)
            assert any(' ADD (NEW_VALUE DATE)' in s for s in statements)
            assert any(' MODIFY (LOAN_ID VARCHAR2(40 CHAR))' in s for s in statements)
    finally:db.close()
    assert 'MANUAL REVIEW: CLIENT_ID removed' in script and 'MANUAL REVIEW: adding NOT NULL REQUIRED_NEW' in script
    assert not any(re.search(r'\b(DROP|RENAME)\b',line) for line in script.splitlines() if not line.lstrip().startswith('--'))


def test_narrowing_numeric_changes_and_target_rename_are_not_automated(models):
    baseline=contract_model(frozen(models['one_to_one']))
    current=deepcopy(baseline)
    main=next(v for v in current['datasets'].values() if v['row']['storage_type']=='ADB_TABLE')
    main['columns'][0]['length_precision_scale']='10 CHAR'
    main['columns'][2]['length_precision_scale']='20,2'
    script=render_main_ddl(current,b'x',baseline=baseline)
    assert 'MANUAL REVIEW' in script and 'EXECUTE IMMEDIATE' not in script
    main['row']['physical_object_name']['DEV']='DMI_MAIN_DEV.RENAMED'
    assert 'target name/owner changed' in render_main_ddl(current,b'x',baseline=baseline)


def test_generated_yaml_freezes_resolved_plans_and_custom_parameters(models):
    for name,model in models.items():
        config=frozen(model)
        for task in model['tasks']:
            options=config['task_overrides'][task['role']]
            assert options['task_code']==task['row']['task_code']
            assert [s if isinstance(s,str) else s['code'] for s in options['task_steps']]==task['steps']
        assert validate_config(config)==config


def test_schema_proposals_relax_nullability_and_create_only_new_targets(models):
    baseline=contract_model(frozen(models['one_to_one']));current=deepcopy(baseline)
    main=next(v for v in current['datasets'].values() if v['row']['storage_type']=='ADB_TABLE')
    main['columns'][0]['is_nullable']='Y'
    new=deepcopy(main);new['row']['dataset_code']='DEMO_LOAN_OTHER_MAIN'
    new['row']['physical_object_name']={e:t+'_OTHER' for e,t in main['row']['physical_object_name'].items()}
    current['datasets'][new['row']['dataset_code']]=new
    db=CatalogDb()
    try:
        statements=ddl_statements(db,render_main_ddl(current,b'x',baseline=baseline),'DEV')
        assert len(statements)==2
        assert 'MODIFY (LOAN_ID VARCHAR2(20 CHAR) NULL)' in statements[0]
        assert statements[1].startswith('CREATE TABLE DMI_MAIN_DEV.LOAN_OTHER')
    finally:db.close()


def test_dataset_rename_does_not_propose_creating_the_existing_table(models):
    baseline=contract_model(frozen(models['one_to_one']));current=deepcopy(baseline)
    old=next(k for k,v in current['datasets'].items() if v['row']['storage_type']=='ADB_TABLE')
    spec=current['datasets'].pop(old);spec['row']['dataset_code']='DEMO_LOAN_RENAMED_MAIN'
    current['datasets'][spec['row']['dataset_code']]=spec
    script=render_main_ddl(current,b'x',baseline=baseline)
    assert 'EXECUTE IMMEDIATE' not in script
