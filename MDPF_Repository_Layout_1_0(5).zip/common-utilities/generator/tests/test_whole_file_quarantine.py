"""Whole-object Parquet quarantine, retry overwrite and conditional OCI copying."""
from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace
import pytest
import yaml
from pyspark.sql import functions as F
from conftest import CatalogDb, ROOT, prepare_execution
from mdpf_runtime.schema import DataValidationError
from mdpf_runtime.storage import ObjectStorage
from mdpf_onboarding.builder import build_config
from mdpf_onboarding.metadata_generator import build_metadata, contract_model, schema_changes
from mdpf_onboarding.sql_renderer import render_sql
from mdpf_onboarding.config import validate_config

def setup_quarantine(model, spark, tmp_path):
    import shutil
    fw, db = prepare_execution(model, tmp_path, spark)
    prefix = 'oci://quarantine@devns/rejected'
    db.execute('UPDATE METADATA.SOURCE_CONFIG SET quarantine_path=:q', q=prefix)
    copies = []
    source = next(d['row']['physical_object_name']['DEV'] for d in model['datasets'].values()
                  if d['row']['dataset_code'].endswith('_LANDING')).replace('{YYYYMMDD}', '20261015')
    # Exact source-object payload is retained independently of the synthetic Spark input.
    path = fw.storage.path(source)
    frame = spark.read.parquet(str(path)).cache()
    frame.count()
    shutil.rmtree(path)
    path.write_bytes(b'PAR1-exact-source-object-bytes-PAR1')
    fw.storage.read_parquet = lambda session, uri: frame
    def copy(src, dst):
        target=fw.storage.path(dst);target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes(fw.storage.path(src).read_bytes())
        copies.append((src,dst))
    fw.storage.quarantine_file = copy
    return fw, db, copies, source, frame

@pytest.mark.parametrize('problem', ['schema', 'empty', 'null', 'length'])
def test_bad_source_is_copied_and_quarantined_without_raw_writes(models,spark,tmp_path,problem):
    fw,db,copies,source,frame=setup_quarantine(models['one_to_one'],spark,tmp_path)
    try:
        bad={'schema':frame.withColumnRenamed('LOAN_ID','WRONG'),
             'empty':frame.limit(0),
             'null':frame.withColumn('LOAN_ID',F.lit(None).cast('string')),
             'length':frame.withColumn('LOAN_ID',F.lit('X'*200))}[problem]
        if problem=='null':
            db.execute("UPDATE METADATA.DATASET_COLUMN SET is_nullable='N' WHERE column_name='LOAN_ID'")
        fw.storage.read_parquet=lambda *args:bad
        fw.storage.write_parquet=lambda *args:pytest.fail('No RAW output for rejected source')
        batch=fw.start_batch('bad-'+problem,'2026-10-15')['batch_id']
        original=fw.storage.path(source).read_bytes()
        with pytest.raises(DataValidationError):fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        receipt=db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
        assert receipt['status']=='QUARANTINED'
        assert receipt['quarantine_location']==f'oci://quarantine@devns/rejected/dmi/loan/ingest_date=20261015/batch_id={batch}/loan_20261015.parquet'
        assert fw.storage.path(receipt['quarantine_location']).read_bytes()==original==fw.storage.path(source).read_bytes()
        assert copies==[(source,receipt['quarantine_location'])]
        assert db.one('SELECT status FROM RUNTIME.TASK_RUN')['status']=='FAILED'
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='RUNNING'
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n']==1
        assert db.one("SELECT * FROM OPERATIONS.EVENT_LOG WHERE event_code='SOURCE_QUARANTINED'")
    finally:frame.unpersist();db.close()

@pytest.mark.parametrize('error',[RuntimeError('Network failed'),ValueError('Access denied')])
def test_source_io_failures_are_not_quarantined(models,spark,tmp_path,error):
    fw,db,copies,source,frame=setup_quarantine(models['one_to_one'],spark,tmp_path)
    try:
        def fail(*args):raise error
        fw.storage.read_parquet=fail
        batch=fw.start_batch('io-failure','2026-10-15')['batch_id']
        with pytest.raises(type(error),match=str(error)):fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        assert not copies
        receipt=db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
        assert receipt['status']=='FAILED' and receipt['quarantine_location'] is None
    finally:frame.unpersist();db.close()

def test_retry_overwrites_quarantine_object_and_preserves_attempt_history(models,spark,tmp_path):
    fw,db,copies,source,frame=setup_quarantine(models['one_to_one'],spark,tmp_path)
    try:
        fw.storage.read_parquet=lambda *args:frame.withColumnRenamed('LOAN_ID','WRONG')
        batch=fw.start_batch('retry','2026-10-15')['batch_id']
        with pytest.raises(DataValidationError):fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        first=db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
        target=fw.storage.path(first['quarantine_location'])
        target.write_bytes(b'existing-quarantine-copy')
        with pytest.raises(DataValidationError):fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        receipts=db.execute('SELECT * FROM RUNTIME.INGESTION_ITEM ORDER BY ingestion_item_id')
        assert [r['status'] for r in receipts]==['QUARANTINED','QUARANTINED']
        assert receipts[0]==first and receipts[1]['quarantine_location']==first['quarantine_location']
        assert target.read_bytes()==fw.storage.path(source).read_bytes()
        assert copies==[(source,first['quarantine_location'])]*2
        runs=db.execute('SELECT * FROM RUNTIME.TASK_RUN ORDER BY task_run_id')
        assert [r['status'] for r in runs]==['FAILED','FAILED']
        assert [r['attempt_number'] for r in runs]==[1,2]
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='RUNNING'
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n']==2
        assert db.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE event_code='SOURCE_QUARANTINED'")['n']==2
    finally:frame.unpersist();db.close()

def test_new_batch_retains_prior_batch_quarantine_object(models,spark,tmp_path):
    fw,db,copies,source,frame=setup_quarantine(models['one_to_one'],spark,tmp_path)
    try:
        fw.storage.read_parquet=lambda *args:frame.withColumnRenamed('LOAN_ID','WRONG')
        first_batch=fw.start_batch('first-delivery','2026-10-15')['batch_id']
        with pytest.raises(DataValidationError):fw.execute_task(first_batch,'DEMO_LOAN_RAW_LOAD')
        first=db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
        target=fw.storage.path(first['quarantine_location'])
        target.write_bytes(b'prior-batch-evidence')
        fw.fail_batch(first_batch)
        second_batch=fw.start_batch('next-delivery','2026-10-15')['batch_id']
        with pytest.raises(DataValidationError):fw.execute_task(second_batch,'DEMO_LOAN_RAW_LOAD')
        receipts=db.execute('SELECT * FROM RUNTIME.INGESTION_ITEM ORDER BY ingestion_item_id')
        assert receipts[0]==first
        assert receipts[1]['status']=='QUARANTINED'
        assert receipts[1]['quarantine_location']!=first['quarantine_location']
        assert f'/batch_id={second_batch}/' in receipts[1]['quarantine_location']
        assert target.read_bytes()==b'prior-batch-evidence'
        assert fw.storage.path(receipts[1]['quarantine_location']).read_bytes()==fw.storage.path(source).read_bytes()
        assert len(copies)==2
    finally:frame.unpersist();db.close()

def test_failed_retry_copy_does_not_reuse_existing_quarantine_as_success(models,spark,tmp_path):
    fw,db,copies,source,frame=setup_quarantine(models['one_to_one'],spark,tmp_path)
    try:
        fw.storage.read_parquet=lambda *args:frame.withColumnRenamed('LOAN_ID','WRONG')
        batch=fw.start_batch('retry-copy-failure','2026-10-15')['batch_id']
        with pytest.raises(DataValidationError):fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        first=db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
        original=fw.storage.path(first['quarantine_location']).read_bytes()
        def fail_copy(*args):raise RuntimeError('Overwrite denied')
        fw.storage.quarantine_file=fail_copy
        with pytest.raises(RuntimeError,match='Source validation failed:.*quarantine copy failed: Overwrite denied'):
            fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        receipts=db.execute('SELECT * FROM RUNTIME.INGESTION_ITEM ORDER BY ingestion_item_id')
        assert receipts[0]==first
        assert receipts[1]['status']=='FAILED' and receipts[1]['quarantine_location'] is None
        assert fw.storage.path(first['quarantine_location']).read_bytes()==original
        assert db.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE event_code='SOURCE_QUARANTINED'")['n']==1
    finally:frame.unpersist();db.close()

@pytest.mark.parametrize('cause',['copy_failure','late_callback'])
def test_copy_failure_and_late_callback_never_claim_quarantine(models,spark,tmp_path,cause):
    fw,db,copies,source,frame=setup_quarantine(models['one_to_one'],spark,tmp_path)
    try:
        fw.storage.read_parquet=lambda *args:frame.withColumnRenamed('LOAN_ID','WRONG')
        original_copy=fw.storage.quarantine_file
        def copy(src,dst):
            if cause=='copy_failure':raise RuntimeError('Copy denied')
            original_copy(src,dst)
            run=db.one("SELECT task_run_id FROM RUNTIME.TASK_RUN WHERE status='RUNNING'")
            fw.fail_task_run(run['task_run_id'],'EXTERNAL_FAILURE','Exact-run callback')
        fw.storage.quarantine_file=copy
        batch=fw.start_batch(cause,'2026-10-15')['batch_id']
        with pytest.raises((RuntimeError,ValueError)):fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        receipt=db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
        assert receipt['status']=='FAILED' and receipt['quarantine_location'] is None
        assert not db.one("SELECT * FROM OPERATIONS.EVENT_LOG WHERE event_code='SOURCE_QUARANTINED'")
        assert fw.storage.path(source).exists()
    finally:frame.unpersist();db.close()

def test_missing_feed_is_rejected_before_source_read(models,spark,tmp_path):
    fw,db,copies,source,frame=setup_quarantine(models['one_to_one'],spark,tmp_path)
    try:
        db.execute("UPDATE METADATA.DATASET SET source_object_code=NULL WHERE dataset_code LIKE '%_LANDING'")
        fw.storage.read_parquet=lambda *args:pytest.fail('Invalid feed metadata must fail before reads')
        batch=fw.start_batch('missing-feed','2026-10-15')['batch_id']
        with pytest.raises(ValueError,match='source_object_code'):fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        assert not copies
    finally:frame.unpersist();db.close()

def test_valid_source_with_quarantine_enabled_finishes_without_copy(models,spark,tmp_path):
    fw,db,copies,source,frame=setup_quarantine(models['one_to_one'],spark,tmp_path)
    try:
        batch=fw.start_batch('valid-quarantine-enabled','2026-10-15')['batch_id']
        result=fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        assert result['status']=='COMPLETED' and not copies
        assert db.one('SELECT status FROM RUNTIME.INGESTION_ITEM')['status']=='PROCESSED'
        assert fw.storage.path(source).exists()
    finally:frame.unpersist();db.close()

def test_overlapping_quarantine_root_is_rejected_before_source_read(models,spark,tmp_path):
    fw,db,copies,source,frame=setup_quarantine(models['one_to_one'],spark,tmp_path)
    try:
        db.execute('UPDATE METADATA.SOURCE_CONFIG SET quarantine_path=:p',p=source.rsplit('/',1)[0])
        fw.storage.read_parquet=lambda *args:pytest.fail('Overlapping quarantine root must fail before reads')
        batch=fw.start_batch('overlapping-quarantine','2026-10-15')['batch_id']
        with pytest.raises(ValueError,match='overlap'):fw.execute_task(batch,'DEMO_LOAN_RAW_LOAD')
        assert not copies and db.one('SELECT COUNT(*) n FROM RUNTIME.INGESTION_ITEM')['n']==0
    finally:frame.unpersist();db.close()

def test_combined_source_rejection_quarantines_only_the_failed_member(models,spark,tmp_path):
    model=models['many_to_one'];fw,db=prepare_execution(model,tmp_path,spark)
    try:
        db.execute("UPDATE METADATA.SOURCE_CONFIG SET quarantine_path='oci://quarantine@devns/rejected'")
        paths=[d['row']['physical_object_name']['DEV'].replace('{YYYYMMDD}','20261015')
               for d in model['datasets'].values() if d['row']['dataset_code'].endswith('_LANDING')]
        actual_read=fw.storage.read_parquet;copies=[]
        def read(session,uri):
            if uri==paths[1]:raise DataValidationError('Invalid client schema')
            return actual_read(session,uri)
        fw.storage.read_parquet=read
        fw.storage.quarantine_file=lambda src,dst:copies.append((src,dst))
        fw.storage.write_parquet=lambda *args:pytest.fail('Rejected combined task must not publish RAW')
        batch=fw.start_batch('combined-rejection','2026-10-15')['batch_id']
        with pytest.raises(DataValidationError):fw.execute_task(batch,'DEMO_JOIN_RAW_LOAD')
        receipts=db.execute('SELECT * FROM RUNTIME.INGESTION_ITEM ORDER BY ingestion_item_id')
        assert [r['status'] for r in receipts]==['FAILED','QUARANTINED']
        assert len(copies)==1 and copies[0][0]==paths[1]
        assert copies[0][1].endswith(f'/dmi/client/ingest_date=20261015/batch_id={batch}/client_20261015.parquet')
    finally:db.close()

@pytest.mark.parametrize('source_format',['CSV','AVRO'])
def test_builder_rejects_non_parquet_landing(source_format):
    profile=yaml.safe_load((ROOT/'examples/shared_profile.yaml').read_text())
    with pytest.raises(ValueError,match='PARQUET'):
        build_config(profile,pipeline_code='DMI_FEE',dataset_code='FEE',source_system='DMI',
            input_sample_csv='fee/input.csv',output_sample_csv='fee/output.csv',source_format=source_format)

def test_quarantine_source_root_is_explicit_in_generated_metadata(models):
    profile=yaml.safe_load((ROOT/'examples/shared_profile.yaml').read_text())
    profile['storage']['quarantine_key_prefix']='quarantine'
    for env in profile['environments'].values():env['buckets']['quarantine']='rejected'
    config=build_config(profile,pipeline_code='DEMO_LOAN',dataset_code='LOAN',source_system='DMI',
        input_sample_csv='loan/input.csv',output_sample_csv='loan/output.csv')
    assert config['storage']['quarantine_key_prefix']=='quarantine'
    complete=deepcopy(models['one_to_one']['config'])
    complete['storage']['quarantine_key_prefix']='quarantine'
    complete['environments']=config['environments']
    profiles={code:(None,ds['columns']) for code,ds in models['one_to_one']['datasets'].items()
              if code.endswith(('_LANDING','_MAIN'))}
    model=build_metadata(complete,profiles,validate_samples=False)
    assert model['tables']['SOURCE_CONFIG'][0]['quarantine_path']['DEV']=='oci://rejected@devns/quarantine'
    db=CatalogDb()
    try:
        db.deploy(render_sql(model,b'quarantine contract'))
        assert db.one('SELECT quarantine_path FROM METADATA.SOURCE_CONFIG')['quarantine_path']=='oci://rejected@devns/quarantine'
    finally:db.close()

@pytest.mark.parametrize('state', ['COMPLETED', 'FAILED', 'CANCELED', None])
def test_oci_copy_waits_and_preserves_source_with_conditions(monkeypatch, state):
    import oci
    heads, calls = [], []
    signer = SimpleNamespace(region='us-ashburn-1')
    def head(*address):
        heads.append(address)
        return SimpleNamespace(headers={'etag': 'source-etag'})
    client = SimpleNamespace(head_object=head)
    def copy(*args, **kwargs):
        calls.append((args, kwargs))
        return SimpleNamespace(data=SimpleNamespace(status=state))
    monkeypatch.setattr(oci.auth.signers, 'get_resource_principals_signer', lambda: signer)
    monkeypatch.setattr(oci.object_storage, 'ObjectStorageClient', lambda *a, **kw: client)
    monkeypatch.setattr(oci.object_storage, 'ObjectStorageClientCompositeOperations',
                        lambda c: SimpleNamespace(copy_object_and_wait_for_state=copy))
    operation = lambda: ObjectStorage().quarantine_file('oci://landing@ns/file.parquet', 'oci://rejected@ns/quarantine/file.parquet')
    if state == 'COMPLETED':
        operation()
        assert heads==[('ns','landing','file.parquet'),('ns','rejected','quarantine/file.parquet')]
    else:
        with pytest.raises(RuntimeError):
            operation()
        assert heads==[('ns','landing','file.parquet')]
    args, options = calls[0]
    details = args[2]
    assert details.source_object_if_match_e_tag == 'source-etag'
    assert details.destination_object_if_none_match_e_tag is None
    assert details.destination_object_if_match_e_tag is None
    assert details.destination_region == signer.region
    assert details.destination_bucket == 'rejected'


def test_oci_existing_destination_is_overwritten_and_confirmed(monkeypatch):
    import oci
    signer=SimpleNamespace(region='us-ashburn-1')
    source=('ns','landing','file.parquet')
    destination=('ns','rejected','quarantine/dmi/fee/file.parquet')
    objects={source:b'immutable-source',destination:b'prior-copy'}
    heads=[];copies=[]
    def head(*address):
        heads.append(address)
        assert address in objects
        return SimpleNamespace(headers={'etag':'source-etag'})
    client=SimpleNamespace(head_object=head)
    def copy(ns,bucket,details,**kwargs):
        copies.append(details)
        assert details.source_object_if_match_e_tag=='source-etag'
        assert details.destination_object_if_none_match_e_tag is None
        target=(details.destination_namespace,details.destination_bucket,details.destination_object_name)
        objects[target]=objects[(ns,bucket,details.source_object_name)]
        return SimpleNamespace(data=SimpleNamespace(status='COMPLETED'))
    monkeypatch.setattr(oci.auth.signers,'get_resource_principals_signer',lambda:signer)
    monkeypatch.setattr(oci.object_storage,'ObjectStorageClient',lambda *a,**k:client)
    monkeypatch.setattr(oci.object_storage,'ObjectStorageClientCompositeOperations',
                        lambda c:SimpleNamespace(copy_object_and_wait_for_state=copy))
    storage=ObjectStorage()
    for _ in range(2):
        storage.quarantine_file('oci://landing@ns/file.parquet','oci://rejected@ns/quarantine/dmi/fee/file.parquet')
    assert objects[destination]==objects[source]==b'immutable-source'
    assert len(copies)==2 and heads==[source,destination]*2
