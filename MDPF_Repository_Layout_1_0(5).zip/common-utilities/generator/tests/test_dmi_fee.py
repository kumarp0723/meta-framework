"""DMI_FEE replacement behavior using local Spark and the existing CI adapters.

These checks exercise the shipped starters; they do not validate live OCI/AIDP,
Data Flow identities, Oracle DDL or concurrent database transactions.
"""
import csv
import io
import json
import runpy
from types import SimpleNamespace

import pytest
import yaml

from conftest import ROOT, CatalogDb, MemoryOCI, prepare_execution
from mdpf_runtime.runner import _run_task
from mdpf_onboarding.bulk_builder import build_catalog
from mdpf_onboarding.config import validate_config, yaml_uri, main_ddl_uri, output_uri
from mdpf_onboarding.metadata_generator import build_metadata, dataset_codes
from mdpf_onboarding.sql_renderer import render_main_ddl
from mdpf_onboarding.onboard import generate
from mdpf_onboarding.config import sample_uri
from mdpf_onboarding.schema_discovery import explicit_columns, read_sample, validate_sample
from test_bulk_builder import SampleOCI, PROFILE, CATALOG


RAW, STAGE, MAIN = ('DMI_FEE_FEE_' + role for role in ('RAW', 'STAGE', 'MAIN'))
APP = ROOT.parent / 'framework/entrypoints/dataflow/raw.py'
NOTEBOOK = ROOT.parent / 'framework/entrypoints/aidp/raw.ipynb'


@pytest.fixture(scope='module')
def fee_model(spark):
    config = validate_config(yaml.safe_load((ROOT / 'examples/dmi_fee.yaml').read_text()))
    codes, profiles = dataset_codes(config), {}
    for role, suffix in (('inputs', 'landing'), ('outputs', 'main')):
        for item, names in zip(config[role], codes[role]):
            frame = read_sample(spark, str(ROOT / 'examples' / item['sample_csv']))
            columns = explicit_columns(item['columns'], source=role == 'inputs')
            validate_sample(frame, columns, source=role == 'inputs')
            profiles[names[suffix]] = frame, columns
    return build_metadata(config, profiles)


def fee_handlers():
    # Regression-only handler; shared runtime starters contain no business logic.
    from pyspark.sql import functions as F
    def trim(frames, context, params):
        return {STAGE: frames[RAW].withColumn(params['column'], F.trim(F.col(params['column'])))}
    return {'CUSTOM_FEE_TRANSFORM': trim}


def test_fee_contract_plans_policies_and_target_ddl(fee_model):
    model = fee_model
    expected = [
        ('MSP_CYCLE_DATE', 'DATE', None, 'N'),
        ('DELTA_FILE_BYTE', 'VARCHAR2', '10 CHAR', 'Y'),
        ('LN_NO', 'NUMBER', '19', 'N'),
        ('FEE_TRAN_CD', 'NUMBER', '10', 'Y'),
        ('FEE_TRAN_TY', 'VARCHAR2', '20 CHAR', 'Y'),
        ('FEE_CD', 'NUMBER', '10', 'Y'),
        ('FEE_TRAN_DT', 'DATE', None, 'Y'),
        ('FEE_TRAN_AM', 'NUMBER', '18,2', 'Y'),
        ('FEE_BATCH_CD', 'VARCHAR2', '20 CHAR', 'Y'),
        ('FEE_SUB_CD', 'VARCHAR2', '20 CHAR', 'Y'),
        ('CLIENT_NO', 'VARCHAR2', '50 CHAR', 'Y'),
        ('DMI_TIME_STAMP', 'VARCHAR2', '30 CHAR', 'Y'),
    ]
    fields = ('column_name', 'data_type', 'length_precision_scale', 'is_nullable')
    for code in (STAGE, MAIN):
        assert [tuple(c[k] for k in fields) for c in model['datasets'][code]['columns']] == expected
    for c in model['datasets'][RAW]['columns']:
        assert (c['data_type'], c['length_precision_scale'], c['is_nullable']) == ('VARCHAR2', '100 CHAR', 'Y')
    assert [t['steps'] for t in model['tasks']] == [
        ['READ_SOURCE', 'WRITE_PARQUET'],
        ['READ_PARQUET', 'CUSTOM_FEE_TRANSFORM', 'DIRECT_MAP', 'VALIDATE_DQ', 'WRITE_PARQUET'],
        ['READ_PARQUET', 'DIRECT_MAP', 'VALIDATE_DQ', 'LOAD_MAIN'],
    ]
    policies = model['tables']['POLICY_DEFINITION']
    assert len(policies) == 4
    assert [json.loads(p['parameter_json']) for p in policies] == [
        {'check': 'NOT_NULL'}, {'check': 'NOT_NULL'},
        {'check': 'ROW_COUNT', 'source_dataset': RAW},
        {'check': 'ROW_COUNT', 'source_dataset': STAGE},
    ]
    assert all((p['policy_severity'], p['threshold_value'], p['failure_action']) == ('ERROR', '0', 'FAIL_TASK') for p in policies)
    source = model['tables']['SOURCE_CONFIG'][0]
    assert (source['source_type'], source['ingestion_mode'], source['expected_input_count'], source['file_pattern']) == ('FILE', 'SINGLE_FILE', 1, 'fee_{YYYYMMDD}.parquet')
    ddl = render_main_ddl(model, b'DMI_FEE fixture')
    for statement in ('MSP_CYCLE_DATE DATE NOT NULL', 'LN_NO NUMBER(19) NOT NULL',
                      'FEE_TRAN_AM NUMBER(18,2)', 'CLIENT_NO VARCHAR2(50 CHAR)',
                      'CREATED_AT TIMESTAMP(6) WITH TIME ZONE NOT NULL'):
        assert statement in ddl
    assert model['datasets'][MAIN]['row']['physical_object_name'] == {
        'DEV': 'DMI_MAIN_DEV.DMI_FEE', 'STAGE': 'DMI_MAIN_STAGE.DMI_FEE', 'PROD': 'DMI_MAIN.DMI_FEE'}


@pytest.mark.parametrize('platform', ['aidp', 'dataflow'])
def test_retained_starters_run_all_three_tasks(fee_model, spark, tmp_path, monkeypatch, platform):
    fw, db = prepare_execution(fee_model, tmp_path, spark)
    monkeypatch.setattr('mdpf_runtime.runner.MetadataFramework', lambda *a, **kw: fw)
    close = db.close
    monkeypatch.setattr('mdpf_runtime.runner.MetadataFramework', lambda *a, **kw: fw)
    for field in ('USER','PASSWORD','DSN'):monkeypatch.setenv('MDPF_MAIN_DB_'+field,'test-adw')
    results = []
    try:
        if platform == 'aidp':
            monkeypatch.setattr('mdpf_runtime.aidp.OracleDb', lambda: db)
            monkeypatch.setattr(db, 'close', lambda: None)
            class Widgets:
                def __init__(self, values): self.values = values
                def text(self, *, name, defaultValue, label): self.values.setdefault(name, defaultValue)
                def get(self, name): return self.values[name]
            for index, task in enumerate(fee_model['tasks'], 1):
                values = dict(pipeline_code='DMI_FEE', task_code=task['row']['task_code'], job_run_id='synthetic-job', task_run_id=f'synthetic-aidp-{index}',
                              execution_count='1', cycle_date='2026-10-15' if index == 1 else '',
                              execution_mode='MANUAL' if index == 1 else '')
                scope = dict(spark=spark, aidputils=SimpleNamespace(widgets=Widgets(values)))
                cells = [c for c in json.loads(NOTEBOOK.with_name(task['role'].lower() + '.ipynb').read_text())['cells'] if c['cell_type'] == 'code']
                if task['role'] == 'STAGE':
                    from mdpf_runtime.aidp import execute_task
                    results.append(execute_task(pipeline_code='DMI_FEE', task_code=task['row']['task_code'],
                                                aidputils=scope['aidputils'], spark=spark, custom_steps=fee_handlers()))
                else:
                    for cell in cells: exec(''.join(cell['source']), scope)
                    results.append(scope['result'])
        else:
            monkeypatch.setattr('mdpf_runtime.dataflow.run_task', lambda **kw: _run_task(db,main_db=fw.main_db, **kw))
            for index, task in enumerate(fee_model['tasks'], 1):
                monkeypatch.setenv('DATAFLOW_RUN_ID', f'ocid1.dataflowrun.oc1.test.synthetic{index}')
                args = ['--execution-key', 'ACTIVEBATCH:synthetic-fee']
                if index == 1: args += ['--cycle-date', '2026-10-15', '--execution-mode', 'MANUAL']
                if task['role'] == 'STAGE':
                    from mdpf_runtime.dataflow import execute_task
                    execute_task(pipeline_code='DMI_FEE', task_code=task['row']['task_code'],
                                 custom_steps=fee_handlers(), spark=spark, argv=args)
                else:
                    runpy.run_path(str(APP.with_name(task['role'].lower() + '.py')))['main'](
                        ['--pipeline-code', 'DMI_FEE', '--task-code', task['row']['task_code']] + args, spark=spark)
            results = db.execute('SELECT * FROM RUNTIME.TASK_RUN ORDER BY task_run_id')
        assert len(results) == 3 and len({r['task_run_id'] for r in results}) == 3
        assert all((r['status'], r['input_count'], r['output_count']) == ('COMPLETED', 2, 2) for r in results)
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
        assert [r['client_no'] for r in fw.main_db.execute('SELECT CLIENT_NO FROM DMI_MAIN_DEV.DMI_FEE ORDER BY ROW_NUMBER')] == ['C001', 'C002']
        assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.DMI_FEE WHERE CREATED_AT IS NOT NULL AND UPDATED_AT IS NOT NULL')['n'] == 2
        assert [r['result_status'] for r in db.execute('SELECT result_status FROM RUNTIME.POLICY_RESULT')] == ['PASS'] * 4
        with pytest.raises(ValueError, match='COMPLETED'):
            fw.execute_task(1, 'DMI_FEE_MAIN_LOAD')
        assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.DMI_FEE')['n'] == 2
    finally:
        close()


@pytest.mark.parametrize('column', ['MSP_CYCLE_DATE', 'LN_NO'])
def test_fee_not_null_failure_is_audited_before_stage_write(fee_model, spark, tmp_path, column):
    fw, db = prepare_execution(fee_model, tmp_path, spark)
    try:
        landing = fee_model['datasets']['DMI_FEE_FEE_LANDING']['row']['physical_object_name']['DEV'].replace('{YYYYMMDD}', '20261015')
        path = fw.storage.path(landing)
        from pyspark.sql import functions as F
        actual_read=fw.storage.read_parquet
        invalid=actual_read(spark,landing).withColumn(column,
            F.when(F.col('CLIENT_NO').contains('C001'),F.lit(None).cast('string')).otherwise(F.col(column)))
        fw.storage.read_parquet=lambda session,uri:invalid if uri==landing else actual_read(session,uri)
        batch = fw.start_batch('fee-null-' + column, '2026-10-15', 'MANUAL')['batch_id']
        fw.execute_task(batch, 'DMI_FEE_RAW_LOAD')
        with pytest.raises(ValueError):
            fw.execute_task(batch, 'DMI_FEE_STAGE_LOAD', custom_steps=fee_handlers())
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        failed = db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE status='FAILED'")
        assert failed['failed_step_code'] == 'VALIDATE_DQ'
        assert db.one("SELECT COUNT(*) n FROM RUNTIME.POLICY_RESULT WHERE result_status='FAIL'")['n'] == 1
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 1
        assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.DMI_FEE')['n'] == 0
    finally:
        db.close()


def test_fee_stage_row_loss_blocks_and_main_insert_mismatch_rolls_back(fee_model, spark, tmp_path, monkeypatch):
    from pyspark.sql import functions as F
    fw, db = prepare_execution(fee_model, tmp_path, spark)
    handler = fee_handlers()['CUSTOM_FEE_TRANSFORM']
    def lose_row(frames, context, params):
        return {code: df.where(F.col('LN_NO') == '100000123') for code, df in handler(frames, context, params).items()}
    try:
        batch = fw.start_batch('fee-reconciliation', '2026-10-15', 'MANUAL')['batch_id']
        fw.execute_task(batch, 'DMI_FEE_RAW_LOAD')
        with pytest.raises(ValueError):
            fw.execute_task(batch, 'DMI_FEE_STAGE_LOAD', custom_steps={'CUSTOM_FEE_TRANSFORM': lose_row})
        assert db.one("SELECT COUNT(*) n FROM RUNTIME.POLICY_RESULT WHERE result_status='FAIL'")['n'] == 1
        fw.execute_task(batch, 'DMI_FEE_STAGE_LOAD', custom_steps=fee_handlers())
        actual_insert = fw.main_db.insert_many
        def wrong_count(*args, **kwargs):
            return actual_insert(*args, **kwargs) - 1
        monkeypatch.setattr(fw.main_db, 'insert_many', wrong_count)
        with pytest.raises(ValueError, match='reconciliation'):
            fw.execute_task(batch, 'DMI_FEE_MAIN_LOAD')
        assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.DMI_FEE')['n'] == 0
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        assert db.one("SELECT COUNT(*) n FROM RUNTIME.POLICY_RESULT WHERE result_status='FAIL'")['n'] == 2
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 2
    finally:
        db.close()


def test_supplied_catalog_preserves_targets_sample_root_and_builder_filename():
    profile = yaml.safe_load((ROOT / 'examples/shared_profile.yaml').read_text())
    catalog = (ROOT / 'examples/bulk_catalog.csv').read_bytes()
    client = SampleOCI(); client.objects.update({PROFILE: yaml.safe_dump(profile).encode(), CATALOG: catalog})
    rows = list(csv.DictReader(io.StringIO(catalog.decode())))
    assert [r['pipeline_code'] for r in rows] == ['DMI_FEE', 'DMI_LOAN', 'DMI_CLIENT']
    for row in rows:
        for key in ('input_sample_csv', 'output_sample_csv'):
            client.objects[profile['samples_root'] + '/' + row[key]] = b'existence-only fixture'
    assert [r['status'] for r in build_catalog(PROFILE, CATALOG, client=client)] == ['VALIDATED'] * 3
    results = build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    for row, result in zip(rows, results):
        assert result['status'] == 'CREATED' and result['yaml_uri'].endswith('/1.0/input/config.yaml')
        config = yaml.safe_load(client.objects[result['yaml_uri']])
        assert config['outputs'][0]['target_table'] == row['target_table']
        assert config['inputs'][0]['sample_csv'] == 'oci://mdpf-samples@devns/dmi/' + row['input_sample_csv']
        assert len({result['yaml_uri'], yaml_uri(config), output_uri(config), main_ddl_uri(config)}) == 4
    assert rows[0]['target_table'] == 'DMI_FEE'


def test_fee_public_generation_creates_complete_contract_ddl_and_draft(spark, monkeypatch):
    import mdpf_onboarding.onboard as onboard
    uri = 'oci://mdpf-dev-artifacts@devns/onboarding/dmi_fee/1.0/input/dmi_fee.yaml'
    original = (ROOT / 'examples/dmi_fee.yaml').read_bytes()
    config = validate_config(yaml.safe_load(original))
    client = MemoryOCI(); client.objects[uri] = original
    samples = {sample_uri(uri, i['sample_csv']): ROOT / 'examples' / i['sample_csv']
               for i in config['inputs'] + config['outputs']}
    monkeypatch.setattr(onboard, 'read_sample', lambda session, path: read_sample(session, str(samples[path])))
    assert generate(uri, spark=spark, client=client) == output_uri(config)
    assert [path for path, _ in client.puts] == [yaml_uri(config), main_ddl_uri(config), output_uri(config)]
    assert client.objects[uri] == original
    complete = validate_config(yaml.safe_load(client.objects[yaml_uri(config)]))
    assert len(complete['outputs'][0]['columns']) == 12
    assert complete['outputs'][0]['target_table'] == 'DMI_FEE'
    assert len(complete['dq_rules']) == 4
    sql = client.objects[output_uri(config)].decode()
    db = CatalogDb()
    try:
        db.deploy(sql)
        assert db.one('SELECT release_status FROM METADATA.CONFIG_RELEASE')['release_status'] == 'DRAFT'
        assert db.one('SELECT COUNT(*) n FROM METADATA.POLICY_DEFINITION')['n'] == 4
        assert db.one("SELECT physical_object_name FROM METADATA.DATASET WHERE dataset_code=:code", code=MAIN)['physical_object_name'] == 'DMI_MAIN_DEV.DMI_FEE'
    finally:
        db.close()
