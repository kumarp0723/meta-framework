"""Package the Framework wheel and six canonical launchers; no deployment/network."""
import argparse
from email.parser import Parser
import hashlib
import json
from pathlib import Path
import zipfile


ROOT = Path(__file__).resolve().parents[1]


def build_release(output):
    wheels = list((ROOT / 'dist').glob('mdpf_runtime-*.whl'))
    if len(wheels) != 1:
        raise ValueError('Keep exactly one approved mdpf-runtime wheel in dist before packaging.')
    wheel = wheels[0]
    with zipfile.ZipFile(wheel) as archive:
        metadata_files = [n for n in archive.namelist() if n.endswith('.dist-info/METADATA')]
        if len(metadata_files) != 1:
            raise ValueError('Expected one wheel METADATA file.')
        metadata = Parser().parsestr(archive.read(metadata_files[0]).decode())
        if metadata['Name'] != 'mdpf-runtime' or not metadata['Version']:
            raise ValueError('Expected a versioned mdpf-runtime wheel.')
        for source in (ROOT / 'src/mdpf_runtime').glob('*.py'):
            if archive.read('mdpf_runtime/' + source.name) != source.read_bytes():
                raise ValueError('Framework wheel is stale; rebuild it before packaging.')
    assets = {'wheels/' + wheel.name: wheel.read_bytes()}
    for platform, extension in (('dataflow', 'py'), ('aidp', 'ipynb')):
        for role in ('raw', 'stage', 'main'):
            name = f'entrypoints/{platform}/{role}.{extension}'
            assets[name] = (ROOT / name).read_bytes()
    manifest = dict(distribution='mdpf-runtime', version=metadata['Version'], wheel='wheels/' + wheel.name,
                    artifacts=[dict(path=name, sha256=hashlib.sha256(data).hexdigest())
                               for name, data in sorted(assets.items())])
    assets['release-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as handle:
        try:
            with zipfile.ZipFile(handle, 'w', zipfile.ZIP_DEFLATED) as archive:
                for name, data in sorted(assets.items()):
                    archive.writestr(name, data)
        except BaseException:
            output.unlink(missing_ok=True)
            raise
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output', type=Path, required=True, help='New release ZIP; existing files are rejected.')
    args = parser.parse_args(argv)
    output = build_release(args.output)
    print(output)
    print('SHA256: ' + hashlib.sha256(output.read_bytes()).hexdigest())


if __name__ == '__main__':
    main()
