-- Metadata Processing Framework 1.0 - fresh ATP object installation
-- 17 tables, 234 columns, 12 triggers, eight sequences. SQLcl/SQL*Plus as ADMIN.
-- Prerequisite: 00_create_schemas.sql. No destructive reset or upgrade behavior.
-- The schema owners have direct privileges; the application is granted access in 02.
-- One environment per ATP; scheduler owns workflow ordering/retries/concurrency.
-- Storage owns commit evidence; EVENT_LOG is audit, not a commit ledger.
SET ECHO OFF
SET VERIFY OFF
SET DEFINE OFF
SET SERVEROUTPUT ON
WHENEVER OSERROR EXIT FAILURE ROLLBACK
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
BEGIN
    IF SYS_CONTEXT('USERENV','SESSION_USER') <> 'ADMIN' THEN
        RAISE_APPLICATION_ERROR(-20100, 'Connect as ATP ADMIN for this script.');
    END IF;
END;
/
DECLARE
    accounts NUMBER;
    objects NUMBER;
BEGIN
    SELECT COUNT(*) INTO accounts FROM ALL_USERS
     WHERE username IN ('METADATA','RUNTIME','OPERATIONS','MDPF_RUNTIME');
    IF accounts <> 4 THEN
        RAISE_APPLICATION_ERROR(-20103, 'Run 00_create_schemas.sql first.');
    END IF;
    SELECT COUNT(*) INTO objects FROM ALL_OBJECTS
     WHERE owner IN ('METADATA','RUNTIME','OPERATIONS');
    IF objects <> 0 THEN
        RAISE_APPLICATION_ERROR(-20104, 'Fresh installation requires empty MDPF schemas; installation will not overwrite objects.');
    END IF;
END;
/
CREATE TABLE METADATA.CONFIG_RELEASE (
    config_release_id NUMBER(19) NOT NULL,
    pipeline_code VARCHAR2(100) NOT NULL,
    pipeline_name VARCHAR2(200) NOT NULL,
    pipeline_direction VARCHAR2(8) DEFAULT 'INBOUND' NOT NULL,
    pipeline_description VARCHAR2(1000),
    release_version VARCHAR2(50) NOT NULL,
    release_desc VARCHAR2(200) NOT NULL,
    release_status VARCHAR2(20) NOT NULL,
    effective_from TIMESTAMP(6) WITH TIME ZONE NOT NULL,
    effective_to TIMESTAMP(6) WITH TIME ZONE,
    created_by VARCHAR2(100) NOT NULL,
    created_timestamp TIMESTAMP(6) WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT PK_CONFIG_RELEASE PRIMARY KEY (config_release_id),
    CONSTRAINT UQ_CONFIG_RELEASE_PIPE_VERSION UNIQUE (pipeline_code, release_version),
    CONSTRAINT UQ_CONFIG_RELEASE_PIPE_ID UNIQUE (config_release_id, pipeline_code),
    CONSTRAINT CK_CONFIG_RELEASE_DIRECTION CHECK (pipeline_direction IN ('INBOUND','OUTBOUND')),
    CONSTRAINT CK_CONFIG_RELEASE_1 CHECK (release_status IN ('DRAFT','APPROVED','ACTIVE','RETIRED')),
    CONSTRAINT CK_CONFIG_RELEASE_2 CHECK (effective_to IS NULL OR effective_to >= effective_from)
);

COMMENT ON TABLE METADATA.CONFIG_RELEASE IS 'Defines an immutable, pipeline-scoped metadata release/version.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.config_release_id IS 'Unique metadata release identifier.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.pipeline_code IS 'Stable logical pipeline code, e.g. PIPELINE_A.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.pipeline_name IS 'Human-readable pipeline name.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.pipeline_direction IS 'Pipeline classification: INBOUND or OUTBOUND; does not change execution behavior.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.pipeline_description IS 'Pipeline purpose/scope.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.release_version IS 'Pipeline-specific metadata version label.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.release_desc IS 'Human-readable release description.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.release_status IS 'DRAFT, APPROVED, ACTIVE, or RETIRED. Only DRAFT metadata is editable.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.effective_from IS 'Effective start; editable in DRAFT and frozen after APPROVED.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.effective_to IS 'NULL until ACTIVE to RETIRED; retirement requires an end not earlier than the approved start.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.created_by IS 'User/service that created the release.';
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.created_timestamp IS 'Creation timestamp.';
CREATE UNIQUE INDEX METADATA.UIX_CONFIG_RELEASE_ONE_ACTIVE
    ON METADATA.CONFIG_RELEASE (CASE WHEN release_status='ACTIVE' THEN pipeline_code END);

CREATE TABLE METADATA.SOURCE_CONFIG (
    config_release_id NUMBER(19) NOT NULL,
    source_config_id NUMBER(19) NOT NULL,
    source_system_name VARCHAR2(200) NOT NULL,
    source_type VARCHAR2(20) NOT NULL,
    ingestion_mode VARCHAR2(20) DEFAULT 'SINGLE_FILE' NOT NULL,
    control_file_pattern VARCHAR2(500),
    connection_reference VARCHAR2(500),
    landing_path VARCHAR2(1000),
    archive_path VARCHAR2(1000),
    quarantine_path VARCHAR2(1000),
    file_pattern VARCHAR2(500),
    database_object_name VARCHAR2(500),
    expected_input_count NUMBER(10),
    CONSTRAINT PK_SOURCE_CONFIG PRIMARY KEY (config_release_id, source_config_id),
    CONSTRAINT CK_SOURCE_CONFIG_1 CHECK (source_type IN ('FILE','DATABASE','API','EVENT','STREAM')),
    CONSTRAINT CK_SOURCE_CONFIG_2 CHECK (expected_input_count IS NULL OR expected_input_count >= 0),
    CONSTRAINT CK_SOURCE_CONFIG_3 CHECK (ingestion_mode IN ('SINGLE_FILE','PACKAGE')),
    CONSTRAINT CK_SOURCE_CONFIG_4 CHECK ((ingestion_mode='SINGLE_FILE') OR (ingestion_mode='PACKAGE' AND control_file_pattern IS NOT NULL)),
    CONSTRAINT FK_SOURCE_CONFIG_1 FOREIGN KEY (config_release_id) REFERENCES METADATA.CONFIG_RELEASE (config_release_id)
);

COMMENT ON TABLE METADATA.SOURCE_CONFIG IS 'Defines where external data enters the platform and the minimum connection/location information needed to acquire it.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.config_release_id IS 'Release identifier.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.source_config_id IS 'Release-specific source configuration identifier.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.source_system_name IS 'Business-readable external source system name.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.source_type IS 'External source type: FILE, DATABASE, API, EVENT, or STREAM.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.connection_reference IS 'Reference to an external connection/credential definition; stores a reference, never a secret.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.landing_path IS 'Location where inbound payloads are landed.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.archive_path IS 'Location where preserved inbound artifacts are archived.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.quarantine_path IS 'Location for invalid or rejected inbound artifacts.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.file_pattern IS 'Inbound filename hint; exact Parquet object URI is stored per DATASET. {YYYYMMDD} uses BATCH.cycle_date.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.database_object_name IS 'External database object/query/procedure reference.';
COMMENT ON COLUMN METADATA.SOURCE_CONFIG.expected_input_count IS 'Expected number of files/extracts/input units for a run.';

CREATE TABLE METADATA.DATASET (
    config_release_id NUMBER(19) NOT NULL,
    dataset_id NUMBER(19) NOT NULL,
    dataset_code VARCHAR2(100) NOT NULL,
    dataset_name VARCHAR2(200) NOT NULL,
    dataset_description VARCHAR2(1000),
    source_object_code VARCHAR2(100),
    physical_object_name VARCHAR2(1000),
    layer VARCHAR2(20) NOT NULL,
    domain_name VARCHAR2(100),
    subject_area VARCHAR2(100),
    storage_type VARCHAR2(50),
    business_owner VARCHAR2(100),
    upstream_config CLOB,
    CONSTRAINT CK_DATASET_UPSTREAM_JSON CHECK (upstream_config IS JSON),
    CONSTRAINT PK_DATASET PRIMARY KEY (config_release_id, dataset_id),
    CONSTRAINT UQ_DATASET_CODE UNIQUE (config_release_id, dataset_code),
    CONSTRAINT UQ_DATASET_SOURCE_OBJECT UNIQUE (config_release_id, source_object_code),
    CONSTRAINT CK_DATASET_1 CHECK (layer IN ('RAW','STAGE','GOLD','OUTBOUND')),
    CONSTRAINT FK_DATASET_1 FOREIGN KEY (config_release_id) REFERENCES METADATA.CONFIG_RELEASE (config_release_id)
);

COMMENT ON TABLE METADATA.DATASET IS 'Defines a logical data asset consumed or produced by a task.';
COMMENT ON COLUMN METADATA.DATASET.config_release_id IS 'Release identifier.';
COMMENT ON COLUMN METADATA.DATASET.dataset_id IS 'Release-specific dataset identifier.';
COMMENT ON COLUMN METADATA.DATASET.dataset_code IS 'Stable logical dataset code across releases.';
COMMENT ON COLUMN METADATA.DATASET.dataset_name IS 'Human-readable dataset name.';
COMMENT ON COLUMN METADATA.DATASET.dataset_description IS 'Dataset purpose, grain, and business meaning.';
COMMENT ON COLUMN METADATA.DATASET.physical_object_name IS 'Physical target/prefix, or exact source Parquet URI template with {YYYYMMDD}; multi-input FILE tasks use one exact URI per input dataset.';
COMMENT ON COLUMN METADATA.DATASET.layer IS 'Logical layer: RAW, STAGE, GOLD, or OUTBOUND.';
COMMENT ON COLUMN METADATA.DATASET.domain_name IS 'Business domain associated with the dataset.';
COMMENT ON COLUMN METADATA.DATASET.subject_area IS 'Optional subject-area grouping.';
COMMENT ON COLUMN METADATA.DATASET.storage_type IS 'Physical storage/access mechanism, e.g. ADB_TABLE or OBJECT_STORAGE.';
COMMENT ON COLUMN METADATA.DATASET.business_owner IS 'Business owner accountable for the data asset.';
COMMENT ON COLUMN METADATA.DATASET.upstream_config IS 'Optional upstream source information for IDMC on source input datasets; JSON without credentials.';

CREATE TABLE METADATA.DATASET_COLUMN (
    config_release_id NUMBER(19) NOT NULL,
    dataset_column_id NUMBER(19) NOT NULL,
    dataset_id NUMBER(19) NOT NULL,
    column_sequence NUMBER(10) NOT NULL,
    column_name VARCHAR2(200) NOT NULL,
    data_type VARCHAR2(100) NOT NULL,
    length_precision_scale VARCHAR2(100),
    is_nullable CHAR(1) DEFAULT 'Y' NOT NULL,
    is_pii CHAR(1) DEFAULT 'N' NOT NULL,
    CONSTRAINT PK_DATASET_COLUMN PRIMARY KEY (config_release_id, dataset_column_id),
    CONSTRAINT UQ_DC_DATASET_COLNAME UNIQUE (config_release_id, dataset_id, column_name),
    CONSTRAINT UQ_DC_DATASET_SEQ UNIQUE (config_release_id, dataset_id, column_sequence),
    CONSTRAINT UQ_DC_DATASET_COLID UNIQUE (config_release_id, dataset_id, dataset_column_id),
    CONSTRAINT CK_DATASET_COLUMN_1 CHECK (column_sequence > 0),
    CONSTRAINT CK_DATASET_COLUMN_2 CHECK (is_nullable IN ('Y','N')),
    CONSTRAINT CK_DATASET_COLUMN_3 CHECK (is_pii IN ('Y','N')),
    CONSTRAINT FK_DATASET_COLUMN_1 FOREIGN KEY (config_release_id, dataset_id) REFERENCES METADATA.DATASET (config_release_id, dataset_id)
);

COMMENT ON TABLE METADATA.DATASET_COLUMN IS 'Defines the field/column contract directly under a dataset.';
COMMENT ON COLUMN METADATA.DATASET_COLUMN.config_release_id IS 'Release identifier.';
COMMENT ON COLUMN METADATA.DATASET_COLUMN.dataset_column_id IS 'Release-specific column-definition identifier.';
COMMENT ON COLUMN METADATA.DATASET_COLUMN.dataset_id IS 'Dataset that owns the column definition.';
COMMENT ON COLUMN METADATA.DATASET_COLUMN.column_sequence IS 'Position of the column within the dataset.';
COMMENT ON COLUMN METADATA.DATASET_COLUMN.column_name IS 'Logical column/field name.';
COMMENT ON COLUMN METADATA.DATASET_COLUMN.data_type IS 'Logical/physical datatype description.';
COMMENT ON COLUMN METADATA.DATASET_COLUMN.length_precision_scale IS 'Length, precision, and scale definition when applicable.';
COMMENT ON COLUMN METADATA.DATASET_COLUMN.is_nullable IS 'Y when NULL values are allowed.';
COMMENT ON COLUMN METADATA.DATASET_COLUMN.is_pii IS 'Y when the field contains personally identifiable information.';

CREATE TABLE METADATA.TASK (
    config_release_id NUMBER(19) NOT NULL,
    task_id NUMBER(19) NOT NULL,
    task_code VARCHAR2(100) NOT NULL,
    task_type VARCHAR2(20) NOT NULL,
    source_config_id NUMBER(19),
    task_name VARCHAR2(200) NOT NULL,
    task_description VARCHAR2(1000),
    close_batch_on_success CHAR(1) DEFAULT 'N' NOT NULL,
    CONSTRAINT PK_TASK PRIMARY KEY (config_release_id, task_id),
    CONSTRAINT UQ_TASK_CODE UNIQUE (config_release_id, task_code),
    CONSTRAINT CK_TASK_1 CHECK (task_type IN ('INGESTION','TRANSFORMATION','OUTBOUND')),
    CONSTRAINT CK_TASK_3 CHECK (((task_type='INGESTION' AND source_config_id IS NOT NULL) OR (task_type IN ('TRANSFORMATION','OUTBOUND') AND source_config_id IS NULL))),
    CONSTRAINT CK_TASK_4 CHECK (close_batch_on_success IN ('Y','N')),
    CONSTRAINT FK_TASK_1 FOREIGN KEY (config_release_id) REFERENCES METADATA.CONFIG_RELEASE (config_release_id),
    CONSTRAINT FK_TASK_2 FOREIGN KEY (config_release_id, source_config_id) REFERENCES METADATA.SOURCE_CONFIG (config_release_id, source_config_id)
);

COMMENT ON TABLE METADATA.TASK IS 'Defines an executable ingestion, transformation, or outbound task within its CONFIG_RELEASE pipeline.';
COMMENT ON COLUMN METADATA.TASK.config_release_id IS 'Pipeline-scoped release identifier.';
COMMENT ON COLUMN METADATA.TASK.task_id IS 'Release-specific task identifier.';
COMMENT ON COLUMN METADATA.TASK.task_code IS 'Stable logical task identity across releases.';
COMMENT ON COLUMN METADATA.TASK.task_type IS 'INGESTION, TRANSFORMATION, or OUTBOUND.';
COMMENT ON COLUMN METADATA.TASK.source_config_id IS 'External source configuration for INGESTION; NULL otherwise.';
COMMENT ON COLUMN METADATA.TASK.task_name IS 'Human-readable task name.';
COMMENT ON COLUMN METADATA.TASK.task_description IS 'Task purpose/scope.';
COMMENT ON COLUMN METADATA.TASK.close_batch_on_success IS 'Y when successful completion of this task atomically completes the batch; at most one task per release may be Y.';

CREATE UNIQUE INDEX METADATA.UIX_TASK_ONE_BATCH_CLOSER
    ON METADATA.TASK (CASE WHEN close_batch_on_success='Y' THEN config_release_id END);

CREATE TABLE METADATA.TASK_DATASET (
    config_release_id NUMBER(19) NOT NULL,
    task_dataset_id NUMBER(19) NOT NULL,
    task_id NUMBER(19) NOT NULL,
    dataset_id NUMBER(19) NOT NULL,
    dataset_role VARCHAR2(10) NOT NULL,
    is_required CHAR(1) DEFAULT 'Y' NOT NULL,
    usage_sequence NUMBER(10),
    is_enabled CHAR(1) DEFAULT 'Y' NOT NULL,
    CONSTRAINT PK_TASK_DATASET PRIMARY KEY (config_release_id, task_dataset_id),
    CONSTRAINT UQ_TASK_DATASET_ROLE UNIQUE (config_release_id, task_id, dataset_id, dataset_role),
    CONSTRAINT CK_TASK_DATASET_1 CHECK (dataset_role IN ('INPUT','OUTPUT')),
    CONSTRAINT CK_TASK_DATASET_2 CHECK (is_required IN ('Y','N')),
    CONSTRAINT CK_TASK_DATASET_3 CHECK (is_enabled IN ('Y','N')),
    CONSTRAINT FK_TASK_DATASET_1 FOREIGN KEY (config_release_id, task_id) REFERENCES METADATA.TASK (config_release_id, task_id),
    CONSTRAINT FK_TASK_DATASET_2 FOREIGN KEY (config_release_id, dataset_id) REFERENCES METADATA.DATASET (config_release_id, dataset_id)
);

COMMENT ON TABLE METADATA.TASK_DATASET IS 'Defines planned task-to-dataset INPUT/OUTPUT lineage.';
COMMENT ON COLUMN METADATA.TASK_DATASET.config_release_id IS 'Release identifier.';
COMMENT ON COLUMN METADATA.TASK_DATASET.task_dataset_id IS 'Release-specific relationship identifier.';
COMMENT ON COLUMN METADATA.TASK_DATASET.task_id IS 'Task consuming or producing the dataset.';
COMMENT ON COLUMN METADATA.TASK_DATASET.dataset_id IS 'Dataset consumed or produced.';
COMMENT ON COLUMN METADATA.TASK_DATASET.dataset_role IS 'INPUT or OUTPUT.';
COMMENT ON COLUMN METADATA.TASK_DATASET.is_required IS 'Y when the relationship is required.';
COMMENT ON COLUMN METADATA.TASK_DATASET.usage_sequence IS 'Order within a task role; Parquet-to-RAW INPUT/OUTPUT pairs use matching unique positive usage_sequence values.';
COMMENT ON COLUMN METADATA.TASK_DATASET.is_enabled IS 'Y when the relationship is enabled.';


CREATE TABLE METADATA.TASK_STEP (
    config_release_id NUMBER(19) NOT NULL,
    task_step_id NUMBER(19) NOT NULL,
    task_id NUMBER(19) NOT NULL,
    step_code VARCHAR2(100) NOT NULL,
    step_sequence_number NUMBER(10) NOT NULL,
    step_name VARCHAR2(200) NOT NULL,
    step_type VARCHAR2(50) NOT NULL,
    parameter_json CLOB,
    is_required CHAR(1) DEFAULT 'Y' NOT NULL,
    on_failure_action VARCHAR2(30) DEFAULT 'FAIL_TASK' NOT NULL,
    CONSTRAINT PK_TASK_STEP PRIMARY KEY (config_release_id, task_step_id),
    CONSTRAINT UQ_TASK_STEP_CODE UNIQUE (config_release_id, task_id, step_code),
    CONSTRAINT UQ_TASK_STEP_SEQUENCE UNIQUE (config_release_id, task_id, step_sequence_number),
    CONSTRAINT CK_TASK_STEP_1 CHECK (step_sequence_number > 0),
    CONSTRAINT CK_TASK_STEP_2 CHECK (is_required IN ('Y','N')),
    CONSTRAINT CK_TASK_STEP_TYPE CHECK (step_type IN ('BUILTIN','CUSTOM_PYTHON')),
    CONSTRAINT CK_STEP_REQUIRED_SKIP CHECK (is_required='N' OR on_failure_action <> 'SKIP_STEP'),
    CONSTRAINT CK_TASK_STEP_6 CHECK (on_failure_action IN ('FAIL_TASK','SKIP_STEP','QUARANTINE')),
    CONSTRAINT CK_TASK_STEP_7 CHECK (parameter_json IS JSON),
    CONSTRAINT FK_TASK_STEP_1 FOREIGN KEY (config_release_id, task_id) REFERENCES METADATA.TASK (config_release_id, task_id)
);

COMMENT ON TABLE METADATA.TASK_STEP IS 'Defines ordered internal operations within a task; step results stay in memory and scheduler owns retries/timeouts.';
COMMENT ON COLUMN METADATA.TASK_STEP.config_release_id IS 'Release identifier.';
COMMENT ON COLUMN METADATA.TASK_STEP.task_step_id IS 'Release-specific step identifier.';
COMMENT ON COLUMN METADATA.TASK_STEP.task_id IS 'Task owning the step.';
COMMENT ON COLUMN METADATA.TASK_STEP.step_code IS 'Stable step code within the task.';
COMMENT ON COLUMN METADATA.TASK_STEP.step_sequence_number IS 'Sequential execution order.';
COMMENT ON COLUMN METADATA.TASK_STEP.step_name IS 'Human-readable step name.';
COMMENT ON COLUMN METADATA.TASK_STEP.step_type IS 'BUILTIN resolves an explicit framework handler; CUSTOM_PYTHON resolves a function registered by the notebook.';
COMMENT ON COLUMN METADATA.TASK_STEP.parameter_json IS 'Step-specific parameters, including file-format details.';
COMMENT ON COLUMN METADATA.TASK_STEP.is_required IS 'Y when the step is required for task success.';
COMMENT ON COLUMN METADATA.TASK_STEP.on_failure_action IS 'FAIL_TASK (default), QUARANTINE, or optional SKIP_STEP. Batch failure remains a scheduler decision.';

CREATE TABLE METADATA.MAPPING_RULE (
    config_release_id NUMBER(19) NOT NULL,
    mapping_rule_id NUMBER(19) NOT NULL,
    task_id NUMBER(19) NOT NULL,
    source_dataset_id NUMBER(19) NOT NULL,
    target_dataset_id NUMBER(19) NOT NULL,
    source_column_name VARCHAR2(200),
    target_column_name VARCHAR2(200) NOT NULL,
    mapping_rule_type VARCHAR2(30) NOT NULL,
    mapping_expression VARCHAR2(4000),
    condition_expression VARCHAR2(4000),
    default_value VARCHAR2(4000),
    rule_sequence NUMBER(10) NOT NULL,
    is_enabled CHAR(1) DEFAULT 'Y' NOT NULL,
    CONSTRAINT PK_MAPPING_RULE PRIMARY KEY (config_release_id, mapping_rule_id),
    CONSTRAINT CK_MAPPING_RULE_1 CHECK (mapping_rule_type IN ('DIRECT_MAP','CAST','TRIM','DEFAULT','CONCAT','LOOKUP','CONDITIONAL','MASKING','DERIVATION')),
    CONSTRAINT CK_MAPPING_RULE_2 CHECK (rule_sequence > 0),
    CONSTRAINT CK_MAPPING_RULE_4 CHECK (is_enabled IN ('Y','N')),
    CONSTRAINT FK_MAPPING_RULE_1 FOREIGN KEY (config_release_id, task_id) REFERENCES METADATA.TASK (config_release_id, task_id),
    CONSTRAINT FK_MAPPING_RULE_2 FOREIGN KEY (config_release_id, source_dataset_id) REFERENCES METADATA.DATASET (config_release_id, dataset_id),
    CONSTRAINT FK_MAPPING_RULE_3 FOREIGN KEY (config_release_id, target_dataset_id) REFERENCES METADATA.DATASET (config_release_id, dataset_id),
    CONSTRAINT FK_MAPPING_RULE_4 FOREIGN KEY (config_release_id, source_dataset_id, source_column_name) REFERENCES METADATA.DATASET_COLUMN (config_release_id, dataset_id, column_name),
    CONSTRAINT FK_MAPPING_RULE_5 FOREIGN KEY (config_release_id, target_dataset_id, target_column_name) REFERENCES METADATA.DATASET_COLUMN (config_release_id, dataset_id, column_name)
);

COMMENT ON TABLE METADATA.MAPPING_RULE IS 'Defines simple declarative source-to-target column transformations.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.config_release_id IS 'Release identifier.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.mapping_rule_id IS 'Release-specific mapping identifier.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.task_id IS 'Task owning/executing the mapping.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.source_dataset_id IS 'Source dataset; replaces source_dataset_schema_id.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.target_dataset_id IS 'Target dataset; replaces target_dataset_schema_id.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.source_column_name IS 'Source column used by the rule; may be NULL for defaults/derived expressions.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.target_column_name IS 'Target column populated by the rule.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.mapping_rule_type IS 'DIRECT_MAP, CAST, TRIM, DEFAULT, CONCAT, LOOKUP, CONDITIONAL, MASKING, or DERIVATION.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.mapping_expression IS 'Adapter-owned transformation expression, including lookup or masking definitions when those rule types are used.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.condition_expression IS 'Conditional predicate when applicable.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.default_value IS 'Default/fallback value.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.rule_sequence IS 'Mapping execution/order position.';
COMMENT ON COLUMN METADATA.MAPPING_RULE.is_enabled IS 'Y when the mapping is enabled. Every enabled rule is required; adapters must raise on unsupported or failed mappings.';

CREATE TABLE METADATA.OUTBOUND_CONFIG (
    config_release_id NUMBER(19) NOT NULL,
    outbound_config_id NUMBER(19) NOT NULL,
    outbound_config_code VARCHAR2(100) NOT NULL,
    task_id NUMBER(19) NOT NULL,
    destination_type VARCHAR2(20) NOT NULL,
    connection_reference VARCHAR2(500) NOT NULL,
    destination_name VARCHAR2(200) NOT NULL,
    destination_path VARCHAR2(1000),
    file_name_pattern VARCHAR2(500),
    compression_type VARCHAR2(20) DEFAULT 'NONE',
    encryption_type VARCHAR2(20) DEFAULT 'NONE',
    encryption_key_reference VARCHAR2(500),
    generate_manifest CHAR(1) DEFAULT 'N' NOT NULL,
    manifest_name_pattern VARCHAR2(500),
    target_database_object VARCHAR2(500),
    write_mode VARCHAR2(20),
    is_acknowledgement_required CHAR(1) DEFAULT 'N' NOT NULL,
    acknowledgement_type VARCHAR2(30),
    CONSTRAINT PK_OUTBOUND_CONFIG PRIMARY KEY (config_release_id, outbound_config_id),
    CONSTRAINT UQ_OUTBOUND_CODE UNIQUE (config_release_id, outbound_config_code),
    CONSTRAINT UQ_OUTBOUND_TASK UNIQUE (config_release_id, task_id),
    CONSTRAINT CK_OUTBOUND_CONFIG_1 CHECK (destination_type IN ('FILE','DATABASE')),
    CONSTRAINT CK_OUTBOUND_CONFIG_2 CHECK (compression_type IS NULL OR compression_type IN ('NONE','ZIP','GZIP')),
    CONSTRAINT CK_OUTBOUND_CONFIG_3 CHECK (encryption_type IS NULL OR encryption_type IN ('NONE','PGP')),
    CONSTRAINT CK_OUTBOUND_CONFIG_4 CHECK (generate_manifest IN ('Y','N')),
    CONSTRAINT CK_OUTBOUND_CONFIG_5 CHECK (is_acknowledgement_required IN ('Y','N')),
    CONSTRAINT CK_OUTBOUND_CONFIG_6 CHECK (acknowledgement_type IS NULL OR acknowledgement_type IN ('FILE_RECEIPT','REMOTE_FILE','DATABASE_COMMIT','CUSTOM')),
    CONSTRAINT CK_OUTBOUND_CONFIG_7 CHECK (write_mode IS NULL OR write_mode IN ('INSERT','UPSERT','REPLACE','APPEND')),
    CONSTRAINT CK_OUTBOUND_CONFIG_8 CHECK (((destination_type='FILE' AND destination_path IS NOT NULL AND file_name_pattern IS NOT NULL) OR (destination_type='DATABASE' AND target_database_object IS NOT NULL))),
    CONSTRAINT CK_OUTBOUND_CONFIG_9 CHECK (((is_acknowledgement_required='N') OR (is_acknowledgement_required='Y' AND acknowledgement_type IS NOT NULL))),
    CONSTRAINT FK_OUTBOUND_CONFIG_1 FOREIGN KEY (config_release_id, task_id) REFERENCES METADATA.TASK (config_release_id, task_id)
);

COMMENT ON TABLE METADATA.OUTBOUND_CONFIG IS 'Defines how Gold-derived outbound data is packaged and delivered externally.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.config_release_id IS 'Release identifier.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.outbound_config_id IS 'Release-specific outbound configuration identifier.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.outbound_config_code IS 'Stable logical outbound configuration code.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.task_id IS 'OUTBOUND task owning this delivery configuration.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.destination_type IS 'FILE or DATABASE for MVP.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.connection_reference IS 'Destination connection/credential reference; stores a reference, not secrets.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.destination_name IS 'Business/technical destination name.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.destination_path IS 'File/SFTP/object-storage destination path.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.file_name_pattern IS 'Metadata-driven output filename pattern.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.compression_type IS 'NONE, ZIP, GZIP, etc.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.encryption_type IS 'NONE, PGP, or other approved mechanism.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.encryption_key_reference IS 'Public-key/key-management reference.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.generate_manifest IS 'Y when a manifest/control file must be generated.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.manifest_name_pattern IS 'Filename pattern for the manifest/control file.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.target_database_object IS 'Destination database object for database publishing.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.write_mode IS 'INSERT, UPSERT, REPLACE, or APPEND for database publishing.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.is_acknowledgement_required IS 'Y when delivery acknowledgement is required.';
COMMENT ON COLUMN METADATA.OUTBOUND_CONFIG.acknowledgement_type IS 'FILE_RECEIPT, REMOTE_FILE, DATABASE_COMMIT, or CUSTOM.';

CREATE TABLE METADATA.POLICY_DEFINITION (
    config_release_id NUMBER(19) NOT NULL,
    policy_id NUMBER(19) NOT NULL,
    policy_code VARCHAR2(100) NOT NULL,
    policy_name VARCHAR2(200) NOT NULL,
    policy_type VARCHAR2(40) NOT NULL,
    policy_scope_type VARCHAR2(30) NOT NULL,
    task_id NUMBER(19),
    dataset_id NUMBER(19),
    dataset_column_id NUMBER(19),
    source_config_id NUMBER(19),
    outbound_config_id NUMBER(19),
    policy_severity VARCHAR2(20) NOT NULL,
    threshold_value VARCHAR2(200),
    parameter_json CLOB,
    failure_action VARCHAR2(30) DEFAULT 'WARN' NOT NULL,
    is_enabled CHAR(1) DEFAULT 'Y' NOT NULL,
    CONSTRAINT PK_POLICY_DEFINITION PRIMARY KEY (config_release_id, policy_id),
    CONSTRAINT UQ_POLICY_CODE UNIQUE (config_release_id, policy_code),
    CONSTRAINT CK_POLICY_DEFINITION_1 CHECK (policy_type IN ('DQ','ABC','RECONCILIATION','SLA','SCHEMA_VALIDATION','COUNT_CHECK','THRESHOLD','WATERMARK','NOTIFICATION','ERROR_HANDLING','OUTBOUND_VALIDATION')),
    CONSTRAINT CK_POLICY_DEFINITION_2 CHECK (policy_scope_type IN ('BATCH','TASK','DATASET','DATASET_COLUMN','SOURCE','OUTBOUND')),
    CONSTRAINT CK_POLICY_DEFINITION_3 CHECK (policy_severity IN ('INFO','WARN','ERROR','CRITICAL')),
    CONSTRAINT CK_POLICY_DEFINITION_4 CHECK (failure_action IN ('WARN','FAIL_TASK','QUARANTINE','CREATE_WORK_ITEM')),
    CONSTRAINT CK_POLICY_DEFINITION_6 CHECK (is_enabled IN ('Y','N')),
    CONSTRAINT CK_POLICY_DEFINITION_7 CHECK (parameter_json IS JSON),
    CONSTRAINT CK_POLICY_DEFINITION_8 CHECK (
        (policy_scope_type='BATCH' AND task_id IS NULL AND dataset_id IS NULL AND dataset_column_id IS NULL AND source_config_id IS NULL AND outbound_config_id IS NULL)
        OR (policy_scope_type='TASK' AND task_id IS NOT NULL AND dataset_id IS NULL AND dataset_column_id IS NULL AND source_config_id IS NULL AND outbound_config_id IS NULL)
        OR (policy_scope_type='DATASET' AND task_id IS NULL AND dataset_id IS NOT NULL AND dataset_column_id IS NULL AND source_config_id IS NULL AND outbound_config_id IS NULL)
        OR (policy_scope_type='DATASET_COLUMN' AND task_id IS NULL AND dataset_id IS NOT NULL AND dataset_column_id IS NOT NULL AND source_config_id IS NULL AND outbound_config_id IS NULL)
        OR (policy_scope_type='SOURCE' AND task_id IS NULL AND dataset_id IS NULL AND dataset_column_id IS NULL AND source_config_id IS NOT NULL AND outbound_config_id IS NULL)
        OR (policy_scope_type='OUTBOUND' AND task_id IS NULL AND dataset_id IS NULL AND dataset_column_id IS NULL AND source_config_id IS NULL AND outbound_config_id IS NOT NULL)
    ),
    CONSTRAINT FK_POLICY_DEFINITION_1 FOREIGN KEY (config_release_id, task_id) REFERENCES METADATA.TASK (config_release_id, task_id),
    CONSTRAINT FK_POLICY_DEFINITION_3 FOREIGN KEY (config_release_id, dataset_id) REFERENCES METADATA.DATASET (config_release_id, dataset_id),
    CONSTRAINT FK_POLICY_DEFINITION_4 FOREIGN KEY (config_release_id, dataset_id, dataset_column_id) REFERENCES METADATA.DATASET_COLUMN (config_release_id, dataset_id, dataset_column_id),
    CONSTRAINT FK_POLICY_DEFINITION_5 FOREIGN KEY (config_release_id, source_config_id) REFERENCES METADATA.SOURCE_CONFIG (config_release_id, source_config_id),
    CONSTRAINT FK_POLICY_DEFINITION_6 FOREIGN KEY (config_release_id, outbound_config_id) REFERENCES METADATA.OUTBOUND_CONFIG (config_release_id, outbound_config_id)
);

COMMENT ON TABLE METADATA.POLICY_DEFINITION IS 'Defines DQ, SLA, reconciliation, notification, watermark, error-handling, schema-validation, and outbound-validation policies.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.config_release_id IS 'Release identifier.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.policy_id IS 'Release-specific policy identifier.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.policy_code IS 'Stable logical policy code.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.policy_name IS 'Human-readable policy name.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.policy_type IS 'Policy category.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.policy_scope_type IS 'BATCH, TASK, DATASET, DATASET_COLUMN, SOURCE, or OUTBOUND.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.task_id IS 'Task-level scope.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.dataset_id IS 'Dataset-level scope and parent dataset for DATASET_COLUMN scope.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.dataset_column_id IS 'Column-level scope; references the owning dataset and DATASET_COLUMN together.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.source_config_id IS 'Source-level scope.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.outbound_config_id IS 'Outbound delivery scope.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.policy_severity IS 'INFO, WARN, ERROR, or CRITICAL.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.threshold_value IS 'Numeric/count/time/SLA threshold represented as text and interpreted by policy type.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.parameter_json IS 'Additional structured policy parameters.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.failure_action IS 'WARN, FAIL_TASK, QUARANTINE, or CREATE_WORK_ITEM. Batch failure remains a scheduler decision.';
COMMENT ON COLUMN METADATA.POLICY_DEFINITION.is_enabled IS 'Y when policy is enabled.';

-- Direct owner privileges required before dependent foreign keys.
GRANT REFERENCES ON METADATA.CONFIG_RELEASE TO RUNTIME;

CREATE TABLE RUNTIME.BATCH (
    batch_id NUMBER(19) NOT NULL,
    config_release_id NUMBER(19) NOT NULL,
    pipeline_code VARCHAR2(100) NOT NULL,
    batch_type VARCHAR2(20) NOT NULL,
    cycle_date DATE NOT NULL,
    execution_key VARCHAR2(300) NOT NULL,
    application_version VARCHAR2(100),
    correlation_id VARCHAR2(200) NOT NULL,
    orchestrator_run_id VARCHAR2(200),
    status VARCHAR2(40) NOT NULL,
    start_timestamp TIMESTAMP(6) WITH TIME ZONE,
    end_timestamp TIMESTAMP(6) WITH TIME ZONE,
    triggered_by VARCHAR2(100) NOT NULL,
    original_batch_id NUMBER(19),
    CONSTRAINT UQ_BATCH_PIPE_ID UNIQUE (batch_id, pipeline_code),
    CONSTRAINT PK_BATCH PRIMARY KEY (batch_id),
    CONSTRAINT UQ_BATCH_RELEASE UNIQUE (batch_id, config_release_id),
    CONSTRAINT UQ_BATCH_EXECUTION UNIQUE (pipeline_code, execution_key),
    CONSTRAINT UQ_BATCH_CORRELATION UNIQUE (correlation_id),
    CONSTRAINT CK_BATCH_ORIGIN CHECK ((batch_type='REPROCESS' AND original_batch_id IS NOT NULL) OR (batch_type<>'REPROCESS' AND original_batch_id IS NULL)),
    CONSTRAINT CK_BATCH_1 CHECK (batch_type IN ('SCHEDULED','MANUAL','REPROCESS')),
    CONSTRAINT CK_BATCH_2 CHECK (status IN ('RUNNING','COMPLETED','COMPLETED_WITH_WARNINGS','FAILED')),
    CONSTRAINT CK_BATCH_3 CHECK (end_timestamp IS NULL OR start_timestamp IS NULL OR end_timestamp >= start_timestamp),
    CONSTRAINT FK_BATCH_1 FOREIGN KEY (config_release_id, pipeline_code) REFERENCES METADATA.CONFIG_RELEASE (config_release_id, pipeline_code),
    CONSTRAINT FK_BATCH_2 FOREIGN KEY (original_batch_id) REFERENCES RUNTIME.BATCH (batch_id)
);

COMMENT ON TABLE RUNTIME.BATCH IS 'Authoritative runtime execution record for one pipeline execution. batch_id is framework-generated.';
COMMENT ON COLUMN RUNTIME.BATCH.batch_id IS 'Framework-generated runtime batch identifier.';
COMMENT ON COLUMN RUNTIME.BATCH.config_release_id IS 'Pipeline metadata release pinned exactly once at batch creation.';
COMMENT ON COLUMN RUNTIME.BATCH.pipeline_code IS 'Stable logical pipeline code.';
COMMENT ON COLUMN RUNTIME.BATCH.batch_type IS 'SCHEDULED, MANUAL, or REPROCESS (REBUILD normalizes to REPROCESS).';
COMMENT ON COLUMN RUNTIME.BATCH.cycle_date IS 'Logical processing/cycle date.';
COMMENT ON COLUMN RUNTIME.BATCH.execution_key IS 'Unique execution correlation key within the pipeline.';
COMMENT ON COLUMN RUNTIME.BATCH.application_version IS 'Optional deployed application/code version.';
COMMENT ON COLUMN RUNTIME.BATCH.correlation_id IS 'Framework-generated end-to-end correlation identifier.';
COMMENT ON COLUMN RUNTIME.BATCH.orchestrator_run_id IS 'Optional scheduler/Data Platform workflow run identifier.';
COMMENT ON COLUMN RUNTIME.BATCH.status IS 'RUNNING, COMPLETED, COMPLETED_WITH_WARNINGS, or FAILED.';
COMMENT ON COLUMN RUNTIME.BATCH.start_timestamp IS 'Execution start timestamp.';
COMMENT ON COLUMN RUNTIME.BATCH.end_timestamp IS 'Execution end timestamp.';
COMMENT ON COLUMN RUNTIME.BATCH.triggered_by IS 'Scheduler/service/operator that started the execution.';
COMMENT ON COLUMN RUNTIME.BATCH.original_batch_id IS 'Original terminal batch for scheduler-triggered REPROCESS.';
CREATE INDEX RUNTIME.IX_BATCH_PIPE_CYCLE ON RUNTIME.BATCH (pipeline_code, cycle_date, batch_type, status);
CREATE INDEX RUNTIME.IX_BATCH_ORCH_RUN ON RUNTIME.BATCH (pipeline_code, orchestrator_run_id);

-- Direct owner privileges required before dependent foreign keys.
GRANT REFERENCES ON METADATA.TASK TO RUNTIME;

CREATE TABLE RUNTIME.TASK_RUN (
    task_run_id NUMBER(19) NOT NULL,
    batch_id NUMBER(19) NOT NULL,
    config_release_id NUMBER(19) NOT NULL,
    task_id NUMBER(19) NOT NULL,
    attempt_number NUMBER(5) DEFAULT 1 NOT NULL,
    orchestrator_task_run_id VARCHAR2(200),
    orchestrator_attempt_number NUMBER(10),
    status VARCHAR2(40) NOT NULL,
    start_timestamp TIMESTAMP(6) WITH TIME ZONE,
    end_timestamp TIMESTAMP(6) WITH TIME ZONE,
    original_task_run_id NUMBER(19),
    error_code VARCHAR2(100),
    error_message VARCHAR2(4000),
    failed_step_code VARCHAR2(100),
    input_count NUMBER(19),
    output_count NUMBER(19),
    reject_count NUMBER(19),
    CONSTRAINT UQ_TASK_RUN_BATCH_RELEASE UNIQUE (task_run_id, batch_id, config_release_id),
    CONSTRAINT PK_TASK_RUN PRIMARY KEY (task_run_id),
    CONSTRAINT UQ_TASK_RUN_RELEASE UNIQUE (task_run_id, config_release_id),
    CONSTRAINT UQ_TASK_RUN_ATTEMPT UNIQUE (batch_id, task_id, attempt_number),
    CONSTRAINT CK_TASK_RUN_1 CHECK (status IN ('RUNNING','COMPLETED','COMPLETED_WITH_WARNINGS','FAILED')),
    CONSTRAINT CK_TASK_RUN_2 CHECK (end_timestamp IS NULL OR start_timestamp IS NULL OR end_timestamp >= start_timestamp),
    CONSTRAINT CK_TASK_RUN_3 CHECK (input_count IS NULL OR input_count >= 0),
    CONSTRAINT CK_TASK_RUN_4 CHECK (output_count IS NULL OR output_count >= 0),
    CONSTRAINT CK_TASK_RUN_5 CHECK (reject_count IS NULL OR reject_count >= 0),
    CONSTRAINT CK_TASK_RUN_6 CHECK (attempt_number > 0),
    CONSTRAINT CK_TASK_RUN_ORCH_ATTEMPT CHECK (orchestrator_attempt_number IS NULL OR
        (orchestrator_attempt_number > 0 AND orchestrator_task_run_id IS NOT NULL)),
    CONSTRAINT FK_TASK_RUN_1 FOREIGN KEY (batch_id, config_release_id) REFERENCES RUNTIME.BATCH (batch_id, config_release_id),
    CONSTRAINT FK_TASK_RUN_2 FOREIGN KEY (config_release_id, task_id) REFERENCES METADATA.TASK (config_release_id, task_id),
    CONSTRAINT FK_TASK_RUN_3 FOREIGN KEY (original_task_run_id) REFERENCES RUNTIME.TASK_RUN (task_run_id)
);

COMMENT ON TABLE RUNTIME.TASK_RUN IS 'Stores one immutable task run attempt within a batch.';
COMMENT ON COLUMN RUNTIME.TASK_RUN.task_run_id IS 'Unique task run identifier.';
COMMENT ON COLUMN RUNTIME.TASK_RUN.batch_id IS 'Owning batch.';
COMMENT ON COLUMN RUNTIME.TASK_RUN.config_release_id IS 'Pinned release inherited from the batch.';
COMMENT ON COLUMN RUNTIME.TASK_RUN.task_id IS 'Configured task.';
COMMENT ON COLUMN RUNTIME.TASK_RUN.attempt_number IS 'Task attempt within the running batch. Scheduler retry creates a new attempt.';
COMMENT ON COLUMN RUNTIME.TASK_RUN.orchestrator_task_run_id IS 'External scheduler task-run identity, such as AIDP task.run_id; does not replace the MDPF run_id.';
COMMENT ON COLUMN RUNTIME.TASK_RUN.orchestrator_attempt_number IS 'Optional external execution count, such as AIDP task.execution_count; independent of the MDPF attempt number.';
COMMENT ON COLUMN RUNTIME.TASK_RUN.status IS 'RUNNING, COMPLETED, COMPLETED_WITH_WARNINGS, or FAILED.';
COMMENT ON COLUMN RUNTIME.TASK_RUN.original_task_run_id IS 'Previous failed task attempt in the same batch.';
CREATE INDEX RUNTIME.IX_TASK_RUN_BATCH ON RUNTIME.TASK_RUN (batch_id, task_id, attempt_number, status);
CREATE INDEX RUNTIME.IX_TASK_RUN_ORCH ON RUNTIME.TASK_RUN (batch_id, orchestrator_task_run_id, orchestrator_attempt_number);

CREATE OR REPLACE TRIGGER RUNTIME.TRG_TASK_RUN_TERMINAL_IMM
BEFORE UPDATE OR DELETE ON RUNTIME.TASK_RUN
FOR EACH ROW
BEGIN
    IF UPDATING AND :OLD.status IN ('COMPLETED','COMPLETED_WITH_WARNINGS','FAILED') THEN
        RAISE_APPLICATION_ERROR(-20087, 'Terminal TASK_RUN rows are immutable.');
    ELSIF DELETING AND :OLD.status IN ('COMPLETED','COMPLETED_WITH_WARNINGS','FAILED') THEN
        RAISE_APPLICATION_ERROR(-20088, 'Terminal TASK_RUN rows are immutable.');
    END IF;
END;
/

-- Direct owner privileges required before dependent foreign keys.
GRANT REFERENCES ON METADATA.SOURCE_CONFIG TO RUNTIME;
GRANT REFERENCES ON METADATA.DATASET TO RUNTIME;

CREATE TABLE RUNTIME.INGESTION_ITEM (
    ingestion_item_id NUMBER(19) NOT NULL,
    task_run_id NUMBER(19) NOT NULL,
    config_release_id NUMBER(19) NOT NULL,
    source_config_id NUMBER(19) NOT NULL,
    dataset_id NUMBER(19),
    parent_ingestion_item_id NUMBER(19),
    item_role VARCHAR2(20) DEFAULT 'DATA' NOT NULL,
    ingestion_type VARCHAR2(20) NOT NULL,
    item_name VARCHAR2(500) NOT NULL,
    source_item_key VARCHAR2(500) NOT NULL,
    source_location VARCHAR2(1000),
    landing_location VARCHAR2(1000),
    archive_location VARCHAR2(1000),
    quarantine_location VARCHAR2(1000),
    checksum_value VARCHAR2(256),
    payload_size_bytes NUMBER(19),
    expected_record_count NUMBER(19),
    source_record_count NUMBER(19),
    received_timestamp TIMESTAMP(6) WITH TIME ZONE,
    processed_timestamp TIMESTAMP(6) WITH TIME ZONE,
    status VARCHAR2(30) NOT NULL,
    reject_file_path VARCHAR2(1000),
    original_ingestion_item_id NUMBER(19),
    replay_source_mode VARCHAR2(30),
    CONSTRAINT PK_INGESTION_ITEM PRIMARY KEY (ingestion_item_id),
    CONSTRAINT UQ_ING_ITEM_RELEASE UNIQUE (ingestion_item_id, config_release_id),
    CONSTRAINT UQ_ING_ITEM_SOURCE_KEY UNIQUE (task_run_id, source_item_key),
    CONSTRAINT CK_INGESTION_ITEM_1 CHECK (ingestion_type IN ('FILE','DATABASE','API','EVENT','STREAM')),
    CONSTRAINT CK_INGESTION_ITEM_2 CHECK (status IN ('EXPECTED','RECEIVED','LANDED','VALIDATED','PROCESSING','QUARANTINED','PROCESSED','FAILED')),
    CONSTRAINT CK_INGESTION_ITEM_3 CHECK (replay_source_mode IS NULL OR replay_source_mode IN ('PRESERVED_ARTIFACT','SOURCE_REEXTRACT','MANUAL_UPLOAD','RECONSTRUCTED_PAYLOAD')),
    CONSTRAINT CK_INGESTION_ITEM_4 CHECK (payload_size_bytes IS NULL OR payload_size_bytes >= 0),
    CONSTRAINT CK_INGESTION_ITEM_5 CHECK (source_record_count IS NULL OR source_record_count >= 0),
    CONSTRAINT CK_INGESTION_ITEM_7 CHECK (expected_record_count IS NULL OR expected_record_count >= 0),
    CONSTRAINT CK_INGESTION_ITEM_8 CHECK (item_role IN ('PACKAGE','DATA')),
    CONSTRAINT CK_INGESTION_ITEM_9 CHECK ((item_role='PACKAGE' AND dataset_id IS NULL) OR (item_role='DATA' AND dataset_id IS NOT NULL)),
    CONSTRAINT FK_INGESTION_ITEM_1 FOREIGN KEY (task_run_id, config_release_id) REFERENCES RUNTIME.TASK_RUN (task_run_id, config_release_id),
    CONSTRAINT FK_INGESTION_ITEM_2 FOREIGN KEY (config_release_id, source_config_id) REFERENCES METADATA.SOURCE_CONFIG (config_release_id, source_config_id),
    CONSTRAINT FK_INGESTION_ITEM_3 FOREIGN KEY (config_release_id, dataset_id) REFERENCES METADATA.DATASET (config_release_id, dataset_id),
    CONSTRAINT FK_INGESTION_ITEM_4 FOREIGN KEY (original_ingestion_item_id) REFERENCES RUNTIME.INGESTION_ITEM (ingestion_item_id),
    CONSTRAINT FK_INGESTION_ITEM_5 FOREIGN KEY (parent_ingestion_item_id) REFERENCES RUNTIME.INGESTION_ITEM (ingestion_item_id)
);

COMMENT ON TABLE RUNTIME.INGESTION_ITEM IS 'Records external input evidence such as a file, database extract, API payload, event batch, or stream range.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.ingestion_item_id IS 'Runtime ingestion item identifier.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.task_run_id IS 'Parent INGESTION task run.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.config_release_id IS 'Metadata release; must match parent task run.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.source_config_id IS 'Source configuration used.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.dataset_id IS 'Inbound/RAW dataset receiving a DATA item; NULL for PACKAGE items.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.parent_ingestion_item_id IS 'Parent PACKAGE item for DATA members; NULL for standalone files and PACKAGE items.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.item_role IS 'PACKAGE for the inbound archive itself; DATA for a loadable member/standalone input.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.ingestion_type IS 'FILE, DATABASE, API, EVENT, or STREAM.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.item_name IS 'Filename, extract ID, request ID, event-batch ID, or stream-range identifier.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.source_item_key IS 'POC hashes pipeline, logical source, dataset code and the resolved immutable delivery URI. Stable across Repair; excludes attempt IDs, transient paths and checksums.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.source_location IS 'Original source location.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.landing_location IS 'Runtime landing location.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.archive_location IS 'Preserved/archive location.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.quarantine_location IS 'Quarantine location.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.checksum_value IS 'Payload checksum/fingerprint.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.payload_size_bytes IS 'Payload size in bytes.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.source_record_count IS 'Source record count when available.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.received_timestamp IS 'Arrival/extract timestamp.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.processed_timestamp IS 'Initial processing completion timestamp.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.status IS 'EXPECTED, RECEIVED, LANDED, VALIDATED, PROCESSING, QUARANTINED, PROCESSED, or FAILED.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.reject_file_path IS 'Reject/evidence location; row-level rejects are not stored in framework tables.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.original_ingestion_item_id IS 'Prior ingestion item for replay lineage.';
COMMENT ON COLUMN RUNTIME.INGESTION_ITEM.replay_source_mode IS 'PRESERVED_ARTIFACT, SOURCE_REEXTRACT, MANUAL_UPLOAD, or RECONSTRUCTED_PAYLOAD.';
CREATE INDEX RUNTIME.IX_ING_ITEM_TASK ON RUNTIME.INGESTION_ITEM (task_run_id, status);
CREATE INDEX RUNTIME.IX_ING_ITEM_NAME ON RUNTIME.INGESTION_ITEM (item_name);
CREATE INDEX RUNTIME.IX_ING_ITEM_PARENT ON RUNTIME.INGESTION_ITEM (parent_ingestion_item_id, item_role, status);

-- Direct owner privileges required before dependent foreign keys.
GRANT REFERENCES ON METADATA.POLICY_DEFINITION TO RUNTIME;
GRANT REFERENCES ON METADATA.OUTBOUND_CONFIG TO RUNTIME;
GRANT REFERENCES ON METADATA.DATASET_COLUMN TO RUNTIME;

CREATE TABLE RUNTIME.POLICY_RESULT (
    policy_result_id NUMBER(19) NOT NULL,
    config_release_id NUMBER(19) NOT NULL,
    policy_id NUMBER(19) NOT NULL,
    batch_id NUMBER(19),
    task_run_id NUMBER(19),
    ingestion_item_id NUMBER(19),
    dataset_id NUMBER(19),
    dataset_column_id NUMBER(19),
    outbound_config_id NUMBER(19),
    result_level VARCHAR2(30) NOT NULL,
    result_status VARCHAR2(20) NOT NULL,
    expected_value VARCHAR2(4000),
    actual_value VARCHAR2(4000),
    threshold_value VARCHAR2(200),
    failed_record_count NUMBER(19),
    evidence_location VARCHAR2(1000),
    failure_action_taken VARCHAR2(40),
    waiver_reason VARCHAR2(1000),
    created_timestamp TIMESTAMP(6) WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT PK_POLICY_RESULT PRIMARY KEY (policy_result_id),
    CONSTRAINT CK_POLICY_RESULT_1 CHECK (result_level IN ('BATCH','TASK','DATASET','DATASET_COLUMN','INGESTION_ITEM','WATERMARK','OUTBOUND')),
    CONSTRAINT CK_POLICY_RESULT_2 CHECK (result_status IN ('PASS','WARN','FAIL','NOT_EVALUATED')),
    CONSTRAINT CK_POLICY_RESULT_4 CHECK (failed_record_count IS NULL OR failed_record_count >= 0),
    CONSTRAINT CK_POLICY_RESULT_5 CHECK (failure_action_taken IS NULL OR failure_action_taken IN ('WARNED','FAILED_TASK','QUARANTINED','WORK_ITEM_CREATED')),
    CONSTRAINT FK_POLICY_RESULT_1 FOREIGN KEY (config_release_id, policy_id) REFERENCES METADATA.POLICY_DEFINITION (config_release_id, policy_id),
    CONSTRAINT FK_POLICY_RESULT_2 FOREIGN KEY (batch_id, config_release_id) REFERENCES RUNTIME.BATCH (batch_id, config_release_id),
    CONSTRAINT FK_POLICY_RESULT_3 FOREIGN KEY (task_run_id, config_release_id) REFERENCES RUNTIME.TASK_RUN (task_run_id, config_release_id),
    CONSTRAINT FK_POLICY_RESULT_4 FOREIGN KEY (ingestion_item_id, config_release_id) REFERENCES RUNTIME.INGESTION_ITEM (ingestion_item_id, config_release_id),
    CONSTRAINT FK_POLICY_RESULT_6 FOREIGN KEY (config_release_id, dataset_id) REFERENCES METADATA.DATASET (config_release_id, dataset_id),
    CONSTRAINT FK_POLICY_RESULT_7 FOREIGN KEY (config_release_id, outbound_config_id) REFERENCES METADATA.OUTBOUND_CONFIG (config_release_id, outbound_config_id),
    CONSTRAINT FK_POLICY_RESULT_8 FOREIGN KEY (config_release_id, dataset_id, dataset_column_id) REFERENCES METADATA.DATASET_COLUMN (config_release_id, dataset_id, dataset_column_id)
);

COMMENT ON TABLE RUNTIME.POLICY_RESULT IS 'Records policy evaluation evidence at its configured batch, task, dataset, column, source-ingestion, or outbound scope.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.policy_result_id IS 'Policy result identifier.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.config_release_id IS 'Metadata release resolving the policy definition.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.policy_id IS 'Policy definition evaluated.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.batch_id IS 'Optional batch scope.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.task_run_id IS 'Optional task scope.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.ingestion_item_id IS 'Optional external-input scope.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.dataset_id IS 'Optional dataset scope.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.dataset_column_id IS 'Column scope; dataset and column are enforced as one metadata identity.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.outbound_config_id IS 'Optional outbound-delivery scope.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.result_level IS 'BATCH, TASK, DATASET, DATASET_COLUMN, INGESTION_ITEM, WATERMARK, or OUTBOUND.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.result_status IS 'PASS, WARN, FAIL, or NOT_EVALUATED.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.expected_value IS 'Expected value/count/state.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.actual_value IS 'Actual value/count/state.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.threshold_value IS 'Pinned policy threshold copied into the result; callers cannot override it.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.failed_record_count IS 'Number of failed records where applicable.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.evidence_location IS 'Supporting evidence or reject artifact location.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.failure_action_taken IS 'WARNED, FAILED_TASK, QUARANTINED, or WORK_ITEM_CREATED.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.waiver_reason IS 'Reason for a waived/not-evaluated result.';
COMMENT ON COLUMN RUNTIME.POLICY_RESULT.created_timestamp IS 'Result creation timestamp.';
CREATE INDEX RUNTIME.IX_POLICY_RESULT_POLICY ON RUNTIME.POLICY_RESULT (config_release_id, policy_id, result_status);
CREATE INDEX RUNTIME.IX_POLICY_RESULT_BATCH ON RUNTIME.POLICY_RESULT (batch_id, result_status);

CREATE TABLE RUNTIME.PIPELINE_STATE (
    pipeline_state_id NUMBER(19) NOT NULL,
    pipeline_code VARCHAR2(100) NOT NULL,
    task_code VARCHAR2(100) NOT NULL,
    config_release_id NUMBER(19) NOT NULL,
    state_type VARCHAR2(30) NOT NULL,
    state_key VARCHAR2(200) DEFAULT 'DEFAULT' NOT NULL,
    state_version NUMBER(19) NOT NULL,
    state_value VARCHAR2(4000) NOT NULL,
    is_current CHAR(1) DEFAULT 'Y' NOT NULL,
    updated_by_task_run_id NUMBER(19),
    updated_timestamp TIMESTAMP(6) WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    CONSTRAINT PK_PIPELINE_STATE PRIMARY KEY (pipeline_state_id),
    CONSTRAINT UQ_PIPELINE_STATE_VERSION UNIQUE (pipeline_code, task_code, state_type, state_key, state_version),
    CONSTRAINT CK_PIPELINE_STATE_1 CHECK (state_type IN ('WATERMARK','CHECKPOINT','LAST_SUCCESS')),
    CONSTRAINT CK_PIPELINE_STATE_2 CHECK (state_version > 0),
    CONSTRAINT CK_PIPELINE_STATE_3 CHECK (is_current IN ('Y','N')),
    CONSTRAINT FK_PIPELINE_STATE_1 FOREIGN KEY (config_release_id, pipeline_code) REFERENCES METADATA.CONFIG_RELEASE (config_release_id, pipeline_code),
    CONSTRAINT FK_PIPELINE_STATE_2 FOREIGN KEY (updated_by_task_run_id) REFERENCES RUNTIME.TASK_RUN (task_run_id)
);

COMMENT ON TABLE RUNTIME.PIPELINE_STATE IS 'Stores persistent task operational state such as watermarks and checkpoints across metadata releases.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.pipeline_state_id IS 'State-history row identifier.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.pipeline_code IS 'Stable pipeline identity; part of the logical state key.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.task_code IS 'Stable task identity within a pipeline across releases.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.config_release_id IS 'Release that wrote this state version; audit context, not part of logical state identity.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.state_type IS 'WATERMARK, CHECKPOINT, or LAST_SUCCESS.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.state_key IS 'Partition/shard/topic/source-object/default sub-key.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.state_version IS 'Incrementing version within the logical state stream.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.state_value IS 'Timestamp, SCN, offset, page token, checkpoint ID, or compact serialized state value.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.is_current IS 'Y for the current state version.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.updated_by_task_run_id IS 'Task run that wrote the state version.';
COMMENT ON COLUMN RUNTIME.PIPELINE_STATE.updated_timestamp IS 'State update timestamp.';
CREATE UNIQUE INDEX RUNTIME.UIX_PIPELINE_STATE_CURRENT ON RUNTIME.PIPELINE_STATE (CASE WHEN is_current='Y' THEN pipeline_code END, CASE WHEN is_current='Y' THEN task_code END, CASE WHEN is_current='Y' THEN state_type END, CASE WHEN is_current='Y' THEN state_key END);
CREATE INDEX RUNTIME.IX_PIPELINE_STATE_TASK ON RUNTIME.PIPELINE_STATE (pipeline_code, task_code, state_type, state_key, updated_timestamp);

-- Direct owner privileges required before dependent foreign keys.
GRANT REFERENCES ON METADATA.CONFIG_RELEASE TO OPERATIONS;
GRANT REFERENCES ON RUNTIME.BATCH TO OPERATIONS;
GRANT REFERENCES ON RUNTIME.TASK_RUN TO OPERATIONS;
GRANT REFERENCES ON RUNTIME.INGESTION_ITEM TO OPERATIONS;

CREATE TABLE OPERATIONS.EVENT_LOG (
    event_log_id NUMBER(19) NOT NULL,
    config_release_id NUMBER(19) NOT NULL,
    batch_id NUMBER(19),
    task_run_id NUMBER(19),
    ingestion_item_id NUMBER(19),
    event_timestamp TIMESTAMP(6) WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    event_code VARCHAR2(100) NOT NULL,
    event_type VARCHAR2(30) NOT NULL,
    severity VARCHAR2(20) NOT NULL,
    error_code VARCHAR2(100),
    message VARCHAR2(4000) NOT NULL,
    details_json CLOB,
    evidence_location VARCHAR2(1000),
    correlation_id VARCHAR2(200),
    created_by VARCHAR2(100) NOT NULL,
    CONSTRAINT PK_EVENT_LOG PRIMARY KEY (event_log_id),
    CONSTRAINT CK_EVENT_LOG_1 CHECK (event_type IN ('INFO','WARNING','ERROR','ALERT','NOTIFICATION','SUPPORT_NOTE')),
    CONSTRAINT CK_EVENT_LOG_2 CHECK (severity IN ('LOW','MEDIUM','HIGH','CRITICAL')),
    CONSTRAINT CK_EVENT_LOG_3 CHECK (details_json IS JSON),
    CONSTRAINT FK_EVENT_LOG_1 FOREIGN KEY (config_release_id) REFERENCES METADATA.CONFIG_RELEASE (config_release_id),
    CONSTRAINT FK_EVENT_LOG_2 FOREIGN KEY (batch_id, config_release_id) REFERENCES RUNTIME.BATCH (batch_id, config_release_id),
    CONSTRAINT FK_EVENT_LOG_3 FOREIGN KEY (task_run_id, config_release_id) REFERENCES RUNTIME.TASK_RUN (task_run_id, config_release_id),
    CONSTRAINT FK_EVENT_LOG_4 FOREIGN KEY (ingestion_item_id, config_release_id) REFERENCES RUNTIME.INGESTION_ITEM (ingestion_item_id, config_release_id)
);

COMMENT ON TABLE OPERATIONS.EVENT_LOG IS 'Stores meaningful structured operational events, alerts, errors, notification evidence, and support notes.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.event_log_id IS 'Operational event identifier.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.config_release_id IS 'Runtime metadata release context.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.batch_id IS 'Related batch.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.task_run_id IS 'Related task run.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.ingestion_item_id IS 'Related ingestion item.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.event_timestamp IS 'Event timestamp.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.event_code IS 'Structured event identifier.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.event_type IS 'INFO, WARNING, ERROR, ALERT, NOTIFICATION, or SUPPORT_NOTE.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.severity IS 'LOW, MEDIUM, HIGH, or CRITICAL.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.error_code IS 'Structured error code.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.message IS 'Support-readable event message.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.details_json IS 'Structured event details for support/observability.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.evidence_location IS 'Supporting log/artifact/evidence location.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.correlation_id IS 'End-to-end correlation identifier.';
COMMENT ON COLUMN OPERATIONS.EVENT_LOG.created_by IS 'System/service/user creating the event.';
CREATE INDEX OPERATIONS.IX_EVENT_LOG_TIME ON OPERATIONS.EVENT_LOG (event_timestamp);
CREATE INDEX OPERATIONS.IX_EVENT_LOG_CORR ON OPERATIONS.EVENT_LOG (correlation_id, event_timestamp);
CREATE INDEX OPERATIONS.IX_EVENT_LOG_CODE ON OPERATIONS.EVENT_LOG (event_code, severity, event_timestamp);

CREATE TABLE OPERATIONS.WORK_QUEUE (
    work_queue_id NUMBER(19) NOT NULL,
    target_config_release_id NUMBER(19) NOT NULL,
    scope_type VARCHAR2(30) NOT NULL,
    batch_id NUMBER(19),
    task_run_id NUMBER(19),
    ingestion_item_id NUMBER(19),
    idempotency_key VARCHAR2(300) NOT NULL,
    reason_code VARCHAR2(100),
    description VARCHAR2(2000),
    status VARCHAR2(30) NOT NULL,
    requested_by VARCHAR2(100) NOT NULL,
    created_timestamp TIMESTAMP(6) WITH TIME ZONE DEFAULT SYSTIMESTAMP NOT NULL,
    completed_timestamp TIMESTAMP(6) WITH TIME ZONE,
    outcome_notes VARCHAR2(2000),
    CONSTRAINT PK_WORK_QUEUE PRIMARY KEY (work_queue_id),
    CONSTRAINT UQ_WORK_QUEUE_IDEMPOTENCY UNIQUE (idempotency_key),
    CONSTRAINT CK_WORK_QUEUE_2 CHECK (scope_type IN ('BATCH','TASK','INGESTION_ITEM','OUTBOUND')),
    CONSTRAINT CK_WORK_QUEUE_3 CHECK (status IN ('OPEN','IN_PROGRESS','COMPLETED','CANCELLED')),
    CONSTRAINT CK_WORK_QUEUE_5 CHECK (completed_timestamp IS NULL OR completed_timestamp >= created_timestamp),
    CONSTRAINT FK_WORK_QUEUE_1 FOREIGN KEY (target_config_release_id) REFERENCES METADATA.CONFIG_RELEASE (config_release_id),
    CONSTRAINT FK_WORK_QUEUE_2 FOREIGN KEY (batch_id) REFERENCES RUNTIME.BATCH (batch_id),
    CONSTRAINT FK_WORK_QUEUE_3 FOREIGN KEY (task_run_id) REFERENCES RUNTIME.TASK_RUN (task_run_id),
    CONSTRAINT FK_WORK_QUEUE_4 FOREIGN KEY (ingestion_item_id) REFERENCES RUNTIME.INGESTION_ITEM (ingestion_item_id)
);
COMMENT ON TABLE OPERATIONS.WORK_QUEUE IS 'Error/support history. Every failed task attempt creates one idempotent EXCEPTION row. Never triggers execution.';
COMMENT ON COLUMN OPERATIONS.WORK_QUEUE.target_config_release_id IS 'Metadata release associated with the error or policy result.';
COMMENT ON COLUMN OPERATIONS.WORK_QUEUE.idempotency_key IS 'EXCEPTION:batch:task_run_id for failed attempts; POLICY:policy_result_id for policy support items.';
COMMENT ON COLUMN OPERATIONS.WORK_QUEUE.outcome_notes IS 'Operator resolution; closing an error does not change execution history.';
CREATE INDEX OPERATIONS.IX_WORK_QUEUE_STATUS ON OPERATIONS.WORK_QUEUE (status, created_timestamp);

-- Scheduler-triggered reprocessing is serialized per original batch.
CREATE UNIQUE INDEX RUNTIME.UQ_BATCH_ACTIVE_REPROCESS ON RUNTIME.BATCH (
    CASE WHEN batch_type='REPROCESS' AND status='RUNNING' THEN original_batch_id END
);

-- Runtime terminal history cannot be reopened, even by direct DML.
CREATE OR REPLACE TRIGGER RUNTIME.TRG_BATCH_TERMINAL
BEFORE UPDATE OR DELETE ON RUNTIME.BATCH FOR EACH ROW
BEGIN
    IF :OLD.status IN ('COMPLETED','COMPLETED_WITH_WARNINGS','FAILED') THEN
        RAISE_APPLICATION_ERROR(-20060, 'Terminal batch history is immutable. Create REPROCESS.');
    END IF;
END;
/

--------------------------------------------------------------------------------
-- Pipeline-scoped metadata immutability
-- Only DRAFT releases may have configuration rows inserted/updated/deleted.
--------------------------------------------------------------------------------
CREATE OR REPLACE TRIGGER METADATA.TRG_CONFIG_RELEASE_LIFECYCLE
BEFORE INSERT OR UPDATE OR DELETE ON METADATA.CONFIG_RELEASE
FOR EACH ROW
BEGIN
    IF NOT DELETING AND :NEW.release_status <> 'RETIRED' AND :NEW.effective_to IS NOT NULL THEN
        RAISE_APPLICATION_ERROR(-20050, 'effective_to must remain NULL until retirement.');
    END IF;
    IF INSERTING THEN
        IF :NEW.release_status <> 'DRAFT' THEN
            RAISE_APPLICATION_ERROR(-20040, 'CONFIG_RELEASE must be created in DRAFT status.');
        END IF;
    ELSIF DELETING THEN
        IF :OLD.release_status <> 'DRAFT' THEN
            RAISE_APPLICATION_ERROR(-20041, 'Only DRAFT CONFIG_RELEASE rows may be deleted.');
        END IF;
    ELSIF UPDATING THEN
        IF :OLD.release_status = 'DRAFT' THEN
            IF :NEW.release_status NOT IN ('DRAFT','APPROVED') THEN
                RAISE_APPLICATION_ERROR(-20042, 'Allowed CONFIG_RELEASE transition: DRAFT -> APPROVED.');
            END IF;
        ELSIF :OLD.release_status = 'APPROVED' THEN
            IF :NEW.release_status <> 'ACTIVE' THEN
                RAISE_APPLICATION_ERROR(-20043, 'Allowed CONFIG_RELEASE transition: APPROVED -> ACTIVE.');
            END IF;
            IF :NEW.pipeline_code <> :OLD.pipeline_code OR
               :NEW.pipeline_name <> :OLD.pipeline_name OR
               :NEW.pipeline_direction <> :OLD.pipeline_direction OR
               NVL(:NEW.pipeline_description,CHR(0)) <> NVL(:OLD.pipeline_description,CHR(0)) OR
               :NEW.release_version <> :OLD.release_version OR
               :NEW.release_desc <> :OLD.release_desc OR
               :NEW.created_by <> :OLD.created_by OR
               :NEW.created_timestamp <> :OLD.created_timestamp OR
               :NEW.effective_from <> :OLD.effective_from THEN
                RAISE_APPLICATION_ERROR(-20044, 'Approved CONFIG_RELEASE content is immutable.');
            END IF;
        ELSIF :OLD.release_status = 'ACTIVE' THEN
            IF :NEW.release_status <> 'RETIRED' THEN
                RAISE_APPLICATION_ERROR(-20045, 'Allowed CONFIG_RELEASE transition: ACTIVE -> RETIRED.');
            END IF;
            IF :NEW.effective_to IS NULL OR :NEW.effective_to < :OLD.effective_from THEN
                RAISE_APPLICATION_ERROR(-20051, 'Retirement requires effective_to >= the approved effective_from.');
            END IF;
            IF :NEW.pipeline_code <> :OLD.pipeline_code OR
               :NEW.pipeline_name <> :OLD.pipeline_name OR
               :NEW.pipeline_direction <> :OLD.pipeline_direction OR
               NVL(:NEW.pipeline_description,CHR(0)) <> NVL(:OLD.pipeline_description,CHR(0)) OR
               :NEW.release_version <> :OLD.release_version OR
               :NEW.release_desc <> :OLD.release_desc OR
               :NEW.created_by <> :OLD.created_by OR
               :NEW.created_timestamp <> :OLD.created_timestamp OR
               :NEW.effective_from <> :OLD.effective_from THEN
                RAISE_APPLICATION_ERROR(-20046, 'Active CONFIG_RELEASE content is immutable.');
            END IF;
        ELSE
            RAISE_APPLICATION_ERROR(-20047, 'RETIRED CONFIG_RELEASE is immutable.');
        END IF;
    END IF;
END;
/

DECLARE
    PROCEDURE create_immutability_trigger(p_table VARCHAR2) IS
        l_name VARCHAR2(30);
        l_sql  CLOB;
    BEGIN
        l_name := 'TRG_IMM_' || SUBSTR(REPLACE(p_table,'_',''),1,22);
        l_sql := 'CREATE OR REPLACE TRIGGER METADATA.' || l_name || CHR(10) ||
                 'BEFORE INSERT OR UPDATE OR DELETE ON METADATA.' || p_table || CHR(10) ||
                 'FOR EACH ROW ' || CHR(10) ||
                 'DECLARE l_release_id NUMBER; l_status VARCHAR2(20); BEGIN ' || CHR(10) ||
                 '  l_release_id := CASE WHEN DELETING THEN :OLD.config_release_id ELSE :NEW.config_release_id END; ' || CHR(10) ||
                 '  SELECT release_status INTO l_status FROM METADATA.CONFIG_RELEASE WHERE config_release_id=l_release_id; ' || CHR(10) ||
                 '  IF l_status <> ''DRAFT'' THEN RAISE_APPLICATION_ERROR(-20048, ''Metadata release is immutable unless DRAFT.''); END IF; ' || CHR(10) ||
                 '  IF UPDATING AND :OLD.config_release_id <> :NEW.config_release_id THEN RAISE_APPLICATION_ERROR(-20049, ''Cannot move metadata between releases.''); END IF; ' || CHR(10) ||
                 'END;';
        EXECUTE IMMEDIATE l_sql;
    END;
BEGIN
    create_immutability_trigger('SOURCE_CONFIG');
    create_immutability_trigger('DATASET');
    create_immutability_trigger('DATASET_COLUMN');
    create_immutability_trigger('TASK');
    create_immutability_trigger('TASK_DATASET');
    create_immutability_trigger('TASK_STEP');
    create_immutability_trigger('MAPPING_RULE');
    create_immutability_trigger('OUTBOUND_CONFIG');
    create_immutability_trigger('POLICY_DEFINITION');
END;
/

-- Fresh schemas: sequences start at one; never reset populated sequence ranges.
CREATE SEQUENCE METADATA.SEQ_CONFIG_RELEASE START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999 CACHE 100 NOCYCLE;
CREATE SEQUENCE RUNTIME.SEQ_BATCH_ID START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999 CACHE 100 NOCYCLE;
CREATE SEQUENCE RUNTIME.SEQ_TASK_RUN_ID START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999 CACHE 100 NOCYCLE;
CREATE SEQUENCE RUNTIME.SEQ_INGESTION_ITEM_ID START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999 CACHE 100 NOCYCLE;
CREATE SEQUENCE RUNTIME.SEQ_POLICY_RESULT_ID START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999 CACHE 100 NOCYCLE;
CREATE SEQUENCE RUNTIME.SEQ_PIPELINE_STATE_ID START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999 CACHE 100 NOCYCLE;
CREATE SEQUENCE OPERATIONS.SEQ_EVENT_LOG_ID START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999 CACHE 100 NOCYCLE;
CREATE SEQUENCE OPERATIONS.SEQ_WORK_QUEUE_ID START WITH 1 INCREMENT BY 1 MAXVALUE 9999999999999999999 CACHE 100 NOCYCLE;

-- Compilation errors are not reliably surfaced by WHENEVER SQLERROR alone.
DECLARE
    invalids NUMBER;
BEGIN
    SELECT COUNT(*) INTO invalids FROM ALL_OBJECTS
     WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') AND status='INVALID';
    IF invalids <> 0 THEN
        RAISE_APPLICATION_ERROR(-20105, 'Invalid framework objects; inspect ALL_ERRORS before proceeding.');
    END IF;
END;
/
PROMPT Framework objects installed. Run 02_grants.sql, then 03_inspect.sql.
