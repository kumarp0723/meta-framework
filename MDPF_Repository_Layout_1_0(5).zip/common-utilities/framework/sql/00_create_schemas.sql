-- MDPF 1.0: fresh ATP account setup. SQLcl/SQL*Plus script mode, connected as ADMIN.
-- Order: 00_create_schemas -> 01_framework -> 02_grants -> 03_inspect.
-- DATA quotas below are initial development limits; adjust deliberately before use.
-- Do not spool credentials. Schema owners have no authentication or CREATE SESSION.
SET ECHO OFF
SET VERIFY OFF
SET DEFINE OFF
SET SERVEROUTPUT ON
WHENEVER OSERROR EXIT FAILURE ROLLBACK
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
BEGIN
    IF SYS_CONTEXT('USERENV','SESSION_USER') <> 'ADMIN' THEN
        RAISE_APPLICATION_ERROR(-20100, 'Connect as ATP ADMIN for this script.');
    END IF;
END;
/
DECLARE
    existing NUMBER;
BEGIN
    SELECT COUNT(*) INTO existing FROM ALL_USERS
     WHERE username IN ('METADATA','RUNTIME','OPERATIONS','MDPF_RUNTIME');
    IF existing <> 0 THEN
        RAISE_APPLICATION_ERROR(-20101, 'MDPF accounts already exist; stop. Use a fresh environment or have the DBA review the existing installation.');
    END IF;
END;
/
CREATE USER METADATA NO AUTHENTICATION DEFAULT TABLESPACE DATA QUOTA 1G ON DATA;
CREATE USER RUNTIME NO AUTHENTICATION DEFAULT TABLESPACE DATA QUOTA 1G ON DATA;
CREATE USER OPERATIONS NO AUTHENTICATION DEFAULT TABLESPACE DATA QUOTA 1G ON DATA;
CREATE USER MDPF_RUNTIME NO AUTHENTICATION;
GRANT CREATE TABLE, CREATE SEQUENCE, CREATE TRIGGER TO METADATA;
GRANT CREATE TABLE, CREATE SEQUENCE, CREATE TRIGGER TO RUNTIME;
GRANT CREATE TABLE, CREATE SEQUENCE TO OPERATIONS;

PROMPT Set the application password using the masked SQL client PASSWORD command.
PASSWORD MDPF_RUNTIME
-- PASSWORD is a SQLcl/SQL*Plus command: the password is never substituted into SQL.
-- Fail closed if the client command did not enable password authentication.
DECLARE
    auth VARCHAR2(30);
BEGIN
    SELECT authentication_type INTO auth FROM DBA_USERS WHERE username='MDPF_RUNTIME';
    IF auth <> 'PASSWORD' THEN
        RAISE_APPLICATION_ERROR(-20102, 'MDPF_RUNTIME password was not configured. Set it with PASSWORD MDPF_RUNTIME before continuing.');
    END IF;
END;
/
GRANT CREATE SESSION TO MDPF_RUNTIME;
PROMPT Account creation complete. Run 01_framework.sql in this ATP ADMIN session.
