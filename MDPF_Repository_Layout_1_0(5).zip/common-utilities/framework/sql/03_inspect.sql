-- Reusable Oracle diagnostics. SQLcl/SQL*Plus script mode; read-only queries.
-- Set these example binds to exact inspected identities. NULL batch/run means all.
-- MAIN owner/table use reviewed SQL-client substitution, never value binds.
SET SERVEROUTPUT ON
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
SET DEFINE ON
DEFINE main_owner = DMI_MAIN_DEV
DEFINE main_table = DMI_FEE
VARIABLE pipeline_code VARCHAR2(100)
VARIABLE batch_id NUMBER
VARIABLE run_id NUMBER
EXEC :pipeline_code := 'DMI_FEE';
EXEC :batch_id := NULL;
EXEC :run_id := NULL;

-- Installation inventory/compilation diagnostics: execute as ATP ADMIN.
SELECT owner,object_type,COUNT(*) object_count
  FROM ALL_OBJECTS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS')
 GROUP BY owner,object_type ORDER BY owner,object_type;
SELECT owner,object_name,object_type,status
  FROM ALL_OBJECTS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') AND status='INVALID';
SELECT owner,name,type,line,position,text
  FROM ALL_ERRORS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') ORDER BY owner,name,sequence;
SELECT owner,table_name,constraint_name,constraint_type,status,validated
  FROM ALL_CONSTRAINTS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS')
 ORDER BY owner,table_name,constraint_name;
SELECT owner,index_name,table_name,status
  FROM ALL_INDEXES WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') ORDER BY owner,index_name;
SELECT sequence_owner,sequence_name,increment_by,last_number
  FROM ALL_SEQUENCES WHERE sequence_owner IN ('METADATA','RUNTIME','OPERATIONS')
 ORDER BY sequence_owner,sequence_name;
DECLARE
    tables_count NUMBER; columns_count NUMBER; triggers_count NUMBER; sequences_count NUMBER; invalid_count NUMBER; bad_constraints NUMBER; pk_count NUMBER; fk_count NUMBER; unique_count NUMBER; check_count NUMBER;
BEGIN
    SELECT COUNT(*) INTO tables_count FROM ALL_TABLES WHERE owner IN ('METADATA','RUNTIME','OPERATIONS');
    SELECT COUNT(*) INTO columns_count FROM ALL_TAB_COLUMNS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS');
    SELECT COUNT(*) INTO triggers_count FROM ALL_TRIGGERS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') AND status='ENABLED';
    SELECT COUNT(*) INTO sequences_count FROM ALL_SEQUENCES WHERE sequence_owner IN ('METADATA','RUNTIME','OPERATIONS');
    SELECT COUNT(*) INTO invalid_count FROM ALL_OBJECTS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') AND status='INVALID';
    SELECT COUNT(*) INTO bad_constraints FROM ALL_CONSTRAINTS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') AND (status<>'ENABLED' OR validated<>'VALIDATED');
    SELECT COUNT(*) INTO pk_count FROM ALL_CONSTRAINTS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') AND constraint_type='P';
    SELECT COUNT(*) INTO fk_count FROM ALL_CONSTRAINTS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') AND constraint_type='R';
    SELECT COUNT(*) INTO unique_count FROM ALL_CONSTRAINTS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') AND constraint_type='U';
    SELECT COUNT(*) INTO check_count FROM ALL_CONSTRAINTS WHERE owner IN ('METADATA','RUNTIME','OPERATIONS') AND constraint_type='C' AND SUBSTR(constraint_name,1,3)='CK_';
    IF bad_constraints<>0 OR pk_count<>17 OR fk_count<>46 OR unique_count<>25 OR check_count<>75 THEN
        RAISE_APPLICATION_ERROR(-20108, 'Missing, disabled or unvalidated framework constraints; review the inventory above.');
    END IF;
    IF tables_count<>17 OR columns_count<>234 OR triggers_count<>12 OR sequences_count<>8 OR invalid_count<>0 THEN
        RAISE_APPLICATION_ERROR(-20107, 'Incomplete or invalid MDPF installation; review the inventory above.');
    END IF;
    DBMS_OUTPUT.PUT_LINE('MDPF installation verified: 17 tables, 234 columns, 12 enabled triggers, eight sequences.');
END;
/

SELECT config_release_id, pipeline_code, pipeline_direction, release_version, release_status
  FROM METADATA.CONFIG_RELEASE
 WHERE pipeline_code=:pipeline_code
 ORDER BY config_release_id;

-- Source details for IDMC: select the intended metadata release, not an arbitrary row.
SELECT d.config_release_id, r.release_version, r.release_status, d.dataset_id,
       d.source_object_code, d.physical_object_name, d.upstream_config
  FROM METADATA.DATASET d
  JOIN METADATA.CONFIG_RELEASE r ON r.config_release_id=d.config_release_id
 WHERE r.pipeline_code=:pipeline_code AND d.source_object_code IS NOT NULL
 ORDER BY d.config_release_id,d.dataset_id;

SELECT batch_id, orchestrator_run_id, execution_key, config_release_id, cycle_date,
       status, start_timestamp, end_timestamp
  FROM RUNTIME.BATCH
 WHERE pipeline_code=:pipeline_code AND (:batch_id IS NULL OR batch_id=:batch_id)
 ORDER BY batch_id;

SELECT tr.batch_id, t.task_code, tr.task_run_id, tr.attempt_number,
       tr.original_task_run_id, tr.status, tr.input_count, tr.output_count,
       tr.orchestrator_task_run_id, tr.orchestrator_attempt_number,
       tr.error_code, tr.error_message, tr.failed_step_code
  FROM RUNTIME.TASK_RUN tr
  JOIN RUNTIME.BATCH b ON b.batch_id=tr.batch_id
  JOIN METADATA.TASK t ON t.config_release_id=tr.config_release_id AND t.task_id=tr.task_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR tr.batch_id=:batch_id)
   AND (:run_id IS NULL OR tr.task_run_id=:run_id)
 ORDER BY tr.batch_id,t.task_id,tr.attempt_number;

SELECT ie.ingestion_item_id, ie.task_run_id, ie.item_name, ie.source_item_key,
       ie.dataset_id, ie.source_location, ie.source_record_count, ie.status,
       ie.quarantine_location
  FROM RUNTIME.INGESTION_ITEM ie
  JOIN RUNTIME.TASK_RUN tr ON tr.task_run_id=ie.task_run_id
  JOIN RUNTIME.BATCH b ON b.batch_id=tr.batch_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR tr.batch_id=:batch_id)
   AND (:run_id IS NULL OR tr.task_run_id=:run_id)
 ORDER BY ie.ingestion_item_id;

SELECT q.batch_id,q.task_run_id,q.reason_code,q.description,q.status,q.idempotency_key
  FROM OPERATIONS.WORK_QUEUE q JOIN RUNTIME.BATCH b ON b.batch_id=q.batch_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR q.batch_id=:batch_id)
   AND (:run_id IS NULL OR q.task_run_id=:run_id)
 ORDER BY q.work_queue_id;

SELECT e.batch_id,e.task_run_id,e.event_code,e.details_json
  FROM OPERATIONS.EVENT_LOG e JOIN RUNTIME.BATCH b ON b.batch_id=e.batch_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR e.batch_id=:batch_id)
   AND (:run_id IS NULL OR e.task_run_id=:run_id)
 ORDER BY e.event_log_id;

SELECT pr.batch_id, pr.task_run_id, pd.policy_code, pr.dataset_id, pr.dataset_column_id,
       pr.result_level, pr.result_status, pr.expected_value, pr.actual_value,
       pr.threshold_value, pr.failed_record_count, pr.failure_action_taken
  FROM RUNTIME.POLICY_RESULT pr JOIN METADATA.POLICY_DEFINITION pd
    ON pd.config_release_id=pr.config_release_id AND pd.policy_id=pr.policy_id
  JOIN RUNTIME.BATCH b ON b.batch_id=pr.batch_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR pr.batch_id=:batch_id)
   AND (:run_id IS NULL OR pr.task_run_id=:run_id)
 ORDER BY pr.policy_result_id;

-- End of ATP diagnostics. The ADW queries below are commented intentionally.

/* ADW ONLY: select/copy only the SQL inside this comment to a separate ADW session.
   Recreate the batch_id/run_id binds and main_owner/main_table definitions there.
-- DMI_FEE-specific business total; adapt the metric for another target.
SELECT batch_id, task_run_id, COUNT(*) record_count, SUM(fee_tran_am) fee_amount
  FROM &&main_owner..&&main_table
 WHERE (:batch_id IS NULL OR batch_id=:batch_id)
   AND (:run_id IS NULL OR task_run_id=:run_id)
 GROUP BY batch_id,task_run_id ORDER BY batch_id;

SELECT batch_id, task_run_id, row_number, created_at, updated_at
  FROM &&main_owner..&&main_table
 WHERE (:batch_id IS NULL OR batch_id=:batch_id)
   AND (:run_id IS NULL OR task_run_id=:run_id)
 ORDER BY batch_id, row_number;

*/
