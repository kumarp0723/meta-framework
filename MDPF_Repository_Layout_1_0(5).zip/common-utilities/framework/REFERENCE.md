# MDPF Framework 1.0 — technical reference

- [How it works](#how-it-works)
- [Public API contracts](#public-api-contracts)
- [Optional whole-file quarantine during RAW ingestion](#optional-whole-file-quarantine-during-raw-ingestion)
- [Set up once](#set-up-once)
- [Run the supplied DMI example](#run-the-supplied-dmi-example)
- [Use your own pipeline](#use-your-own-pipeline)
- [Run from Data Flow / ActiveBatch](#run-from-data-flow--activebatch)
- [Available Task Steps](#available-task-steps)
- [Default task sequences](#default-task-sequences)
- [Custom task steps](#custom-task-steps)
- [Supported DQ rules](#supported-dq-rules)
- [Find and resolve a failure](#find-and-resolve-a-failure)
- [Where the code lives](#where-the-code-lives)
- [DQ, reconciliation and audit contracts](#dq-reconciliation-and-audit-contracts)

MDPF runs metadata-defined Spark steps from OCI AIDP notebooks or OCI Data Flow
applications and records their execution in Oracle. AIDP or ActiveBatch owns
scheduling, dependencies and restart. Run each pipeline entirely on one platform.
This package and its wheel are version **1.0**.
Keep `framework/` and `generator/` as siblings under `common-utilities/`.
Start with the [developer guide](DEVELOPER_GUIDE.md); this file holds runtime/API details.

New developers should first read the [developer guide](DEVELOPER_GUIDE.md) for
function-level generation/execution flows, transaction ownership, local setup and
the change/test map. This document retains the detailed runtime contracts.

## Parquet landing and partitioned output

READ_SOURCE accepts only Parquet input datasets with exact .parquet object URIs.
LANDING and RAW schemas must match. Supported types remain VARCHAR2, exact NUMBER
and date-only DATE. Proven schema/value failures can quarantine one source object;
generic read or infrastructure failures do not classify a delivery as invalid.

RAW/STAGE require explicit extensionless output templates with {batch_id}.
{YYYYMMDD} uses the pinned cycle date. Missing templates, .parquet output folder
names and prefix-only batch_<id> paths are rejected before external I/O.

## OCI Vault to HCP Vault Dedicated

`mdpf_runtime.vault.read_hcp_secret(bootstrap_secret_id, *, client=None, timeout=30,
ca_bundle=None)` returns the KV v2 secret's dictionary. It is shared Python code;
both onboarding notebooks and runtime callers can import it from the Framework
wheel. It does not connect Oracle or modify process settings automatically.

Store this JSON as the content of one OCI Vault secret (illustrative values):

```json
{
  "vault_url": "https://your-dedicated-vault.example.com",
  "namespace": "admin",
  "role_id": "<APPROLE_ROLE_ID>",
  "secret_id": "<APPROLE_SECRET_ID>",
  "auth_mount": "approle",
  "kv_mount": "kv",
  "secret_path": "dmi/oracle"
}
```

`auth_mount` is optional; all other fields are required. Mount and secret paths do
not include `/v1/` or `/data/`. Use the namespace and network endpoint provisioned
for your HCP Vault. AppRole policy must allow read on `kv/data/dmi/oracle` (adjust
mount/path); choose short-lived tokens and manage SecretID rotation in Vault.
The utility reads the CURRENT OCI secret version for every invocation; no cache,
renewal worker or new credential service is introduced.

```python
from mdpf_runtime.vault import read_hcp_secret
credentials = read_hcp_secret('ocid1.vaultsecret...')
# Pass credentials to the consuming client. Never print the mapping or token.
```

Default OCI authentication uses Resource Principal. Pass an approved OCI
SecretsClient via `client=` for another authentication method. The runtime identity
needs secret-bundle read permission for that bootstrap secret, plus HTTPS network
access to HCP Vault. Spark bucket credentials are separate. HTTPS certificate
verification stays enabled; `ca_bundle` supplies an approved CA file when needed.
Redirects are rejected; `timeout` bounds each HTTP request. Failures raise sanitized
RuntimeError messages without remote bodies or credential values. The utility
performs AppRole login then `GET /v1/<kv_mount>/data/<secret_path>` and returns
`data.data`; a missing/deleted/inaccessible secret fails, without fallback values.

API references: [AppRole](https://developer.hashicorp.com/vault/api-docs/auth/approle),
[KV v2](https://developer.hashicorp.com/vault/api-docs/secret/kv/kv-v2),
[OCI SecretsClient](https://docs.oracle.com/en-us/iaas/tools/python/latest/api/secrets/client/oci.secrets.SecretsClient.html).

## Separate ATP and ADW connections

The launchers require two independently configured Oracle connections.
ATP owns METADATA, RUNTIME and OPERATIONS. ADW owns MAIN business tables. RAW/STAGE
continue to use OCI Parquet plus ATP control records. MAIN keeps the existing
bounded INSERT strategy and 100,000-row default; no new database tables are added.

Set the following in the approved runtime's secret/environment configuration:

```text
MDPF_DB_USER=<ATP user>
MDPF_DB_PASSWORD=<ATP password>
MDPF_DB_DSN=<ATP DSN>
MDPF_MAIN_DB_USER=<ADW user>
MDPF_MAIN_DB_PASSWORD=<ADW password>
MDPF_MAIN_DB_DSN=<ADW DSN>
```

When wallets are required, each prefix has its own optional `CONFIG_DIR`,
`WALLET_LOCATION` and `WALLET_PASSWORD` settings, for example
`MDPF_MAIN_DB_WALLET_LOCATION`. Each wallet/directory must be accessible to the
runtime driver. ADW never borrows ATP credentials or wallet settings. Both prefixes require USER, PASSWORD and DSN for framework execution. A caller-owned
ATP adapter and separate ADW adapter are supported instead. Missing ADW settings
fail before a task attempt starts; MAIN never falls back to ATP.

Generic AIDP/Data Flow launchers need no new wrapper or business registration.
The framework opens ADW only for a task producing ADB_TABLE outputs, closes an
ADW connection it creates on success/failure, and keeps all control SQL on ATP.
For RAW/STAGE, ADW is not opened. Provision MAIN tables/grants in ADW; target
`OWNER.TABLE` names stay in the existing YAML/metadata location fields. SQL/MAIN DDL generation needs no Oracle connection.

To check the required environment settings without printing credentials:

```python
from mdpf_runtime.db import OracleDb

for prefix in ('MDPF_DB', 'MDPF_MAIN_DB'):
    db = OracleDb(prefix=prefix)
    try:
        assert db.one('SELECT 1 ok FROM DUAL')['ok'] == 1
        print(prefix, 'connection OK')
    finally:
        db.close()
```

Both checks must succeed. This checks connectivity, not target schema or grants.

For direct Python/Vault use, `OracleDb` accepts keyword settings without changing
process environment. KV data passed as `**values` must contain the supported
keys `user`, `password`, `dsn`, and optional `config_dir`, `wallet_location`,
`wallet_password`. Never print these mappings. Connections supplied by the caller
are caller-owned:

```python
from contextlib import ExitStack
from mdpf_runtime.db import OracleDb
from mdpf_runtime.pipeline import MetadataFramework

# atp_values/adw_values are securely retrieved mappings, for example from Vault.
with ExitStack() as cleanup:
    atp = OracleDb(prefix='MDPF_DB', **atp_values)
    cleanup.callback(atp.close)
    adw = OracleDb(prefix='MDPF_MAIN_DB', **adw_values)
    cleanup.callback(adw.close)
    framework = MetadataFramework(atp, 'DMI_FEE', spark=spark, main_db=adw)
    result = framework.execute_task(batch_id, 'DMI_FEE_MAIN_LOAD')
```

`main_db=` is also accepted by `runner.execute_task()`, `aidp.execute_task()` and
`dataflow.execute_task()`; these wrappers still create/close ATP from MDPF_DB
settings. Do not wrap framework lifecycle calls in an external transaction.

**Commit order:** all MAIN targets and actual-insert count reconciliation share
one ADW transaction. ADW commits first; ATP then commits policy results, load events,
task completion and optional batch completion. These two commits are independent.
An ADW mismatch rolls back all its targets. Once ADW has committed, an ATP error
cannot undo its rows; a lost commit acknowledgement may also leave data present.

**Failed MAIN attempts:** the error code is MAIN_RECOVERY_REQUIRED. A new attempt
requires review of the latest exact failed run, including pre-commit failures.
The operator acknowledgement is not commit evidence. Follow the
[MAIN recovery procedure](OPERATIONS.md#atpadw-setup-and-controlled-main-recovery)
for writer shutdown, ADW inspection and the one-retry parameter. Normal RAW/STAGE
retries keep their existing behavior.

The optional onboarding gate accepts `verify_main_targets(atp, pipeline_code=...,
release_version=..., main_db=adw)`. Metadata reads use ATP; NLS/table/column inspection
uses ADW. Without explicit `main_db`, ADW environment settings select an owned target
connection. The gate closes only its own connection and remains read-only.

## How it works

```mermaid
flowchart TD
    A["AIDP or ActiveBatch workflow"] --> N["Notebook or Data Flow application"]
    N --> F["MDPF step runner"]
    M["Oracle metadata"] --> F
    F <-->|Spark I/O| O["Separate landing, RAW and STAGE buckets"]
    F --> D["Oracle MAIN tables"]
    F --> R["Runtime status and error history"]
```

The scheduler chooses which notebook/application runs. MDPF reads pinned metadata and runs that
task's steps; Spark handles Parquet runtime I/O and Oracle records the outcome.

| Part | Responsibility |
|---|---|
| SQL Generator | Turns YAML and CSV/Parquet samples into DRAFT metadata; see the [onboarding README](../generator/README.md) |
| Oracle metadata | Defines datasets, columns, task inputs/outputs and ordered `TASK_STEP` rows |
| Notebook / Data Flow application | Registers custom business functions and calls its platform `execute_task()` |
| MDPF | Resolves/runs the plan and records status, errors and lineage |
| Spark / OCI | Reads landing Parquet objects and writes RAW/STAGE Parquet to their separate buckets |
| Oracle MAIN | Stores final rows; same-DB mode shares the control transaction, while separate mode commits ADW before ATP completion |

Oracle generates internal `batch_id` and `task_run_id` values. AIDP uses
`AIDP:<job.run_id>` as the shared execution key; Data Flow tasks receive
`ACTIVEBATCH:<parent-workflow-instance-id>` from ActiveBatch. Each actual task
attempt gets a new `TASK_RUN`, with its external run ID recorded separately.
Restart retains the batch's pinned release/cycle and never reopens a terminal batch.

Before deploying a changed pipeline, use the onboarding utility's optional baseline
comparison. Review task plans, parameters, DQ rules, sources and associations as well
as schemas/locations. Deploy a new DRAFT release; existing batches keep their pinned
configuration. The utility proposes target DDL but never executes it.

## Public API contracts

Use `MetadataFramework` from `mdpf_runtime.pipeline`. Construct it with an existing `db`,
an explicit `pipeline_code` and optionally the configured Spark session. Runtime
SQL helpers are internal participants, not independent lifecycle entry points.

| Method | Important inputs/context | Successful return | Failure and transaction contract |
|---|---|---|---|
| `start_batch(execution_key, cycle_date=None, execution_mode=None, *, orchestrator_run_id=None, triggered_by='SCHEDULER')` | Stable workflow key; new batches need an ISO cycle date and an ACTIVE release; modes are SCHEDULED/MANUAL | Persisted BATCH dictionary with generated `batch_id`, pinned release, cycle and state; resolves an existing compatible RUNNING batch | Owns the batch/event transaction. Conflicting overrides, invalid identity/date or terminal batch raise ValueError; DB errors propagate. |
| `execute_task(batch_id, task_code, custom_steps=None, orchestrator_task_run_id=None, orchestrator_attempt_number=None, main_retry_reviewed_run_id=None)` | Existing RUNNING batch and configured task; optional exact custom-callable registry and external attempt identity/count | Persisted TASK_RUN dictionary: includes `batch_id`, `task_run_id`, `attempt_number`, `status`, input/output counts and other recorded fields | Owns lifecycle/completion/failure scopes. Completed tasks or still-RUNNING writers are rejected. Errors after attempt creation follow guarded failure recording and propagate. |
| `fail_task_run(run_id, code, message, failed_step=None)` | Exact internal attempt ID; caller must confirm its external writer has stopped | `None`; terminal attempts are unchanged on duplicate/delayed callbacks | Owns the failure/work-item/event transaction, leaves BATCH RUNNING. Unknown attempt or an active attempt in a terminal batch raises ValueError; DB errors propagate. |
| `fail_batch(batch_id)` | Scheduler/operator has abandoned retries and stopped/terminalized active attempts | `None`; an already FAILED batch is unchanged | Owns finalization transaction. Refuses RUNNING attempts and other terminal batch states. This is not a waiting-phase transition. |

Do not wrap these lifecycle methods in another `db.transaction()`; there are no
nested-transaction/savepoint semantics. `OracleDb.transaction()` commits on normal
exit, rolls back and re-raises any BaseException. The facade chooses scopes;
`runtime.py` does not commit or roll back. MAIN DML/reconciliation commits in ADW;
success evidence/completion commits in ATP afterward. These are independent
transactions with the recovery rules above. Parquet/OCI I/O is also external.

Typical contract errors are ValueError; invalid handler return shapes raise
TypeError. Handler, Spark, OCI and Oracle errors propagate rather than being turned
into success values. Failure-recording errors can also propagate. A WARN policy
does not create a separate task-success status in this implementation: a task
whose remaining checks succeed is COMPLETED.

### Custom handler contract

The callable is `(frames, context, params)`. See the single
[CUSTOM_FEE_TRANSFORM implementation and registration example](#custom-task-steps) below.

| Value | Contract |
|---|---|
| `frames` | Dictionary of dataset codes to Spark DataFrames from the previous step. Use the actual configured keys; input/output routing depends on the task plan. |
| `context` | Read-only public mapping: `batch_id`, `task_run_id`, `pipeline_code`, `task_code`, `config_release_id`, `cycle_date`, `input_locations`, `output_locations`. It does not expose the framework or database. |
| `params` | Dictionary from this custom step's JSON/YAML parameters. Validate any business-specific values in the handler. |
| Return | Nonempty `dict[str, DataFrame]`. Multi-input joins and output routing are explicit; supply the keys required by the following configured steps/sink. |
| Errors | Raise to fail the attempt. None, empty dictionaries and non-DataFrame values cause TypeError. Missing/noncallable registry entries fail plan validation before data I/O. |

Keep the configured custom code identical to its `custom_steps` registry key.
STAGE/MAIN sinks require the exact frames retained by VALIDATE_DQ. For platform
identities use the [AIDP/Data Flow execution instructions](#run-from-data-flow--activebatch);
for recovery use [the existing failure guidance](#find-and-resolve-a-failure).

## Optional whole-file quarantine during RAW ingestion

Configure `METADATA.SOURCE_CONFIG.quarantine_path` in a new pinned configuration
release to enable quarantine. When it is NULL, existing fail-only behavior stays
unchanged. Use the updated companion generator to populate it from YAML.

During READ_SOURCE, proven schema/length/type/null/nonempty violations can copy
the entire original Parquet object before RAW writes. Generic read or infrastructure
errors are not automatically quarantined. The destination is:

<quarantine_path>/<source_system>/<feed>/ingest_date=YYYYMMDD/batch_id=<batch_id>/<filename>.parquet

The root excludes source_system. source_system_name and LANDING source_object_code
are required; there is no feed fallback or run directory. OCI copy uses source ETag
matching and permits overwriting this batch's destination. A confirmed copy and running-attempt audit are
required before QUARANTINED is recorded. Landing is retained and the task still fails
with its normal work-queue evidence. A same-batch retry copies the source again,
replacing an existing destination; its existence alone never proves copy success.
Different batches use separate destination paths. Previous receipts and terminal
records remain unchanged. Quarantine IAM permissions must include OBJECT_OVERWRITE.

This first version quarantines RAW source validation failures only. STAGE/MAIN
conversion, custom-code and DQ failures retain normal task-failure behavior.
Network, missing-file, permission, database and unclassified Spark failures do
not automatically quarantine a source. No archive or row-level reject processing
is included. `TASK_STEP` actions remain `FAIL_TASK`; business policies now support `FAIL_TASK` or `WARN`; this feature does
not enable the otherwise unsupported `QUARANTINE` action values in those tables.

If copying fails or is uncertain, the ingestion item remains FAILED, with no
confirmed quarantine location; the error retains both the validation and copy
failure. A copy can physically complete before a database/audit failure: inspect
the deterministic destination before manual cleanup. Do not assume Oracle and OCI
are one transaction. An attempt terminalized while copying is never reopened or
marked quarantined by a delayed audit.

Quarantine must be disjoint from active landing/RAW/STAGE prefixes. Use a dedicated
bucket when practical. Source and quarantine buckets must be in the Resource
Principal's region in this implementation. Configure SDK source metadata/read,
destination create/inspect, copy/work-request permissions and the required OCI
Object Storage service permissions. Spark retains its existing sample/source
permissions. The source delivery URI must remain immutable during processing.
Install the OCI SDK dependency on the runtime as well as on the onboarding host.
The current fresh baseline includes direction and optional upstream JSON. Quarantine
uses SOURCE_CONFIG.quarantine_path; no separate upgrade script is packaged.

Separate dataset pipelines fail independently. An existing combined RAW task
still fails as one task; only the file whose validation failed is quarantined.

## Set up once

Use [fresh ATP installation](README.md#fresh-atp-installation) for account creation,
objects and grants. That is the authoritative SQL order. Use the
[developer guide](DEVELOPER_GUIDE.md#local-setup-and-checks) for Python installation.
Before execution, configure both [database connections](#separate-atp-and-adw-connections),
[OCI access](OPERATIONS.md#oci-permissions) and the selected platform's packages.
The [DMI_FEE walkthrough](../../data-pipelines/providers/dmi/README.md) handles
ADW target deployment and metadata activation in separate sessions.

## Run the supplied DMI example

The main example is the [production Parquet DMI_FEE walkthrough](../../data-pipelines/providers/dmi/README.md).
Use its provider YAML, shared RAW/MAIN launchers and provider STAGE launcher.
Utility CSV fixtures are separate examples. For AIDP, bind these resolved values:

| Scope | Parameters |
|---|---|
| Every task | Actual `job_run_id`, `task_run_id`, positive `execution_count` |
| Shared RAW/MAIN notebooks | `pipeline_code=DMI_FEE`; task name defaults from layer, with optional `task_code` override |
| RAW | `cycle_date=2026-10-15`, `execution_mode=MANUAL` or `SCHEDULED` |
| STAGE / MAIN | Omit cycle/mode overrides; use the batch values |
| Separate phase jobs | Share a resolved `workflow_execution_key` across both jobs |

A single job defaults to `AIDP:<job_run_id>`. Scheduler expressions such as
`{{job.run_id}}` must resolve before the framework receives them; validate the
actual platform bindings. Connect tasks on predecessor success. Disable
retry-on-timeout until writer shutdown and exact-run recovery are proven in your
environment. See [scheduling](OPERATIONS.md#two-phase-scheduling) and
[MAIN recovery](OPERATIONS.md#atpadw-setup-and-controlled-main-recovery).

## Use your own pipeline

Follow the [SQL Generator README](../generator/README.md) to deploy/activate metadata and prepare MAIN
tables. Supply the generic starter's pipeline/task selection explicitly. Register
custom handlers only in a provider-owned launcher, aligned with its dataset contract.

Use the [custom handler implementation and registration](#custom-task-steps)
below when your plan references business code; keep the call aligned with your
own pipeline/task codes. A missing registration fails before source I/O.

## Run from Data Flow / ActiveBatch

Use `entrypoints/dataflow/raw.py`, `stage.py` or `main.py` for built-in-only tasks.
Supply required `--pipeline-code` and optional `--task-code` selection flags.
The launcher derives the layer-specific task default and consumes these flags before calling
the existing adapter. Use a provider-owned script for custom tasks; generic starters
register no custom functions. Each invocation executes one task; ActiveBatch owns dependencies.

1. Install the supplied wheel and Oracle driver in the Data Flow Python environment.
   Configure the same Spark OCI permissions, driver DB variables/network and wallet
   as AIDP. Bootstrap secrets through the platform; do not put them in REST arguments.
2. ActiveBatch launches RAW, waits for success, then STAGE, then MAIN through the
   OCI Data Flow REST API. `examples/dataflow/create_run.json` is a request-body example;
   supply real application/compartment IDs and authenticate through your OCI setup.
3. Pass `--execution-key ACTIVEBATCH:<parent-workflow-instance-id>` to every run.
   RAW also needs `--cycle-date YYYY-MM-DD` and optional `--execution-mode MANUAL`.
   The key is generated from the scheduler's parent instance, not manually typed,
   and stays unchanged for failed-task retries. A new workflow gets a new key.
4. The adapter records the actual `DATAFLOW_RUN_ID`. If your environment does not
   expose it, bootstrap must supply the real run OCID through `--run-id`; the
   framework never invents an external run ID. Oracle's attempt counter increments.
5. On failure, ActiveBatch resubmits the failed application, then downstream work.
   RAW stays completed. Keep application code/wheel/metadata/source unchanged.
   ActiveBatch owns polling, retries and exhaustion; MDPF does not call its API.
   The starter has no failure-injection option. Handler errors must propagate
   to the platform as failed runs; do not catch them and return success.

For example, every child run receives the same `--execution-key`, while its
Data Flow run OCID and internal TASK_RUN ID differ. After abandoning retry and
stopping active writers, call
`mdpf_runtime.runner.finalize_failed_batch(pipeline_code="...", execution_key="...")`.
Hard-killed attempts require explicit exact-run failure after writer shutdown;
there is no automatic stale-run or timeout recovery.

## Available Task Steps

Steps pass a dictionary of Spark DataFrames between them, keyed by dataset code.
INPUT/OUTPUT datasets come from `TASK_DATASET`; their locations and column rules
come from `DATASET` and `DATASET_COLUMN`. Built-ins use these settings and accept
empty parameters only. Their names cannot be overridden by notebook functions.

| Step | When to use it | Required inputs | What it does and produces |
|---|---|---|---|
| `READ_SOURCE` | Start RAW ingestion from landing files | Parquet INPUT datasets in OCI, matching column definitions, a FILE source configuration and cycle date | Reads each file with Spark, checks its schema/values and records `INGESTION_ITEM` receipts. Returns INPUT DataFrames. No previous DataFrame is needed. |
| `READ_PARQUET` | Start STAGE or MAIN from an earlier task's output | RAW/STAGE Parquet INPUT datasets and a completed producer attempt in the same batch | Checks columns and actual batch/run lineage. Returns INPUT DataFrames with the stored business types; validates and removes the layer-specific system audit/lineage columns. |
| `DIRECT_MAP` | Convert types or select a subset of columns before output | DataFrames containing the target column names; OUTPUT column definitions | Selects columns in target order and converts to VARCHAR2, exact NUMBER(p,s) or date-only DATE. Returns OUTPUT DataFrames; invalid/lossy conversions fail. It does not rename, join or calculate business values. |
| `VALIDATE_DQ` | Check the final data before STAGE/MAIN output | DataFrames already matching OUTPUT columns/types; STAGE NOT_NULL/UNIQUE/RANGE/ALLOWED_VALUES and paired ROW_COUNT policies | Checks column/value constraints and configured policies. Records `POLICY_RESULT` for configured checks and returns the validated OUTPUT DataFrames. A blocking failure stops the task. |
| `WRITE_PARQUET` | Finish RAW or STAGE | Validated output-shaped DataFrames and RAW/STAGE Parquet OUTPUT locations | Rechecks the output contract and writes a batch folder in OCI, adding the layer-specific system audit fields (see DQ and audit contracts in the framework reference). Repair overwrites that batch folder. Returns OUTPUT DataFrames. |
| `LOAD_MAIN` | Finish MAIN with an Oracle load | Output-shaped DataFrames and configured Oracle OUTPUT tables (`GOLD` / `ADB_TABLE`) | Validates and prepares rows; task completion inserts/reconciles them in the target database, then records runtime completion (ADW commits before ATP). Returns OUTPUT DataFrames. MAIN tables also need `BATCH_ID`, `TASK_RUN_ID`, `ROW_NUMBER`, `CREATED_AT` and `UPDATED_AT`. |

For example, `DIRECT_MAP` can convert text `1250.75` to NUMBER(18,2) and
`2026-10-05` to DATE. A name change or a date such as `10/05/2026` needs custom
Python first. It never invents missing target columns or silently truncates values.

Multiple landing files are copied to their RAW datasets by matching
`TASK_DATASET.usage_sequence`. Built-ins do not automatically join multiple inputs;
custom joins/routing must return the configured OUTPUT dataset keys.

## Default task sequences

The SQL Generator creates these when YAML omits `task_steps`:

| Task | Default sequence |
|---|---|
| RAW | `READ_SOURCE` → `WRITE_PARQUET` |
| STAGE | `READ_PARQUET` → `DIRECT_MAP` (when needed) → `VALIDATE_DQ` → `WRITE_PARQUET` |
| MAIN | `READ_PARQUET` → `VALIDATE_DQ` → `LOAD_MAIN` |

RAW preserves the declared source contract (supported Parquet types). STAGE needs `DIRECT_MAP` when input columns require
projection or datatype conversion; omit it if they already match the output.
MAIN normally needs no conversion because generated STAGE/MAIN schemas match.
The reviewed DMI_FEE plan includes an explicit MAIN DIRECT_MAP step.
If custom MAIN logic changes that, include `DIRECT_MAP` explicitly where needed.

A supplied `task_steps` list is used exactly. Keep one reader first, one final
write/load step, and `VALIDATE_DQ` immediately before STAGE/MAIN output—even with
no DQ policies. Any step failure fails the task. Repair reruns the whole task;
there are no internal step checkpoints.

## Custom task steps

Use custom Python for joins/routing, renaming, cleaning, filtering, business date
formats, derived columns or calculations. Built-ins handle generic reading,
matching-name conversion, validation and writing.
The utility example demonstrates this required transformation. Production ownership is in
`data-pipelines/providers/dmi/src/provider_dmi/fee.py`.
Register it in a provider-owned launcher. Generic AIDP/Data Flow starters do not
include or register this function. The implementation below is a reference example.

Add a reference inside the YAML `task_steps` list:

```yaml
- code: CUSTOM_FEE_TRANSFORM
  parameters:
    column: CLIENT_NO
```

See the [complete YAML plan](../generator/REFERENCE.md#configure-task-steps).
Implement and register that exact code in the STAGE notebook:

```python
from pyspark.sql import functions as F
from mdpf_runtime.aidp import execute_task

def custom_fee_transform(frames, context, params):
    df = frames["DMI_FEE_FEE_RAW"]
    column = params["column"]
    return {"DMI_FEE_FEE_STAGE": df.withColumn(column, F.trim(F.col(column)))}

result = execute_task(
    pipeline_code="DMI_FEE",
    task_code="DMI_FEE_STAGE_LOAD",
    aidputils=aidputils,
    spark=spark,
    custom_steps={"CUSTOM_FEE_TRANSFORM": custom_fee_transform},
)
```

`frames` contains dataset-coded DataFrames; return a nonempty dictionary of
DataFrames. `context` is read-only and supplies IDs, cycle date and input/output
location maps. `params` contains the YAML `parameters` values. This example trims
CLIENT_NO, then the YAML plan runs `DIRECT_MAP`, DQ and the writer.

The generator creates the custom metadata reference; it does not implement or
test your function. The runtime checks every handler before data I/O. Missing or
non-callable registrations fail clearly. Raising an exception fails the task.
The notebook registers functions and invokes MDPF; it does not call each step.

## Supported DQ rules

See [DQ and audit contracts in the framework reference](REFERENCE.md#dq-reconciliation-and-audit-contracts) for STAGE column rules, FAIL/WARN, paired row counts,
transactional MAIN reconciliation and the five audit columns. Column policies run
once at VALIDATE_DQ; schema/type constraints remain blocking at required boundaries.
MAIN enforces Oracle contracts/constraints and actual insert counts, without
repeating unchanged STAGE business DQ. MDPF_MAIN_MAX_ROWS defaults to 100,000 rows per task.


## Find and resolve a failure

Use [troubleshooting](OPERATIONS.md#troubleshooting) and the
[worked investigations](OPERATIONS.md#worked-investigations). Inspect by the printed
batch/run IDs. The operational guide owns retry/finalization procedures, including
MAIN review; do not infer safe replay from ATP status alone.

## Where the code lives

| Module in `src/mdpf_runtime/` | Responsibility |
|---|---|
| `aidp.py` | Reads notebook parameters and supplies AIDP workflow/attempt identities |
| `dataflow.py` | Reads application arguments and the actual Data Flow run identity |
| `runner.py` | Shares task launch/finalization across platforms; manages the DB connection |
| `pipeline.py` | Public facade, execution loop, lifecycle decisions and transaction coordination, including MAIN inserts/reconciliation |
| `metadata.py` | Batch-pinned task/dataset/schema/policy resolution and plan/path validation before external I/O |
| `runtime.py` | Runtime records, receipts, policy evidence, work queue and operational event SQL on the existing DB connection |
| `dq.py` | Shared rule-parameter validation, Spark rule calculations and result formatting |
| `steps.py` | Built-in registry, readers, direct mapping, DQ coordination and validated output preparation |
| `schema.py` | Validates schemas/values and performs explicit conversions |
| `storage.py` | Validates OCI paths; uses Spark for Parquet runtime I/O |
| `db.py` | Opens Oracle connections; handles binds, inserts and transactions |
| `__init__.py` | Identifies the package/version |

Use `MetadataFramework` for lifecycle operations. Internal `runtime.py` helpers
never open transactions, commit or roll back; the facade checks allowed transitions
and calls them inside the ATP/control transaction. MAIN inserts/reconciliation
commit in ADW first, then ATP control evidence; failure after the first commit requires MAIN recovery review. The source-receipt transaction still
finishes before opening a Parquet source object. Operational event inserts move to `runtime.py`;
task lifecycle logging remains in the execution loop; detailed plans and steps are DEBUG only.

Existing facade methods, handler signatures and `mdpf_runtime.steps` DQ imports remain
available. Readers/writers stay in `steps.py`; no service or repository classes
were added. Stored MAIN layer values remain `GOLD`.

Current limits: MAIN collects at most the configured MDPF_MAIN_MAX_ROWS on the driver (default 100,000 across outputs). Parquet Repair overwrites
batch paths; multiple OCI writes are not atomic. Dated source URIs must be
immutable; automatic receipts provide lineage, not cross-batch deduplication.
DQ supports NOT_NULL, single-column UNIQUE, numeric RANGE, ALLOWED_VALUES and explicitly paired ROW_COUNT. The 17-table model retains unused
MAPPING_RULE, PIPELINE_STATE and OUTBOUND_CONFIG. REPROCESS, Iceberg and automatic
hard-timeout recovery are outside scope. See the [current bundle validation](../../VALIDATION.txt)
for completed checks and outstanding live AIDP/Oracle/OCI validation. Dated release
notes retain historical evidence for their own builds.

## DQ, reconciliation and audit contracts

### Layer ownership

RAW checks the exact source delivery, Parquet schema/length/type contracts and nonempty
input. Proven technical failures still trigger optional whole-file quarantine.
LANDING/RAW inference now defaults to nullable strings even when the target default
is NOT NULL. An explicit source `is_nullable: N` remains a technical source contract;
do not use it for a business-only restriction. Put business DQ in STAGE.

STAGE supports `NOT_NULL`, `UNIQUE`, `RANGE` and `ALLOWED_VALUES`. Business policies
run once at `VALIDATE_DQ`. Conversion/type/length checks remain at boundaries;
required target nullability is enforced after DQ evidence and again at the sink.
MAIN checks the Oracle contract/constraints and actual insert counts. Column DQ
policies targeting MAIN are rejected; move them to the corresponding STAGE dataset
in a new DRAFT release. If MAIN custom code changes business values, move that
transformation and its business validation to STAGE. Do not load unvalidated
business changes under the assumption that prior STAGE DQ covers them.

### YAML

DMI_FEE configures two NOT_NULL and two ROW_COUNT policies. The excerpt below
also illustrates optional checks; it does not add them to the shipped DMI_FEE plan.
See `generator/examples/dq_and_reconciliation.yaml` for the separate DQ fixture.

```yaml
dq_rules:
  - column: LN_NO       # Omitted datasets means all generated STAGE outputs.
    check: NOT_NULL
    severity: FAIL       # Default; ERROR / FAIL_TASK in Oracle metadata.
  - column: LN_NO
    check: UNIQUE
  - datasets: [DMI_FEE_FEE_STAGE]
    column: FEE_TRAN_TY
    check: ALLOWED_VALUES
    values: [ASSESS, REVERSE]
  - datasets: [DMI_FEE_FEE_STAGE]
    column: FEE_TRAN_AM
    check: RANGE
    min: 0
    max: 1000000
    severity: WARN       # WARN / WARN in Oracle metadata.
  - datasets: [DMI_FEE_FEE_STAGE]
    check: ROW_COUNT
    source_dataset: DMI_FEE_FEE_RAW
  - datasets: [DMI_FEE_FEE_MAIN]
    check: ROW_COUNT
    source_dataset: DMI_FEE_FEE_STAGE
```

`column` is required for column checks, forbidden for `ROW_COUNT`. Each output can
have one `ROW_COUNT` rule and must explicitly name an input of the adjacent layer.
The rule declares that this mapping preserves rows: equality is intended. STAGE
count rules support one RAW input with one or several independently paired STAGE
outputs. Multi-input joins/aggregation are rejected for count equality. Custom
filters, joins and aggregations need their own explicitly reviewed reconciliation
contract; do not configure equality for them. MAIN append count rules pair each
output with a configured STAGE input; never compare summed fan-out counts.

`ALLOWED_VALUES` uses case-sensitive, untrimmed equality. Values must be a nonempty,
unique list compatible with the column: strings for VARCHAR2, finite YAML numbers
that fit NUMBER precision/scale, ISO YYYY-MM-DD dates for DATE. NULL is ignored;
use `NOT_NULL` separately. Empty string is a real value for this check; MAIN still
rejects empty strings because Oracle converts them to NULL. Booleans, NULL entries,
nested values and duplicates are invalid. RANGE is inclusive; UNIQUE counts every
row sharing a duplicate non-null value. Neither repairs nor drops rows.

WARN failures record `WARN` / `WARNED` and continue. Tasks remain `COMPLETED`, so
existing producer reads work. `reject_count` remains zero. FAIL records durable
`FAIL` / `FAILED_TASK`, fails the exact attempt, retains RAW and leaves the batch
RUNNING for the scheduler. A WARN never bypasses required schema or Oracle constraints.
STAGE DQ never copies landing files to quarantine.

### MAIN transaction and row limit

STAGE `ROW_COUNT` runs before any STAGE write. MAIN `ROW_COUNT` runs after DML and
before COMMIT using `cursor.rowcount` returned by `OracleDb.insert_many()`.
Inserts/reconciliation commit in ADW first; successful policy results, load events,
task completion and batch closure commit in ATP second. A mismatch before the ADW commit rolls back all its MAIN outputs. Failure policy evidence and failed-attempt/error history are then
recorded in a separate transaction. Unknown/negative affected counts fail closed.
Even without a configured count policy, actual inserts must equal prepared rows.
MAIN reconciliation cannot be WARN.

`MDPF_MAIN_MAX_ROWS` defaults to `100000` **across all MAIN outputs in one task**.
Every driver collection uses `limit(remaining + 1)`. Exceeding the cap fails before
any insert, without truncation. The setting must be 1–2147483646; no unlimited
sentinel is supported. A row cap does not bound bytes for unusually wide rows.
After reviewing driver capacity, raise the cap in the MAIN worker environment and
retry only failed MAIN in the same batch (with exact recovery acknowledgement in
separate-database mode). MAIN loading remains bounded by driver memory and the configured row cap.

Generated MAIN DDL does not infer business keys/unique/check/FK constraints from DQ.
STAGE UNIQUE cannot prevent duplicates already in MAIN; review required Oracle
constraints separately. Affected-row counts prove DML counts, not post-trigger
business values or cross-batch uniqueness.

### Five framework-managed audit fields

| Layer | Existing fields | Added fields |
|---|---|---|
| RAW | `_batch_id`, `_run_id` | `_ingestion_item_id` BIGINT; `_ingested_at` TIMESTAMP |
| STAGE | `_batch_id`, `_run_id` | `_processed_at` TIMESTAMP |
| MAIN | `BATCH_ID`, `TASK_RUN_ID`, `ROW_NUMBER` | `CREATED_AT`, `UPDATED_AT` TIMESTAMP(6) WITH TIME ZONE |

Timestamps represent UTC instants; set Spark `spark.sql.session.timeZone=UTC` for
consistent display. MAIN timestamps use an explicit Oracle timestamp-with-time-zone
bind and are equal on insert. There is no UPDATE/MERGE implementation; a future
upsert must preserve CREATED_AT and change UPDATED_AT only for actual updates.
RAW receives the exact source receipt associated through its validated input/output
pair. Multi-input RAW custom transformations are rejected: place combinations in
STAGE so the receipt ID is never assigned arbitrarily.

Parquet readers require exactly the business columns plus the layer's system fields,
validate their types/non-null values, batch and completed producer IDs, and verify
RAW receipt ownership against the paired PROCESSED input in that producer attempt.
System fields are removed before transformations and DQ. All system names are
reserved; never put them in business YAML columns/overrides or DQ rules.

No new framework tables, scheduler states, archive, row rejection, MERGE or waiting
batch dashboard are included. See [upgrade instructions](OPERATIONS.md#development-rollout) before installing.

## Release timestamp and terminal-record rules

DRAFT releases can edit effective_from; effective_to stays NULL until retirement.
Once APPROVED, effective_from and approved content are frozen. APPROVED → ACTIVE
cannot change either date. ACTIVE → RETIRED must supply effective_to greater than
or equal to the approved effective_from. RETIRED rows are immutable. The existing
lifecycle trigger enforces these rules; no extra trigger or constraint is added.
Terminal BATCH rows, like terminal TASK_RUN rows, reject UPDATE and DELETE.

## Quarantine destination layout

Use <root>/<source_system>/<feed>/ingest_date=YYYYMMDD/batch_id=<id>/<original filename>.parquet.
The root excludes source_system; feed metadata is mandatory. There is no run folder.
Same-batch retries overwrite their quarantine destination; new batches retain separate
copies. RAW/STAGE use extensionless folders.
See [path details](../generator/REFERENCE.md#quarantine-and-parquet-folder-names).
