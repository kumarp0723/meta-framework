"""Read one HCP Vault Dedicated KV v2 secret using bootstrap JSON in OCI Vault.

No caching, credential logging, global environment mutation or DB connection.
The caller chooses how to consume the returned mapping.
"""
import base64
import json
import math
import ssl
from urllib import error, parse, request


class _NoRedirect(request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None  # Never forward AppRole credentials or Vault tokens elsewhere.


def read_hcp_secret(bootstrap_secret_id, *, client=None, timeout=30, ca_bundle=None):
    """Retrieve CURRENT OCI bootstrap, AppRole-login, then return KV v2 data.data.

    Bootstrap fields: vault_url, namespace, role_id, secret_id, kv_mount,
    secret_path; optional auth_mount (default approle). Default OCI authentication
    is Resource Principal. A supplied SecretsClient supports other approved auth.
    HTTPS certificate verification and a finite per-request timeout are mandatory.
    Errors omit remote bodies and credential values.
    """
    if not isinstance(bootstrap_secret_id,str) or not bootstrap_secret_id.strip():
        raise ValueError('A bootstrap secret OCID is required.')
    if isinstance(timeout,bool) or not isinstance(timeout,(int,float)) or not math.isfinite(timeout) or timeout<=0:
        raise ValueError('timeout must be a positive finite number of seconds.')
    if client is None:
        import oci
        client = oci.secrets.SecretsClient({},signer=oci.auth.signers.get_resource_principals_signer())
    try:
        response = client.get_secret_bundle(bootstrap_secret_id,stage='CURRENT')
        config = json.loads(base64.b64decode(response.data.secret_bundle_content.content,validate=True))
        required = {'vault_url','namespace','role_id','secret_id','kv_mount','secret_path'}
        if not isinstance(config,dict) or not required<=config.keys() or config.keys()-required-{'auth_mount'}:
            raise ValueError()
        if any(not isinstance(v,str) or not v.strip() or any(ord(c)<32 for c in v) for v in config.values()):
            raise ValueError()
        url = parse.urlsplit(config['vault_url'])
        if url.scheme!='https' or not url.hostname or url.username or url.password or url.query or url.fragment or url.path not in ('','/'):
            raise ValueError()
        for key in ('namespace','kv_mount','secret_path'):
            if any(p in ('','.','..') for p in config[key].strip('/').split('/')) or not config[key].strip('/'):
                raise ValueError()
        auth_mount = config.get('auth_mount','approle')
        if any(p in ('','.','..') for p in auth_mount.split('/')):
            raise ValueError()
    except Exception:
        raise RuntimeError('Cannot read or validate OCI Vault bootstrap JSON.') from None
    opener = request.build_opener(request.HTTPSHandler(context=ssl.create_default_context(cafile=ca_bundle)),_NoRedirect())
    headers = {'X-Vault-Namespace':config['namespace'],'Accept':'application/json'}
    base = config['vault_url'].rstrip('/')+'/v1/'

    def call(path, *, payload=None, token=None, label):
        sent = dict(headers)
        if token is not None:
            sent['X-Vault-Token'] = token
        body = None
        if payload is not None:
            sent['Content-Type'] = 'application/json'
            body = json.dumps(payload).encode('utf-8')
        req = request.Request(base+path,data=body,headers=sent)
        try:
            with opener.open(req,timeout=timeout) as response:
                return json.load(response)
        except error.HTTPError as exc:
            raise RuntimeError(f'HCP Vault {label} failed (HTTP {exc.code}).') from None
        except Exception:
            raise RuntimeError(f'HCP Vault {label} failed.') from None

    login = call('auth/'+parse.quote(auth_mount,safe='/')+'/login',
        payload={'role_id':config['role_id'],'secret_id':config['secret_id']},label='AppRole login')
    try:
        token = login['auth']['client_token']
        if not isinstance(token,str) or not token or any(ord(c)<32 for c in token):
            raise ValueError()
    except Exception:
        raise RuntimeError('HCP Vault AppRole login returned no usable token.') from None
    result = call(parse.quote(config['kv_mount'].strip('/'),safe='/')+'/data/'+
                  parse.quote(config['secret_path'].strip('/'),safe='/'),token=token,label='KV v2 read')
    try:
        value = result['data']['data']
        if not isinstance(value,dict):
            raise ValueError()
        return value
    except Exception:
        raise RuntimeError('HCP Vault KV v2 returned no usable secret data.') from None
