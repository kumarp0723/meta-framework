"""Runtime records and audit SQL on the caller's existing connection.

The facade owns lifecycle decisions and transactions. These helpers never open
transactions, commit, roll back, process Spark data, or contact Object Storage.
"""
import json


def batch_by_execution_key(db, pipeline_code, execution_key):
    return db.one('SELECT * FROM RUNTIME.BATCH WHERE pipeline_code=:p AND execution_key=:k',
                  p=pipeline_code, k=execution_key)


def batches_by_job_run_id(db, pipeline_code, job_run_id):
    return db.execute('SELECT * FROM RUNTIME.BATCH WHERE pipeline_code=:p AND orchestrator_run_id=:j',
                      p=pipeline_code, j=job_run_id)


def locked_batch(db, batch_id):
    """Read a batch row FOR UPDATE, or None; the caller owns and ends the transaction."""
    return db.one('SELECT * FROM RUNTIME.BATCH WHERE batch_id=:id FOR UPDATE', id=batch_id)


def insert_batch(db, values):
    """Insert supplied batch fields and start time; return the allocated batch_id.

    Values omit batch_id; lifecycle checks belong to the facade. Uses the caller's
    transaction, never commits, and propagates sequence/insert/update errors."""
    batch_id = db.next_id('RUNTIME.BATCH', 'batch_id')
    db.insert('RUNTIME.BATCH', dict(batch_id=batch_id, **values))
    db.execute('UPDATE RUNTIME.BATCH SET start_timestamp=SYSTIMESTAMP WHERE batch_id=:id', id=batch_id)
    return batch_id


def latest_attempt(db, batch_id, task_id):
    return db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE batch_id=:b AND task_id=:t ORDER BY attempt_number DESC',
                  b=batch_id, t=task_id)


def task_run(db, run_id, *, lock=False):
    """Return the exact attempt row or None; lock=True requires a caller-owned transaction."""
    sql = 'SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id'
    return db.one(sql + (' FOR UPDATE' if lock else ''), id=run_id)


def locked_task_status(db, run_id):
    """Read the exact attempt status FOR UPDATE without committing the caller's transaction."""
    return db.one('SELECT status FROM RUNTIME.TASK_RUN WHERE task_run_id=:id FOR UPDATE', id=run_id)


def running_attempt(db, batch_id):
    return db.one("SELECT task_run_id FROM RUNTIME.TASK_RUN WHERE batch_id=:b AND status='RUNNING'", b=batch_id)


def insert_task_attempt(db, values):
    """Insert supplied attempt fields/start time and return the allocated task_run_id.

    Values omit task_run_id. The facade chooses attempt/predecessor identities and
    enforces retry guards. SQL errors propagate in its existing transaction."""
    run_id = db.next_id('RUNTIME.TASK_RUN', 'task_run_id')
    db.insert('RUNTIME.TASK_RUN', dict(task_run_id=run_id, **values))
    db.execute('UPDATE RUNTIME.TASK_RUN SET start_timestamp=SYSTIMESTAMP WHERE task_run_id=:id', id=run_id)
    return run_id


def previous_source_receipt(db, batch_id, task_id, dataset_id):
    return db.one('''SELECT ie.source_location, ie.source_item_key FROM RUNTIME.INGESTION_ITEM ie
        JOIN RUNTIME.TASK_RUN tr ON tr.task_run_id=ie.task_run_id
        WHERE tr.batch_id=:b AND tr.task_id=:t AND ie.dataset_id=:d ORDER BY tr.attempt_number ASC''',
        b=batch_id, t=task_id, d=dataset_id)


def insert_source_receipt(db, values):
    """Insert supplied receipt fields/receive time and return its ingestion_item_id.

    Values omit ingestion_item_id. The facade commits this receipt before source
    reads; this helper neither owns the transaction nor catches SQL failures."""
    item_id = db.next_id('RUNTIME.INGESTION_ITEM', 'ingestion_item_id')
    db.insert('RUNTIME.INGESTION_ITEM', dict(ingestion_item_id=item_id, **values))
    db.execute('UPDATE RUNTIME.INGESTION_ITEM SET received_timestamp=SYSTIMESTAMP WHERE ingestion_item_id=:id', id=item_id)
    return item_id


def completed_producers(db, batch_id, release_id, task_id):
    """List COMPLETED producer attempts in the exact batch, release and task.

    The reader requires exactly one result before reading retained Parquet."""
    return db.execute('''SELECT task_run_id FROM RUNTIME.TASK_RUN
        WHERE batch_id=:b AND config_release_id=:r AND task_id=:t AND status='COMPLETED' ''',
        b=batch_id, r=release_id, t=task_id)


def processed_source_receipts(db, run_id, release_id, task_id, dataset_id):
    """Find PROCESSED source receipts paired to a RAW output by usage_sequence.

    Filter by the completed producer attempt and pinned release. The reader checks
    uniqueness and compares the returned identity with Parquet lineage."""
    return db.execute('''SELECT ie.ingestion_item_id FROM RUNTIME.INGESTION_ITEM ie
        JOIN METADATA.TASK_DATASET src ON src.config_release_id=ie.config_release_id
            AND src.dataset_id=ie.dataset_id AND src.dataset_role='INPUT' AND src.is_enabled='Y'
        JOIN METADATA.TASK_DATASET dst ON dst.config_release_id=src.config_release_id
            AND dst.task_id=src.task_id AND dst.usage_sequence=src.usage_sequence
            AND dst.dataset_role='OUTPUT' AND dst.is_enabled='Y'
        WHERE ie.task_run_id=:run AND ie.config_release_id=:r AND ie.status='PROCESSED'
            AND src.task_id=:task AND dst.dataset_id=:dataset''',
        run=run_id, r=release_id, task=task_id, dataset=dataset_id)


def mark_source_quarantined(db, item_id, run_id, destination):
    """Update this attempt's receipt/location after a confirmed copy and facade guards.

    No object I/O or commit occurs here; SQL errors propagate to the caller."""
    db.execute("""UPDATE RUNTIME.INGESTION_ITEM SET status='QUARANTINED',
        quarantine_location=:q WHERE ingestion_item_id=:id AND task_run_id=:run""",
        q=destination, id=item_id, run=run_id)


def mark_source_processed(db, item_id, count):
    """Set receipt count, PROCESSED status and time inside the completion transaction."""
    db.execute('''UPDATE RUNTIME.INGESTION_ITEM SET status='PROCESSED', source_record_count=:count,
        processed_timestamp=SYSTIMESTAMP WHERE ingestion_item_id=:id''', count=count, id=item_id)


def insert_policy_results(db, results):
    """Insert dq.policy_result() dictionaries, allocating each policy_result_id.

    Results include pinned policy/dataset identities, expected/actual values,
    status and action evidence. They omit policy_result_id. Never evaluate rules,
    apply lifecycle decisions or commit; SQL errors propagate to the facade."""
    for result in results:
        db.insert('RUNTIME.POLICY_RESULT', dict(result,
            policy_result_id=db.next_id('RUNTIME.POLICY_RESULT', 'policy_result_id')))


def mark_task_completed(db, run_id, input_count, output_count):
    """Set counts, zero rejects and COMPLETED/end time in the caller's transaction.

    The facade has already validated outputs and the active attempt; no commit here."""
    db.execute('''UPDATE RUNTIME.TASK_RUN SET status='COMPLETED', input_count=:ic, output_count=:oc,
        reject_count=0, end_timestamp=SYSTIMESTAMP WHERE task_run_id=:id''',
        ic=input_count, oc=output_count, id=run_id)


def mark_task_failed(db, run_id, code, message, failed_step):
    """Persist the supplied failure/code/step and end time without committing.

    The facade owns terminal guards and the transaction containing related evidence."""
    db.execute('''UPDATE RUNTIME.TASK_RUN SET status='FAILED', error_code=:c,
        error_message=:m, failed_step_code=:s, end_timestamp=SYSTIMESTAMP WHERE task_run_id=:id''',
        c=code[:100], m=message[:4000], s=failed_step, id=run_id)


def mark_unprocessed_sources_failed(db, run_id):
    """Fail remaining receipts for this attempt while preserving PROCESSED/QUARANTINED."""
    db.execute("UPDATE RUNTIME.INGESTION_ITEM SET status='FAILED' WHERE task_run_id=:id AND status NOT IN ('PROCESSED','QUARANTINED')", id=run_id)


def mark_batch_completed(db, batch_id):
    """Set COMPLETED/end time within the facade's guarded completion transaction."""
    db.execute("UPDATE RUNTIME.BATCH SET status='COMPLETED', end_timestamp=SYSTIMESTAMP WHERE batch_id=:id", id=batch_id)


def mark_batch_failed(db, batch_id):
    """Set FAILED/end time after facade finalization guards; never commit here."""
    db.execute("UPDATE RUNTIME.BATCH SET status='FAILED', end_timestamp=SYSTIMESTAMP WHERE batch_id=:id", id=batch_id)


def insert_failure_work_item(db, run, code, message):
    """Insert EXCEPTION:<batch_id>:<task_run_id> support evidence without committing.

    The facade's locked failure path prevents duplicate callbacks from reinserting
    it. This helper does not retry work, close prior errors or catch SQL failures."""
    queue_id = db.next_id('OPERATIONS.WORK_QUEUE', 'work_queue_id')
    db.insert('OPERATIONS.WORK_QUEUE', dict(work_queue_id=queue_id,
        target_config_release_id=run['config_release_id'], scope_type='TASK', batch_id=run['batch_id'],
        task_run_id=run['task_run_id'], idempotency_key=f"EXCEPTION:{run['batch_id']}:{run['task_run_id']}",
        reason_code=code[:100], description=message[:2000], status='OPEN', requested_by='MDPF'))


def insert_event(db, batch, run_id, code, message, details=None, error_code=None):
    """Insert a correlated operational event in the caller's existing transaction.

    Optional details are JSON-serialized; error_code selects ERROR/HIGH. This is
    database audit evidence, separate from worker stdout. Errors propagate; no commit."""
    event_id = db.next_id('OPERATIONS.EVENT_LOG', 'event_log_id')
    db.insert('OPERATIONS.EVENT_LOG', dict(event_log_id=event_id,
        config_release_id=batch['config_release_id'], batch_id=batch['batch_id'], task_run_id=run_id,
        event_code=code, event_type='ERROR' if error_code else 'INFO', severity='HIGH' if error_code else 'LOW',
        error_code=error_code[:100] if error_code else None, message=message[:4000],
        details_json=json.dumps(details) if details else None,
        correlation_id=batch['correlation_id'], created_by='MDPF'))
