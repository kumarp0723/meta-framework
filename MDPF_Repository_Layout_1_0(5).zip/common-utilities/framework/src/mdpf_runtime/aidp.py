"""AIDP entry point. The scheduler owns dependencies and Repair selection."""
import json

from .db import OracleDb
from .pipeline import MetadataFramework


def _workflow_key(value):
    if (not isinstance(value, str) or not value.strip() or '{{' in value or
            len(value.encode('utf-8')) > 300 or any(ord(c) < 32 for c in value)):
        raise ValueError('workflow_execution_key must be a resolved stable workflow identity, at most 300 UTF-8 bytes.')
    return value.strip()


def _execute_task(pipeline_code, task_code, parameters, db, custom_steps=None, spark=None, *, main_db=None):
    values = {key: str(value).strip() for key, value in parameters.items() if value is not None}
    for key in ("job_run_id", "task_run_id", "execution_count"):
        if not values.get(key) or "{{" in values[key]:
            raise ValueError(f"Missing or unresolved AIDP task parameter: {key}")
    count = int(values["execution_count"])
    if count < 1:
        raise ValueError("AIDP execution_count must be positive.")
    key = values.get('workflow_execution_key')
    if key:
        key = _workflow_key(key)
    else:
        key = 'AIDP:' + values['job_run_id']
    # A stable workflow key can span jobs. Keep the initial job correlation on BATCH;
    # do not pass a different job ID back through the strict initial-creation guard.
    existing = MetadataFramework(db, pipeline_code).get_batch_by_execution_key(key)
    from .runner import _run_task
    options = {'main_db':main_db} if main_db is not None else {}
    if values.get('main_retry_reviewed_run_id'):
        options['main_retry_reviewed_run_id'] = int(values['main_retry_reviewed_run_id'])
    return _run_task(db, pipeline_code=pipeline_code, task_code=task_code,
        execution_key=key, task_run_id=values['task_run_id'],
        orchestrator_run_id=existing['orchestrator_run_id'] if existing else values['job_run_id'], orchestrator_attempt_number=count,
        cycle_date=values.get('cycle_date') or None,
        execution_mode=values.get('execution_mode','').upper() or None,
        triggered_by='AIDP', custom_steps=custom_steps, spark=spark, **options)


def execute_task(*, pipeline_code, task_code, aidputils, custom_steps=None, spark=None, main_db=None):
    """Execute one metadata task. Call from each AIDP task notebook."""
    names = ("job_run_id", "task_run_id", "execution_count", "cycle_date", "execution_mode", "workflow_execution_key", "main_retry_reviewed_run_id")
    for name in names:
        aidputils.widgets.text(name=name, defaultValue="", label=name)
    parameters = {name: aidputils.widgets.get(name) for name in names}
    db = OracleDb()
    try:
        result = _execute_task(pipeline_code, task_code, parameters, db, custom_steps, spark,
                               **({'main_db':main_db} if main_db is not None else {}))
        print(json.dumps({key: result[key] for key in (
            "batch_id", "task_run_id", "status", "input_count", "output_count")}, default=str))
        return result
    finally:
        db.close()


def finalize_failed_job(*, pipeline_code, job_run_id=None, workflow_execution_key=None):
    """Finalize only after the scheduler/operator gives up on restart."""
    db = OracleDb()
    try:
        fw = MetadataFramework(db, pipeline_code)
        if workflow_execution_key is not None:
            if job_run_id is not None:
                raise ValueError('Supply workflow_execution_key or job_run_id, not both.')
            batch = fw.get_batch_by_execution_key(_workflow_key(workflow_execution_key))
        elif job_run_id:
            batch = fw.get_batch_by_job_run_id(job_run_id)
        else:
            raise ValueError('Supply workflow_execution_key or job_run_id.')
        if not batch:
            raise ValueError("No batch exists for this pipeline and job run.")
        fw.fail_batch(batch["batch_id"])
    finally:
        db.close()
