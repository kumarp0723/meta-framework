"""MDPF: metadata-driven Spark tasks with Oracle control and OCI Parquet I/O."""
import logging

logging.getLogger(__name__).addHandler(logging.NullHandler())

__version__ = "1.0"
