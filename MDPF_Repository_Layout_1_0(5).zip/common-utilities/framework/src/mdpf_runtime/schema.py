"""Small, explicit Spark schema contracts shared by built-in steps."""
import re

from pyspark.sql import functions as F, types as T


class DataValidationError(ValueError):
    """A proven data/contract violation, distinct from storage or database failures."""


RESERVED = {"_BATCH_ID", "_RUN_ID", "BATCH_ID", "TASK_RUN_ID", "ROW_NUMBER",
            "_INGESTION_ITEM_ID", "_INGESTED_AT", "_PROCESSED_AT", "CREATED_AT", "UPDATED_AT"}


def sql_identifier(value, qualified=False):
    pattern = r"[A-Z][A-Z0-9_]{0,127}"
    if qualified:
        pattern += r"\." + pattern
    if not isinstance(value, str) or not re.fullmatch(pattern, value):
        raise ValueError("Use uppercase, unquoted SQL identifiers" + (" in OWNER.TABLE form." if qualified else "."))
    return value


def string_limit(column):
    match = re.fullmatch(r"([1-9][0-9]*)(?: (BYTE|CHAR))?", str(column.get("length_precision_scale") or ""))
    if not match:
        raise ValueError("VARCHAR2 requires a positive length, optionally followed by BYTE or CHAR.")
    return int(match[1]), match[2] or "BYTE"


def spark_type(column):
    kind, spec = column["data_type"], column.get("length_precision_scale")
    if kind == "VARCHAR2":
        string_limit(column)
        return T.StringType()
    if kind == "DATE" and not spec:
        return T.DateType()
    if kind == "NUMBER":
        match = re.fullmatch(r"([1-9][0-9]*)(?:,([0-9]+))?", str(spec or ""))
        if match:
            precision, scale = int(match[1]), int(match[2] or 0)
            if 1 <= precision <= 38 and 0 <= scale <= precision:
                return T.DecimalType(precision, scale)
    raise ValueError("Supported types: VARCHAR2(length [BYTE|CHAR]), NUMBER(p[,s]) with 1<=p<=38 and 0<=s<=p, and date-only DATE.")


def validate_columns(columns):
    if not columns:
        raise ValueError("Dataset columns are required.")
    names, sequences = set(), set()
    for column in columns:
        name, sequence = sql_identifier(column["column_name"]), column["column_sequence"]
        if name in RESERVED or name in names or sequence in sequences or sequence <= 0:
            raise ValueError("Duplicate/reserved column name or invalid column sequence in DATASET_COLUMN.")
        if column["is_nullable"] not in ("Y", "N"):
            raise ValueError("Column nullability must be Y or N.")
        spark_type(column)
        names.add(name)
        sequences.add(sequence)


def require_columns(df, columns, label, exact=True):
    names = [c["column_name"] for c in columns]
    folded = [n.upper() for n in df.columns]
    if len(set(folded)) != len(folded):
        raise DataValidationError(f"{label} columns contain duplicate or ambiguous names.")
    if not set(names) <= set(df.columns) or (exact and len(df.columns) != len(names)):
        raise DataValidationError(f"{label} columns do not match DATASET_COLUMN.")
    return names


def validate_frame(df, columns, label, check_nulls=True, source=False, oracle=False):
    """Check values without changing them. Return null counts for policy recording."""
    require_columns(df, columns, label)
    checks = [F.count("*").alias("_rows")]
    for index, column in enumerate(columns):
        name = column["column_name"]
        if df.schema[name].dataType != spark_type(column):
            raise DataValidationError(f"{label} types do not match DATASET_COLUMN: {name}.")
        value = F.col(name)
        null = value.isNull()
        if column["data_type"] == "VARCHAR2":
            # Required source fields retain the previous blank-value protection.
            null = null | ((F.trim(value) == "") if source else (value == ""))
            length, unit = string_limit(column)
            size = F.length(F.encode(value, "UTF-8")) if unit == "BYTE" else F.length(value)
            checks.append(F.sum(F.when(size > length, 1).otherwise(0)).alias(f"length_{index}"))
            if oracle:
                checks.append(F.sum(F.when(value == "", 1).otherwise(0)).alias(f"empty_{index}"))
        checks.append(F.sum(F.when(null, 1).otherwise(0)).alias(f"null_{index}"))
    summary = df.agg(*checks).first().asDict()
    nulls = {}
    for index, column in enumerate(columns):
        name = column["column_name"]
        nulls[name] = int(summary[f"null_{index}"] or 0)
        if summary.get(f"length_{index}"):
            raise DataValidationError(f"{label} length constraint violated: {name}.")
        if summary.get(f"empty_{index}"):
            raise DataValidationError(f"Oracle empty strings become NULL; normalize explicitly in the notebook: {name}.")
        if check_nulls and column["is_nullable"] == "N" and nulls[name]:
            raise DataValidationError(f"Required {'source column is blank' if source else 'target column has nulls'}: {name}.")
    if source and not summary["_rows"]:
        raise DataValidationError("Source must contain data rows.")
    return nulls, int(summary["_rows"])


def convert_frame(df, columns):
    """Project by matching names; reject failed or numerically lossy conversions."""
    names = require_columns(df, columns, "DIRECT_MAP", exact=False)
    expressions, checks = [], []
    for index, column in enumerate(columns):
        name, target = column["column_name"], spark_type(column)
        original = F.col(name)
        incoming = df.schema[name].dataType
        text = original.cast("string")
        converted = F.expr(f"try_cast(`{name}` AS {target.simpleString()})")
        invalid = original.isNotNull() & converted.isNull()
        if isinstance(target, T.DecimalType):
            if not isinstance(incoming, (T.StringType, T.DecimalType, T.ByteType, T.ShortType, T.IntegerType, T.LongType, T.NullType)):
                raise DataValidationError(f"DIRECT_MAP requires exact numeric input, not floating-point/other types: {name}.")
            # Check lexical digits before casting, so rounding/overflow cannot hide loss.
            fraction = F.regexp_replace(F.regexp_extract(text, r"\.([0-9]*)$", 1), "0+$", "")
            whole = F.regexp_replace(F.regexp_extract(text, r"^[+-]?([0-9]*)", 1), "^0+", "")
            invalid = invalid | (original.isNotNull() & (
                ~text.rlike(r"^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)$") |
                (F.length(fraction) > target.scale) | (F.length(whole) > target.precision-target.scale)))
        elif isinstance(target, T.DateType):
            if not isinstance(incoming, (T.StringType, T.DateType, T.NullType)):
                raise DataValidationError(f"DIRECT_MAP DATE is date-only; parse business timestamps explicitly: {name}.")
            invalid = invalid | (original.isNotNull() & (
                ~text.rlike(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$") |
                (F.substring(text, 1, 4) == "0000") | (F.date_format(converted, "yyyy-MM-dd") != text)))
        elif not isinstance(incoming, (T.StringType, T.DateType, T.DecimalType, T.ByteType, T.ShortType, T.IntegerType, T.LongType, T.NullType)):
            raise DataValidationError(f"DIRECT_MAP cannot prove an exact string conversion for {name}; normalize in the notebook.")
        checks.append(F.sum(F.when(invalid, 1).otherwise(0)).alias(str(index)))
        expressions.append(converted.alias(name))
    if any(df.agg(*checks).first().asDict().values()):
        raise DataValidationError("Input values cannot be cast without conversion loss or precision/scale violations.")
    return df.select(*expressions).select(*names)
