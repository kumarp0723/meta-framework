"""Shared DQ parameter validation, Spark calculations and result formatting."""
from datetime import date, datetime
from decimal import Decimal, localcontext

from pyspark.sql import functions as F

from .schema import spark_type, string_limit


def validate_dq_parameters(params, column=None):
    """Validate the fixed rule keys/types and optional column contract.

    Return params, normalizing ALLOWED_VALUES in place (including date strings).
    Unsupported rules/values raise ValueError before evaluation; no database I/O."""
    checks = {'NOT_NULL': {'check'}, 'UNIQUE': {'check'},
              'RANGE': {'check', 'min', 'max'},
              'ALLOWED_VALUES': {'check', 'values'},
              'ROW_COUNT': {'check', 'source_dataset'}}
    if not isinstance(params, dict) or not isinstance(params.get('check'), str) or params['check'] not in checks:
        raise ValueError('Supported DQ checks: NOT_NULL, UNIQUE, RANGE, ALLOWED_VALUES and ROW_COUNT.')
    check = params['check']
    if set(params) != checks[check]:
        raise ValueError(f'{check} requires exactly {sorted(checks[check])}.')
    if check == 'ROW_COUNT':
        from .schema import sql_identifier
        sql_identifier(params['source_dataset'])
    if check == 'RANGE':
        for value in (params['min'], params['max']):
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError('RANGE min/max must be finite numeric YAML values.')
            number = Decimal(str(value))
            if (not number.is_finite() or
                    max(len(number.as_tuple().digits) + max(number.as_tuple().exponent, 0), -number.as_tuple().exponent) > 38):
                raise ValueError('RANGE bounds must fit Spark decimal precision/scale 38.')
        if params['min'] > params['max']:
            raise ValueError('RANGE min must not exceed max.')
        if column is not None and column['data_type'] != 'NUMBER':
            raise ValueError('RANGE requires a NUMBER column.')
    if check == 'ALLOWED_VALUES':
        values = params['values']
        if not isinstance(values, list) or not values:
            raise ValueError('ALLOWED_VALUES requires a nonempty list of unique scalar values.')
        normalized = []
        for value in values:
            if isinstance(value, bool) or value is None or not isinstance(value, (str, int, float, date)) or isinstance(value, datetime):
                raise ValueError('ALLOWED_VALUES requires non-null string, numeric or date scalars; booleans are unsupported.')
            if isinstance(value, (int, float)) and not Decimal(str(value)).is_finite():
                raise ValueError('ALLOWED_VALUES numeric values must be finite.')
            if column is not None:
                kind = column['data_type']
                if kind == 'VARCHAR2':
                    if not isinstance(value, str):
                        raise ValueError('ALLOWED_VALUES requires string values for VARCHAR2.')
                    length, unit = string_limit(column)
                    if (len(value.encode('utf-8')) if unit == 'BYTE' else len(value)) > length:
                        raise ValueError('ALLOWED_VALUES value exceeds the column length.')
                elif kind == 'NUMBER':
                    if not isinstance(value, (int, float)):
                        raise ValueError('ALLOWED_VALUES requires numeric values for NUMBER.')
                    number, typ = Decimal(str(value)), spark_type(column)
                    with localcontext() as context:
                        context.prec = 80
                        if abs(number) >= Decimal(10) ** (typ.precision - typ.scale) or number != number.quantize(Decimal(1).scaleb(-typ.scale)):
                            raise ValueError('ALLOWED_VALUES number does not fit the column precision/scale.')
                elif kind == 'DATE':
                    if isinstance(value, date):
                        value = value.isoformat()
                    if not isinstance(value, str) or date.fromisoformat(value).isoformat() != value:
                        raise ValueError('ALLOWED_VALUES DATE values require YYYY-MM-DD dates.')
            if isinstance(value, date):
                value = value.isoformat()
            if value in normalized:
                raise ValueError('ALLOWED_VALUES values must be unique.')
            normalized.append(value)
        params['values'] = normalized
    return params


def _policy_failures(df, policy, nulls):
    """Return (failed_row_count, expectation) for one non-ROW_COUNT policy.

    NOT_NULL uses precomputed null counts. Other checks ignore NULLs; UNIQUE counts
    all rows in duplicate groups. Spark actions may run here; persistence is separate."""
    params, name = policy['parameters'], policy['column_name']
    if params['check'] == 'NOT_NULL':
        return nulls[name], '0 nulls'
    values = df.where(F.col(name).isNotNull())
    if params['check'] == 'UNIQUE':
        duplicates = values.select(F.col(name).alias('_dq_value')).groupBy('_dq_value').agg(F.count('*').alias('_dq_count'))
        amount = duplicates.where(F.col('_dq_count') > 1).agg(F.sum('_dq_count')).first()[0]
        return int(amount or 0), '0 rows with duplicate non-null values'
    if params['check'] == 'ALLOWED_VALUES':
        kind = df.schema[name].dataType
        allowed = [F.lit(Decimal(str(v)) if kind.typeName() == 'decimal' else v).cast(kind) for v in params['values']]
        return values.where(~F.col(name).isin(allowed)).count(), '0 rows outside the allowed values'
    invalid = (F.col(name) < F.lit(Decimal(str(params['min'])))) | (F.col(name) > F.lit(Decimal(str(params['max']))))
    return values.where(invalid).count(), f"0 rows outside [{params['min']}, {params['max']}]"


def policy_result(ctx, policy, failed_count, expected, actual):
    """Format one pinned policy fact for runtime.insert_policy_results().

    Return a dictionary without policy_result_id. Zero failures produces PASS;
    unknown/nonzero failures produce FAIL or the configured WARN. No I/O occurs."""
    failed = failed_count is None or failed_count != 0
    warning = failed and policy['failure_action'] == 'WARN'
    return dict(config_release_id=policy['config_release_id'], policy_id=policy['policy_id'],
        batch_id=ctx['batch']['batch_id'], task_run_id=ctx['run_id'], dataset_id=policy['dataset_id'],
        dataset_column_id=policy.get('dataset_column_id'), result_level=policy['policy_scope_type'],
        result_status=('WARN' if warning else 'FAIL') if failed else 'PASS',
        expected_value=str(expected), actual_value=str(actual), threshold_value=policy['threshold_value'],
        failed_record_count=failed_count, failure_action_taken=('WARNED' if warning else 'FAILED_TASK') if failed else None)
