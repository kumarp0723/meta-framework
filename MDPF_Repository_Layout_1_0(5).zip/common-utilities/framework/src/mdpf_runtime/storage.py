"""OCI paths and native Spark Parquet I/O for metadata-selected tasks."""
from pathlib import PurePosixPath
from urllib.parse import urlsplit


def object_address(uri):
    parts = urlsplit(str(uri))
    if parts.scheme != "oci" or "@" not in parts.netloc or parts.query or parts.fragment:
        raise ValueError("Use oci://bucket@namespace/object-key (no query or fragment).")
    bucket, namespace = parts.netloc.split("@", 1)
    key = parts.path.lstrip("/")
    if not bucket or not namespace or ".." in PurePosixPath(key).parts:
        raise ValueError("Invalid OCI object address.")
    return namespace, bucket, key


class ObjectStorage:
    def quarantine_file(self, source, destination):
        """Copy an immutable delivery, replacing this batch's quarantine object on retry."""
        import oci
        source_ns, source_bucket, source_key = object_address(source)
        dest_ns, dest_bucket, dest_key = object_address(destination)
        if not source_key or not dest_key or source == destination:
            raise ValueError('Quarantine requires distinct exact object locations.')
        signer = oci.auth.signers.get_resource_principals_signer()
        client = oci.object_storage.ObjectStorageClient({}, signer=signer)
        etag = client.head_object(source_ns, source_bucket, source_key).headers['etag']
        details = oci.object_storage.models.CopyObjectDetails(
            source_object_name=source_key, source_object_if_match_e_tag=etag,
            destination_region=signer.region, destination_namespace=dest_ns,
            destination_bucket=dest_bucket, destination_object_name=dest_key)
        response = oci.object_storage.ObjectStorageClientCompositeOperations(client).copy_object_and_wait_for_state(
            source_ns, source_bucket, details, wait_for_states=['COMPLETED', 'FAILED', 'CANCELED'],
            waiter_kwargs={'max_wait_seconds': 300, 'max_interval_seconds': 5})
        if getattr(response.data, 'status', None) != 'COMPLETED':
            raise RuntimeError('Quarantine copy did not complete successfully.')
        client.head_object(dest_ns, dest_bucket, dest_key)

    def read_parquet(self, spark, location):
        if not object_address(location)[2]:
            raise ValueError("An exact OCI object prefix is required.")
        return spark.read.parquet(location)

    def write_parquet(self, location, df):
        """Spark replaces this batch's Parquet dataset on Repair."""
        if not object_address(location)[2]:
            raise ValueError("An exact OCI object prefix is required.")
        df.write.mode("overwrite").parquet(location)
