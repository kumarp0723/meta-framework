"""Shared launcher contracts: selection/forwarding, validation and error visibility."""
import json
from pathlib import Path
import runpy
from types import SimpleNamespace

import pytest


ROOT = Path(__file__).resolve().parents[1] / 'entrypoints'
ROLES = ('raw', 'stage', 'main')


class Widgets:
    def __init__(self, values):
        self.values = values
    def text(self, *, name, defaultValue, label):
        self.values.setdefault(name, defaultValue)
    def get(self, name):
        return self.values[name]


def notebook(role, values, spark=None):
    scope = {'aidputils': SimpleNamespace(widgets=Widgets(values)), 'spark': spark}
    for cell in json.loads((ROOT / 'aidp' / f'{role}.ipynb').read_text())['cells']:
        if cell['cell_type'] == 'code':
            exec(compile(''.join(cell['source']), f'{role}.ipynb', 'exec'), scope)
    return scope


@pytest.mark.parametrize('role', ROLES)
@pytest.mark.parametrize('override', [None, 'PROVIDER_SPECIAL_TASK'])
def test_dataflow_selection_and_exact_argument_forwarding(monkeypatch, role, override):
    calls = []
    monkeypatch.setattr('mdpf_runtime.dataflow.execute_task', lambda **kw: calls.append(kw) or {'status': 'COMPLETED'})
    main = runpy.run_path(str(ROOT / 'dataflow' / f'{role}.py'))['main']
    execution = ['--execution-key', 'SCHEDULER:workflow-17', '--run-id',
                 'ocid1.dataflowrun.oc1.test.attempt17', '--cycle-date', '2026-10-15',
                 '--execution-mode', 'MANUAL']
    selection = ['--pipeline-code', 'PROVIDER_DATA'] + (['--task-code', override] if override else [])
    spark = object()
    assert main(selection + execution, spark=spark) == {'status': 'COMPLETED'}
    assert calls == [dict(pipeline_code='PROVIDER_DATA',
                          task_code=override or f'PROVIDER_DATA_{role.upper()}_LOAD',
                          spark=spark, argv=execution)]
    assert 'custom_steps' not in calls[0]


@pytest.mark.parametrize('role', ROLES)
@pytest.mark.parametrize('override', ['', 'PROVIDER_SPECIAL_TASK'])
def test_aidp_selection_leaves_scheduler_widgets_to_adapter(monkeypatch, role, override):
    calls = []
    monkeypatch.setattr('mdpf_runtime.aidp.execute_task', lambda **kw: calls.append(kw) or {'status': 'COMPLETED'})
    values = {'pipeline_code': 'PROVIDER_DATA', 'task_code': override,
              'job_run_id': 'scheduler-job', 'task_run_id': 'attempt-17',
              'execution_count': '2', 'workflow_execution_key': 'SCHEDULER:workflow-17'}
    original = dict(values)
    spark = object()
    scope = notebook(role, values, spark)
    assert scope['result'] == {'status': 'COMPLETED'}
    assert calls[0]['pipeline_code'] == 'PROVIDER_DATA'
    assert calls[0]['task_code'] == (override or f'PROVIDER_DATA_{role.upper()}_LOAD')
    assert calls[0]['spark'] is spark
    assert calls[0]['aidputils'].widgets.values == original
    assert 'custom_steps' not in calls[0]


@pytest.mark.parametrize('platform', ['aidp', 'dataflow'])
@pytest.mark.parametrize('value', ['', 'lowercase', '{{job.parameters.pipeline_code}}'])
def test_bad_selection_fails_before_adapter(monkeypatch, platform, value):
    def unexpected(**kwargs):
        pytest.fail('Adapter must not be reached for invalid selection.')
    monkeypatch.setattr(f'mdpf_runtime.{platform}.execute_task', unexpected)
    with pytest.raises(ValueError, match='identifiers'):
        if platform == 'aidp':
            notebook('raw', {'pipeline_code': value})
        else:
            main = runpy.run_path(str(ROOT / 'dataflow/raw.py'))['main']
            main(['--pipeline-code', value])


@pytest.mark.parametrize('role', ROLES)
@pytest.mark.parametrize('platform', ['aidp', 'dataflow'])
def test_worker_errors_reach_scheduler(monkeypatch, role, platform):
    def failure(**kwargs):
        raise RuntimeError('worker failure')
    monkeypatch.setattr(f'mdpf_runtime.{platform}.execute_task', failure)
    with pytest.raises(RuntimeError, match='worker failure'):
        if platform == 'aidp':
            notebook(role, {'pipeline_code': 'PROVIDER_DATA'})
        else:
            main = runpy.run_path(str(ROOT / 'dataflow' / f'{role}.py'))['main']
            main(['--pipeline-code', 'PROVIDER_DATA'])


def test_dataflow_missing_pipeline_and_help_are_connection_free(monkeypatch, capsys):
    def unexpected(**kwargs):
        pytest.fail('Help/invalid arguments must not call adapter.')
    monkeypatch.setattr('mdpf_runtime.dataflow.execute_task', unexpected)
    main = runpy.run_path(str(ROOT / 'dataflow/raw.py'))['main']
    with pytest.raises(SystemExit) as missing:
        main([])
    assert missing.value.code == 2
    with pytest.raises(SystemExit) as help_result:
        main(['--help'])
    assert help_result.value.code == 0
    assert '--execution-key' in capsys.readouterr().out


def test_only_canonical_launchers_remain():
    assert not (ROOT.parent / 'dataflow/raw.py').exists()
    assert not (ROOT.parent / 'notebooks/Task_raw.ipynb').exists()
    assert len(list(ROOT.rglob('*.py'))) + len(list(ROOT.rglob('*.ipynb'))) == 6


def test_shared_runtime_assets_have_no_fee_defaults_or_handlers():
    import re
    for folder in ('entrypoints', 'dataflow', 'notebooks'):
        for path in (ROOT.parent / folder).rglob('*'):
            if path.suffix in ('.py', '.ipynb'):
                assert not re.search(r'DMI[_-]FEE|custom_fee_transform|CUSTOM_FEE_TRANSFORM', path.read_text(), re.I), path
