"""Opt-in destructive Oracle tests for an explicitly selected development ATP only.

Run with MDPF_TEST_ORACLE_RESET=DROP_MDPF_DEV_SCHEMAS plus separate
MDPF_TEST_ORACLE_DSN/PASSWORD/DB_NAME. No normal MDPF_DB_* credentials are used.
The fixture requires absent MDPF accounts, installs/tests, then removes its own accounts.
"""
from datetime import datetime, timezone, timedelta
import os
from pathlib import Path
import re
import secrets

import oracledb
import pytest

SQL=Path(__file__).resolve().parents[1]/'sql'
pytestmark=pytest.mark.skipif(
    os.environ.get('MDPF_TEST_ORACLE_RESET')!='DROP_MDPF_DEV_SCHEMAS',
    reason='Live destructive Oracle tests require explicit dedicated-ATP opt-in.')


def statements(path):
    """Read this package's SQLcl scripts, not an arbitrary SQL/SQLcl parser."""
    pending=[];block=False
    for line in path.read_text().splitlines():
        stripped=line.strip()
        if not stripped or stripped.startswith('--'):continue
        if not pending and re.match(r'^(SET|WHENEVER|PROMPT|ACCEPT|UNDEFINE)\b',stripped,re.I):continue
        if not pending and stripped=='PASSWORD MDPF_RUNTIME':
            yield ('PASSWORD',stripped);continue
        if stripped=='/':
            if pending:yield ('SQL','\n'.join(pending));pending=[];block=False
            continue
        if not pending:block=bool(re.match(r'^(DECLARE|BEGIN|CREATE OR REPLACE TRIGGER)\b',stripped,re.I))
        pending.append(line)
        if not block and stripped.endswith(';'):
            yield ('SQL','\n'.join(pending)[:-1]);pending=[]
    assert not pending,'Unexpected unfinished statement'


def run_script(db,name,password=None):
    for kind,sql in statements(SQL/name):
        if kind=='PASSWORD':
            # Generated test password is an ASCII token, never a committed secret.
            assert re.fullmatch(r'[A-Za-z0-9!]+',password)
            db.execute('ALTER USER MDPF_RUNTIME IDENTIFIED BY "'+password+'"')
        else:
            db.execute(sql)


@pytest.fixture(scope='module')
def admin():
    args=dict(user='ADMIN',password=os.environ['MDPF_TEST_ORACLE_PASSWORD'],dsn=os.environ['MDPF_TEST_ORACLE_DSN'])
    for key in ('config_dir','wallet_location','wallet_password'):
        if os.environ.get('MDPF_TEST_ORACLE_'+key.upper()):args[key]=os.environ['MDPF_TEST_ORACLE_'+key.upper()]
    connection=oracledb.connect(**args);db=connection.cursor()
    try:
        expected=os.environ['MDPF_TEST_ORACLE_DB_NAME']
        assert db.execute("SELECT SYS_CONTEXT('USERENV','DB_NAME') FROM DUAL").fetchone()[0]==expected
        assert db.execute("SELECT COUNT(*) FROM ALL_USERS WHERE username IN ('METADATA','RUNTIME','OPERATIONS','MDPF_RUNTIME')").fetchone()[0]==0, 'Live setup tests require absent MDPF accounts.'
    except BaseException:
        db.close();connection.close();raise
    password='Mdpf1!'+secrets.token_hex(12)
    # Cleanup is limited to accounts this fixture creates after the fresh-DB check.
    try:
        run_script(db,'00_create_schemas.sql',password=password)
        run_script(db,'01_framework.sql');run_script(db,'02_grants.sql')
        yield db,connection,args,password
    finally:
        for owner in ('MDPF_RUNTIME','OPERATIONS','RUNTIME','METADATA'):
            if db.execute('SELECT COUNT(*) FROM ALL_USERS WHERE username=:owner',owner=owner).fetchone()[0]:
                db.execute('DROP USER '+owner+' CASCADE')
        db.close();connection.close()


def scalar(db,sql,**binds):return db.execute(sql,binds).fetchone()[0]


def new_release(db):
    rid=scalar(db,'SELECT METADATA.SEQ_CONFIG_RELEASE.NEXTVAL FROM DUAL')
    start=datetime(2026,11,1,tzinfo=timezone.utc)
    db.execute('''INSERT INTO METADATA.CONFIG_RELEASE
        (config_release_id,pipeline_code,pipeline_name,release_version,release_desc,release_status,effective_from,created_by)
        VALUES (:rid,:pipeline,'Oracle setup test','1.0','Isolated test','DRAFT',:start,'TEST')''',
        rid=rid,pipeline='SETUP_TEST_'+str(rid),start=start)
    return rid,start


def test_fresh_install_objects_constraints_and_app_access(admin):
    db,conn,args,password=admin
    owners="('METADATA','RUNTIME','OPERATIONS')"
    assert scalar(db,f'SELECT COUNT(*) FROM ALL_TABLES WHERE owner IN {owners}')==17
    assert scalar(db,f'SELECT COUNT(*) FROM ALL_TAB_COLUMNS WHERE owner IN {owners}')==234
    assert scalar(db,f"SELECT COUNT(*) FROM ALL_TRIGGERS WHERE owner IN {owners} AND status='ENABLED'")==12
    assert scalar(db,f'SELECT COUNT(*) FROM ALL_SEQUENCES WHERE sequence_owner IN {owners}')==8
    assert scalar(db,f"SELECT COUNT(*) FROM ALL_OBJECTS WHERE owner IN {owners} AND status='INVALID'")==0
    for kind,count in [('P',17),('R',46),('U',25)]:
        assert scalar(db,f'SELECT COUNT(*) FROM ALL_CONSTRAINTS WHERE owner IN {owners} AND constraint_type=:kind',kind=kind)==count
    assert scalar(db,"SELECT COUNT(*) FROM DBA_USERS WHERE username IN ('METADATA','RUNTIME','OPERATIONS') AND authentication_type='NONE'")==3
    with oracledb.connect(**{**args,'user':'MDPF_RUNTIME','password':password}) as runtime:
        with runtime.cursor() as cur:
            cur.execute('SELECT COUNT(*) FROM METADATA.CONFIG_RELEASE')
            with pytest.raises(oracledb.DatabaseError):cur.execute("DELETE FROM METADATA.CONFIG_RELEASE")
    with pytest.raises(oracledb.DatabaseError,match='ORA-20101'):run_script(db,'00_create_schemas.sql',password=password)
    with pytest.raises(oracledb.DatabaseError,match='ORA-20104'):run_script(db,'01_framework.sql')


def test_release_timestamp_transitions_and_metadata_immutability(admin):
    db,conn,_,_=admin;rid,start=new_release(db)
    db.execute("UPDATE METADATA.CONFIG_RELEASE SET effective_from=:start WHERE config_release_id=:rid",start=start+timedelta(hours=1),rid=rid)
    start+=timedelta(hours=1)
    with pytest.raises(oracledb.DatabaseError,match='ORA-20050'):
        db.execute('UPDATE METADATA.CONFIG_RELEASE SET effective_to=:end WHERE config_release_id=:rid',end=start+timedelta(days=1),rid=rid)
    db.execute("INSERT INTO METADATA.DATASET (config_release_id,dataset_id,dataset_code,dataset_name,layer) VALUES (:rid,1,'INPUT','Input','RAW')",rid=rid)
    db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='APPROVED' WHERE config_release_id=:rid",rid=rid)
    with pytest.raises(oracledb.DatabaseError,match='ORA-20048'):
        db.execute("UPDATE METADATA.DATASET SET dataset_name='Changed' WHERE config_release_id=:rid",rid=rid)
    with pytest.raises(oracledb.DatabaseError,match='ORA-20044'):
        db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE',effective_from=:start WHERE config_release_id=:rid",start=start+timedelta(hours=1),rid=rid)
    db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE' WHERE config_release_id=:rid",rid=rid)
    for end in (None,start-timedelta(seconds=1)):
        with pytest.raises(oracledb.DatabaseError,match='ORA-20051'):
            db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='RETIRED',effective_to=:end WHERE config_release_id=:rid",end=end,rid=rid)
    with pytest.raises(oracledb.DatabaseError,match='ORA-20046'):
        db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='RETIRED',effective_to=:end,effective_from=:start WHERE config_release_id=:rid",end=start+timedelta(days=2),start=start+timedelta(hours=1),rid=rid)
    db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='RETIRED',effective_to=:end WHERE config_release_id=:rid",end=start+timedelta(days=1),rid=rid)
    with pytest.raises(oracledb.DatabaseError,match='ORA-20047'):
        db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE' WHERE config_release_id=:rid",rid=rid)
    conn.commit()


@pytest.mark.parametrize('status',['COMPLETED','COMPLETED_WITH_WARNINGS','FAILED'])
def test_terminal_batches_block_update_and_delete_without_child_rows(admin,status):
    db,conn,_,_=admin;rid,start=new_release(db)
    bid=scalar(db,'SELECT RUNTIME.SEQ_BATCH_ID.NEXTVAL FROM DUAL')
    db.execute('''INSERT INTO RUNTIME.BATCH (batch_id,config_release_id,pipeline_code,batch_type,cycle_date,execution_key,correlation_id,status,triggered_by)
        VALUES (:bid,:rid,:pipeline,'MANUAL',:cycle,:key,:key,'RUNNING','TEST')''',bid=bid,rid=rid,pipeline='SETUP_TEST_'+str(rid),cycle=start.date(),key='TEST:'+str(bid))
    db.execute('UPDATE RUNTIME.BATCH SET status=:status WHERE batch_id=:bid',status=status,bid=bid)
    for sql in ("UPDATE RUNTIME.BATCH SET triggered_by='CHANGED' WHERE batch_id=:bid",'DELETE FROM RUNTIME.BATCH WHERE batch_id=:bid'):
        with pytest.raises(oracledb.DatabaseError,match='ORA-20060'):db.execute(sql,bid=bid)
    conn.commit()


def test_constraint_violations_and_duplicate_execution_keys(admin):
    db,conn,_,_=admin;rid,start=new_release(db)
    for bid in (100001,100002):
        sql='''INSERT INTO RUNTIME.BATCH (batch_id,config_release_id,pipeline_code,batch_type,cycle_date,execution_key,correlation_id,status,triggered_by)
            VALUES (:bid,:rid,:pipeline,'MANUAL',:cycle,'DUPLICATE',:correlation,'RUNNING','TEST')'''
        if bid==100001:db.execute(sql,bid=bid,rid=rid,pipeline='SETUP_TEST_'+str(rid),cycle=start.date(),correlation=str(bid))
        else:
            with pytest.raises(oracledb.DatabaseError,match='ORA-00001'):db.execute(sql,bid=bid,rid=rid,pipeline='SETUP_TEST_'+str(rid),cycle=start.date(),correlation=str(bid))
    with pytest.raises(oracledb.DatabaseError,match='ORA-02290'):
        db.execute("INSERT INTO METADATA.DATASET (config_release_id,dataset_id,dataset_code,dataset_name,layer,upstream_config) VALUES (:rid,1,'JSON','JSON','RAW','invalid')",rid=rid)
    with pytest.raises(oracledb.DatabaseError,match='ORA-02291'):
        db.execute("INSERT INTO METADATA.DATASET (config_release_id,dataset_id,dataset_code,dataset_name,layer) VALUES (-999,1,'ORPHAN','Orphan','RAW')")
    conn.rollback()
