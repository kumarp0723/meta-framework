# MDPF Framework 1.0

The framework executes one metadata-defined Spark task at a time. RAW reads landing
data and writes Parquet. STAGE applies transformations and DQ. MAIN loads ADW.
ATP records metadata, batches, attempts, policy results and operational events.

New developers: start with the [developer guide](DEVELOPER_GUIDE.md), then the
[production DMI_FEE walkthrough](../../data-pipelines/providers/dmi/README.md).
For runtime settings and APIs, use the [reference](REFERENCE.md). For failures and
retries, use [operations](OPERATIONS.md).

## Fresh ATP installation

Use SQLcl/SQL*Plus connected as ATP `ADMIN`. From `common-utilities/framework/`:

```sql
@sql/00_create_schemas.sql
@sql/01_framework.sql
@sql/02_grants.sql
@sql/03_inspect.sql
```

| Script | Result |
|---|---|
| `00_create_schemas.sql` | Three schema-only owners and the `MDPF_RUNTIME` application login. Enter its password at the masked prompt. Review the initial 1 GB DATA quota per owner. |
| `01_framework.sql` | 17 tables, 234 columns, 12 triggers and eight sequences, with direct dependency grants in order. Stops on existing objects or invalid compilation. |
| `02_grants.sql` | Required application object access. ATP ADMIN publishes metadata in this development setup; the runtime account cannot publish it. |
| `03_inspect.sql` | Object, sequence, constraint and compilation checks, followed by runtime diagnostics. Expected inventory and enabled/validated constraints must pass. |

These scripts create a fresh ATP installation. They stop on existing accounts or
objects. Oracle DDL commits independently, so a failed install can leave partial
objects. Do not rerun them over a populated environment. No incremental upgrade
scripts are included.

Provision MAIN owners, reviewed generated table DDL and runtime grants separately
in **ADW**. The walkthrough shows the two deployment sessions. Runtime execution
requires both [ATP and ADW settings](REFERENCE.md#separate-atp-and-adw-connections)
or two caller-owned adapters; MAIN never falls back to ATP.

## Runtime behavior

- Shared launchers live in `entrypoints/aidp/` and `entrypoints/dataflow/`; custom
  tasks use provider launchers. See [launcher selection](../README.md#shared-launchers).
- The scheduler controls task dependencies and retries. Reuse the workflow key
  across tasks/retries; each attempt has its own identity.
- MAIN commits ADW before recording ATP completion. Failed MAIN attempts require
  [operator review](OPERATIONS.md#atpadw-setup-and-controlled-main-recovery) before retry.
- `MDPF_MAIN_MAX_ROWS` defaults to **100000**, shared across a task's MAIN outputs.
  Exceeding it fails before inserts. MAIN still uses driver-side bounded collection.
- RAW can quarantine a whole source file on a proven technical validation failure.
  STAGE business DQ failures retain normal failed-task behavior.

Python installation and local tests are in the [developer guide](DEVELOPER_GUIDE.md#local-setup-and-checks).
Current verification and environment limits are in [VALIDATION.txt](../../VALIDATION.txt).
CI/CD and platform job creation automation are deferred.
