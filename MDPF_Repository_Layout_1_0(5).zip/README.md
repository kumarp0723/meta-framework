# MDPF 1.0

MDPF runs data pipelines on OCI Data Flow or AIDP. The onboarding tools prepare
YAML and SQL; the framework reads published metadata and runs RAW, STAGE and MAIN.
ATP stores metadata and execution history. ADW stores MAIN business data.

## Start here

1. Follow the [developer guide](common-utilities/framework/DEVELOPER_GUIDE.md) to
   install locally, run tests and understand the module flow.
2. Follow the [production DMI_FEE walkthrough](data-pipelines/providers/dmi/README.md)
   in a prepared OCI/Oracle environment.
3. Use the [framework reference](common-utilities/framework/REFERENCE.md),
   [generator reference](common-utilities/generator/REFERENCE.md) and
   [operations guide](common-utilities/framework/OPERATIONS.md) when you need details.

The full walkthrough needs OCI, ATP and ADW. Local tests use Spark and test adapters;
passing them does not mean the cloud environment is configured.

## Repository map

| Folder | What belongs here |
|---|---|
| [common-utilities](common-utilities/README.md) | Shared framework, onboarding tools, platform launchers and reference fixtures |
| [data-pipelines](data-pipelines/README.md) | Provider configurations, business transformations, samples and tests |
| [platform-deployments](platform-deployments/README.md) | Placeholder for future environment/deployment automation |

The ZIP contains these three roots side by side. Each can become a GitLab
repository. Keep `framework/` and `generator/` under `common-utilities/` for the
cross-package tests and links. Production DMI_FEE is maintained in
`data-pipelines/providers/dmi`; the utility Parquet landing examples with CSV samples are regression fixtures.

Python packages are `mdpf_runtime` and `mdpf_onboarding`. Software versions remain
**1.0**. Wheels, review bundles and local test assets are included in the ZIP;
each repository's `.gitignore` excludes test files, test-support and `dist/` contents.
Existing tracked files must be untracked separately; ignore rules do not remove them.
CI/CD, registry publishing and job
creation automation are deferred. Manual generation, release packaging and platform
handoff are documented.

See [VALIDATION.txt](VALIDATION.txt) for checks performed on this build and pending
live verification. Package and release manifests identify the delivered artifacts.

The `common-utilities/test-support/` package provides development-only local test adapters
and a versioned SQL fixture. It is not deployed with either runtime utility.
