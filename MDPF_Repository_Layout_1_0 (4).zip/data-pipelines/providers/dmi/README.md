# DMI provider

This is the production source of the DMI_FEE contract and its custom Python step.
Utility examples remain independent reference fixtures. Change the provider files
here for production work; do not maintain a second production YAML in the utilities.

| File | Responsibility |
|---|---|
| [datasets/fee/onboarding.yaml](datasets/fee/onboarding.yaml) | Ordered business schema, paths, three task plans and four policies |
| [src/provider_dmi/fee.py](src/provider_dmi/fee.py) | `CUSTOM_FEE_TRANSFORM`: trim `CLIENT_NO`, return `DMI_FEE_FEE_STAGE` |
| [entrypoints/dataflow/stage.py](entrypoints/dataflow/stage.py) / [entrypoints/aidp/stage.ipynb](entrypoints/aidp/stage.ipynb) | Fixed DMI_FEE STAGE entry points with explicit handler registration |
| [scripts/package_release.py](scripts/package_release.py) | Assemble matching generated YAML/SQL, wheels and launchers into a new release ZIP |
| [datasets/fee/samples](datasets/fee/samples/) | Two-row synthetic input and expected output |
| [tests](tests/) | Transformation checks |
| [datasets/fee/tests](datasets/fee/tests/) | Contract, generation and local execution checks |
| [pyproject.toml](pyproject.toml) | Independently buildable `provider-dmi` package, version 1.0 |

## Local setup and checks

Use Python 3.10+ and Java 17. With the three repository folders side by side,
run from their parent directory:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e './common-utilities/framework' -e './common-utilities/generator' -e './data-pipelines/providers/dmi[test]'
python -m pip check
python -m pip wheel --no-deps --wheel-dir common-utilities/framework/dist ./common-utilities/framework
python common-utilities/framework/scripts/package_release.py --output common-utilities/framework/dist/local-check/mdpf-1.0-release.zip
export MDPF_FRAMEWORK_BUNDLE="$PWD/common-utilities/framework/dist/local-check/mdpf-1.0-release.zip"
python -m pip wheel --no-deps --wheel-dir data-pipelines/providers/dmi/dist ./data-pipelines/providers/dmi
cd data-pipelines/providers/dmi
python -m pytest -q
```

Expected: tests pass and `dist/provider_dmi-1.0-py3-none-any.whl` is created.
Build both wheels before tests: packaging checks read them from `dist/`, which
is absent from a fresh Git clone. The Framework ZIP built above is a local test
artifact. Production release packaging uses an approved ZIP and its trusted SHA256.
The supplied distribution already includes review bundles; inspect those directly
or build to the new `local-check/` destination above. Repeated runs must use a
different unused ZIP destination: release builders never overwrite existing files.
The supplied local test profile uses PySpark 3.5.7. Production uses the platform's
compatible Spark runtime; the provider wheel does not install Spark.

The `integration` tests use real local Spark with the existing SQLite/OCI test
adapters in the sibling `common-utilities/generator/tests` source directory.
They exercise the provider through the framework and both platform entry APIs,
including policy failures, rollback and retry. They need no cloud credentials and
do not validate live Oracle transactions, permissions or platform execution.
Without that sibling source checkout, integration tests skip; run
`python -m pytest -q -m 'not integration'` for standalone transformation/contract
and release-packaging checks. Set MDPF_FRAMEWORK_BUNDLE to the approved download
for packaging tests; those tests skip with an explicit message if no bundle is supplied.
Unit tests and provider release packaging do not read Framework source.
For an independent data-pipelines checkout, start in `providers/dmi/`. Put the
approved mdpf and mdpf-onboarding wheels and Framework release ZIP in a downloads
directory, then replace the DOWNLOADS path below. No sibling checkout is needed:

```bash
python -m venv .venv
source .venv/bin/activate
DOWNLOADS="/path/to/approved/downloads"
python -m pip install "$DOWNLOADS/mdpf-1.0-py3-none-any.whl" "$DOWNLOADS/mdpf_onboarding-1.0-py3-none-any.whl" -e '.[test]'
python -m pip check
python -m pip wheel --no-deps --wheel-dir dist .
export MDPF_FRAMEWORK_BUNDLE="$DOWNLOADS/mdpf-1.0-release.zip"
python -m pytest -q -m 'not integration'
```

Expected: all standalone tests pass, with integration cases deselected. Full
cross-repository integration requires the source layout described above.

To check the companion utilities, run `python -m pytest -q` from
`common-utilities/generator` after installing both utility test extras.

## Onboarding and deployment

The input YAML preserves the reviewed 12-column schema, MAIN table `DMI_FEE`,
the `CLIENT_NO` trim, two STAGE NOT NULL checks, STAGE-to-RAW row-count
reconciliation and MAIN-to-STAGE inserted-row reconciliation. The framework
continues to own validation, audit persistence, transactions and retries.

1. Review the illustrative DEV/STAGE/PROD namespaces, buckets and Oracle owners
   in `onboarding.yaml` against provisioned infrastructure. Review the metadata
   `release_version` too: use a new release when 1.0 already exists.
2. Upload this input YAML and its two samples to a separate OCI input prefix.
   For example, place the YAML at
   `oci://mdpf-dev-artifacts@devns/onboarding/providers/dmi/fee/1.0/input/onboarding.yaml`
   and the samples under the same prefix's `samples/` folder. This preserves the
   YAML's relative sample references. These are onboarding samples; actual daily
   input is one Parquet object under `dmi/inbound/fee/ingest_date=YYYYMMDD/fee_YYYYMMDD.parquet`.
3. In the existing OCI notebook, call the existing generator:

   ```python
   from mdpf_onboarding.onboard import generate

   metadata_sql_uri = generate(
       'oci://mdpf-dev-artifacts@devns/onboarding/providers/dmi/fee/1.0/input/onboarding.yaml',
       spark=spark,
   )
   ```

4. Review the complete YAML, MAIN DDL and DRAFT metadata SQL under the separate
   `onboarding/providers/dmi/fee/1.0/generated` output prefix. Generation does
   not deploy or activate metadata. Follow the existing
   [onboarding guide](../../../common-utilities/generator/README.md)
   for target verification, manual deployment and activation.
5. Install `provider-dmi==1.0` alongside `mdpf==1.0` on the selected runtime.
   Use the launchers below in RAW, STAGE, MAIN task order.

The provider wheel contains Python code only. The input YAML and samples stay in
the source repository and must be uploaded separately. Provider software version
and metadata release version are independent. No generated SQL is maintained here.

## Select launchers

Create three scheduled tasks using the paths below. The shared RAW/MAIN launchers
read `pipeline_code=DMI_FEE`; they register no custom functions. The two provider
STAGE launchers fix `DMI_FEE_STAGE_LOAD` and register only `CUSTOM_FEE_TRANSFORM`.
Do not use the shared STAGE launcher for this custom plan: it fails before data I/O.

| Task | Code | Launcher owner / path within owner |
|---|---|---|
| RAW | `DMI_FEE_RAW_LOAD` | common `framework/entrypoints/<platform>/raw.*` |
| STAGE | `DMI_FEE_STAGE_LOAD` | provider `entrypoints/<platform>/stage.*` |
| MAIN | `DMI_FEE_MAIN_LOAD` | common `framework/entrypoints/<platform>/main.*` |

Use `.py` under `dataflow` and `.ipynb` under `aidp`. See the
[shared launcher reference](../../../common-utilities/README.md#shared-launchers)
for exact paths, selection defaults and widget/argument handling. These files
contain only startup wiring; the transformation stays in the installed provider
wheel. It has no task-code check and can be reused with compatible frame keys,
parameters and schemas. No launcher dynamically imports functions from YAML.

AIDP: import the selected notebooks into the workspace and configure resolved
`job_run_id`, `task_run_id`, positive `execution_count` and,
when spanning jobs, `workflow_execution_key` task widgets. RAW also needs
`cycle_date` and `execution_mode`. The default workflow key is `AIDP:<job_run_id>`.

Data Flow: select the scripts above. Supply `--pipeline-code DMI_FEE` for the
shared RAW/MAIN scripts. The fixed provider STAGE script takes no pipeline/task
selection flags. Supply `--execution-key` on every child run and a real run OCID through
`DATAFLOW_RUN_ID` or `--run-id`. RAW also needs `--cycle-date` and
`--execution-mode MANUAL` or `SCHEDULED`. The common scripts optionally consume
`--task-code` for metadata-name overrides before calling the existing adapter.
Leave exceptions uncaught so the scheduler sees failures.
Retries reuse the workflow key while supplying the new attempt identity. Both
platforms need the existing secure DB/OCI configuration; no credentials belong here.

## Assemble a release

After generation and review, download the complete YAML, metadata SQL and MAIN DDL
into one local directory outside source control. From the provider directory:

```bash
python -m pip wheel --no-deps --wheel-dir dist .
GENERATED_DIR="/path/to/reviewed/generated"
FRAMEWORK_BUNDLE="/path/to/approved/mdpf-1.0-release.zip"
FRAMEWORK_SHA256="REPLACE_WITH_APPROVED_64_CHARACTER_SHA256"
python scripts/package_release.py \
    --generated-dir "$GENERATED_DIR" \
    --framework-bundle "$FRAMEWORK_BUNDLE" \
    --framework-sha256 "$FRAMEWORK_SHA256" \
    --output dist/review/provider_dmi-1.0-release.zip
```

The Framework ZIP and its trusted SHA256 are required; the sibling-source fallback
and `--framework-dir` were removed. Obtain the ZIP/pin from an approved release
location; registry downloads remain a later CI step. Versions are read from the
provider wheel's METADATA and exact mdpf dependency, then checked against the
Framework manifest and wheel. Multiple provider wheels in dist are rejected; keep
only the wheel intended for this release. The packager checks the bundle's whole
SHA256, every internal artifact hash, the generated business contract and
input/complete-YAML provenance, and provider source/wheel consistency,
then creates a new ZIP. Existing outputs are rejected. It does not read cloud
credentials, contact Oracle, generate SQL or decide whether SQL has been approved.
That review remains an explicit developer/DBA step.
Replace the three example variable values before running. Obtain the SHA256 from
the approved release record, not by accepting an unverified download. The fresh
`dist/review/` destination avoids overwriting the supplied distribution's ZIP;
choose another unused destination when repeating the command.

The release contains both runtime wheels, all six common launchers, both provider
STAGE launchers, source YAML/samples, three generated artifacts and one
`release-manifest.json` with task-to-launcher paths and artifact SHA256 values.
The manifest keeps provider version and metadata release separate and records
the approved Framework ZIP SHA256. Generated
outputs and release ZIPs are under ignored `dist/` or external directories;
maintain only source assets in Git. The ZIP is not a Data Flow dependency archive.
Install the wheels/dependencies through the platform's supported mechanism and
upload the selected scripts/notebooks separately.
For the concrete file/URI and notebook-path binding steps, follow the
[deployment handoff](../../../common-utilities/README.md#deployment-handoff).

The supplied `dist/provider_dmi-1.0-release.zip` was assembled from the current
synthetic samples using the public generator with a local OCI test adapter and
Spark. Its metadata remains DRAFT and its environment values are illustrative;
it is a reproducible review bundle, not proof of live deployment.

These instructions reuse the existing platform APIs; creating jobs, schedules,
CI/CD and deployment automation remains outside this change. Live execution
requires provisioned OCI/Oracle resources and credentials. See the framework's
[operations guide](../../../common-utilities/framework/OPERATIONS.md).

## Parquet delivery contract

The production input YAML now selects `source_format: PARQUET` and `direction:
INBOUND`. RAW/STAGE output uses
`dmi/fee/ingest_date=YYYYMMDD/batch_id=<id>/fee_YYYYMMDD.parquet/part-*.parquet` in
separate buckets. The `.parquet` output component is a Spark folder. Source date
comes from batch `cycle_date`; retries retain the same batch output path.

The two supplied CSVs remain small onboarding/schema fixtures; normal generation
can validate these explicit columns without requiring binary sample files. Actual
production delivery must be Parquet. The existing LANDING/RAW string business
contract is preserved; supported native Parquet values are converted explicitly.
STAGE/MAIN types, CLIENT_NO trimming and all four policies are unchanged. If the
provider changes its source business schema, update the explicit columns in a new
reviewed metadata release. Do not edit the utility reference as a production copy.

For a local demonstration only, create a Parquet delivery from the CSV fixture
with `read_sample(spark, 'datasets/fee/samples/fee_input.csv').write.parquet(...)`.
Spark writes a directory locally; live landing requires uploading its actual
`part-*.parquet` file to the exact configured landing object key. Output folders
are left as part files. Runtime platform entrypoints require no wrapper changes.
Apply the Framework direction-column upgrade before deploying new generated SQL.

## ATP metadata and ADW MAIN

Set MDPF_DB_* for ATP and MDPF_MAIN_DB_* for ADW (independent wallets). Generic
RAW/STAGE/MAIN launchers and custom DMI_FEE STAGE registration remain unchanged.
The framework lazily opens ADW for MAIN, then records control completion in ATP.
The provider contract, generated target names, trimming and four policies remain.
Failed separate-database MAIN requires the latest exact failed run ID reviewed via
--main-retry-reviewed-run-id (Data Flow) or main_retry_reviewed_run_id (AIDP) after
operator/DBA recovery. See the Framework operations guide; never automatically
approve a MAIN retry after a possibly committed warehouse load.
