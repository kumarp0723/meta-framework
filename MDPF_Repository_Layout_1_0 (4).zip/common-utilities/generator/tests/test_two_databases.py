"""Two independent SQLite connections plus mocked Oracle/platform boundaries.

No live Oracle atomicity/concurrency claim. In particular, a committed warehouse
transaction must survive a later control failure, and blind MAIN retry must stop.
"""
from contextlib import contextmanager
import os
import sqlite3
from types import SimpleNamespace

import pytest

from conftest import CatalogDb, prepare_execution
from mdpf.db import OracleDb, main_database_configured
from mdpf.pipeline import MetadataFramework


@pytest.fixture(autouse=True)
def clean_connection_environment(monkeypatch):
    for name in list(os.environ):
        if name.startswith(('MDPF_DB_', 'MDPF_MAIN_DB_')):
            monkeypatch.delenv(name)


def test_connection_prefixes_and_wallets_are_independent(monkeypatch):
    calls=[]
    for prefix,label in (('MDPF_DB','atp'),('MDPF_MAIN_DB','adw')):
        for suffix in ('USER','PASSWORD','DSN','CONFIG_DIR','WALLET_LOCATION','WALLET_PASSWORD'):
            monkeypatch.setenv(prefix+'_'+suffix,label+'-'+suffix.lower())
    monkeypatch.setattr('mdpf.db.oracledb.connect',lambda **kw:calls.append(kw) or object())
    OracleDb();OracleDb(prefix='MDPF_MAIN_DB')
    assert calls[0]=={k:'atp-'+k for k in ('user','password','dsn','config_dir','wallet_location','wallet_password')}
    assert calls[1]=={k:'adw-'+k for k in ('user','password','dsn','config_dir','wallet_location','wallet_password')}


def test_explicit_vault_values_override_environment(monkeypatch):
    monkeypatch.setenv('MDPF_MAIN_DB_USER','environment-user')
    calls=[]
    monkeypatch.setattr('mdpf.db.oracledb.connect',lambda **kw:calls.append(kw) or object())
    OracleDb(prefix='MDPF_MAIN_DB',user='vault-user',password='vault-password',dsn='warehouse')
    assert calls==[dict(user='vault-user',password='vault-password',dsn='warehouse')]


@pytest.mark.parametrize('suffix',['USER','PASSWORD','DSN','CONFIG_DIR','WALLET_LOCATION'])
def test_partial_adw_configuration_never_falls_back_to_atp(monkeypatch,suffix):
    for field in ('USER','PASSWORD','DSN'):
        monkeypatch.setenv('MDPF_DB_'+field,'atp-value')
    monkeypatch.setenv('MDPF_MAIN_DB_'+suffix,'adw-value')
    assert main_database_configured()
    monkeypatch.setattr('mdpf.db.oracledb.connect',lambda **kw:pytest.fail('Partial credentials must not connect'))
    with pytest.raises(ValueError,match='Missing connection settings'):
        OracleDb(prefix='MDPF_MAIN_DB')


def test_shared_connection_adapters_are_rejected():
    conn=object()
    with pytest.raises(ValueError,match='same connection'):
        MetadataFramework(SimpleNamespace(conn=conn),'P',main_db=SimpleNamespace(conn=conn))


class Warehouse:
    """Only ADW business schemas exist here; metadata queries cannot succeed."""
    def __init__(self,model):
        self.conn=sqlite3.connect(':memory:',isolation_level=None)
        self.conn.execute("ATTACH DATABASE ':memory:' AS DMI_MAIN_DEV")
        self.commits=0;self.rollbacks=0;self.closed=0;self.commit_failure=None
        for definition in model['datasets'].values():
            row=definition['row']
            if row['storage_type']=='ADB_TABLE':
                columns=[c['column_name']+' TEXT' for c in definition['columns']]
                self.conn.execute('CREATE TABLE '+row['physical_object_name']['DEV']+' ('+','.join(columns)+
                    ',BATCH_ID INTEGER,TASK_RUN_ID INTEGER,ROW_NUMBER INTEGER,CREATED_AT TEXT,UPDATED_AT TEXT)')
    @contextmanager
    def transaction(self):
        self.conn.execute('BEGIN')
        try:
            yield
            if self.commit_failure=='before':raise RuntimeError('warehouse commit unavailable')
            self.conn.commit();self.commits+=1
            if self.commit_failure=='after':raise RuntimeError('warehouse commit acknowledgement lost')
        except BaseException:
            self.conn.rollback();self.rollbacks+=1
            raise
    def insert_many(self,table,columns,records,types):
        for row in records:
            self.conn.execute('INSERT INTO '+table+' ('+','.join(columns)+') VALUES ('+
                ','.join(':'+n for n in columns)+')',{k:CatalogDb.value(v) for k,v in row.items()})
        return len(records)
    def rows(self):return self.conn.execute('SELECT * FROM DMI_MAIN_DEV.LOAN').fetchall()
    def close(self):self.closed+=1;self.conn.close()


def setup_case(models,spark,tmp_path):
    model=models['one_to_one'];fw,atp=prepare_execution(model,tmp_path,spark)
    adw=Warehouse(model);fw.main_db=adw
    batch=fw.start_batch('separate-databases','2026-10-15')['batch_id']
    raw,stage,main=[t['row']['task_code'] for t in model['tasks']]
    fw.execute_task(batch,raw);fw.execute_task(batch,stage)
    assert adw.commits==0
    return fw,atp,adw,batch,main


def test_main_writes_only_to_adw_and_records_success_only_in_atp(models,spark,tmp_path):
    fw,atp,adw,batch,main=setup_case(models,spark,tmp_path)
    try:
        result=fw.execute_task(batch,main)
        assert result['status']=='COMPLETED' and result['output_count']==2
        assert adw.commits==1 and len(adw.rows())==2 and adw.closed==0
        assert atp.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n']==0
        assert atp.one('SELECT status FROM RUNTIME.BATCH')['status']=='COMPLETED'
        assert all(row[-5]==batch and row[-4]==result['task_run_id'] for row in adw.rows())
    finally:adw.close();atp.close()


@pytest.mark.parametrize('failure',['insert','count','commit_before','commit_after','atp_completion'])
def test_main_failure_blocks_blind_retry_and_requires_exact_review(models,spark,tmp_path,monkeypatch,failure):
    from mdpf import runtime
    fw,atp,adw,batch,main=setup_case(models,spark,tmp_path)
    insert=adw.insert_many;complete=runtime.mark_task_completed
    try:
        if failure=='insert':
            def broken(*args):
                insert(*args)
                raise RuntimeError('warehouse insert failure')
            monkeypatch.setattr(adw,'insert_many',broken)
        elif failure=='count':monkeypatch.setattr(adw,'insert_many',lambda *args:insert(*args)-1)
        elif failure.startswith('commit_'):adw.commit_failure=failure.removeprefix('commit_')
        else:
            monkeypatch.setattr(runtime,'mark_task_completed',lambda *args:(_ for _ in ()).throw(RuntimeError('ATP completion unavailable')))
        with pytest.raises((RuntimeError,ValueError)):fw.execute_task(batch,main)
        failed=atp.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_id=3')
        assert failed['status']=='FAILED' and failed['error_code']=='MAIN_RECOVERY_REQUIRED'
        assert len(adw.rows())==(2 if failure in ('commit_after','atp_completion') else 0)
        assert atp.one('SELECT status FROM RUNTIME.BATCH')['status']=='RUNNING'
        fw.main_db=None
        with pytest.raises(ValueError,match='Restore the separate ADW connection'):
            fw.execute_task(batch,main,main_retry_reviewed_run_id=failed['task_run_id'])
        fw.main_db=adw
        for review in (None,failed['task_run_id']+10):
            with pytest.raises(ValueError,match='recovery review required'):
                fw.execute_task(batch,main,main_retry_reviewed_run_id=review)
        assert atp.one('SELECT COUNT(*) n FROM RUNTIME.TASK_RUN')['n']==3
        # Deliberate operator action in this test, never automatic framework cleanup.
        # A real operator must stop the writer and reconcile ADW before approving.
        adw.commit_failure=None
        with adw.transaction():adw.conn.execute('DELETE FROM DMI_MAIN_DEV.LOAN WHERE BATCH_ID=?',(batch,))
        monkeypatch.setattr(adw,'insert_many',insert)
        monkeypatch.setattr(runtime,'mark_task_completed',complete)
        retried=fw.execute_task(batch,main,main_retry_reviewed_run_id=failed['task_run_id'])
        assert retried['status']=='COMPLETED' and retried['original_task_run_id']==failed['task_run_id']
        assert len(adw.rows())==2
        assert atp.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE event_code='MAIN_RETRY_REVIEWED'")['n']==1
        assert atp.one('SELECT status FROM RUNTIME.TASK_RUN WHERE task_run_id=:id',id=failed['task_run_id'])['status']=='FAILED'
    finally:adw.close();atp.close()


@pytest.mark.parametrize('fail_commit',[False,True])
def test_environment_main_connection_is_lazy_and_owned(models,spark,tmp_path,monkeypatch,fail_commit):
    import mdpf.pipeline as pipeline
    fw,atp=prepare_execution(models['one_to_one'],tmp_path,spark)
    adw=Warehouse(models['one_to_one']);opened=[]
    monkeypatch.setenv('MDPF_MAIN_DB_DSN','warehouse')
    monkeypatch.setattr(pipeline,'OracleDb',lambda **kw:opened.append(kw) or adw)
    try:
        batch=fw.start_batch('lazy-adw','2026-10-15')['batch_id']
        tasks=[t['row']['task_code'] for t in models['one_to_one']['tasks']]
        for task in tasks[:2]:fw.execute_task(batch,task)
        assert not opened
        if fail_commit:
            adw.commit_failure='before'
            with pytest.raises(RuntimeError,match='commit unavailable'):
                fw.execute_task(batch,tasks[2])
            assert adw.commits==0
        else:
            result=fw.execute_task(batch,tasks[2])
            assert result['status']=='COMPLETED' and adw.commits==1
        assert opened==[{'prefix':'MDPF_MAIN_DB'}] and adw.closed==1
    finally:
        if not adw.closed:adw.close()
        atp.close()


def test_multiple_adw_targets_roll_back_together(models,spark,tmp_path,monkeypatch):
    from test_templates import handlers
    model=models['one_to_many'];fw,atp=prepare_execution(model,tmp_path,spark)
    adw=Warehouse(model);fw.main_db=adw
    try:
        batch=fw.start_batch('multiple-adw-targets','2026-10-15')['batch_id']
        raw,stage,main=[t['row']['task_code'] for t in model['tasks']]
        fw.execute_task(batch,raw);fw.execute_task(batch,stage)
        insert=adw.insert_many;calls=[]
        def wrong_second_count(*args):
            actual=insert(*args);calls.append(args[0])
            return actual-1 if len(calls)==2 else actual
        monkeypatch.setattr(adw,'insert_many',wrong_second_count)
        with pytest.raises(ValueError,match='reconciliation'):
            fw.execute_task(batch,main,custom_steps=handlers())
        assert len(calls)==2 and adw.commits==0 and adw.rollbacks==1
        for table in calls:
            assert adw.conn.execute('SELECT COUNT(*) FROM '+table).fetchone()[0]==0
            assert atp.one('SELECT COUNT(*) n FROM '+table)['n']==0
    finally:adw.close();atp.close()


def test_exact_run_failure_callback_preserves_manual_guard_after_worker_loss(models,spark,tmp_path,monkeypatch):
    from mdpf import runtime
    class WorkerLost(BaseException):pass
    fw,atp,adw,batch,main=setup_case(models,spark,tmp_path)
    try:
        monkeypatch.setattr(runtime,'mark_task_completed',lambda *a:(_ for _ in ()).throw(WorkerLost()))
        with pytest.raises(WorkerLost):fw.execute_task(batch,main)
        active=atp.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_id=3')
        assert active['status']=='RUNNING' and len(adw.rows())==2
        with pytest.raises(ValueError,match='still RUNNING'):fw.execute_task(batch,main)
        # Test represents an exact callback after external writer shutdown.
        fw.fail_task_run(active['task_run_id'],'WORKER_LOST','Writer stopped','LOAD_MAIN')
        failed=atp.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_id=3')
        assert failed['status']=='FAILED' and failed['error_code']=='MAIN_RECOVERY_REQUIRED'
        with pytest.raises(ValueError,match='recovery review required'):fw.execute_task(batch,main)
    finally:adw.close();atp.close()


@pytest.mark.parametrize('review',[0,-1,True,'3'])
def test_invalid_review_id_is_rejected_before_database_access(review):
    with pytest.raises(ValueError,match='positive exact failed task run'):
        MetadataFramework(object(),'P').execute_task(1,'MAIN',main_retry_reviewed_run_id=review)


def test_dataflow_forwards_explicit_adw_and_exact_review(monkeypatch):
    from mdpf import dataflow
    monkeypatch.setattr(dataflow,'run_task',lambda **kw:kw)
    monkeypatch.setenv('DATAFLOW_RUN_ID','ocid1.dataflowrun.oc1.test.actual')
    adw=object()
    result=dataflow.execute_task(pipeline_code='P',task_code='MAIN',main_db=adw,
        argv=['--execution-key','workflow','--main-retry-reviewed-run-id','17'])
    assert result['main_db'] is adw and result['main_retry_reviewed_run_id']==17


def test_aidp_forwards_explicit_adw_and_exact_review(monkeypatch):
    from mdpf import aidp,runner
    monkeypatch.setattr(aidp,'MetadataFramework',lambda *a:SimpleNamespace(get_batch_by_execution_key=lambda key:None))
    monkeypatch.setattr(runner,'_run_task',lambda db,**kw:kw)
    adw=object()
    result=aidp._execute_task('P','MAIN',dict(job_run_id='job',task_run_id='run',execution_count='2',
        main_retry_reviewed_run_id='17'),object(),main_db=adw)
    assert result['main_db'] is adw and result['main_retry_reviewed_run_id']==17


def test_runner_passes_main_connection_and_review_to_framework(monkeypatch):
    from mdpf import runner
    calls=[]
    fw=SimpleNamespace(get_batch_by_execution_key=lambda key:dict(batch_id=1),
        _task=lambda batch,code:dict(task_type='TRANSFORMATION'),
        execute_task=lambda *a,**kw:kw)
    monkeypatch.setattr(runner,'MetadataFramework',lambda *a,**kw:calls.append(kw) or fw)
    adw=object()
    result=runner._run_task(object(),pipeline_code='P',task_code='MAIN',execution_key='workflow',
        task_run_id='run',main_db=adw,main_retry_reviewed_run_id=17)
    assert calls[0]['main_db'] is adw and result['main_retry_reviewed_run_id']==17


@pytest.mark.parametrize('present',[True,False])
def test_oracle_gate_routes_metadata_to_atp_and_target_inspection_to_adw(present):
    from test_oracle_gate import OracleCatalog
    from mdpf_onboarding.oracle_gate import verify_main_targets
    atp,adw=OracleCatalog(),OracleCatalog();adw.present=present;atp.charset='NOT_THE_TARGET'
    if present:assert verify_main_targets(atp,pipeline_code='P',release_version='1.0',main_db=adw)==['BIZ.TARGET']
    else:
        with pytest.raises(ValueError,match='missing or inaccessible'):
            verify_main_targets(atp,pipeline_code='P',release_version='1.0',main_db=adw)
    assert all('METADATA.' in sql for sql in atp.calls)
    assert all('METADATA.' not in sql for sql in adw.calls)


def test_gate_closes_only_automatically_created_adw_on_failure(monkeypatch):
    from test_oracle_gate import OracleCatalog
    import mdpf_onboarding.oracle_gate as gate
    atp,adw=OracleCatalog(),OracleCatalog();adw.present=False;closed=[]
    adw.close=lambda:closed.append(True)
    monkeypatch.setenv('MDPF_MAIN_DB_DSN','warehouse')
    monkeypatch.setattr(gate,'OracleDb',lambda **kw:adw)
    with pytest.raises(ValueError):gate.verify_main_targets(atp,pipeline_code='P',release_version='1.0')
    assert closed==[True]
