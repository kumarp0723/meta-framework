# SQL Generator 1.0 verification

Verified 2026-10-20: **323 automated checks passed in 81.17 seconds; no failures or skips**.
Python 3.12, actual Spark 3.5.7 and Java 17; Oracle and OCI use test doubles.

## Input review and fix

The supplied packages already contain reusable output YAML, explicit contracts,
limited parameter substitution, optional baseline comparison, conditional OCI
uploads, target DDL proposals, NOT_NULL/UNIQUE/RANGE and AIDP/Data Flow support.
No previously agreed feature was missing from these supplied builds.

Baseline comparison now covers every populated generated metadata table, rather
than just dataset columns and locations. It reports task plans/order/parameters,
handler types, DQ scopes/bounds/actions, source/delivery settings, task/dataset
associations and execution flags as well as dataset/schema changes.

Baseline and current metadata use the same builder. Baseline compilation reads
explicit schemas without loading samples, running transformations, registering
custom functions or contacting Oracle. Normal generation retains all sample
validation. Foreign keys are normalized to logical task/dataset/column/step
identities; generated numeric IDs and row order do not produce false differences.
JSON objects are compared semantically. Equivalent defaults/type declarations
normalize consistently. Version/publishing details and artifact/sample paths are
excluded from execution-metadata comparison. Source delivery patterns are included.

## Test evidence

All 285 existing regression checks remain covered. The 38 new cases cover all
three relationships, default/explicit equivalence, custom handler changes,
step reordering/nested parameter changes, policy add/remove/bounds/regrouping,
source changes, association ordering/input counts, closure/requiredness/action
flags, ID rebasing, provenance/filename noise, JSON/types, no baseline data I/O,
nonmutation/determinism and printing the complete comparison before uploads.

Additional build-time output comparisons against the supplied generator verify
identical metadata rows, metadata SQL, CREATE DDL and ALTER proposals for
ONE_TO_ONE, MANY_TO_ONE and ONE_TO_MANY. Plan-only changes emit no target ALTER.
SQL/DDL renderers and the read-only deployed-target gate are unchanged.

## Preserved assets and packaging

The framework's nine Python modules, wheel, SQL, notebooks and Data Flow examples
are byte-identical to the supplied package. The Oracle model is unchanged:
17 tables / 232 columns. Generator examples, sample CSVs, schema-discovery code,
version and configuration format are unchanged. Only comparison logic, console
label, tests and existing documentation changed. No files or metadata were deleted.

The rebuilt generator 1.0 wheel matches its four source modules. Compilation,
wheel RECORD hashes, direct wheel imports, ZIP integrity and manifests pass.
Old builds, caches and temporary files are excluded. Framework wheel is preserved.

Target DDL remains a baseline-based proposal, generated without Oracle access;
no DDL or metadata was executed. Metadata SQL still creates a complete new DRAFT
release. Live Oracle/AIDP/Data Flow/ActiveBatch/OCI validation remains outstanding;
offline results do not prove Oracle concurrency or real cloud integration.

Generator wheel SHA256: `763525058e631d2f30739d0058b22adac86298d3af6e852cf25d8fbee9239894`.
Framework wheel SHA256 (unchanged): `5ab097b9de2b68e6b971f5dc0517b1e0ae9254b031bc953e737a424af7ec7df8`.
