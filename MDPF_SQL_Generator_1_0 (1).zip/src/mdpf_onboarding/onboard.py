"""OCI YAML input, Spark samples, metadata SQL and optional MAIN DDL."""
import argparse
from copy import deepcopy
import hashlib
import json
import re
import sys

import yaml
from pyspark.sql import SparkSession

from .schema_discovery import (SchemaOverridesRequired, discover, explicit_columns,
                               read_sample, validate_overrides, validate_sample)
from mdpf.storage import object_address
from .metadata_generator import (build_metadata, dataset_codes, physical_locations,
                                 relationship, render_main_ddl, render_sql, resolve_steps,
                                 contract_model, schema_changes)


class UniqueLoader(yaml.SafeLoader):
    pass


def _mapping(loader, node):
    result = {}
    for key, value in node.value:
        name = loader.construct_object(key, deep=True)
        if not isinstance(name, str) or name in result:
            raise ValueError(f'YAML keys must be unique strings: {name!r}')
        result[name] = loader.construct_object(value, deep=True)
    return result


UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)


def keys(obj, required, optional, label):
    if not isinstance(obj, dict) or set(required)-set(obj) or set(obj)-set(required)-set(optional):
        raise ValueError(f'{label}: required keys {sorted(required)}; optional keys {sorted(optional)}.')


def text(value, label, limit):
    if not isinstance(value, str) or not value.strip() or len(value.encode('utf-8')) > limit or any(ord(c)<32 for c in value):
        raise ValueError(f'{label} must be nonempty text, at most {limit} UTF-8 bytes, without control characters.')
    return value


def expand_parameters(config):
    """Only pipeline identity and an explicit sample root can be referenced."""
    if not isinstance(config, dict):
        raise ValueError('config must be a mapping.')
    pipeline = config.get('pipeline', {})
    values = {f'pipeline.{k}': pipeline.get(k) for k in ('code', 'release_version')} if isinstance(pipeline, dict) else {}
    token = re.compile(r'\$\{([^{}]+)\}')
    def string(value):
        def replace(match):
            name = match[1]
            replacement = values.get(name)
            if not isinstance(replacement, str) or '${' in replacement:
                raise ValueError(f'Unknown or recursive parameter reference: {name}')
            return replacement
        result = token.sub(replace, value)
        if '${' in result:
            raise ValueError(f'Unresolved parameter reference: {value}')
        return result
    if 'samples_root' in config:
        if not isinstance(config['samples_root'], str):
            raise ValueError('samples_root must be a full OCI prefix.')
        values['samples_root'] = string(config['samples_root'])
    def walk(value):
        if isinstance(value, str):
            return string(value)
        if isinstance(value, list):
            return [walk(v) for v in value]
        if isinstance(value, dict):
            result = {}
            for key, item in value.items():
                name = string(key) if isinstance(key, str) else key
                if name in result:
                    raise ValueError(f'Parameter expansion creates duplicate key: {name}')
                result[name] = walk(item)
            return result
        return value
    return walk(config)


def validate_config(config):
    """Validate this utility's fixed input format; unknown keys fail instead of being ignored."""
    from mdpf.schema import sql_identifier
    c = expand_parameters(config)
    keys(c, {'pipeline','inputs','outputs','storage','environments','sql_output'}, {'inference','task_overrides','created_by','dq_rules','samples_root'}, 'config')
    if 'samples_root' in c:
        oci_uri(c['samples_root'].rstrip('/'))
    keys(c['pipeline'], {'code','name','release_version'}, set(), 'pipeline')
    for field, length in [('code',100),('name',200),('release_version',50)]:
        text(c['pipeline'][field], 'pipeline.'+field, length)
    sql_identifier(c['pipeline']['code'])
    for role in ('inputs','outputs'):
        if not isinstance(c[role], list) or not c[role]:
            raise ValueError(f'{role} must be a nonempty list.')
        seen = set()
        for item in c[role]:
            required = {'code','sample_csv'} | ({'source_system','landing_key_prefix','file_name'} if role=='inputs' else {'target_table'})
            optional = {'columns'} | ({'bucket_ref'} if role=='inputs' else set())
            keys(item, required, optional, role)
            sql_identifier(text(item['code'], role+'.code', 100))
            if item['code'] in seen:
                raise ValueError(f'Duplicate {role} code: {item["code"]}')
            seen.add(item['code'])
            text(item['sample_csv'], 'sample_csv', 2000)
            if 'columns' in item:
                explicit_columns(item['columns'], source=role=='inputs')
            if role=='inputs':
                text(item['source_system'], 'source_system', 200)
                item.setdefault('bucket_ref','landing')
                text(item['bucket_ref'], 'bucket_ref', 100)
            else:
                sql_identifier(item['target_table'])
    shape = relationship(c)
    roots = {(i['source_system'],i['bucket_ref'],i['landing_key_prefix']) for i in c['inputs']}
    if len(roots) != 1:
        raise ValueError('Combined RAW requires one source_system, landing bucket reference and landing_key_prefix.')
    keys(c['storage'], {'raw_key_prefix','stage_key_prefix'}, set(), 'storage')
    keys(c['environments'], {'DEV','STAGE','PROD'}, set(), 'environments')
    for name, env in c['environments'].items():
        keys(env, {'namespace','buckets','oracle_main_owner'}, set(), name)
        sql_identifier(env['oracle_main_owner'])
        if not isinstance(env['buckets'], dict) or not {'landing','raw','stage'} <= set(env['buckets']):
            raise ValueError(f'{name} requires landing/raw/stage bucket references.')
    inf = c.setdefault('inference', {})
    keys(inf, set(), {'varchar_growth_percent','default_nullable','column_overrides'}, 'inference')
    growth = inf.setdefault('varchar_growth_percent',25)
    if isinstance(growth,bool) or not isinstance(growth,(int,float)) or not 0<=growth<=1000:
        raise ValueError('varchar_growth_percent must be between 0 and 1000.')
    if inf.setdefault('default_nullable','Y') not in ('Y','N'):
        raise ValueError('default_nullable must be Y or N.')
    overrides = inf.setdefault('column_overrides',{})
    if not isinstance(overrides,dict) or any(not isinstance(v,dict) for v in overrides.values()):
        raise ValueError('column_overrides must map LANDING/MAIN dataset codes to column overrides.')
    codes = dataset_codes(c)
    landing_codes = {p['landing'] for p in codes['inputs']}
    allowed = landing_codes | {p['main'] for p in codes['outputs']}
    if set(overrides)-allowed:
        raise ValueError('Use LANDING/MAIN dataset codes for overrides; paired RAW/STAGE schemas are copied automatically.')
    for name, columns in overrides.items():
        validate_overrides(columns, source=name in landing_codes)
    for role, suffix in (('inputs','landing'), ('outputs','main')):
        for item, names in zip(c[role], codes[role]):
            if 'columns' in item and overrides.get(names[suffix]):
                raise ValueError('Use explicit columns or inference overrides for a dataset, not both.')
    rules = c.setdefault('dq_rules', [])
    if not isinstance(rules, list):
        raise ValueError('dq_rules must be a list.')
    targets = {name for output in codes['outputs'] for name in output.values()}
    seen_rules = set()
    for rule in rules:
        keys(rule, {'datasets','column','check'}, {'min','max'}, 'dq_rules entry')
        if (not isinstance(rule['datasets'], list) or not rule['datasets'] or
                any(not isinstance(name, str) or name not in targets for name in rule['datasets'])):
            raise ValueError('dq_rules.datasets must be a nonempty list of generated STAGE/MAIN dataset codes.')
        sql_identifier(rule['column'])
        from mdpf.steps import validate_dq_parameters
        validate_dq_parameters({k: v for k, v in rule.items() if k not in ('datasets','column')})
        for name in rule['datasets']:
            identity = (name, rule['column'], rule['check'])
            if identity in seen_rules:
                raise ValueError(f'Duplicate DQ rule: {name}.{rule["column"]} {rule["check"]}')
            seen_rules.add(identity)
    c.setdefault('created_by','MDPF_ONBOARD')
    text(c['created_by'],'created_by',100)
    roles = {'RAW','STAGE','MAIN'}
    task_options = c.setdefault('task_overrides',{})
    if not isinstance(task_options,dict) or set(task_options)-roles:
        raise ValueError('task_overrides keys must be RAW, STAGE or MAIN.')
    custom_roles=set()
    for role, opt in task_options.items():
        plan=resolve_steps(opt,role)
        if 'task_code' in opt:
            sql_identifier(text(opt['task_code'],'task_code',100))
        if any(kind=='CUSTOM_PYTHON' for _,kind,_ in plan):
            custom_roles.add(role)
    required_role = 'STAGE' if shape=='MANY_TO_ONE' else 'MAIN' if shape=='ONE_TO_MANY' else None
    if required_role and required_role not in custom_roles:
        raise ValueError(f'{shape} requires declared {required_role} custom steps for explicit frame combination/routing.')
    task_codes = [task_options.get(role, {}).get('task_code', f"{c['pipeline']['code']}_{role}_LOAD")
                  for role in ('RAW', 'STAGE', 'MAIN')]
    for code in task_codes:
        text(code, 'task_code', 100)
    if len(set(task_codes)) != len(task_codes):
        raise ValueError('RAW, STAGE and MAIN must use distinct task codes.')
    physical_locations(c,codes)  # Validate every environment before reading samples.
    output_uri(c)
    main_ddl_uri(c)
    yaml_uri(c)
    return c


def oci_uri(value):
    """Exact object URI only; samples and artifacts never use local path fallback."""
    text(value,'OCI URI',2000)
    namespace,bucket,key=object_address(value)
    if (not key or not all(re.fullmatch(r'[A-Za-z0-9_.-]+',s) for s in (namespace,bucket)) or
            any(c.isspace() or c in '*[]{}\\' for c in key) or
            any(p in ('','.','..') for p in key.split('/'))):
        raise ValueError('Use an exact oci://bucket@namespace/object-key without wildcards or path traversal.')
    return value


def sample_uri(config_uri, value, samples_root=None):
    if '://' in value:
        result=value
    else:
        if value.startswith('/'):
            raise ValueError('Sample paths must be relative to the OCI YAML, or full OCI URIs.')
        result=(samples_root.rstrip('/') if samples_root else config_uri.rsplit('/',1)[0])+'/'+value
    result=oci_uri(result)
    if not result.lower().endswith('.csv'):
        raise ValueError('Sample must reference one exact OCI .csv file.')
    return result


def output_uri(config):
    out=config['sql_output']
    keys(out,{'namespace','bucket','path','filename'},
         {'overwrite','generate_main_ddl','main_ddl_filename','yaml_filename'},'sql_output')
    if not isinstance(out.setdefault('overwrite',False),bool):
        raise ValueError('sql_output.overwrite must be boolean.')
    if not isinstance(out.setdefault('generate_main_ddl',False),bool):
        raise ValueError('sql_output.generate_main_ddl must be boolean.')
    for name in ('namespace','bucket','path','filename'):
        text(out[name],'sql_output.'+name,1000)
    if out['path'] != out['path'].strip('/'):
        raise ValueError('sql_output.path must not have surrounding slashes.')
    if '/' in out['filename'] or not out['filename'].lower().endswith('.sql'):
        raise ValueError('sql_output.filename must be a .sql filename without directories.')
    return oci_uri(f"oci://{out['bucket']}@{out['namespace']}/{out['path']}/{out['filename']}")


def main_ddl_uri(config):
    prefix,filename=output_uri(config).rsplit('/',1)
    stem=re.sub(r'_metadata(?:_draft)?$','',filename[:-4])
    filename=config['sql_output'].get('main_ddl_filename',stem+'_main_ddl.sql')
    return artifact_uri(prefix,filename,('.sql',))


def artifact_uri(prefix, filename, suffixes):
    if not isinstance(filename,str) or '/' in filename or not filename.lower().endswith(suffixes):
        raise ValueError(f'Artifact filename must end with {suffixes}, without directories.')
    return oci_uri(prefix+'/'+filename)


def yaml_uri(config):
    prefix=output_uri(config).rsplit('/',1)[0]
    return artifact_uri(prefix,config['sql_output'].get('yaml_filename',config['pipeline']['code'].lower()+'.yaml'),('.yaml','.yml'))


def complete_config(model, sample_paths):
    """Emit a reusable contract, with sample paths independent of the YAML location."""
    config=deepcopy(model['config'])
    codes=dataset_codes(config)
    for role, suffix in (('inputs','landing'),('outputs','main')):
        for item,names in zip(config[role],codes[role]):
            item['sample_csv']=sample_paths[item['sample_csv']]
            item['columns']=[{k:v for k,v in column.items() if k!='column_sequence'}
                             for column in model['datasets'][names[suffix]]['columns']]
    config['inference']['column_overrides']={}
    config['sql_output']['yaml_filename']=yaml_uri(config).rsplit('/',1)[1]
    config['sql_output']['main_ddl_filename']=main_ddl_uri(config).rsplit('/',1)[1]
    for task in model['tasks']:
        steps=[step for step in model['tables']['TASK_STEP'] if step['task_id']==task['row']['task_id']]
        config['task_overrides'][task['role']]=dict(task_code=task['row']['task_code'],task_steps=[
            step['step_code'] if step['step_type']=='BUILTIN' else
            dict(code=step['step_code'],parameters=json.loads(step['parameter_json'])) for step in steps])
    return config


def object_client():
    import oci
    return oci.object_storage.ObjectStorageClient({},signer=oci.auth.signers.get_resource_principals_signer())


def _load_config(uri, client):
    """One YAML read/validation path; retain original bytes and client for generation."""
    uri=oci_uri(uri)
    if not uri.lower().endswith(('.yaml','.yml')):
        raise ValueError('Config must be an OCI .yaml or .yml object.')
    namespace,bucket,key=object_address(uri)
    client=client or object_client()
    data=client.get_object(namespace,bucket,key).data.content
    return validate_config(yaml.load(data.decode('utf-8'),Loader=UniqueLoader)),data,client


def load_config(uri, *, client=None):
    return _load_config(uri,client)[0]


def _print_summary(model, artifacts):
    config, tables = model['config'], model['tables']
    pipeline = config['pipeline']
    print(f"Generation summary: {pipeline['code']}, release {pipeline['release_version']}, DRAFT, {relationship(config)}")
    print(f"  {len(model['datasets'])} datasets, {len(tables['DATASET_COLUMN'])} columns, "
          f"{len(model['tasks'])} tasks, {len(tables['TASK_STEP'])} steps, "
          f"{len(tables['POLICY_DEFINITION'])} DQ rules")
    for code, definition in model['datasets'].items():
        columns = ', '.join(' '.join(filter(None, [c['column_name'], c['data_type'],
            c['length_precision_scale'], 'NOT NULL' if c['is_nullable'] == 'N' else None]))
            for c in definition['columns'])
        print(f'  {code}: {columns}')
    for task in model['tasks']:
        print('  '+task['row']['task_code']+': '+', '.join(task['inputs'])+' -> '+', '.join(task['outputs']))
        print('    steps: '+' -> '.join(task['steps']))
    for policy in tables['POLICY_DEFINITION']:
        print(f"  DQ: {policy['policy_name']} -> {policy['failure_action']}")
    for uri, _ in artifacts:
        print('  Artifact: '+uri)
    for warning in model['warnings']:
        print('NOTE: '+warning)


def generate(config_uri, *, baseline_yaml=None, spark=None, client=None):
    """Notebook/CLI API. Requires the existing MDPF wheel; never connects to Oracle."""
    config,config_bytes,client=_load_config(config_uri,client)
    baseline=None
    if baseline_yaml is not None:
        baseline_yaml=oci_uri(baseline_yaml)
        if baseline_yaml==config_uri:
            raise ValueError('baseline_yaml must be a separate previous configuration.')
        try:
            previous,_,client=_load_config(baseline_yaml,client)
        except Exception as exc:
            raise ValueError(f'Cannot read or validate baseline_yaml {baseline_yaml}: {exc}') from exc
        if previous['pipeline']['code']!=config['pipeline']['code']:
            raise ValueError('Baseline must belong to the same pipeline.')
        if previous['pipeline']['release_version']==config['pipeline']['release_version']:
            raise ValueError('Comparison requires a new release_version; published releases are never updated.')
        baseline=contract_model(previous)
        contract_model(config)  # Enhancement schemas must be explicit, never silently re-inferred.
    sql_uri=output_uri(config)
    sample_paths={i['sample_csv']:sample_uri(config_uri,i['sample_csv'],config.get('samples_root')) for i in config['inputs']+config['outputs']}
    targets=[sql_uri,yaml_uri(config)]+([main_ddl_uri(config)] if config['sql_output']['generate_main_ddl'] else [])
    if len(set(targets))!=len(targets) or set(targets)&{config_uri,baseline_yaml,*sample_paths.values()}:
        raise ValueError('Artifact outputs must be distinct from each other, input YAML, baseline and sample objects.')
    existing = spark or SparkSession.getActiveSession()
    session = existing or SparkSession.builder.appName('MDPF metadata onboarding').getOrCreate()
    profiles, codes, missing = {}, dataset_codes(config), {}
    try:
        for role in ('inputs','outputs'):
            for item, names in zip(config[role], codes[role]):
                path = sample_paths[item['sample_csv']]
                code = names['landing' if role=='inputs' else 'main']
                df = read_sample(session,path)
                try:
                    if 'columns' in item:
                        columns=validate_sample(df,explicit_columns(item['columns'],source=role=='inputs'),source=role=='inputs')
                    else:
                        columns = discover(df,source=role=='inputs',
                            overrides=config['inference']['column_overrides'].get(code,{}),
                            growth=config['inference']['varchar_growth_percent'], nullable=config['inference']['default_nullable'])
                except SchemaOverridesRequired as exc:
                    missing[code] = exc.columns
                    continue
                profiles[code] = (df, columns)
        if missing:
            print('Datatype input required; no SQL or DDL was uploaded. Empty target columns:')
            for code, columns in missing.items():
                print('  ' + code + ': ' + ', '.join(columns))
            print('Merge these overrides into your YAML, replace every <...> value, then generate again:')
            print(yaml.safe_dump({'inference': {'column_overrides': missing}}, sort_keys=False))
            return None
        model = build_metadata(config,profiles)
        yaml_bytes=yaml.safe_dump(complete_config(model,sample_paths),sort_keys=False,allow_unicode=True).encode('utf-8')
        provenance='-- GENERATED YAML SHA256: '+hashlib.sha256(yaml_bytes).hexdigest()+'\n'
        sql = render_sql(model,config_bytes).replace('\n','\n'+provenance,1)
        artifacts=[(yaml_uri(config),yaml_bytes.decode('utf-8'))]
        if config['sql_output']['generate_main_ddl']:
            artifacts.append((main_ddl_uri(config),render_main_ddl(model,config_bytes,baseline=baseline).replace('\n','\n'+provenance,1)))
        artifacts.append((sql_uri,sql))
        print('Mode: '+('INITIAL SETUP; no baseline comparison.' if baseline is None else 'COMPARISON; resolved release changes from baseline.'))
        if baseline is not None:
            for change in schema_changes(model,baseline):
                print('  CHANGE: '+change)
        _print_summary(model, artifacts)
        # Render everything before publication; upload metadata last. Uploads are independent.
        condition={} if config['sql_output']['overwrite'] else {'if_none_match':'*'}
        for uri,content in artifacts:
            namespace,bucket,key=object_address(uri)
            client.put_object(namespace,bucket,key,content.encode('utf-8'),
                content_type='application/yaml' if uri==yaml_uri(config) else 'application/sql',**condition)
            if uri!=sql_uri:
                print(f'Generated {uri}: '+('reusable configuration; intended metadata, not deployment state.' if uri==yaml_uri(config)
                    else 'proposed MAIN DDL for manual review; no DDL has been executed.'))
        print(f'Generated {sql_uri}: {relationship(config)}, three tasks, DRAFT only; Oracle has not been contacted.')
        return sql_uri
    finally:
        if existing is None:session.stop()


def main(argv=None):
    parser=argparse.ArgumentParser(description='Generate DRAFT metadata SQL and optional MAIN table DDL.')
    parser.add_argument('--config',required=True)
    parser.add_argument('--baseline-yaml',help='Previous complete generated YAML in OCI; omitted for initial setup.')
    args=parser.parse_args(argv)
    try:
        return 0 if generate(args.config,baseline_yaml=args.baseline_yaml) is not None else 2
    except Exception as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        return 1


if __name__=='__main__':
    raise SystemExit(main())
