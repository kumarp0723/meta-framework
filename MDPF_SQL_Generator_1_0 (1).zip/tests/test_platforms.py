"""Both platform adapters share the same lifecycle and internal IDs."""
import pytest

from conftest import prepare_execution
from mdpf.aidp import _execute_task
from mdpf.runner import _run_task


def test_aidp_job_identity_and_internal_attempt_ids(models,spark,tmp_path,monkeypatch):
    model=models['one_to_one'];fw,db=prepare_execution(model,tmp_path,spark)
    monkeypatch.setattr('mdpf.runner.MetadataFramework',lambda *a,**kw:fw)
    try:
        for i,task in enumerate(model['tasks'],1):
            result=_execute_task(model['config']['pipeline']['code'],task['row']['task_code'],
                dict(job_run_id='workflow-1',task_run_id='aidp-attempt-'+str(i),execution_count='1',
                     cycle_date='2026-10-15' if i==1 else '',execution_mode='MANUAL' if i==1 else ''),db,spark=spark)
            assert result['batch_id']==1 and result['task_run_id']==i
        batch=db.one('SELECT * FROM RUNTIME.BATCH')
        assert batch['execution_key']=='AIDP:workflow-1' and batch['orchestrator_run_id']=='workflow-1'
        assert batch['status']=='COMPLETED'
        assert [r['orchestrator_task_run_id'] for r in db.execute('SELECT * FROM RUNTIME.TASK_RUN ORDER BY task_run_id')]==['aidp-attempt-1','aidp-attempt-2','aidp-attempt-3']
    finally:db.close()


def test_activebatch_dataflow_runs_share_batch_and_keep_distinct_attempt_ids(models,spark,tmp_path,monkeypatch):
    from mdpf import dataflow
    model=models['one_to_one'];fw,db=prepare_execution(model,tmp_path,spark)
    monkeypatch.setattr('mdpf.runner.MetadataFramework',lambda *a,**kw:fw)
    settings=[];runs=[]
    def launch(**kw):
        settings.append(kw)
        return _run_task(db,**kw)
    monkeypatch.setattr(dataflow,'run_task',launch)
    key='ACTIVEBATCH:workflow-123'
    args=['--execution-key',key,'--cycle-date','2026-10-15','--execution-mode','MANUAL']
    try:
        for i,task in enumerate(model['tasks'],1):
            external=f'ocid1.dataflowrun.oc1.phx.attempt{i}'
            monkeypatch.setenv('DATAFLOW_RUN_ID',external)
            result=dataflow.execute_task(pipeline_code=model['config']['pipeline']['code'],
                task_code=task['row']['task_code'],spark=spark,argv=args if i==1 else ['--execution-key',key])
            runs.append(result)
        assert {r['batch_id'] for r in runs}=={1} and len({r['task_run_id'] for r in runs})==3
        assert db.one('SELECT execution_key FROM RUNTIME.BATCH')['execution_key']==key
        assert [s['task_run_id'] for s in settings]==[f'ocid1.dataflowrun.oc1.phx.attempt{i}' for i in range(1,4)]
        assert all('orchestrator_attempt_number' not in s for s in settings)
        with pytest.raises(ValueError,match='already COMPLETED'):
            dataflow.execute_task(pipeline_code=model['config']['pipeline']['code'],
                task_code=model['tasks'][1]['row']['task_code'],spark=spark,argv=['--execution-key',key])
    finally:db.close()


@pytest.mark.parametrize('native,explicit',[(None,None),('bad',None),('ocid1.dataflowrun.oc1.a','ocid1.dataflowrun.oc1.b')])
def test_dataflow_requires_exact_external_run_identity(monkeypatch,native,explicit):
    from mdpf import dataflow
    monkeypatch.delenv('DATAFLOW_RUN_ID',raising=False)
    if native:monkeypatch.setenv('DATAFLOW_RUN_ID',native)
    monkeypatch.setattr(dataflow,'run_task',lambda **kw:pytest.fail('Invalid identity must not open Oracle'))
    argv=['--execution-key','ACTIVEBATCH:1']+(['--run-id',explicit] if explicit else [])
    with pytest.raises(ValueError):dataflow.execute_task(pipeline_code='X',task_code='RAW',argv=argv)


def test_supplied_dataflow_run_fallback(monkeypatch):
    from mdpf import dataflow
    monkeypatch.delenv('DATAFLOW_RUN_ID',raising=False)
    monkeypatch.setattr(dataflow,'run_task',lambda **kw:kw)
    result=dataflow.execute_task(pipeline_code='X',task_code='RAW',argv=[
        '--execution-key','ACTIVEBATCH:1','--run-id','ocid1.dataflowrun.oc1.phx.actual'])
    assert result['task_run_id']=='ocid1.dataflowrun.oc1.phx.actual'
    assert result['execution_key']=='ACTIVEBATCH:1'


def test_downstream_cannot_initialize_batch(models,spark,tmp_path):
    fw,db=prepare_execution(models['one_to_one'],tmp_path,spark)
    try:
        with pytest.raises(ValueError,match='INGESTION task'):
            _run_task(db,pipeline_code=fw.pipeline_code,task_code=models['one_to_one']['tasks'][1]['row']['task_code'],
                execution_key='ACTIVEBATCH:empty',task_run_id='ocid1.dataflowrun.oc1.a',spark=spark)
        assert db.one('SELECT COUNT(*) n FROM RUNTIME.BATCH')['n']==0
    finally:db.close()


def test_generic_runner_closes_connection_on_failure(monkeypatch):
    from mdpf import runner
    closed=[]
    class Connection:
        def close(self):closed.append(True)
    monkeypatch.setattr(runner,'OracleDb',Connection)
    def fail(*a,**kw):raise RuntimeError('expected')
    monkeypatch.setattr(runner,'_run_task',fail)
    with pytest.raises(RuntimeError,match='expected'):runner.execute_task()
    assert closed==[True]


def test_dataflow_failure_then_restart_preserves_batch_and_error_history(models,spark,tmp_path,monkeypatch):
    from copy import deepcopy
    from mdpf import dataflow
    from mdpf_onboarding.metadata_generator import build_metadata
    from mdpf_onboarding.onboard import validate_config
    from test_cleanup import profiles_for
    original=models['one_to_one'];config=deepcopy(original['config'])
    config['task_overrides']['STAGE']={'task_steps':['READ_PARQUET',{'code':'BUSINESS_STEP'},'DIRECT_MAP','VALIDATE_DQ','WRITE_PARQUET']}
    model=build_metadata(validate_config(config),profiles_for(original,spark))
    fw,db=prepare_execution(model,tmp_path,spark)
    monkeypatch.setattr('mdpf.runner.MetadataFramework',lambda *a,**kw:fw)
    monkeypatch.setattr(dataflow,'run_task',lambda **kw:_run_task(db,**kw))
    fail=[True]
    def business(frames,context,params):
        if fail[0]:raise RuntimeError('Notebook/application business failure')
        return frames
    custom={'BUSINESS_STEP':business};key='ACTIVEBATCH:retry-demo'
    tasks=[t['row']['task_code'] for t in model['tasks']]
    def launch(task,attempt,first=False):
        monkeypatch.setenv('DATAFLOW_RUN_ID','ocid1.dataflowrun.oc1.phx.'+attempt)
        argv=['--execution-key',key]+(['--cycle-date','2026-10-15','--execution-mode','MANUAL'] if first else [])
        return dataflow.execute_task(pipeline_code=fw.pipeline_code,task_code=task,argv=argv,
            spark=spark,custom_steps=custom)
    try:
        raw=launch(tasks[0],'raw',True)
        with pytest.raises(RuntimeError,match='business failure'):launch(tasks[1],'stage1')
        old=db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE status='FAILED'")
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='RUNNING'
        fail[0]=False
        stage=launch(tasks[1],'stage2');main=launch(tasks[2],'main')
        assert raw['batch_id']==stage['batch_id']==main['batch_id']
        assert stage['attempt_number']==2 and stage['original_task_run_id']==old['task_run_id']
        assert stage['orchestrator_task_run_id']=='ocid1.dataflowrun.oc1.phx.stage2'
        assert db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id',id=old['task_run_id'])==old
        assert db.one('SELECT status FROM OPERATIONS.WORK_QUEUE')['status']=='OPEN'
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='COMPLETED'
        with pytest.raises(ValueError,match='Terminal batches'):
            fw.start_batch(key,'2026-10-15','MANUAL')
    finally:db.close()
