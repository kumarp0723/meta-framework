"""Fixed DQ policies exercised through actual Spark and the runtime lifecycle."""
from copy import deepcopy
from decimal import Decimal
import json

import pytest
from pyspark.sql import functions as F

from conftest import prepare_execution
from mdpf.steps import _policy_failures, validate_dq_parameters
from mdpf_onboarding.onboard import validate_config
from mdpf_onboarding.metadata_generator import build_metadata
from test_cleanup import profiles_for


STAGE='DEMO_LOAN_LOAN_STAGE'
MAIN='DEMO_LOAN_LOAN_MAIN'


@pytest.mark.parametrize('params', [None,{}, {'check':'UNKNOWN'}, {'check':'UNIQUE','min':0},
    {'check':'RANGE'}, {'check':'RANGE','min':2,'max':1}, {'check':'RANGE','min':True,'max':5},
    {'check':'RANGE','min':'0','max':5}, {'check':'RANGE','min':float('nan'),'max':5},
    {'check':'RANGE','min':0,'max':float('inf')}, {'check':'RANGE','min':0,'max':10**39}])
def test_unsupported_or_ambiguous_parameters_rejected(params):
    with pytest.raises(ValueError):validate_dq_parameters(params)


def test_range_requires_numeric_schema(models,spark):
    config=deepcopy(models['one_to_one']['config'])
    config['dq_rules']=[dict(datasets=[STAGE],column='LOAN_ID',check='RANGE',min=0,max=10)]
    with pytest.raises(ValueError,match='NUMBER column'):
        build_metadata(validate_config(config),profiles_for(models['one_to_one'],spark))


def test_unique_ignores_nulls_and_counts_all_duplicate_rows(spark):
    df=spark.createDataFrame([('X',),('X',),('Y',),(None,),(None,)],'COUNT string')
    amount,expected=_policy_failures(df,dict(column_name='COUNT',parameters={'check':'UNIQUE'}),{})
    assert amount==2 and 'duplicate non-null' in expected


def test_range_is_inclusive_and_ignores_nulls(spark):
    df=spark.createDataFrame([(Decimal('0.00'),),(Decimal('10.00'),),(Decimal('-0.01'),),
        (Decimal('10.01'),),(None,)],'VALUE decimal(8,2)')
    amount,expected=_policy_failures(df,dict(column_name='VALUE',parameters={'check':'RANGE','min':0,'max':10}),{})
    assert amount==2 and '[0, 10]' in expected


@pytest.mark.parametrize('check,column,bounds',[('UNIQUE','LOAN_ID',{}),('RANGE','BALANCE',{'min':0,'max':1000000})])
def test_new_policy_failure_and_same_batch_repair(models,spark,tmp_path,check,column,bounds):
    original=models['one_to_one'];config=deepcopy(original['config'])
    config['task_overrides']['STAGE']={'task_steps':['READ_PARQUET',{'code':'PREPARE'},'DIRECT_MAP','VALIDATE_DQ','WRITE_PARQUET']}
    config['dq_rules']=[dict(datasets=[STAGE,MAIN],column=column,check=check,**bounds)]
    model=build_metadata(validate_config(config),profiles_for(original,spark))
    assert json.loads(model['tables']['POLICY_DEFINITION'][0]['parameter_json'])==dict(check=check,**bounds)
    fw,db=prepare_execution(model,tmp_path,spark);fail=[True]
    def prepare(frames,context,params):
        df=next(iter(frames.values()))
        if fail[0]:df=df.withColumn(column,F.lit('DUPLICATE' if check=='UNIQUE' else '-0.01'))
        return {STAGE:df}
    try:
        batch=fw.start_batch('dq-'+check,'2026-10-15','MANUAL')['batch_id']
        raw,stage,main=[t['row']['task_code'] for t in model['tasks']]
        fw.execute_task(batch,raw)
        fw.storage.write_parquet_original=fw.storage.write_parquet
        fw.storage.write_parquet=lambda *a:pytest.fail('Blocking DQ must prevent Stage writes')
        with pytest.raises(ValueError,match='Blocking policy'):
            fw.execute_task(batch,stage,custom_steps={'PREPARE':prepare})
        failed=db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE status='FAILED'")
        assert db.one('SELECT failed_record_count FROM RUNTIME.POLICY_RESULT')['failed_record_count']==2
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n']==1
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='RUNNING'
        assert not db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_id=3')
        fail[0]=False;fw.storage.write_parquet=fw.storage.write_parquet_original
        attempt=fw.execute_task(batch,stage,custom_steps={'PREPARE':prepare})
        fw.execute_task(batch,main)
        assert attempt['attempt_number']==2 and attempt['original_task_run_id']==failed['task_run_id']
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='COMPLETED'
        assert db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id',id=failed['task_run_id'])==failed
        assert [r['result_status'] for r in db.execute('SELECT result_status FROM RUNTIME.POLICY_RESULT ORDER BY policy_result_id')]==['FAIL','PASS','PASS']
    finally:db.close()
