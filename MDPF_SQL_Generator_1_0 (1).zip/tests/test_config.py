from copy import deepcopy
from pathlib import Path
import json
import yaml

import pytest

from conftest import ROOT,MemoryOCI
from mdpf_onboarding.onboard import generate,load_config,validate_config,output_uri,yaml_uri
from mdpf_onboarding.metadata_generator import build_metadata


@pytest.fixture
def config():return yaml.safe_load((ROOT/'examples/one_to_one.yaml').read_text())


@pytest.mark.parametrize('mutate',[
    lambda c:c.update(typo=True),
    lambda c:c['pipeline'].update(code='lowercase'),
    lambda c:c['pipeline'].update(release_version=1.0),
    lambda c:c['pipeline'].update(code='A'*100),
    lambda c:c['inputs'][0].update(file_name='loan_*.csv'),
    lambda c:c['inputs'][0].update(file_name='loan_{DATE}.csv'),
    lambda c:c['inputs'][0].update(file_name='../loan.csv'),
    lambda c:c['inputs'][0].update(landing_key_prefix='landing/../x'),
    lambda c:c['inputs'][0].update(bucket_ref='missing'),
    lambda c:c['inputs'][0].update(file_name='x'*501+'.csv'),
    lambda c:c['environments']['DEV']['buckets'].update(raw='bad@bucket'),
    lambda c:c['environments'].pop('PROD'),
    lambda c:c['outputs'][0].update(target_table='TABLE;DROP'),
    lambda c:c['inference'].update(varchar_growth_percent=-1),
    lambda c:c['inference'].update(column_overrides={'UNKNOWN':{}}),
    lambda c:c.update(task_overrides={'STAGE':{'task_steps':['READ_PARQUET',{'code':'DIRECT_MAP','parameters':{'override':True}},'VALIDATE_DQ','WRITE_PARQUET']}}),
    lambda c:c.update(task_overrides={'RAW:LOAN':{'task_steps':['READ_SOURCE','WRITE_PARQUET']}}),
    lambda c:c.update(task_overrides={'STAGE':{'task_steps':['READ_PARQUET',{'code':'CUSTOM','parameters':[]},'VALIDATE_DQ','WRITE_PARQUET']}}),
])
def test_bad_config_fails_before_samples(config,mutate):
    mutate(config)
    with pytest.raises((ValueError,TypeError)):validate_config(config)


@pytest.mark.parametrize('name,role',[('many_to_one','STAGE'),('one_to_many','MAIN')])
def test_required_custom_reference(name,role):
    config=yaml.safe_load((ROOT/'examples'/(name+'.yaml')).read_text())
    config['task_overrides']={}
    with pytest.raises(ValueError,match=role):validate_config(config)


def test_duplicate_yaml_key():
    client=MemoryOCI();uri='oci://onboarding@devns/config/bad.yaml'
    client.objects[uri]=b'pipeline: 1\npipeline: 2\n'
    with pytest.raises(ValueError,match='unique'):load_config(uri,client=client)


def test_missing_column_in_builtin_path_blocks_generation(models,spark):
    from mdpf_onboarding.schema_discovery import discover
    model=models['one_to_one'];config=deepcopy(model['config'])
    profiles={}
    for code,ds in model['datasets'].items():
        if code.endswith('_LANDING'):
            df=spark.createDataFrame([('x',)],['OTHER'])
            profiles[code]=(df,discover(df,source=True,overrides={}))
        if code.endswith('_MAIN'):
            df=spark.createDataFrame([('x',)],['OTHER'])
            profiles[code]=(df,ds['columns'])
    with pytest.raises(ValueError,match='columns do not match'):build_metadata(config,profiles)


def test_one_sql_output_and_determinism(spark,oci_setup):
    config,uri,client,_=oci_setup;config['sql_output']['overwrite']=True
    client.objects[uri]=yaml.safe_dump(config).encode()
    output=generate(uri,spark=spark,client=client);first=client.objects[output]
    generate(uri,spark=spark,client=client)
    assert first==client.objects[output]
    assert set(client.objects)=={uri,output,yaml_uri(config)}
    assert b"'DRAFT'" in first and b"'ACTIVE'" not in first and b'POLICY_DEFINITION' not in first


def test_failed_generation_does_not_replace_existing_sql(spark,tmp_path,oci_setup):
    c,uri,client,samples=oci_setup
    # Valid target date contract, incompatible input date representation.
    (tmp_path/'input.csv').write_text('AS_OF_DATE\n10/15/2026\n')
    (tmp_path/'output.csv').write_text('AS_OF_DATE\n2026-10-15\n')
    samples[next(p for p in samples if 'loan_input' in p)]=tmp_path/'input.csv'
    samples[next(p for p in samples if 'loan_output' in p)]=tmp_path/'output.csv'
    c['inference']['column_overrides']={};c['sql_output']['overwrite']=True
    client.objects[uri]=yaml.safe_dump(c).encode()
    out=output_uri(c);client.objects[out]=b'previous approved artifact'
    with pytest.raises(ValueError,match='conversion loss'):generate(uri,spark=spark,client=client)
    assert client.objects[out]==b'previous approved artifact' and not client.puts
