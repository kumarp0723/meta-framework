# MDPF SQL Generator 1.0

Generate a complete pipeline YAML, DRAFT metadata SQL, and optional MAIN table
schema proposals from OCI YAML and sample CSVs. The utility never executes SQL,
queries Oracle during generation, activates releases, or updates Git.

Use the companion **MDPF 1.0** wheel. Extract the two packages into sibling
`framework/` and `generator/` folders for the [framework README](../framework/README.md)
links. MDPF runs on AIDP or Data Flow; onboarding configuration is platform-neutral.

## How it works

```mermaid
flowchart TD
    C["Current YAML and samples in OCI"] --> G["Validate and generate"]
    B["Optional previous complete YAML"] --> G
    G --> Y["Reusable pipeline YAML"]
    G --> S["Metadata SQL and optional target DDL"]
    Y --> R["Review and commit to Git"]
    S --> D["Review, deploy DRAFT, verify and activate"]
```

No `baseline_yaml` means initial setup. Supplying it means comparison. The
baseline must be the previous complete generated YAML for the same pipeline;
its samples are not read. A missing/invalid baseline fails before sample reads.
Comparison requires a different metadata `release_version`.

## First onboarding

1. Install the companion `mdpf-1.0-py3-none-any.whl`, then
   `dist/mdpf_onboarding-1.0-py3-none-any.whl`. Use cluster PySpark and Java.
   Replacing another build labelled 1.0 needs `pip install --force-reinstall --no-deps`.
2. Copy `examples/one_to_one.yaml`. Set pipeline/input/output identifiers,
   separate landing/RAW/STAGE buckets, Oracle owners/targets and artifact settings.
   Keep DEV/STAGE/PROD entries; deployment selects one using `:target_env`.
3. Upload the YAML and representative nonempty input/output CSV samples to OCI.
   Configure SDK Resource Principal read/create permissions for YAML/artifacts
   and Spark OCI driver/worker read/list access for samples. These are separate
   access paths. There is no local-file fallback.
4. Generate from your Spark notebook:

   ```python
   from mdpf_onboarding.onboard import generate

   metadata_uri = generate(
       "oci://mdpf-dev-artifacts@devns/onboarding/demo_loan/config.yaml",
       spark=spark,
   )
   ```

5. Review the printed datasets, schemas, task sequences, DQ rules and paths.
   Download metadata SQL, the complete YAML and optional target DDL from OCI.
   `generate()` still returns the metadata SQL URI. Commit the complete YAML as
   the maintained pipeline configuration; it describes intended metadata, not
   actual deployed Oracle state. `examples/pipeline_complete.yaml` shows its shape.
6. Review/provision target tables, deploy metadata as DRAFT, verify it, then activate.
   Follow the framework README to configure AIDP tasks or Data Flow applications.

## Make a change

1. Keep the previous approved YAML as the baseline (for example a prior Git revision).
2. Edit the current complete YAML: add/remove/rename columns or change their types,
   lengths, nullability, locations, steps or DQ rules. Update representative samples.
3. Choose a new `pipeline.release_version` and release-specific artifact destination.
   Upload both YAML files to OCI and run:

   ```python
   metadata_uri = generate(
       "oci://artifacts@devns/demo_loan/current.yaml",
       baseline_yaml="oci://artifacts@devns/demo_loan/previous.yaml",
       spark=spark,
   )
   ```

4. Review the release-change summary and all proposed SQL. Deploy a **complete new
   DRAFT release**. Published metadata and existing batches are never changed.

Both YAML files have the same format; the input parameter identifies their role.
Comparison requires explicit `columns` on every input/output. Samples must match
those contracts; they do not silently resize or re-infer them. No rename guessing:
a renamed column is reported as one removal and one addition.


The comparison covers the **resolved release**, using the same metadata builder
for current and baseline configuration:

| Area | Changes reported |
|---|---|
| Datasets | Columns, order/types/constraints, layers, storage types and physical locations |
| Tasks and steps | Task identity/type, batch closure, step additions/removals/order, handler type and JSON parameters |
| DQ policies | Added/removed checks, scope, numeric bounds, threshold and failure action |
| Sources | Source system, delivery pattern, landing root and expected input count |
| Associations | Task inputs/outputs, usage sequence, requiredness and enabled status |

Numeric IDs are matched through logical task/dataset/column/step codes. Equivalent
explicit/default plans and JSON formatting do not create false changes. The release
version bump, publishing details, sample paths and artifact filenames are ignored.
Only settings that affect generated metadata are compared; the utility does not
inspect custom Python function bodies or live Oracle state. Target DDL proposals
still depend only on target schema differences: plan/DQ-only changes produce no
ALTER statements. Both inputs remain unchanged.

## YAML field reference

Unknown settings are rejected. Versions are quoted strings. `<ROLE>` is RAW,
STAGE or MAIN. Fields below retain the existing input format.

| Field | Required? | Default / meaning |
|---|---|---|
| `pipeline` | Yes | `code`, `name`, `release_version` |
| `inputs[]` | Yes | `code`, `source_system`, `sample_csv`, `landing_key_prefix`, `file_name` |
| `inputs[].bucket_ref` | No | `landing`; bucket alias in every environment |
| `outputs[]` | Yes | `code`, `sample_csv`, `target_table` |
| `inputs[].columns`, `outputs[].columns` | For comparison | Ordered explicit schema; initial generation can infer it |
| Each `columns[]` | When explicit | `column_name`, `data_type`; optional `length_precision_scale`, `is_nullable` (`Y`), `is_pii` (`N`) |
| `samples_root` | No | Full OCI prefix for relative sample paths |
| `storage` | Yes | `raw_key_prefix`, `stage_key_prefix` |
| `environments` | Yes | DEV, STAGE, PROD; each has `namespace`, `buckets` (landing/raw/stage), `oracle_main_owner` |
| `inference.varchar_growth_percent` | No | `25`; initial text-length headroom |
| `inference.default_nullable` | No | `Y`; initial inference only |
| `inference.column_overrides` | No | LANDING/MAIN dataset → column overrides; cannot coexist with explicit columns for that dataset |
| `task_overrides.<ROLE>.task_code` | No | `<PIPELINE>_<ROLE>_LOAD` |
| `task_overrides.<ROLE>.task_steps` | No | Complete ordered sequence; omitted means automatic defaults |
| `dq_rules` | No | `[]`; see examples below |
| `created_by` | No | `MDPF_ONBOARD` |
| `sql_output` | Yes | `namespace`, `bucket`, `path`, metadata SQL `filename` |
| `sql_output.yaml_filename` | No | Lowercase pipeline code + `.yaml` |
| `sql_output.main_ddl_filename` | No | Derived from SQL stem as `<name>_main_ddl.sql` |
| `sql_output.generate_main_ddl` | No | `false`; create target schema proposals when true |
| `sql_output.overwrite` | No | `false`; preserve existing artifact objects |

### Reuse values and control paths

Only `${pipeline.code}`, `${pipeline.release_version}` and `${samples_root}`
are supported references. They work in values and mapping keys (including dataset
references); undefined/recursive references and resulting duplicate keys fail.
There are no expressions or environment-variable substitutions. YAML anchors
can also reuse entire values. Runtime `{YYYYMMDD}` stays unchanged.

```yaml
pipeline:
  code: DEMO_LOAN
  name: Loan pipeline
  release_version: '1.1'
samples_root: oci://samples@devns/demo_loan
# Within an input/output entry:
# sample_csv: '${samples_root}/loan_input.csv'
sql_output:
  namespace: devns
  bucket: mdpf-dev-artifacts
  path: 'onboarding/${pipeline.code}/${pipeline.release_version}'
  filename: '${pipeline.code}_metadata.sql'
  main_ddl_filename: '${pipeline.code}_target_changes.sql'
  yaml_filename: '${pipeline.code}.yaml'
  generate_main_ddl: true
  overwrite: false
```

This is a settings excerpt; use a complete supplied YAML as the starting point.
Full sample OCI URIs are used directly. Relative paths use `samples_root` when
provided, otherwise the input YAML's directory; no DMI prefix is hardcoded.
Generated YAML contains full sample URIs so moving it does not change resolution.
All artifacts share the configured OCI destination and must be distinct from
input YAML, baseline and samples, even with overwrite enabled. Uploads are
independent: YAML first, optional DDL next, metadata last. Inspect partial output
if a conditional upload fails; there is no cross-object transaction.

## Schemas and target DDL proposals

LANDING/RAW share input-file columns as VARCHAR2. STAGE/MAIN share expected-output
columns/types: VARCHAR2, exact NUMBER(p,s), date-only DATE. Explicit column order
becomes metadata order. Sample values, lengths and conversions are checked using
MDPF's existing schema helpers. Business parsing/renaming stays in custom code.

Initially use `inference.column_overrides` to correct types/bounds. All-null target
columns require a type and applicable length/precision/scale. Generation lists
all unresolved columns and prints override guidance; it returns `None`, uploads
nothing and CLI exits 2. The complete generated YAML replaces inference overrides
with explicit contracts and the resolved task sequences. Future samples cannot
silently change those definitions. Edit the explicit plan when a schema change
requires DIRECT_MAP or another processing step.

`generate_main_ddl: true` produces review-only scripts, **without Oracle access**:

| Situation | Proposal |
|---|---|
| Initial setup / new target dataset | CREATE TABLE with business columns and BATCH_ID/TASK_RUN_ID/ROW_NUMBER NUMBER(19) NOT NULL |
| Added nullable column | ALTER TABLE ADD |
| Increased VARCHAR2 length, same BYTE/CHAR semantics | ALTER TABLE MODIFY |
| Relaxed NOT NULL | ALTER TABLE MODIFY ... NULL |
| Removal, possible rename, narrowing, numeric/type changes, new NOT NULL, target owner/name change | MANUAL REVIEW comment; no automatic destructive statement |

A baseline is intended configuration, not deployed state. Verify every proposal
against actual Oracle tables before running it. Existing data may require
backfills/defaults. No keys/indexes/grants or automatic ALTER/DROP/rename decisions
are inferred. DDL assumes STANDARD/AL32UTF8 capacity up to 4000 BYTE or 1000 CHAR;
larger contracts need separate reviewed DDL. DDL commits independently in Oracle.

## Configure task steps

The generator always creates RAW, STAGE and MAIN tasks. Input/output counts select
ONE_TO_ONE, MANY_TO_ONE or ONE_TO_MANY; many-to-many is rejected. Combined RAW
pairs LANDING/RAW through `usage_sequence` and retries the entire task. Inputs
share a source system and landing bucket/root. MANY_TO_ONE needs a STAGE custom
combiner; ONE_TO_MANY needs MAIN custom routing.

Omit `task_steps` for defaults. When present, it is the complete exact sequence:

```yaml
task_overrides:
  STAGE:
    task_steps:
      - READ_PARQUET
      - code: CLEAN_LOAN
        parameters: {column: CLIENT_ID}
      - DIRECT_MAP
      - VALIDATE_DQ
      - WRITE_PARQUET
```

One reader first, one sink last; VALIDATE_DQ immediately precedes STAGE/MAIN
output. Custom parameters are a JSON-compatible mapping; built-ins use `{}`.
Include DIRECT_MAP when conversion/projection is needed. Register the matching
Python function in the notebook/application. See the framework's
[Available Task Steps](../framework/README.md#available-task-steps),
[default sequences](../framework/README.md#default-task-sequences) and
[custom function example](../framework/README.md#custom-task-steps).
YAML `custom_steps` and `output_is_typed` remain rejected; migrate to explicit
`task_steps`. The notebook/application `custom_steps` registry remains supported.

## Optional DQ rules

```yaml
dq_rules:
  - datasets: ['${pipeline.code}_LOAN_STAGE', '${pipeline.code}_LOAN_MAIN']
    column: LOAN_ID
    check: NOT_NULL
  - datasets: ['${pipeline.code}_LOAN_STAGE', '${pipeline.code}_LOAN_MAIN']
    column: LOAN_ID
    check: UNIQUE
  - datasets: ['${pipeline.code}_LOAN_STAGE', '${pipeline.code}_LOAN_MAIN']
    column: BALANCE
    check: RANGE
    min: 0
    max: 1000000
```

Each dataset/column/check becomes a POLICY_DEFINITION row. Only generated
STAGE/MAIN dataset codes are accepted; unknown names, duplicates, unsupported
parameters and nonnumeric RANGE columns fail. RANGE requires finite numeric
min/max, inclusive. UNIQUE checks single-column non-null values and counts all
rows sharing duplicates; it does not deduplicate. RANGE/UNIQUE ignore nulls, so
combine NOT_NULL when required. All rules use zero tolerance and FAIL_TASK.
Allowed values, regex, cross-table and composite checks are outside this POC.
`dq_rules: []` creates no policies; ordinary schema/nullability checks remain.

## Deploy and debug

1. Provision the framework once. A DBA runs `sql/01_release_sequence.sql` once
   with publishers paused; never reset the sequence. Deployment needs metadata
   INSERT and sequence SELECT grants, plus POLICY_DEFINITION INSERT for DQ.
2. Review target proposals against the actual table, provision owner/runtime
   grants, then deploy target DDL and metadata SQL in SQLcl/SQL*Plus script mode:

   ```sql
   VARIABLE target_env VARCHAR2(10)
   EXEC :target_env := 'DEV';
   @demo_loan_main_ddl.sql
   @demo_loan_metadata_draft.sql
   ```

3. Run the existing optional read-only `verify_main_targets()` gate against the
   deployed DRAFT release, test runtime access, then promote DRAFT → APPROVED →
   ACTIVE. This separate gate requires Oracle access; generation does not.
   Retire the previous ACTIVE in the activation transaction. Never edit published
   metadata or reinstall the fresh framework DDL for an enhancement.

| Problem | Check |
|---|---|
| Missing sample | Full URI, explicit samples_root, otherwise input YAML folder |
| Invalid baseline | Previous complete YAML, same pipeline, different release version |
| Unexpected/missing column | Edit explicit schema and representative samples deliberately |
| Conversion fails | Values and datatype bounds; business parsing needs custom code |
| Bad plan | Required reader/sink/DQ and registered custom handler |
| Existing artifact | New release destination, or deliberate overwrite |
| Oracle target differs | Review proposals; run the separate deployed-target gate |

## Where the code lives

| Module | Responsibility |
|---|---|
| `onboard.py` | Validates OCI YAML/references, loads samples/baseline, emits complete YAML and publishes artifacts |
| `schema_discovery.py` | Infers initial columns or validates explicit contracts using MDPF schema helpers |
| `metadata_generator.py` | Builds metadata, compares resolved releases, renders SQL/DDL proposals and provides the separate Oracle target gate |
| `__init__.py` | Package version |

CLI: `python -m mdpf_onboarding.onboard --config <oci-uri> [--baseline-yaml <oci-uri>]`.
All runs create a complete new DRAFT release; baseline comparison never generates
in-place metadata UPDATEs. Software remains 1.0; metadata release versions change.
Source tests are included in `tests/`; see `VERIFICATION_REPORT.md` for actual
checks and outstanding live Oracle/AIDP/Data Flow/OCI validation.
