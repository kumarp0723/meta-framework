# MDPF SQL Generator 1.0

Create onboarding input YAML from an OCI profile and CSV catalog, then generate
complete YAML, DRAFT metadata SQL and optional MAIN DDL from sample CSVs.

Start with the [end-to-end quick start](README.md#end-to-end-quick-start). Use the companion
`mdpf-1.0` wheel with `dist/mdpf_onboarding-1.0-py3-none-any.whl`, then restart sessions.
Extract both packages into sibling `framework/` and `generator/` folders.

```python
from mdpf_onboarding.bulk_builder import build_catalog
from pprint import pprint

preview = build_catalog(profile_uri, catalog_uri, dry_run=True)
results = build_catalog(profile_uri, catalog_uri, dry_run=False)

from mdpf_onboarding.onboard import generate
generate(input_yaml_uri, spark=spark)
```

- One catalog row creates one independent pipeline's input YAML. Environment
  settings live in one reusable OCI profile. Existing YAML objects are skipped.
- Bulk preview and save check input/output sample existence with OCI HEAD.
  Sample schema checks remain in onboarding generation.
- STAGE DQ supports NOT_NULL, UNIQUE, RANGE and ALLOWED_VALUES with FAIL/WARN.
  ROW_COUNT uses explicit input/output pairs at STAGE and MAIN.
- MAIN DDL includes framework-managed CREATED_AT/UPDATED_AT timestamps alongside
  existing IDs. Audit fields never belong in business YAML schemas or DQ rules.
- Optional whole-file quarantine settings continue into SOURCE_CONFIG metadata.
  Generation never deploys SQL, changes Oracle tables or activates releases.

| Reference | Contents |
|---|---|
| [Complete example](examples/dq_and_reconciliation.yaml) | New rule/severity/count syntax |
| [Rules and audit contract](../framework/REFERENCE.md#dq-reconciliation-and-audit-contracts) | Matching, severity, transactions and reserved fields |
| [Development rollout](../framework/OPERATIONS.md#development-rollout) | Old metadata, MAIN table changes and retained Parquet |
| [Two-phase scheduling](../framework/OPERATIONS.md#two-phase-scheduling) | Data Flow keys and AIDP workflow_execution_key |
| [Detailed reference](REFERENCE.md) | Catalog columns, APIs, schemas, baseline comparison and DDL |
| [Troubleshooting](../framework/OPERATIONS.md#troubleshooting) | Configuration and operational failures |
| [OCI permissions example](../framework/OPERATIONS.md#oci-permissions) | Concrete IAM example and official links |
| [Verification report](../framework/RELEASE_NOTES.md#runtime-verification-2026-10-25) | Test evidence and limitations |

Edit the maintained YAML for enhancements and choose a new metadata release.
`generate(..., baseline_yaml=previous_complete_yaml_uri)` compares compatible
complete configurations. Published metadata stays immutable. Review generated
DDL and actual Oracle constraints before deployment.

## End-to-end quick start

1. Extract the packages into sibling `framework/` and `generator/` folders. On an
   existing development installation, follow [the Development rollout section of OPERATIONS.md](../framework/OPERATIONS.md#development-rollout) first. Have
   a DBA provision Oracle owners, framework tables, sequences and grants using the
   framework SQL scripts on a fresh installation. Configure Spark OCI access and
   secure `MDPF_DB_USER`, `MDPF_DB_PASSWORD`, `MDPF_DB_DSN` (plus wallet settings
   when needed). See [the OCI permissions section of OPERATIONS.md](../framework/OPERATIONS.md#oci-permissions).

2. Install both wheels and dependencies in the OCI notebook and runtime workers;
   use the platform's Spark/Java. Restart notebook/worker Python sessions.

   ```bash
   pip install --force-reinstall --no-deps ./framework/dist/mdpf-1.0-py3-none-any.whl ./generator/dist/mdpf_onboarding-1.0-py3-none-any.whl
   ```

3. Edit/upload the generator's `examples/shared_profile.yaml`, `bulk_catalog.csv`
   and sample CSVs to OCI. The profile holds reusable environment/bucket settings;
   each catalog row describes one independent dataset pipeline. A ZIP containing
   unrelated CSV datasets becomes separate catalog rows using separately extracted
   samples. This builder does not unpack ZIP deliveries.

4. Preview, then create the small input YAML files:

   ```python
   from mdpf_onboarding.bulk_builder import build_catalog
   from pprint import pprint
   profile = 'oci://artifacts@namespace/profiles/shared.yaml'
   catalog = 'oci://artifacts@namespace/catalogs/pipelines.csv'
   preview = build_catalog(profile, catalog, dry_run=True)
   pprint(preview)
   results = build_catalog(profile, catalog, dry_run=False)
   pprint(results)
   ```

   Check failed rows before continuing. Preview/save both check sample existence
   using OCI HEAD; they do not read or validate sample schemas. Save creates only
   missing YAMLs. Rows remain independent; existing YAMLs are skipped.

5. Review each input YAML. Add contracts, custom steps or STAGE DQ when needed.
   See the generator's `examples/dq_and_reconciliation.yaml` and
   [DQ and audit contracts in the framework reference](../framework/REFERENCE.md#dq-reconciliation-and-audit-contracts). Request `sql_output.generate_main_ddl: true` for
   initial MAIN table proposals. Generate one pipeline at a time:

   ```python
   from mdpf_onboarding.onboard import generate
   generate('oci://artifacts@namespace/onboarding/my_pipeline/1.1/input/config.yaml', spark=spark)
   ```

   Generation reads samples and writes complete YAML, DRAFT metadata SQL and
   optional reviewed MAIN DDL. It never deploys/activates metadata or executes DDL.

6. Review/deploy target DDL and metadata SQL with the correct environment binding.
   Verify MAIN contracts/grants with `verify_main_targets()` where applicable;
   approve/activate the new release through your controlled deployment process.
   Keep published releases immutable. Audit fields are framework-managed.

7. Run RAW → STAGE → MAIN using separate Data Flow applications or AIDP tasks.
   Share one execution key, use a real fresh external task-run identity for every
   attempt, and set the initial cycle date explicitly. MAIN success closes the
   batch. Default MAIN limit: 10,000 rows across all outputs per task.

8. Optionally stop scheduling after RAW and schedule STAGE → MAIN later with the
   same key/cycle/pinned batch. RAW stays COMPLETED and BATCH stays RUNNING.
   For separate AIDP jobs, pass the same `workflow_execution_key` to both jobs.
   See [the Two-phase scheduling section of OPERATIONS.md](../framework/OPERATIONS.md#two-phase-scheduling). Do not finalize a batch merely because it waits.

9. Verify TASK_RUN counts/status, POLICY_RESULT evidence and final MAIN rows. To
   test optional whole-file quarantine, enable its profile prefix/bucket aliases,
   publish a new release and use a new test delivery with a proven technical CSV
   error. Expect failed RAW, QUARANTINED receipt/location, SOURCE_QUARANTINED event,
   confirmed copied object and retained landing source. STAGE DQ does not quarantine.
   See [the Troubleshooting section of OPERATIONS.md](../framework/OPERATIONS.md#troubleshooting).

Shared operations and release documentation lives in the sibling framework folder.

When replacing an existing install, force-reinstall both supplied 1.0 wheels and
restart Python/worker sessions. Install required dependencies before using --no-deps.
