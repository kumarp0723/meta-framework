-- DMI POC: retained 17-table runtime prerequisites
-- Run AFTER sql/00_framework.sql in a fresh POC environment.
-- Fresh installation only. Includes the MAIN business table and executable runtime grants.

--------------------------------------------------------------------------------
-- Runtime ID sequences: create/bump above current MAX(primary_key).
--------------------------------------------------------------------------------
DECLARE
    PROCEDURE ensure_seq(
        p_owner VARCHAR2,
        p_seq   VARCHAR2,
        p_table VARCHAR2,
        p_pk    VARCHAR2
    ) IS
        l_target NUMBER;
        l_curr   NUMBER;
        l_exists NUMBER;
        l_diff   NUMBER;
    BEGIN
        EXECUTE IMMEDIATE 'SELECT NVL(MAX('||p_pk||'),0)+1 FROM '||p_owner||'.'||p_table INTO l_target;
        SELECT COUNT(*) INTO l_exists
          FROM ALL_SEQUENCES
         WHERE SEQUENCE_OWNER=UPPER(p_owner)
           AND SEQUENCE_NAME=UPPER(p_seq);

        IF l_exists=0 THEN
            EXECUTE IMMEDIATE 'CREATE SEQUENCE '||p_owner||'.'||p_seq||
                              ' START WITH '||TO_CHAR(l_target)||
                              ' INCREMENT BY 1 CACHE 100 NOCYCLE';
        ELSE
            EXECUTE IMMEDIATE 'SELECT '||p_owner||'.'||p_seq||'.NEXTVAL FROM DUAL' INTO l_curr;
            IF l_curr < l_target THEN
                l_diff := l_target - l_curr;
                EXECUTE IMMEDIATE 'ALTER SEQUENCE '||p_owner||'.'||p_seq||' INCREMENT BY '||TO_CHAR(l_diff);
                EXECUTE IMMEDIATE 'SELECT '||p_owner||'.'||p_seq||'.NEXTVAL FROM DUAL' INTO l_curr;
                EXECUTE IMMEDIATE 'ALTER SEQUENCE '||p_owner||'.'||p_seq||' INCREMENT BY 1';
            END IF;
        END IF;
    END;
BEGIN
    ensure_seq('RUNTIME','SEQ_BATCH_ID','BATCH','BATCH_ID');
    ensure_seq('RUNTIME','SEQ_TASK_RUN_ID','TASK_RUN','TASK_RUN_ID');
    ensure_seq('RUNTIME','SEQ_INGESTION_ITEM_ID','INGESTION_ITEM','INGESTION_ITEM_ID');
    ensure_seq('RUNTIME','SEQ_POLICY_RESULT_ID','POLICY_RESULT','POLICY_RESULT_ID');
    ensure_seq('RUNTIME','SEQ_PIPELINE_STATE_ID','PIPELINE_STATE','PIPELINE_STATE_ID');
    ensure_seq('OPERATIONS','SEQ_EVENT_LOG_ID','EVENT_LOG','EVENT_LOG_ID');
    ensure_seq('OPERATIONS','SEQ_WORK_QUEUE_ID','WORK_QUEUE','WORK_QUEUE_ID');
END;
/


--------------------------------------------------------------------------------

-- Separate BUSINESS table, not an eighteenth framework/control table.
-- Run as a DBA after creating the DMI_MAIN owner and the 17 framework tables.
GRANT REFERENCES ON RUNTIME.BATCH TO DMI_MAIN;
GRANT REFERENCES ON RUNTIME.TASK_RUN TO DMI_MAIN;
CREATE TABLE DMI_MAIN.DMI_FEE (
    BATCH_ID NUMBER(19) NOT NULL,
    TASK_RUN_ID NUMBER(19) NOT NULL,
    ROW_NUMBER NUMBER(19) NOT NULL,
    MSP_CYCLE_DATE DATE NOT NULL,
    DELTA_FILE_BYTE VARCHAR2(10),
    LN_NO NUMBER(19) NOT NULL,
    FEE_TRAN_CD NUMBER(10),
    FEE_TRAN_TY VARCHAR2(20),
    FEE_CD NUMBER(10),
    FEE_TRAN_DT DATE,
    FEE_TRAN_AM NUMBER(18,2),
    FEE_BATCH_CD VARCHAR2(20),
    FEE_SUB_CD VARCHAR2(20),
    CLIENT_NO VARCHAR2(50),
    DMI_TIME_STAMP VARCHAR2(30),
    CONSTRAINT PK_DMI_FEE PRIMARY KEY (BATCH_ID, ROW_NUMBER),
    CONSTRAINT FK_DMI_FEE_BATCH FOREIGN KEY (BATCH_ID) REFERENCES RUNTIME.BATCH (BATCH_ID),
    CONSTRAINT FK_DMI_FEE_RUN FOREIGN KEY (TASK_RUN_ID) REFERENCES RUNTIME.TASK_RUN (TASK_RUN_ID)
);
COMMENT ON TABLE DMI_MAIN.DMI_FEE IS 'POC business rows retained per batch. Task restart does not insert another copy into a completed batch.';

-- Run as DBA. Change this DEFINE if your POC service user has another name.
DEFINE runtime_user = MDPF_RUNTIME
GRANT SELECT ON METADATA.CONFIG_RELEASE TO &&runtime_user;
GRANT SELECT ON METADATA.SOURCE_CONFIG TO &&runtime_user;
GRANT SELECT ON METADATA.DATASET TO &&runtime_user;
GRANT SELECT ON METADATA.DATASET_COLUMN TO &&runtime_user;
GRANT SELECT ON METADATA.TASK TO &&runtime_user;
GRANT SELECT ON METADATA.TASK_DATASET TO &&runtime_user;
GRANT SELECT ON METADATA.TASK_STEP TO &&runtime_user;
GRANT SELECT ON METADATA.MAPPING_RULE TO &&runtime_user;
GRANT SELECT ON METADATA.POLICY_DEFINITION TO &&runtime_user;
GRANT SELECT, INSERT, UPDATE ON RUNTIME.BATCH TO &&runtime_user;
GRANT SELECT, INSERT, UPDATE ON RUNTIME.TASK_RUN TO &&runtime_user;
GRANT SELECT, INSERT, UPDATE ON RUNTIME.INGESTION_ITEM TO &&runtime_user;
GRANT SELECT, INSERT ON RUNTIME.POLICY_RESULT TO &&runtime_user;
GRANT SELECT, INSERT ON OPERATIONS.EVENT_LOG TO &&runtime_user;
GRANT SELECT, INSERT ON OPERATIONS.WORK_QUEUE TO &&runtime_user;
GRANT SELECT ON RUNTIME.SEQ_BATCH_ID TO &&runtime_user;
GRANT SELECT ON RUNTIME.SEQ_TASK_RUN_ID TO &&runtime_user;
GRANT SELECT ON RUNTIME.SEQ_INGESTION_ITEM_ID TO &&runtime_user;
GRANT SELECT ON RUNTIME.SEQ_POLICY_RESULT_ID TO &&runtime_user;
GRANT SELECT ON OPERATIONS.SEQ_EVENT_LOG_ID TO &&runtime_user;
GRANT SELECT ON OPERATIONS.SEQ_WORK_QUEUE_ID TO &&runtime_user;
GRANT SELECT, INSERT ON DMI_MAIN.DMI_FEE TO &&runtime_user;
