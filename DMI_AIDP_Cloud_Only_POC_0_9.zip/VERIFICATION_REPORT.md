# DMI AIDP POC 0.9.0 — verification

**74 offline checks passed with real Spark. Pyflakes passed.** CI uses Spark
3.5.7 with Java 17. Actual AIDP, Oracle, and OCI validation remains outstanding.

## Changes

- Replaced the one shared storage_root with per-dataset full OCI prefixes in
  DATASET.physical_object_name. RAW and STAGE can use separate buckets,
  namespaces, and folder prefixes. No schema columns/tables were added.
- Both input and output locations resolve from the batch's pinned release;
  Stage reads the RAW dataset location, MAIN reads the STAGE dataset location.
  Metadata-defined prefixes get /batch_<batch_id> appended for Parquet.
- Removed storage_root from job/task bindings, runtime construction, and the
  failure finalizer. Custom read-only context now exposes output_location,
  the actual batch output prefix or Oracle MAIN table. Notebooks still only
  register custom functions and invoke the framework.
- Landing is read from source_uri and is not moved/overwritten. Quarantine file
  movement is not implemented; the dedicated bucket receives no POC outputs.

- Removed demo failure flags/branches from aidp.py, pipeline.py, and built-ins.
  The Stage notebook reads fail_first_stage and AIDP execution_count. Its custom
  function raises only when the flag is true and the external count is 1.
- Same notebook, flag, inputs, and metadata succeed on Repair with count 2.
  The failure is retained at CUSTOM_FEE_TRANSFORM, before DQ and writing.
- READ_SOURCE uses Spark CSV directly through the OCI Hadoop connector.
  CSV and Parquet now share one file-access/authentication path. Removed Python
  OCI SDK source download, SDK client parameters/auth setup, csv.DictReader,
  complete-file buffering, and Python row-list conversion.
- Runtime dependencies contain oracledb only. AIDP supplies Spark/PySpark and
  the OCI Hadoop connector; the wheel does not install Spark or connector JARs.
- RAW is string-valued. Header/data presence and configured required-value checks
  remain; Stage mappings convert to DATE/NUMBER. CSV options explicitly use
  headers, no inference, FAILFAST, multiline input, and doubled-quote escaping.
- Ingestion lineage retains receipt identity, source URI, counts, and status.
  Changed receipt/URI during RAW Repair is rejected against the first receipt,
  so a rejected changed input does not become the new baseline.
- SHA-256 byte-integrity and payload-size verification were intentionally removed.
  Those optional DDL fields remain NULL. Receipt hashing is identity only.
  Replacing source bytes at the same URI is not detected; source immutability
  during the entire job/Repair is a POC operating requirement.
- No new tables or runtime layers. Six runtime modules, 626 Python lines.
  Oracle TASK_STEP remains the sole ordered recipe; generic plan boundaries stay.
- Pinned releases, immutable attempts/batches, same-batch Repair, WORK_QUEUE,
  EVENT_LOG, policy actions, and read-only custom context remain.
- MAIN rows and TASK_RUN/BATCH completion still use one Oracle transaction.
  MAIN collects the small sample to native Python DATE/Decimal values; Spark
  JDBC, large-volume loading, and separate commit machinery were not introduced.

## Regression evidence

The 74 checks cover:

- Actual notebook cells with AIDP-style bindings: RAW success, notebook-owned
  Stage failure, unchanged flag on Repair, attempt 2 in the same batch, and MAIN.
- Distinct RAW/STAGE buckets and namespaces, exact metadata-defined prefixes,
  output audit locations, retained landing source, and Oracle MAIN rows.
- A newer ACTIVE release pointing to different buckets cannot redirect Repair
  of a batch pinned to the old release. Invalid relative/bucket-only/glob output
  locations fail before source I/O and retain the failed-attempt error.
- Real Spark CSV input and Parquet output, typed mappings, visible lineage, and
  unchanged successful RAW during Stage Repair.
- CSV BOM, quoted commas/multiline values, string preservation, duplicate/extra
  headers, empty data, configured required values, and missing-source failure.
- Source receipt/URI changes rejected repeatedly; restoring the original input
  allows another attempt. Checksum and payload-size fields stay unpopulated.
- Native Spark CSV/Parquet adapter options/OCI paths; source prefixes/globs fail
  before reading. No SDK client is injected into runtime code.
- Metadata-controlled plan changes, complete preflight before source I/O,
  built-in override rejection, required/FAIL_TASK settings, JSON objects, and
  read/sink/final-DQ boundaries. No per-task Python recipe exists.
- Custom callable/context/parameters, wrong returns/layout/types/nulls, immediate
  and lazy exceptions, and failures retained at the executing step.
- Two simple pinned NOT_NULL policies, scope/threshold/action integrity, and
  atomic policy-result/failure/error-queue recording.
- Active/terminal state guards, immutable attempts, scheduler exhaustion,
  completed-task rejection, and retained/idempotent failed-attempt error history.
- MAIN partial insert/audit/batch-closure failures roll back business rows and
  completion; restart succeeds without duplicate MAIN rows.
- Native Oracle bind types, adapter transaction calls, metadata seed parity,
  release pinning, and one input/output metadata lookup per task.

Spark's parser and Parquet reader/writer are real in CI. Test-only URI routing
maps OCI paths to temporary directories. AIDP widgets and Oracle-driver calls
are test doubles; SQLite substitutes for Oracle lifecycle storage. These
fixtures are excluded from deployment and are not supported runtime backends.
Spark CSV FAILFAST is not a guarantee of strict row-length validation.

## Package checks

Runtime/notebook cells compile, notebook outputs are empty, and the current
wheel matches all six delivered runtime modules byte-for-byte. Archive manifests
are verified. Deployment excludes tests, old wheels, caches, and generated data.
The separate source package retains CI tests/fixtures without a built wheel.
The suite is also exercised from the extracted source archive.

The 17-table DDL, MAIN/grants script, and inspection script are unchanged from
0.8. Sample metadata advances to release 2026100509 / version 0.9.0; business
columns, mappings, policies, and step plans are unchanged. Landing/RAW/STAGE
locations advance to separate bucket placeholders; set actual names before
activating the release. Existing running 0.8 batches need their original wheel,
notebooks, and parameters.

## Real-cloud proof still required

1. Validate one representative DMI FEE extract and the selected CSV options.
2. Set real full OCI locations for RAW/STAGE DATASET rows and the landing
   source/job input, then apply Oracle DDL/grants and activate release 2026100509.
3. Verify AIDP widgets, Spark runtime/connector, Oracle network/wallet access,
   and connector authentication on driver/workers.
4. Verify landing read/list and RAW/STAGE read/list/create/overwrite/delete plus
   applicable multipart permissions in each configured bucket; there is no
   separate Python SDK auth requirement.
5. Run the three-task job normally and capture Oracle rows and OCI part files.
6. Run with fail_first_stage=true; capture failed_step_code, retained WORK_QUEUE,
   and RUNNING BATCH. Repair Stage/Main with unchanged wheel/notebook/input/flag.
7. Confirm job.run_id stays correlated to the original BATCH and task execution
   count advances so the demo custom function succeeds.

No live Oracle transaction/DDL or AIDP/OCI run was available. No exactly-once,
source-byte integrity, cross-system commit reconciliation, distributed MAIN
loading, REPROCESS, or automatic killed-worker recovery is claimed.
