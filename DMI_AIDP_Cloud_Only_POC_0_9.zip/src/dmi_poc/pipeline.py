"""Explicit three-task DMI runner. No mixins, DAG engine, or commit ledger."""
from datetime import date
import json
from types import MappingProxyType
import uuid

from pyspark.sql import DataFrame, SparkSession

from .storage import ObjectStorage, object_address
from .steps import BUILTINS

PIPELINE = "DMI_PARQUET_POC"
TASK_CODES = ("DMI_FEE_RAW_LOAD", "DMI_FEE_STAGE_LOAD", "DMI_FEE_MAIN_LOAD")



class DmiPoc:
    def __init__(self, db, source_uri=None, receipt_id=None, spark=None):
        self.db = db
        self.spark = spark
        self.storage = ObjectStorage()
        self.source_uri = str(source_uri) if source_uri else None
        self.receipt_id = receipt_id

    def start_batch(self, job_run_id, cycle_date=None, execution_mode=None):
        if not job_run_id or not job_run_id.strip() or "{{" in job_run_id:
            raise ValueError("A resolved AIDP job.run_id is required.")
        execution_key = "AIDP:" + job_run_id
        if execution_mode is not None and execution_mode not in ("SCHEDULED", "MANUAL"):
            raise ValueError("POC supports SCHEDULED and MANUAL only.")
        mode = execution_mode or "SCHEDULED"
        with self.db.transaction():
            existing = self.db.one("SELECT * FROM RUNTIME.BATCH WHERE pipeline_code=:p AND execution_key=:k",
                p=PIPELINE, k=execution_key)
            if existing:
                if execution_mode is not None and existing["batch_type"] != mode:
                    raise ValueError("Execution mode conflicts with the existing batch.")
                if cycle_date and str(existing["cycle_date"])[:10] != cycle_date:
                    raise ValueError("Execution key already belongs to another cycle date.")
                if job_run_id and existing["orchestrator_run_id"] != job_run_id:
                    raise ValueError("Execution key already belongs to another scheduler job.")
                if existing["status"] == "FAILED":
                    raise ValueError("Terminal batches cannot restart; use a new execution key.")
                return existing
            release = self.db.one("SELECT * FROM METADATA.CONFIG_RELEASE WHERE pipeline_code=:p AND release_status='ACTIVE'", p=PIPELINE)
            if release is None:
                raise ValueError("Activate the DMI POC metadata first.")
            batch_id = self.db.next_id("RUNTIME.BATCH", "batch_id")
            self.db.insert("RUNTIME.BATCH", dict(batch_id=batch_id,
                config_release_id=release["config_release_id"], pipeline_code=PIPELINE,
                batch_type=mode,
                cycle_date=date.fromisoformat(cycle_date) if cycle_date else date.today(),
                execution_key=execution_key, correlation_id=str(uuid.uuid4()),
                orchestrator_run_id=job_run_id, status="RUNNING", triggered_by="DMI_POC"))
            self.db.execute("UPDATE RUNTIME.BATCH SET start_timestamp=SYSTIMESTAMP WHERE batch_id=:id", id=batch_id)
            batch = self._batch(batch_id)
            self._event(batch, None, "BATCH_STARTED", "Started DMI Parquet POC")
            return batch

    def get_batch_by_job_run_id(self, job_run_id):
        rows = self.db.execute("SELECT * FROM RUNTIME.BATCH WHERE pipeline_code=:p AND orchestrator_run_id=:j",
            p=PIPELINE, j=job_run_id)
        if len(rows) > 1:
            raise ValueError("Ambiguous scheduler job-to-batch correlation.")
        return rows[0] if rows else None

    def _batch(self, batch_id):
        batch = self.db.one("SELECT * FROM RUNTIME.BATCH WHERE batch_id=:id FOR UPDATE", id=batch_id)
        if not batch or batch["pipeline_code"] != PIPELINE:
            raise ValueError("Batch does not belong to the DMI POC.")
        return batch

    def _task(self, batch, task_code):
        if task_code not in TASK_CODES:
            raise ValueError("Unknown POC task code.")
        task = self.db.one("SELECT * FROM METADATA.TASK WHERE config_release_id=:r AND task_code=:c",
            r=batch["config_release_id"], c=task_code)
        if not task:
            raise ValueError("Task is missing from the pinned release.")
        return task

    def _latest(self, batch_id, task_id):
        return self.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE batch_id=:b AND task_id=:t ORDER BY attempt_number DESC",
            b=batch_id, t=task_id)

    def _dataset(self, batch, task, role):
        rows = self.db.execute("""SELECT d.* FROM METADATA.TASK_DATASET td JOIN METADATA.DATASET d
            ON d.config_release_id=td.config_release_id AND d.dataset_id=td.dataset_id
            WHERE td.config_release_id=:r AND td.task_id=:t AND td.dataset_role=:role AND td.is_enabled='Y'""",
            r=batch["config_release_id"], t=task["task_id"], role=role)
        if len(rows) != 1:
            raise ValueError("POC supports exactly one dataset per input/output role.")
        return rows[0]

    def _columns(self, release_id, dataset_id):
        columns = self.db.execute("SELECT * FROM METADATA.DATASET_COLUMN WHERE config_release_id=:r AND dataset_id=:d ORDER BY column_sequence",
            r=release_id, d=dataset_id)
        if not columns:
            raise ValueError("Dataset columns are required.")
        return columns

    def output_path(self, batch, dataset):
        if dataset["storage_type"] != "PARQUET":
            raise ValueError("Oracle MAIN has no Parquet output path.")
        location = str(dataset["physical_object_name"] or "").rstrip("/")
        if not object_address(location)[2] or any(c in location for c in "*[]{}"):
            raise ValueError("Parquet DATASET requires a full OCI dataset prefix.")
        return location + f"/batch_{batch['batch_id']}"

    def execute_task(self, batch_id, task_code, custom_steps=None,
                     orchestrator_task_run_id=None, orchestrator_attempt_number=None):
        if orchestrator_attempt_number is not None and (
                not orchestrator_task_run_id or orchestrator_attempt_number < 1):
            raise ValueError("External execution count requires its task-run ID and must be positive.")
        with self.db.transaction():
            batch = self._batch(batch_id)
            task = self._task(batch, task_code)
            latest = self._latest(batch_id, task["task_id"])
            if latest and latest["status"] == "COMPLETED":
                raise ValueError("Task already COMPLETED; select only failed/downstream tasks in AIDP Repair.")
            if batch["status"] != "RUNNING":
                raise ValueError("New attempts require a RUNNING batch.")
            if latest and latest["status"] == "RUNNING":
                raise ValueError("Attempt still RUNNING; stop its writer and fail that exact attempt before restarting.")
            run_id = self.db.next_id("RUNTIME.TASK_RUN", "task_run_id")
            self.db.insert("RUNTIME.TASK_RUN", dict(task_run_id=run_id, batch_id=batch_id,
                config_release_id=batch["config_release_id"], task_id=task["task_id"],
                attempt_number=int(latest["attempt_number"])+1 if latest else 1,
                original_task_run_id=latest["task_run_id"] if latest else None, status="RUNNING",
                orchestrator_task_run_id=orchestrator_task_run_id,
                orchestrator_attempt_number=orchestrator_attempt_number))
            self.db.execute("UPDATE RUNTIME.TASK_RUN SET start_timestamp=SYSTIMESTAMP WHERE task_run_id=:id", id=run_id)
            self._event(batch, run_id, "TASK_STARTED", task_code)
        ctx = dict(batch=batch, task=task, run_id=run_id, state={}, input_count=0, output_count=0,
                   step_code=None, framework=self)
        try:
            plan = self._resolve_plan(ctx, {} if custom_steps is None else custom_steps)
            ctx["output_dataset"] = self._dataset(batch, task, "OUTPUT")
            ctx["output_columns"] = self._columns(batch["config_release_id"], ctx["output_dataset"]["dataset_id"])
            dataset = ctx["output_dataset"]
            public_context = MappingProxyType(dict(batch_id=batch_id, task_run_id=run_id,
                task_code=task_code, config_release_id=batch["config_release_id"], cycle_date=batch["cycle_date"],
                output_location=self.output_path(batch, dataset) if dataset["storage_type"] == "PARQUET"
                                else dataset["physical_object_name"]))
            print(json.dumps(dict(event="TASK_PLAN", **public_context,
                steps=[dict(sequence=s["step_sequence_number"], code=s["step_code"], type=s["step_type"])
                       for s, _, _ in plan]), default=str), flush=True)
            if self.spark is None:
                self.spark = SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()
            df = None
            for step, handler, params in plan:
                ctx["step_code"] = step["step_code"]
                print(f"STEP_STARTED run={run_id} step={ctx['step_code']}", flush=True)
                df = handler(df, public_context if step["step_type"] == "CUSTOM_PYTHON" else ctx, params)
                if not isinstance(df, DataFrame):
                    raise TypeError(f"Step {ctx['step_code']} must return a Spark DataFrame.")
            self._complete(ctx)
            return self.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id", id=run_id)
        except Exception as exc:
            print(f"TASK_FAILED run={run_id} step={ctx['step_code']} error={type(exc).__name__}: {exc}", flush=True)
            self.fail_task_run(run_id, type(exc).__name__, str(exc), ctx["step_code"])
            raise

    def _resolve_plan(self, ctx, custom_steps):
        """Resolve every handler before source reads, business code, or writes."""
        builtins = BUILTINS
        if not isinstance(custom_steps, dict):
            raise ValueError("custom_steps must be a dictionary of named functions.")
        if builtins.keys() & custom_steps.keys():
            raise ValueError("BUILTIN names cannot be overridden by custom_steps.")
        steps = self.db.execute("SELECT * FROM METADATA.TASK_STEP WHERE config_release_id=:r AND task_id=:t ORDER BY step_sequence_number",
            r=ctx["batch"]["config_release_id"], t=ctx["task"]["task_id"])
        if not steps:
            raise ValueError("Task has no configured steps.")
        plan = []
        for step in steps:
            ctx["step_code"] = code = step["step_code"]
            if step["is_required"] != "Y" or step["on_failure_action"] != "FAIL_TASK":
                raise ValueError("POC uses required steps and FAIL_TASK only.")
            if step["step_type"] not in ("BUILTIN", "CUSTOM_PYTHON"):
                raise ValueError(f"Unsupported step_type for {code}.")
            handler = (builtins if step["step_type"] == "BUILTIN" else custom_steps).get(code)
            if not callable(handler):
                raise ValueError(f"Missing callable {step['step_type']} handler: {code}")
            params = json.loads(step["parameter_json"] or "{}")
            if not isinstance(params, dict):
                raise ValueError(f"Step {code} parameter_json must be a JSON object.")
            if step["step_type"] == "BUILTIN" and params:
                raise ValueError(f"BUILTIN {code} uses empty parameters in this POC.")
            plan.append((step, handler, params))
        # Generic boundaries, not a second per-task execution recipe.
        codes = [s["step_code"] if s["step_type"] == "BUILTIN" else None for s in steps]
        readers = {"READ_SOURCE", "READ_RAW", "READ_STAGE"}
        sinks = {"WRITE_RAW", "WRITE_STAGE", "LOAD_MAIN"}
        if codes[0] not in readers or any(c in readers for c in codes[1:]):
            raise ValueError("Plan must start with one read step.")
        if codes[-1] not in sinks or any(c in sinks for c in codes[:-1]):
            raise ValueError("Plan must end with one final sink step.")
        if codes[-1] != "WRITE_RAW" and (len(codes) < 2 or codes[-2] != "VALIDATE_DQ"):
            raise ValueError("VALIDATE_DQ must immediately precede the final sink.")
        ctx["step_code"] = None
        return plan

    def _complete(self, ctx):
        batch, task, run_id = ctx["batch"], ctx["task"], ctx["run_id"]
        if "output" not in ctx["state"]:
            raise ValueError("Task did not prepare its required output.")
        with self.db.transaction():
            current_batch = self._batch(batch["batch_id"])
            run = self.db.one("SELECT status FROM RUNTIME.TASK_RUN WHERE task_run_id=:id FOR UPDATE", id=run_id)
            if current_batch["status"] != "RUNNING" or run["status"] != "RUNNING":
                raise ValueError("Completion requires a RUNNING batch and exact attempt.")
            if "main_rows" in ctx["state"]:
                table = ctx["state"]["main_rows"]
                records = [dict(row, BATCH_ID=batch["batch_id"], TASK_RUN_ID=run_id, ROW_NUMBER=seq)
                           for seq, row in enumerate(table, 1)]
                types = {c["column_name"]: c["data_type"] for c in ctx["output_columns"]}
                types.update(BATCH_ID="NUMBER", TASK_RUN_ID="NUMBER", ROW_NUMBER="NUMBER")
                self.db.insert_many(ctx["state"]["output"], list(types), records, types)
            self.db.execute("""UPDATE RUNTIME.INGESTION_ITEM SET status='PROCESSED', source_record_count=:count,
                processed_timestamp=SYSTIMESTAMP WHERE task_run_id=:id""", count=ctx["input_count"], id=run_id)
            self._event(batch, run_id, "MAIN_TABLE_LOADED" if "main_rows" in ctx["state"] else "PARQUET_WRITTEN", "Output written",
                details={"path": ctx["state"]["output"], "rows": ctx["output_count"]})
            self.db.execute("""UPDATE RUNTIME.TASK_RUN SET status='COMPLETED', input_count=:ic, output_count=:oc,
                reject_count=0, end_timestamp=SYSTIMESTAMP WHERE task_run_id=:id""",
                ic=ctx["input_count"], oc=ctx["output_count"], id=run_id)
            self._event(batch, run_id, "TASK_COMPLETED", task["task_code"])
            if task["close_batch_on_success"] == "Y":
                self.db.execute("UPDATE RUNTIME.BATCH SET status='COMPLETED', end_timestamp=SYSTIMESTAMP WHERE batch_id=:id", id=batch["batch_id"])
                self._event(batch, run_id, "BATCH_COMPLETED", "Terminal AIDP task completed")

    def fail_task_run(self, run_id, code, message, failed_step=None):
        with self.db.transaction():
            run = self.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id", id=run_id)
            if not run:
                raise ValueError("Unknown exact task run ID.")
            batch = self._batch(run["batch_id"])
            run = self.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id FOR UPDATE", id=run_id)
            if run["status"] != "RUNNING":
                return  # Delayed/duplicate callbacks never change terminal attempts.
            if batch["status"] != "RUNNING":
                raise ValueError("Cannot fail an attempt in a terminal batch.")
            self._fail_in_tx(run, batch, code, message, failed_step)

    def _fail_in_tx(self, run, batch, code, message, failed_step):
        run_id = run["task_run_id"]
        self.db.execute("""UPDATE RUNTIME.TASK_RUN SET status='FAILED', error_code=:c,
            error_message=:m, failed_step_code=:s, end_timestamp=SYSTIMESTAMP WHERE task_run_id=:id""",
            c=code[:100], m=message[:4000], s=failed_step, id=run_id)
        self.db.execute("UPDATE RUNTIME.INGESTION_ITEM SET status='FAILED' WHERE task_run_id=:id AND status<>'PROCESSED'", id=run_id)
        queue_id = self.db.next_id("OPERATIONS.WORK_QUEUE", "work_queue_id")
        self.db.insert("OPERATIONS.WORK_QUEUE", dict(work_queue_id=queue_id,
            target_config_release_id=run["config_release_id"], scope_type="TASK", batch_id=run["batch_id"],
            task_run_id=run_id, idempotency_key=f"EXCEPTION:{run['batch_id']}:{run_id}",
            reason_code=code[:100], description=message[:2000], status="OPEN", requested_by="DMI_POC"))
        self._event(batch, run_id, "TASK_FAILED", message, error_code=code)

    def fail_batch(self, batch_id):
        with self.db.transaction():
            batch = self._batch(batch_id)
            if batch["status"] == "FAILED":
                return
            if batch["status"] != "RUNNING":
                raise ValueError("Terminal batch cannot change status.")
            if self.db.one("SELECT task_run_id FROM RUNTIME.TASK_RUN WHERE batch_id=:b AND status='RUNNING'", b=batch_id):
                raise ValueError("Stop writers and terminalize exact active attempts first.")
            self.db.execute("UPDATE RUNTIME.BATCH SET status='FAILED', end_timestamp=SYSTIMESTAMP WHERE batch_id=:id", id=batch_id)
            self._event(batch, None, "BATCH_FAILED", "Scheduler declared retries exhausted", error_code="RETRIES_EXHAUSTED")

    def _event(self, batch, run_id, code, message, details=None, error_code=None):
        event_id = self.db.next_id("OPERATIONS.EVENT_LOG", "event_log_id")
        self.db.insert("OPERATIONS.EVENT_LOG", dict(event_log_id=event_id,
            config_release_id=batch["config_release_id"], batch_id=batch["batch_id"], task_run_id=run_id,
            event_code=code, event_type="ERROR" if error_code else "INFO", severity="HIGH" if error_code else "LOW",
            error_code=error_code[:100] if error_code else None, message=message[:4000],
            details_json=json.dumps(details) if details else None,
            correlation_id=batch["correlation_id"], created_by="DMI_POC"))
