"""Small DMI proof of concept: OCI Parquet, Oracle MAIN, and restart."""

__version__ = "0.9.0"
