"""One AIDP notebook entry point; AIDP owns the job and retry scheduling."""
import json

from .db import OracleDb
from .pipeline import DmiPoc, TASK_CODES


def run_task(task_code, parameters, db, custom_steps=None, spark=None):
    values = {key: str(value).strip() for key, value in parameters.items() if value is not None}
    for key in ("job_run_id", "task_run_id", "execution_count"):
        if not values.get(key) or "{{" in values[key]:
            raise ValueError(f"Missing or unresolved AIDP task parameter: {key}")
    count = int(values["execution_count"])
    if count < 1:
        raise ValueError("AIDP execution_count must be positive.")
    if task_code not in TASK_CODES:
        raise ValueError("Unknown DMI task code.")
    source, receipt = values.get("source_uri"), values.get("receipt_id")
    if task_code == TASK_CODES[0] and (not source or not source.startswith("oci://") or not receipt):
        raise ValueError("RAW needs an exact OCI source URI and stable receipt ID.")
    poc = DmiPoc(db, source, receipt, spark)
    batch = poc.get_batch_by_job_run_id(values["job_run_id"])
    if batch is None and task_code != TASK_CODES[0]:
        raise ValueError("RAW must create the batch before downstream tasks run.")
    if task_code == TASK_CODES[0]:
        batch = poc.start_batch(values["job_run_id"], values.get("cycle_date") or None,
            values.get("execution_mode", "").upper() or None)
    return poc.execute_task(batch["batch_id"], task_code,
        custom_steps=custom_steps,
        orchestrator_task_run_id=values["task_run_id"], orchestrator_attempt_number=count)


def run_notebook(task_code, aidputils, custom_steps=None):
    """Uses documented AIDP widgets; exceptions propagate so the job sees failure."""
    defaults = {"job_run_id": "", "task_run_id": "", "execution_count": ""}
    if task_code == TASK_CODES[0]:
        defaults.update(source_uri="", receipt_id="", cycle_date="", execution_mode="")
    for name, default in defaults.items():
        aidputils.widgets.text(name=name, defaultValue=default, label=name)
    parameters = {name: aidputils.widgets.get(name) for name in defaults}
    db = OracleDb()
    try:
        result = run_task(task_code, parameters, db, custom_steps=custom_steps)
        print(json.dumps({key: result[key] for key in (
            "batch_id", "task_run_id", "status", "input_count", "output_count")}, default=str))
        return result
    finally:
        db.close()


def finalize_failed_job(job_run_id):
    """Explicit finalization after the operator/scheduler gives up on restart."""
    db = OracleDb()
    try:
        poc = DmiPoc(db)
        batch = poc.get_batch_by_job_run_id(job_run_id)
        if not batch:
            raise ValueError("No batch exists for this job run.")
        poc.fail_batch(batch["batch_id"])
    finally:
        db.close()
