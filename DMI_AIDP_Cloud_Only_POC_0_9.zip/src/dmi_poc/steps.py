"""Small built-in Spark steps. Lifecycle and the ordered loop live in pipeline.py."""
import hashlib
import json
import re

from pyspark.sql import functions as F, types as T


def spark_type(column):
    kind = column["data_type"]
    if kind == "VARCHAR2":
        return T.StringType()
    if kind == "DATE":
        return T.DateType()
    if kind == "NUMBER":
        parts = str(column["length_precision_scale"] or "19").split(",")
        return T.DecimalType(int(parts[0]), int(parts[1])) if len(parts) == 2 else T.LongType()
    raise ValueError("POC supports VARCHAR2, DATE, and NUMBER only.")


def validate_schema(df, columns, label):
    if len(df.columns) != len(columns) or set(df.columns) != {c["column_name"] for c in columns}:
        raise ValueError(f"{label} columns do not match DATASET_COLUMN.")
    for column in columns:
        if df.schema[column["column_name"]].dataType != spark_type(column):
            raise ValueError(f"{label} types do not match DATASET_COLUMN.")


def read_source(df, ctx, params):
    fw, batch, task = ctx["framework"], ctx["batch"], ctx["task"]
    source = fw.db.one("SELECT source_type,ingestion_mode,expected_input_count FROM METADATA.SOURCE_CONFIG WHERE config_release_id=:r AND source_config_id=:s",
        r=batch["config_release_id"], s=task["source_config_id"])
    if not source or source["source_type"] != "FILE" or source["ingestion_mode"] != "SINGLE_FILE" or source["expected_input_count"] != 1:
        raise ValueError("POC SOURCE_CONFIG must describe one FILE in SINGLE_FILE mode.")
    if not fw.source_uri:
        raise ValueError("RAW requires an exact source CSV URI in OCI.")
    path = fw.source_uri
    if not fw.receipt_id or not fw.receipt_id.strip():
        raise ValueError("Stable source receipt ID is required.")
    key = "DMI_FEE:" + hashlib.sha256(fw.receipt_id.encode()).hexdigest()
    with fw.db.transaction():
        previous = fw.db.one("""SELECT ie.source_location, ie.source_item_key FROM RUNTIME.INGESTION_ITEM ie
            JOIN RUNTIME.TASK_RUN tr ON tr.task_run_id=ie.task_run_id
            WHERE tr.batch_id=:b AND tr.task_id=:t ORDER BY tr.attempt_number ASC""",
            b=batch["batch_id"], t=task["task_id"])
        item_id = fw.db.next_id("RUNTIME.INGESTION_ITEM", "ingestion_item_id")
        fw.db.insert("RUNTIME.INGESTION_ITEM", dict(ingestion_item_id=item_id,
            task_run_id=ctx["run_id"], config_release_id=batch["config_release_id"],
            source_config_id=task["source_config_id"], dataset_id=ctx["output_dataset"]["dataset_id"],
            item_role="DATA", ingestion_type="FILE", item_name=path.rsplit("/", 1)[-1], source_item_key=key,
            source_location=path, landing_location=path, archive_location=path,
            status="RECEIVED"))
        fw.db.execute("UPDATE RUNTIME.INGESTION_ITEM SET received_timestamp=SYSTIMESTAMP WHERE ingestion_item_id=:id", id=item_id)
    if previous and (previous["source_location"] != path or previous["source_item_key"] != key):
        raise ValueError("Source receipt or URI changed during restart; do not reuse this batch.")
    result = fw.storage.read_csv(fw.spark, path)
    columns = ctx["output_columns"]
    names = [c["column_name"] for c in columns]
    if len(result.columns) != len(names) or set(result.columns) != set(names):
        raise ValueError("CSV header does not match DATASET_COLUMN.")
    required = [c["column_name"] for c in columns if c["is_nullable"] == "N"]
    summary = result.agg(F.count("*").alias("_rows"), *[
        F.sum(F.when(F.col(n).isNull() | (F.trim(F.col(n)) == ""), 1).otherwise(0)).alias(n)
        for n in required]).first().asDict()
    if not summary["_rows"]:
        raise ValueError("CSV must contain data rows.")
    if any(summary[n] for n in required):
        raise ValueError("Required source column is blank.")
    ctx["input_count"] = summary["_rows"]
    return result.select(*names)


def read_parquet(df, ctx, params):
    fw, batch, task = ctx["framework"], ctx["batch"], ctx["task"]
    source = fw._dataset(batch, task, "INPUT")
    ctx["input_dataset"] = source
    result = fw.storage.read_parquet(fw.spark, fw.output_path(batch, source))
    columns = fw._columns(batch["config_release_id"], source["dataset_id"])
    if len(result.columns) != len(columns)+2 or set(result.columns) != {c["column_name"] for c in columns} | {"_batch_id", "_run_id"}:
        raise ValueError("Input Parquet columns do not match DATASET_COLUMN.")
    result = result.drop("_batch_id", "_run_id")
    validate_schema(result, columns, "Input Parquet")
    ctx["input_count"] = result.count()
    return result


def direct_map(df, ctx, params):
    fw, batch, task = ctx["framework"], ctx["batch"], ctx["task"]
    source, target, columns = ctx["input_dataset"], ctx["output_dataset"], ctx["output_columns"]
    rules = fw.db.execute("SELECT * FROM METADATA.MAPPING_RULE WHERE config_release_id=:r AND task_id=:t AND is_enabled='Y' ORDER BY rule_sequence",
        r=batch["config_release_id"], t=task["task_id"])
    if len(rules) != len(columns) or {r["target_column_name"] for r in rules} != {c["column_name"] for c in columns}:
        raise ValueError("Exactly one enabled mapping per target column is required.")
    expressions, invalid = {}, []
    definitions = {c["column_name"]: c for c in columns}
    for rule in rules:
        if (rule["mapping_rule_type"] != "DIRECT_MAP" or rule["source_dataset_id"] != source["dataset_id"]
                or rule["target_dataset_id"] != target["dataset_id"]
                or any(rule.get(k) for k in ("mapping_expression", "condition_expression", "default_value"))):
            raise ValueError("POC supports direct mappings only; unsupported rules must not be skipped.")
        name, original = rule["target_column_name"], rule["source_column_name"]
        quoted = "`" + original.replace("`", "``") + "`"
        converted = F.expr(f"try_cast({quoted} AS {spark_type(definitions[name]).simpleString()})")
        expressions[name] = converted.alias(name)
        invalid.append(F.sum(F.when(F.col(quoted).isNotNull() & converted.isNull(), 1).otherwise(0)).alias(name))
    # One action rejects invalid casts even when the cluster's ANSI mode is off.
    if any(df.agg(*invalid).first().asDict().values()):
        raise ValueError("Input values cannot be cast to DATASET_COLUMN types.")
    return df.select(*[expressions[c["column_name"]] for c in columns])


def validate_dq(df, ctx, params):
    fw, dataset = ctx["framework"], ctx["output_dataset"]
    validate_schema(df, ctx["output_columns"], "Output")
    policies = fw.db.execute("""SELECT p.*, c.column_name FROM METADATA.POLICY_DEFINITION p
        JOIN METADATA.DATASET_COLUMN c ON c.config_release_id=p.config_release_id
        AND c.dataset_id=p.dataset_id AND c.dataset_column_id=p.dataset_column_id
        WHERE p.config_release_id=:r AND p.dataset_id=:d AND p.is_enabled='Y'""",
        r=ctx["batch"]["config_release_id"], d=dataset["dataset_id"])
    for policy in policies:
        if (json.loads(policy["parameter_json"]).get("check") != "NOT_NULL" or
                policy["failure_action"] != "FAIL_TASK" or policy["threshold_value"] != "0"):
            raise ValueError("POC supports NOT_NULL with threshold 0 and FAIL_TASK only.")
    required = {c["column_name"] for c in ctx["output_columns"] if c["is_nullable"] == "N"}
    names = sorted(required | {p["column_name"] for p in policies})
    nulls = df.agg(*[F.sum(F.when(F.col(n).isNull(), 1).otherwise(0)).alias(n) for n in names]).first().asDict() if names else {}
    failed = []
    if policies:
        with fw.db.transaction():
            for policy in policies:
                count = int(nulls[policy["column_name"]] or 0)
                fw.db.insert("RUNTIME.POLICY_RESULT", dict(
                    policy_result_id=fw.db.next_id("RUNTIME.POLICY_RESULT", "policy_result_id"),
                    config_release_id=policy["config_release_id"], policy_id=policy["policy_id"],
                    batch_id=ctx["batch"]["batch_id"], task_run_id=ctx["run_id"],
                    dataset_id=policy["dataset_id"], dataset_column_id=policy["dataset_column_id"],
                    result_level=policy["policy_scope_type"], result_status="FAIL" if count else "PASS",
                    expected_value="0 nulls", actual_value=str(count), threshold_value=policy["threshold_value"],
                    failed_record_count=count, failure_action_taken="FAILED_TASK" if count else None))
                if count:
                    failed.append(policy["policy_code"])
            if failed:
                run = fw.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id", id=ctx["run_id"])
                batch = fw._batch(run["batch_id"])
                fw._fail_in_tx(run, batch, "POLICY_FAILED", ", ".join(failed), ctx["step_code"])
    if failed:
        raise ValueError("Blocking policy failed: " + ", ".join(failed))
    if any(nulls[n] for n in required):
        raise ValueError("Required target column has nulls.")
    return df


def write_parquet(df, ctx, params):
    fw = ctx["framework"]
    validate_schema(df, ctx["output_columns"], "Output")
    path = fw.output_path(ctx["batch"], ctx["output_dataset"])
    result = df.withColumn("_batch_id", F.lit(ctx["batch"]["batch_id"]).cast("long"))
    result = result.withColumn("_run_id", F.lit(ctx["run_id"]).cast("long"))
    ctx["output_count"] = df.count()
    fw.storage.write_parquet(path, result)
    ctx["state"]["output"] = path
    return df


def load_main(df, ctx, params):
    validate_schema(df, ctx["output_columns"], "Output")
    dataset = ctx["output_dataset"]
    name = dataset["physical_object_name"]
    if dataset["storage_type"] != "ADB_TABLE" or not re.fullmatch(r"[A-Z][A-Z0-9_]*\.[A-Z][A-Z0-9_]*", name):
        raise ValueError("MAIN requires a metadata-defined Oracle owner.table identifier.")
    # Small POC only: collect native DATE/Decimal values, then insert atomically in Oracle.
    records = [row.asDict() for row in df.collect()]
    ctx["state"].update(main_rows=records, output=name)
    ctx["output_count"] = len(records)
    return df


BUILTINS = {"READ_SOURCE": read_source, "READ_RAW": read_parquet, "READ_STAGE": read_parquet,
            "DIRECT_MAP": direct_map, "VALIDATE_DQ": validate_dq, "WRITE_RAW": write_parquet,
            "WRITE_STAGE": write_parquet, "LOAD_MAIN": load_main}
