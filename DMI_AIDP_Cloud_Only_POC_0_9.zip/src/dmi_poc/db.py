"""Oracle connection, named binds, and explicit transactions."""
from contextlib import contextmanager
import os

import oracledb


class OracleDb:
    def __init__(self):
        options = {name: os.environ[env] for name, env in (
            ("config_dir", "MDPF_DB_CONFIG_DIR"),
            ("wallet_location", "MDPF_DB_WALLET_LOCATION"),
            ("wallet_password", "MDPF_DB_WALLET_PASSWORD"),
        ) if os.environ.get(env)}
        self.conn = oracledb.connect(user=os.environ["MDPF_DB_USER"],
            password=os.environ["MDPF_DB_PASSWORD"], dsn=os.environ["MDPF_DB_DSN"], **options)

    @contextmanager
    def transaction(self):
        try:
            yield
            self.conn.commit()
        except BaseException:
            self.conn.rollback()
            raise

    def execute(self, sql, **params):
        return self._query(sql, params, False)

    def one(self, sql, **params):
        return self._query(sql, params, True)

    def _query(self, sql, params, one):
        cursor = self.conn.cursor()
        try:
            cursor.execute(sql, params)
            if not cursor.description:
                return None if one else []
            names = [d[0].lower() for d in cursor.description]
            records = [cursor.fetchone()] if one else cursor.fetchall()
            mapped = [dict(zip(names, [v.read() if hasattr(v, "read") else v for v in row]))
                      for row in records if row is not None]
            return (mapped[0] if mapped else None) if one else mapped
        finally:
            cursor.close()

    def insert_many(self, table, columns, records, types):
        """Explicit Oracle bind types also handle a first row containing NULLs."""
        binds = ",".join(":" + name for name in columns)
        sql = f"INSERT INTO {table} ({','.join(columns)}) VALUES ({binds})"
        cursor = self.conn.cursor()
        try:
            mapping = {"DATE": oracledb.DB_TYPE_DATE, "NUMBER": oracledb.DB_TYPE_NUMBER,
                       "VARCHAR2": oracledb.DB_TYPE_VARCHAR}
            cursor.setinputsizes(**{name: mapping[kind] for name, kind in types.items()})
            cursor.executemany(sql, records)
        finally:
            cursor.close()

    def insert(self, table, values):
        # Identifiers are supplied by this package.
        columns = ",".join(values)
        binds = ",".join(":" + key for key in values)
        self.execute(f"INSERT INTO {table} ({columns}) VALUES ({binds})", **values)

    def next_id(self, table, column):
        schema, _ = table.split(".")
        return int(self.one(f"SELECT {schema}.SEQ_{column.upper()}.NEXTVAL id FROM DUAL")["id"])

    def close(self):
        self.conn.close()
