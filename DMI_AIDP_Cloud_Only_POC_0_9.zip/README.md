# DMI AIDP POC — 0.9.0

Run this POC entirely in **OCI AIDP Job_DMI**, using three Notebook tasks.
Oracle stores the 17-table framework model and MAIN business rows. OCI Object
Storage holds the source CSV and plain RAW/STAGE Parquet.

This release uses **Spark DataFrames** for processing and native Spark Parquet
I/O. TASK_STEP is the execution recipe; there is no hardcoded TASK_PLANS copy.
The notebook supplies custom functions and invokes the common runner.
Spark reads the source CSV directly through the same OCI connector used for
Parquet. Landing, RAW, and STAGE can use different buckets. MAIN is in Oracle.
Demo failure injection belongs entirely to the Stage notebook.

## Ownership

| Component | Owns |
|---|---|
| AIDP | Job dependencies, scheduling, retry limits, and Repair task selection |
| Oracle metadata | Pinned release, ordered TASK_STEP plan, datasets, mappings, policies |
| MDPF | Plan validation/loop, built-ins, batch/attempt lifecycle, failure/audit records |
| Notebook | CUSTOM_PYTHON functions and their registration |

The framework does not reconstruct the job DAG, select Repair tasks, skip
successful work, or retry individual steps. Selecting an already COMPLETED task
is rejected to prevent duplicate output. AIDP must select the failed task and its
unfinished downstream tasks.

## Execution plans

| Notebook / TASK | Ordered steps |
|---|---|
| Task_raw / DMI_FEE_RAW_LOAD | READ_SOURCE → WRITE_RAW |
| Task_stage / DMI_FEE_STAGE_LOAD | READ_RAW → DIRECT_MAP → CUSTOM_FEE_TRANSFORM → VALIDATE_DQ → WRITE_STAGE |
| Task_main / DMI_FEE_MAIN_LOAD | READ_STAGE → DIRECT_MAP → VALIDATE_DQ → LOAD_MAIN |

TASK_STEP.step_sequence_number controls order. step_type is BUILTIN or
CUSTOM_PYTHON. step_code resolves an explicit handler; no dynamic imports or
Python expressions are executed from metadata. All POC steps are required and
use FAIL_TASK.

Before processing, MDPF validates every handler and JSON parameter object. It
checks only generic boundaries: one read first, one sink last, and VALIDATE_DQ
immediately before STAGE/MAIN output. Custom transformations and mapping steps
execute wherever the metadata orders them before final validation. There is no
per-task Python recipe. Custom functions cannot use reserved BUILTIN names.
Built-in parameters are empty objects in this POC; custom parameters come from
TASK_STEP.parameter_json. Invalid types/handlers/parameter objects fail visibly.

The resolved plan and each current step print in notebook output. Failures
retain failed_step_code on TASK_RUN. There is no step-execution table.

Every handler uses `step(df, context, params)` and returns a Spark DataFrame. The first read
receives df=None. Write handlers return the same business DataFrame. LOAD_MAIN
prepares typed rows; framework completion inserts them and completes TASK_RUN
and BATCH in **one Oracle transaction**.

## Notebook customization

The Stage notebook's business transformation uses this pattern:

```python
from pyspark.sql import functions as F

def custom_fee_transform(df, context, params):
    column = params["column"]
    return df.withColumn(column, F.trim(F.col(column)))

custom_steps = {"CUSTOM_FEE_TRANSFORM": custom_fee_transform}

from dmi_poc.aidp import run_notebook
result = run_notebook("DMI_FEE_STAGE_LOAD", aidputils,
                      custom_steps=custom_steps)
```

Its metadata parameters are `{"column": "CLIENT_NO"}`. It trims that string
column while preserving the dataset layout. RAW and MAIN register empty
custom_steps dictionaries. Notebooks do not call individual processing steps.

Custom functions receive a read-only context with batch_id, task_run_id,
task_code, config_release_id, cycle_date, and output_location. They should transform
the input, return a DataFrame, and let exceptions propagate. Final columns, types,
and required values must match dataset metadata. Stage enforces the two pinned
NOT_NULL policies for LN_NO and MSP_CYCLE_DATE and records POLICY_RESULT.

## 1. Prepare Oracle and OCI

A DBA provisions METADATA, RUNTIME, OPERATIONS, DMI_MAIN and MDPF_RUNTIME with
suitable quotas and session access. For a fresh environment run, in order:

1. sql/00_framework.sql — the 17 framework tables, step_type CHECK constraint, and immutability guards.
2. sql/01_main_and_access.sql — DMI_MAIN.DMI_FEE and runtime grants.
3. sql/02_dmi_metadata.sql — release 2026100509, tasks, steps, mappings, policies.

For an existing installation, do not rerun CREATE TABLE scripts. Finish old
batches with their original wheel/notebooks and retire the older ACTIVE release
before activating this release. For an existing 0.6 schema whose step_type values
are all BUILTIN/CUSTOM_PYTHON, a DBA can add the one new constraint:

```sql
ALTER TABLE METADATA.TASK_STEP ADD CONSTRAINT CK_TASK_STEP_TYPE
CHECK (step_type IN ('BUILTIN','CUSTOM_PYTHON'));
```

If older releases contain other step_type values, use a fresh POC schema rather
than editing published metadata to satisfy this constraint. The wider schema
still permits SKIP_STEP/QUARANTINE; this POC runner supports required FAIL_TASK only.
Published metadata is immutable. PIPELINE_STATE and OUTBOUND_CONFIG remain in
the model and are unused by this POC.

Set the real locations in sql/02_dmi_metadata.sql while the release is DRAFT,
before its final APPROVED/ACTIVE statements:

| Location | Configuration | Example |
|---|---|---|
| Landing source | Job source_uri; matching SOURCE_CONFIG.landing_path for metadata | oci://LANDING_BUCKET@NAMESPACE/landing/delivery-001/fee.csv |
| RAW output | DATASET.physical_object_name for DMI_FEE_RAW | oci://RAW_BUCKET@NAMESPACE/raw/dmi_fee |
| STAGE output | DATASET.physical_object_name for DMI_FEE_STAGE | oci://STAGE_BUCKET@NAMESPACE/stage/dmi_fee |
| MAIN output | DATASET.physical_object_name for DMI_FEE_MAIN | DMI_MAIN.DMI_FEE |
| Quarantine | Reserved for file quarantine; not written by this POC | Your separate quarantine bucket |

Use full OCI prefixes for Parquet datasets, including bucket and namespace,
without a batch suffix or glob. The framework appends /batch_<batch_id>.
Stage reads RAW using the INPUT dataset location and writes to its own OUTPUT
location. MAIN reads STAGE the same way. Locations belong to the pinned release;
a newer ACTIVE release cannot redirect an existing batch's Repair.

There is no shared storage_root parameter. Remove it from the new job/task
configuration; keep source_uri, receipt_id, cycle_date, and the demo flag.
Notebook code remains unchanged for bucket names. Custom context output_location
is the resolved output prefix for this batch, or the Oracle MAIN table name.
The SQL table model is unchanged. Finish existing 0.8 batches with their original
wheel, notebooks, and job parameters; do not switch them to this API mid-Repair.
Quarantine file copy/move is outside this demo. Failed attempts record errors in
TASK_RUN and WORK_QUEUE without moving source or output files.

Configure Oracle credentials securely on the cluster: MDPF_DB_USER,
MDPF_DB_PASSWORD, MDPF_DB_DSN. Optional wallet settings: MDPF_DB_CONFIG_DIR,
MDPF_DB_WALLET_LOCATION, MDPF_DB_WALLET_PASSWORD. Keep credentials out of job
parameters and notebooks. Every task needs Oracle network access.

All file I/O uses Spark's OCI Hadoop connector on the driver and workers:
source CSV read, RAW/STAGE Parquet read, and Parquet overwrite. Configure the
connector and its principal through your cluster administration. There is no
Python OCI SDK dependency or OCI_AUTH setting in this package. The wheel does
not install JARs or change shared Hadoop authentication. Confirm the connector
can read/write oci://bucket@namespace/prefix paths. Oracle documents
fs.oci.client.custom.authenticator values ResourcePrincipalsCustomAuthenticator
and InstancePrincipalsCustomAuthenticator in the com.oracle.bmc.hdfs.auth package.
Configure the appropriate regional endpoint through your cluster administration.

The connector identity needs landing read/list, RAW read/list/create/overwrite/delete,
and STAGE read/list/create/overwrite/delete access in their respective buckets.
Spark overwrite deletes old objects under that batch prefix; native Spark
may also use multipart/temporary-object operations. Scope permissions to the POC
output area. No workstation auth or local runtime storage path is supported.

Place one immutable representative FEE CSV in OCI, for example:
`oci://LANDING_BUCKET@NAMESPACE/landing/delivery-001/fee.csv`.
Check its 12-column layout, types, and ISO dates against the sample metadata.
The example layout is synthetic; validate it against your real FEE extract.
The source must be one exact .csv object, without a prefix/glob. Spark reads
with header=true, inferSchema=false, FAILFAST, multiline CSV, and doubled-quote
escaping. RAW stays string-valued; Stage mappings perform typed conversion.
Header, nonempty data, and configured required-column checks remain.
Spark's CSV parser does not guarantee rejection of every row-length mismatch;
validate representative input with these options before the demo.

INGESTION_ITEM records source URI, stable receipt identity, count, and status.
RAW Repair rejects a changed receipt or URI. Byte checksum and payload-size
verification are outside this POC; their optional columns are left NULL. Keep
the source object unchanged for the entire job and Repair. Replacing bytes at
the same URI with the same receipt is not detected.

## 2. Configure Job_DMI

1. Install dist/dmi_poc-0.9.0-py3-none-any.whl on the AIDP cluster and its declared
   oracledb dependency. Use the cluster-provided PySpark; do not install
   another Spark distribution on AIDP. The CI baseline is Spark 3.5.7; verify your
   selected cluster runtime and OCI connector before the demo. Restart as required.
2. Import the three notebooks into /Workspace/DMI/ and select them in the three
   Notebook tasks on your cluster.
3. Configure Task_stage to require Task_raw success and Task_main to require
   Task_stage success. Use All success, streaming off, retry count 0 for the
   manual Repair demonstration, and retry-on-timeout off.
4. Enter parameters using notebooks/job_parameters.json. This JSON is a setup
   guide, not an AIDP API import payload.

| Parameter on every task | Binding |
|---|---|
| job_run_id | {{job.run_id}} |
| task_run_id | {{task.run_id}} |
| execution_count | {{task.execution_count}} |

RAW also receives source_uri, receipt_id, cycle_date, and execution_mode.
Stage receives fail_first_stage, which its notebook reads directly. The
framework does not read or interpret that demo flag. aidputils.widgets reads the named values;
AIDP must resolve the bindings. RAW alone creates the BATCH. Downstream tasks
find it using job.run_id; they need no BATCH_ID publication or shared filesystem.

## 3. Demonstrate normal execution, failure, and Repair

1. **Normal:** fail_first_stage=false. Run Job_DMI. Expect one COMPLETED BATCH,
   three completed TASK_RUNs, RAW/STAGE Parquet, two PASS policies, and MAIN rows.
2. **Failure:** fail_first_stage=true on another job run. RAW completes. Stage
   notebook reads execution_count=1 and raises at CUSTOM_FEE_TRANSFORM, before
   DQ or output writing. TASK_RUN is FAILED,
   WORK_QUEUE retains an OPEN error, BATCH stays RUNNING, and AIDP does not run MAIN.
3. **Repair:** select failed Stage and unfinished MAIN in the same AIDP job run.
   Do not select completed RAW. Confirm job.run_id stays unchanged. Stage creates
   attempt 2. AIDP execution_count is now greater than 1, so the same notebook
   and unchanged flag allow its entire plan to finish. MAIN completes the batch.
   The original failed attempt and error remain. Use false for the next normal demo.
4. Inspect sql/03_inspect.sql and capture actual job/task IDs, notebook step logs,
   Oracle rows, and OCI objects.

Keep **notebook code, wheel, source receipt, and job inputs unchanged during
Repair**. Metadata remains pinned to the original batch. A new job.run_id starts
a new batch. A caught exception creates an immutable failed attempt and retained
WORK_QUEUE error; there are no internal retries or checkpoints.
The notebook's demo condition is `fail_first_stage == "true" and execution_count == 1`.
A fixed inject_failure metadata parameter without the count condition would fail
every Repair. Execution count is the AIDP task count, not an internal retry counter.

Parquet prefixes are deterministic within each configured bucket:
oci://RAW_BUCKET@NAMESPACE/raw/dmi_fee/batch_N/ and
oci://STAGE_BUCKET@NAMESPACE/stage/dmi_fee/batch_N/. Spark creates part-*.parquet files under each prefix;
there is no fixed single data.parquet object. A failed task recomputes and overwrites its
batch output. Data includes _batch_id and _run_id lineage columns. Successful
RAW is retained for Stage Repair. There is no publication/commit reconciliation.
MAIN stores rows per batch without business-cycle MERGE. Its small sample is
collected to the driver and inserted through the same Oracle connection as the
runtime completion; Spark JDBC is not used. This is not a large-volume MAIN loader.

Spark transformations are lazy. A custom expression's error may surface at a
later validation/write action; failed_step_code records the step executing when
the error surfaces. Spark traceback and notebook logs retain the originating
expression. MDPF does not force evaluation or cache/checkpoint after every step.
Keep custom transformations deterministic through Repair.

If retries are abandoned, explicitly finalize from an AIDP notebook:

```python
from dmi_poc.aidp import finalize_failed_job
finalize_failed_job("EXACT_AIDP_JOB_RUN_ID")
```

This refuses an active RUNNING attempt. Hard-killed workers are not automatically
made stale; confirm their writer stopped before failing the exact TASK_RUN.

## Maintenance map and scope

| File | Where to look |
|---|---|
| notebooks/Task_stage.ipynb | Custom business function, demo flag/count, and registration |
| sql/02_dmi_metadata.sql | Step plan, parameters, dataset layout, mappings/policies |
| src/dmi_poc/pipeline.py | execute_task loop, _resolve_plan, lifecycle, and Oracle completion |
| src/dmi_poc/steps.py | Built-in Spark read/map/DQ/write/MAIN preparation functions |
| src/dmi_poc/aidp.py | AIDP parameters, notebook entry point, failure finalizer |
| src/dmi_poc/db.py / storage.py | Oracle transactions/binds and OCI read/write |

Deployment contains one wheel, notebooks, SQL, runtime source, this README,
verification, and hashes. The separate source ZIP also preserves CI tests and
fixtures and omits the built wheel. Neither package contains older versions,
local launchers, or generated demo data.

This is a sequential small-file POC. REPROCESS, Iceberg,
commit ledgers, watermarks, outbound execution, ZIP handling, generic policy
engines, and automatic hard-timeout recovery are outside this release.
Offline regression results are recorded in VERIFICATION_REPORT.md. Real Oracle DDL/transactions, Spark OCI principal access,
and AIDP success/failure/Repair still need validation in your environment.

Official references: [AIDP notebooks](https://docs.oracle.com/en/cloud/paas/ai-data-platform/aidug/notebooks.html),
[job parameters](https://docs.oracle.com/en/cloud/paas/ai-data-platform/aidug/parameters.html),
[cluster libraries](https://docs.oracle.com/en/cloud/paas/ai-data-platform/aidug/manage-libraries.html),
[OCI Hadoop connector](https://docs.oracle.com/en-us/iaas/Content/API/SDKDocs/hdfsconnector.htm),
[OCI object permissions](https://docs.oracle.com/en-us/iaas/Content/Identity/Reference/objectstoragepolicyreference.htm),
[Spark CSV](https://spark.apache.org/docs/3.5.7/sql-data-sources-csv.html),
[Spark Parquet](https://spark.apache.org/docs/3.5.7/sql-data-sources-parquet.html).
