# MDPF SQL Generator 1.0

The onboarding tools prepare configuration and deployment artifacts. They do not
run pipelines or deploy SQL. The [production DMI_FEE walkthrough](../../data-pipelines/providers/dmi/README.md)
is the main end-to-end example. Start with the [developer guide](../framework/DEVELOPER_GUIDE.md)
for local installation and tests.

## Choose an onboarding route

| Starting point | What to do |
|---|---|
| One pipeline with a known schema | Edit an existing input YAML, such as the provider's `datasets/fee/onboarding.yaml`, and upload it with its samples. |
| Many independent pipelines | Use the CSV catalog and shared OCI profile to prepare one input YAML per row, then review each before generation. |
| Samples are not available yet | Use `template_only=True` to create an incomplete YAML with placeholders. Complete it before normal generation. |

The catalog builder and existing YAML are alternatives. You do not need to run both.

## Bulk pre-onboarding

Upload the reviewed [shared profile](examples/shared_profile.yaml) and
[catalog](examples/bulk_catalog.csv) to OCI. From an OCI notebook with both utility
packages installed:

```python
from pprint import pprint
from mdpf_onboarding.bulk_builder import build_catalog

PROFILE = 'oci://config@namespace/profiles/shared_profile.yaml'
CATALOG = 'oci://config@namespace/catalogs/providers.csv'
pprint(build_catalog(PROFILE, CATALOG))                 # preview
pprint(build_catalog(PROFILE, CATALOG, dry_run=False))  # save valid rows
```

Replace the example URIs. Each row describes an independent pipeline; a bad row
does not block unrelated valid rows. Preview and save check sample-object existence
with HEAD calls, without downloading sample data or starting Spark. Existing input
YAMLs are skipped. See [catalog fields and statuses](REFERENCE.md#prepare-input-yamls-from-a-csv-catalog).

The shared profile supplies environment bindings and sample/artifact roots. New
inputs default to Parquet and source/feed/date paths, with batch_id for RAW/STAGE.
For dataset `FEE`, set `target_table=DMI_FEE` explicitly; otherwise the target defaults
to `FEE`. The catalog's CSV format does not imply CSV landing deliveries.

## Generate and review artifacts

After reviewing the input YAML, run in a prepared OCI Spark notebook:

```python
from mdpf_onboarding.onboard import generate

CONFIG = 'oci://artifacts@namespace/provider/input/onboarding.yaml'
metadata_sql_uri = generate(CONFIG, spark=spark)
print(metadata_sql_uri)
```

Use your actual input URI. Normal generation reads samples and requires both SDK
and Spark bucket access. It needs no Oracle credentials. Explicit column definitions
are checked against the samples; missing definitions can be inferred. The production
DMI_FEE YAML already defines its reviewed business schema.

| Output | Purpose |
|---|---|
| Complete YAML | Reviewed column definitions, resolved plans and reusable configuration |
| Metadata SQL | Create a new **DRAFT** release in ATP |
| MAIN DDL | Proposed table DDL for manual review in ADW; enabled by default, suppress with `generate_main_ddl: false` |

Generated artifacts use a separate output prefix. Keep input YAML, complete YAML,
metadata SQL, DDL and samples at distinct object locations. Normal uploads are
create-only unless explicitly configured otherwise; partial upload success is
possible. The return value is the metadata SQL URI. No SHA256 comments are added
to generated YAML/SQL; package integrity checks remain.

For command-line use:

```bash
mdpf-onboard --config 'oci://artifacts@namespace/provider/input/onboarding.yaml'
```

For a changed pipeline, bump its metadata release version and use the previous
complete YAML as `baseline_yaml` or `--baseline-yaml`. Both comparison schemas must
be explicit. See [change workflow](REFERENCE.md#make-a-change) and
[DDL proposals](REFERENCE.md#schemas-and-target-ddl-proposals).

## Planning without samples

```python
pprint(build_catalog(PROFILE, CATALOG, dry_run=True, template_only=True))
pprint(build_catalog(PROFILE, CATALOG, dry_run=False, template_only=True))
# Or use an existing OCI input YAML:
template_uri = generate(CONFIG, template_only=True)
```

These explicit template-only calls create marked **INCOMPLETE** YAML, without
sample HEAD/read operations, Spark startup, SQL or DDL. Fill sample references
and business column placeholders, remove `template_status`, then generate normally.
A successful template run does not verify OCI sample access.

## Deploy and run

Continue with [DMI_FEE deployment](../../data-pipelines/providers/dmi/README.md#deploy-and-activate):
review MAIN DDL in ADW, metadata SQL in ATP, verify targets, activate the release,
then run RAW → STAGE → MAIN. Fresh ATP installation belongs to the
[Framework setup](../framework/README.md#fresh-atp-installation); recovery belongs
to [operations](../framework/OPERATIONS.md).

Optional per-feed `upstream_config` records IDMC source details as JSON. IDMC owns
acquisition/conversion; the utility only stores its settings. See the
[field reference](REFERENCE.md#optional-upstream-information-for-idmc).

## Reference examples

`examples/dmi_fee.yaml` and the LOAN/JOIN/SPLIT/DQ YAMLs remain CSV-based regression
examples. They are not a second production DMI_FEE configuration. CSV samples can
also describe an explicit Parquet schema, as in the production provider. Keep
actual delivery format and sample format separate when reviewing paths.

Use [REFERENCE.md](REFERENCE.md) for YAML fields, supported rules, API results,
exceptions and comparison behavior. See [VALIDATION.txt](../../VALIDATION.txt) for
checks performed and pending live verification.
