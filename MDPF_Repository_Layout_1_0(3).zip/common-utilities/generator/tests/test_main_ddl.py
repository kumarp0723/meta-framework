from copy import deepcopy
import re
import sqlite3

import pytest
import yaml
from oci.exceptions import ServiceError

from conftest import CatalogDb,prepare_execution
from test_templates import handlers
from mdpf_onboarding.metadata_generator import render_main_ddl
from mdpf_onboarding.onboard import generate,main_ddl_uri,output_uri,yaml_uri,validate_config


def ddl_statements(db,script,env):
    """Evaluate only generated string expressions; this is not an Oracle PL/SQL parser."""
    statements=[]
    for expression in re.findall(r'  EXECUTE IMMEDIATE (.*?);',script,re.S):
        expression=re.sub(r"'(?:''|[^'])*'|\bv_env\b",lambda m:m[0] if m[0].startswith("'") else ':env',expression)
        statements.append(db.conn.execute('SELECT '+expression,dict(env=env)).fetchone()[0])
    return statements


def test_flag_is_optional_and_boolean(oci_setup):
    config,_,_,_=oci_setup
    config['sql_output'].pop('generate_main_ddl',None)
    assert validate_config(config)['sql_output']['generate_main_ddl'] is True
    config['sql_output']['generate_main_ddl']=True
    assert validate_config(config)['sql_output']['generate_main_ddl'] is True
    for value in ('true','false',1,0,None,[]):
        config['sql_output']['generate_main_ddl']=value
        with pytest.raises(ValueError,match='generate_main_ddl'):validate_config(config)


@pytest.mark.parametrize('enabled',[False,None])
def test_false_suppresses_ddl_and_omitted_enables_it(spark,oci_setup,enabled):
    config,uri,client,_=oci_setup
    if enabled is None:config['sql_output'].pop('generate_main_ddl',None)
    else:config['sql_output']['generate_main_ddl']=enabled
    client.objects[uri]=yaml.safe_dump(config).encode()
    result=generate(uri,spark=spark,client=client)
    assert result==output_uri(config)
    expected=[yaml_uri(config)]+([main_ddl_uri(config)] if enabled is None else [])+[result]
    assert [target for target,_ in client.puts]==expected
    assert (main_ddl_uri(config) in client.objects)==(enabled is None)


def test_enabled_uploads_both_artifacts_and_preserves_return(spark,oci_setup,capsys):
    config,uri,client,_=oci_setup;config['sql_output']['generate_main_ddl']=True
    client.objects[uri]=yaml.safe_dump(config).encode()
    result=generate(uri,spark=spark,client=client);ddl=main_ddl_uri(config)
    assert ddl.endswith('/demo_loan_main_ddl.sql') and result==output_uri(config)
    assert [target for target,_ in client.puts]==[yaml_uri(config),ddl,result]
    assert all(options.get('if_none_match')=='*' for _,options in client.puts)
    assert b'CREATE TABLE' in client.objects[ddl] and b'INSERT INTO METADATA.TASK' in client.objects[result]
    assert ddl in capsys.readouterr().out


@pytest.mark.parametrize('existing',['ddl','metadata'])
def test_overwrite_protection_applies_to_both_artifacts(spark,oci_setup,existing):
    config,uri,client,_=oci_setup;config['sql_output']['generate_main_ddl']=True
    client.objects[uri]=yaml.safe_dump(config).encode()
    target=main_ddl_uri(config) if existing=='ddl' else output_uri(config)
    client.objects[target]=b'existing reviewed artifact'
    with pytest.raises(ServiceError) as error:generate(uri,spark=spark,client=client)
    assert error.value.status==412 and client.objects[target]==b'existing reviewed artifact'
    if existing=='ddl':assert output_uri(config) not in client.objects
    else:assert main_ddl_uri(config) in client.objects  # Independent uploads, no false atomicity.


def test_explicit_overwrite_replaces_both(spark,oci_setup):
    config,uri,client,_=oci_setup;config['sql_output'].update(generate_main_ddl=True,overwrite=True)
    client.objects[uri]=yaml.safe_dump(config).encode()
    for target in (main_ddl_uri(config),output_uri(config)):client.objects[target]=b'old'
    generate(uri,spark=spark,client=client)
    assert all('if_none_match' not in options for _,options in client.puts)
    assert all(client.objects[target]!=b'old' for target,_ in client.puts)


@pytest.mark.parametrize('env',['DEV','STAGE','PROD'])
def test_ddl_uses_metadata_columns_targets_and_environment(models,env):
    model=models['one_to_many'];db=CatalogDb();script=render_main_ddl(model,b'config')
    statements=ddl_statements(db,script,env)
    outputs=[spec for spec in model['datasets'].values() if spec['row']['storage_type']=='ADB_TABLE']
    assert len(statements)==len(outputs)==2
    for statement,spec in zip(statements,outputs):
        assert statement.startswith('CREATE TABLE '+spec['row']['physical_object_name'][env]+' (')
        expected=[c['column_name'] for c in sorted(spec['columns'],key=lambda c:c['column_sequence'])]
        expected+=['BATCH_ID','TASK_RUN_ID','ROW_NUMBER','CREATED_AT','UPDATED_AT']
        actual=re.findall(r'^    ([A-Z][A-Z0-9_]*) ',statement,re.M)
        assert actual==expected
        assert all(name+' NUMBER(19) NOT NULL' in statement for name in ['BATCH_ID','TASK_RUN_ID','ROW_NUMBER'])
        assert all(name+' TIMESTAMP(6) WITH TIME ZONE NOT NULL' in statement for name in ('CREATED_AT','UPDATED_AT'))
        assert 'LOAN_ID VARCHAR2(20 CHAR) NOT NULL' in statement
        assert not re.search(r'\b(DROP|ALTER|GRANT|PRIMARY KEY|FOREIGN KEY|CREATE INDEX)\b',statement)
    assert ':target_env' in script and "v_env NOT IN ('DEV','STAGE','PROD')" in script and 'SET DEFINE OFF' in script
    db.close()


@pytest.mark.parametrize('name',['one_to_one','many_to_one','one_to_many'])
def test_generated_new_tables_support_framework_load(models,spark,tmp_path,name):
    model=models[name];fw,db=prepare_execution(model,tmp_path,spark)
    script=render_main_ddl(model,b'config')
    for statement in ddl_statements(db,script,'DEV'):
        table=statement.split()[2]
        fw.main_db.conn.execute('DROP TABLE '+table)  # Replace the CI fixture's generic tables only.
        translated=re.sub(r'VARCHAR2\((\d+) (?:BYTE|CHAR)\)',r'VARCHAR2(\1)',statement)
        translated=translated.replace('TIMESTAMP(6) WITH TIME ZONE','TEXT')
        fw.main_db.conn.execute(translated)
    batch=fw.start_batch('ddl-'+name,'2026-10-15','MANUAL')['batch_id']
    for task in model['tasks']:fw.execute_task(batch,task['row']['task_code'],custom_steps=handlers())
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='COMPLETED'
    for spec in model['datasets'].values():
        if spec['row']['storage_type']=='ADB_TABLE':
            table=spec['row']['physical_object_name']['DEV']
            assert fw.main_db.one(f'SELECT COUNT(*) n FROM {table}')['n']==2
            with pytest.raises(sqlite3.IntegrityError):fw.main_db.execute(f'INSERT INTO {table} (BATCH_ID) VALUES (1)')
    db.close()


@pytest.mark.parametrize('kind,spec',[('VARCHAR2','4001 BYTE'),('VARCHAR2','1001 CHAR'),('NUMBER','39,0'),('UNSUPPORTED',None)])
def test_invalid_or_out_of_scope_ddl_contracts_fail(models,kind,spec):
    model=deepcopy(models['one_to_one'])
    target=next(d for d in model['datasets'].values() if d['row']['storage_type']=='ADB_TABLE')
    target['columns'][0].update(data_type=kind,length_precision_scale=spec)
    with pytest.raises(ValueError):render_main_ddl(model,b'config')


def test_render_failure_prevents_either_upload(spark,oci_setup):
    config,uri,client,_=oci_setup;config['sql_output']['generate_main_ddl']=True
    config['inference']['column_overrides']['DEMO_LOAN_LOAN_MAIN']['LOAN_ID']['length_precision_scale']='1001 CHAR'
    client.objects[uri]=yaml.safe_dump(config).encode()
    with pytest.raises(ValueError,match='Sample MAIN DDL'):generate(uri,spark=spark,client=client)
    assert not client.puts


def test_wide_ddl_is_chunked_without_losing_columns(models):
    model=deepcopy(models['one_to_one'])
    target=next(d for d in model['datasets'].values() if d['row']['storage_type']=='ADB_TABLE')
    template=target['columns'][0]
    target['columns']=[dict(template,column_name=f'COLUMN_{i:03d}',column_sequence=i) for i in range(1,201)]
    db=CatalogDb();script=render_main_ddl(model,b'config');statement=ddl_statements(db,script,'DEV')[0]
    assert 'COLUMN_200 VARCHAR2(20 CHAR) NOT NULL' in statement and len(statement)>4000
    assert max(len(line) for line in script.splitlines())<2499
    db.close()
