"""Catalog checks use the real configuration validator; OCI publication is mocked."""
from copy import deepcopy
import csv
import io

from oci.exceptions import ServiceError
import pytest
import yaml

from conftest import MemoryOCI, ROOT
from mdpf_onboarding import builder, bulk_builder
from mdpf_onboarding.onboard import generate, load_config, sample_uri, validate_config


PROFILE = 'oci://mdpf-config@devns/profiles/shared_profile.yaml'
CATALOG = 'oci://mdpf-config@devns/catalogs/dmi.csv'


class SampleOCI(MemoryOCI):
    """HEAD reports object availability without reading sample bytes."""
    def __init__(self):
        super().__init__()
        self.heads = []

    def head_object(self, namespace, bucket, key):
        uri = f'oci://{bucket}@{namespace}/{key}'
        self.heads.append(uri)
        if uri not in self.objects:
            raise ServiceError(404, 'ObjectNotFound', {}, 'Object missing or inaccessible')


def row(index=1, **options):
    return dict(pipeline_code=f'DMI_DATA{index}', dataset_code=f'DATA{index}',
                source_system='DMI', input_sample_csv=f'data{index}/input.csv',
                output_sample_csv=f'data{index}/output.csv', **options)


def csv_bytes(records, fields=None):
    fields = fields or list(bulk_builder.REQUIRED) + [
        field for field in bulk_builder.OPTIONAL if any(field in record for record in records)]
    out = io.StringIO(newline='')
    writer = csv.DictWriter(out, fieldnames=fields)
    writer.writeheader()
    writer.writerows(records)
    return out.getvalue().encode('utf-8')


@pytest.fixture
def catalog_setup():
    profile = yaml.safe_load((ROOT / 'examples/shared_profile.yaml').read_text())
    client = SampleOCI()
    client.objects[PROFILE] = yaml.safe_dump(profile).encode()
    client.objects[CATALOG] = csv_bytes([row()])
    for index in range(1, 11):
        for name in ('input', 'output'):
            client.objects[f"{profile['samples_root']}/data{index}/{name}.csv"] = b''
    return profile, client


def test_ten_rows_create_ten_distinct_valid_input_yamls(catalog_setup):
    profile, client = catalog_setup
    client.objects[CATALOG] = csv_bytes([row(i) for i in range(1, 11)])
    actual_put = client.put_object
    def put(*args, **options):
        assert len(client.heads) == 20  # All checks precede the first publication.
        return actual_put(*args, **options)
    client.put_object = put
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert [r['status'] for r in results] == ['CREATED'] * 10
    assert [r['row'] for r in results] == list(range(1, 11))
    assert len({r['yaml_uri'] for r in results}) == 10
    assert client.gets == [PROFILE, CATALOG]
    for result in results:
        config = yaml.safe_load(client.objects[result['yaml_uri']])
        assert validate_config(config) == config
        assert config['environments'] == profile['environments']
        assert config['inputs'][0]['code'] == config['outputs'][0]['code']
        assert len(config['inputs']) == len(config['outputs']) == 1
        assert result['yaml_uri'].endswith('/1.0/input/config.yaml')
        assert set(result) == {'row', 'pipeline_code', 'status', 'yaml_uri', 'message'}
    assert all(options['if_none_match'] == '*' for _, options in client.puts)


def test_one_bad_row_does_not_block_other_nine(catalog_setup):
    _, client = catalog_setup
    records = [row(i) for i in range(1, 11)]
    records[3]['source_system'] = ''
    client.objects[CATALOG] = csv_bytes(records)
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert [r['status'] for r in results].count('CREATED') == 9
    assert results[3]['status'] == 'FAILED'
    assert 'source_system' in results[3]['message']
    assert len(client.puts) == 9


def test_preview_checks_existence_without_sample_reads_spark_or_uploads(catalog_setup, monkeypatch, capsys):
    _, client = catalog_setup
    import mdpf_onboarding.onboard as onboard
    monkeypatch.setattr(onboard, 'read_sample', lambda *a: pytest.fail('No samples during pre-onboarding'))
    monkeypatch.setattr(onboard.SparkSession, 'getActiveSession', lambda: pytest.fail('No Spark session lookup'))
    monkeypatch.setattr(onboard.SparkSession.Builder, 'getOrCreate', lambda *a: pytest.fail('No Spark startup'))
    results = bulk_builder.build_catalog(PROFILE, CATALOG, client=client)
    assert results[0]['status'] == 'VALIDATED'
    assert results[0]['yaml_uri'].endswith('/dmi_data1/1.0/input/config.yaml')
    assert client.gets == [PROFILE, CATALOG] and not client.puts
    assert client.heads == ['oci://mdpf-samples@devns/dmi/data1/input.csv',
                            'oci://mdpf-samples@devns/dmi/data1/output.csv']
    assert 'sample objects exist' in results[0]['message']
    assert 'VALIDATED=1' in capsys.readouterr().out


@pytest.mark.parametrize('options', [
    {}, dict(release_version='', file_name='', target_table=''),
    dict(release_version='2.5', file_name='delivered_{YYYYMMDD}.parquet', target_table='MAIN_DATA'),
])
def test_optional_defaults_and_explicit_strings(catalog_setup, options):
    _, client = catalog_setup
    client.objects[CATALOG] = csv_bytes([row(**options)])
    result = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)[0]
    config = yaml.safe_load(client.objects[result['yaml_uri']])
    assert config['pipeline']['release_version'] == (options.get('release_version') or '1.0')
    assert config['inputs'][0]['file_name'] == (options.get('file_name') or 'data1_{YYYYMMDD}.parquet')
    assert config['outputs'][0]['target_table'] == (options.get('target_table') or 'DATA1')
    assert config['inputs'][0]['sample_csv'] == 'oci://mdpf-samples@devns/dmi/data1/input.csv'
    assert config['inputs'][0]['landing_key_prefix'] == 'dmi/inbound/data1/ingest_date={YYYYMMDD}'
    assert config['storage']['raw_key_prefix'] == config['storage']['stage_key_prefix'] == 'dmi'
    assert 'batch_id={batch_id}' in config['storage']['raw_path_template']
    assert config['sql_output']['path'].endswith('/generated')


def test_bom_whitespace_and_quoted_cells(catalog_setup):
    _, client = catalog_setup
    record = row()
    record['source_system'] = '  DMI  '
    record['input_sample_csv'] = ' oci://samples@other/data/input.csv '
    client.objects['oci://samples@other/data/input.csv'] = b''
    data = csv_bytes([record]).decode().replace('pipeline_code,', ' pipeline_code ,', 1)
    client.objects[CATALOG] = ('\ufeff' + data).encode()
    result = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)[0]
    config = yaml.safe_load(client.objects[result['yaml_uri']])
    assert config['inputs'][0]['source_system'] == 'DMI'
    assert config['inputs'][0]['sample_csv'] == 'oci://samples@other/data/input.csv'


@pytest.mark.parametrize('data', [
    b'', b'pipeline_code,dataset_code\nP,D\n',
    b'pipeline_code,pipeline_code,source_system,input_sample_csv,output_sample_csv\n',
    csv_bytes([row()], fields=list(bulk_builder.REQUIRED) + ['custom_steps']),
    csv_bytes([row()]) + b'P,D,DMI,input.csv\n',
    csv_bytes([row()]) + b'P,D,DMI,input.csv,output.csv,extra\n',
    csv_bytes([row()]) + b'P,D,DMI,"unterminated\n',
    (','.join(bulk_builder.REQUIRED) + '\n').encode(),
    csv_bytes([row()]) + b'\xff',
])
def test_whole_catalog_parse_errors_stop_before_any_upload(catalog_setup, data):
    _, client = catalog_setup
    client.objects[CATALOG] = data
    with pytest.raises((ValueError, csv.Error, UnicodeDecodeError)):
        bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert not client.puts


@pytest.mark.parametrize('field,value', [
    ('pipeline_code', 'lowercase'), ('dataset_code', 'INVALID-NAME'),
    ('target_table', 'OWNER.TABLE'), ('release_version', '../2.0'),
    ('input_sample_csv', '../input.csv'), ('output_sample_csv', 'file:///tmp/output.csv'),
    ('file_name', 'input_*.csv'), ('source_system', ''),
])
def test_bad_row_settings_are_reported_independently(catalog_setup, field, value):
    _, client = catalog_setup
    bad = row()
    bad[field] = value
    client.objects[CATALOG] = csv_bytes([bad, row(2)])
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert [r['status'] for r in results] == ['FAILED', 'CREATED']
    assert len(client.puts) == 1


@pytest.mark.parametrize('conflict', ['pipeline', 'target', 'invalid_duplicate'])
def test_all_conflicting_rows_fail_before_uploads(catalog_setup, conflict):
    _, client = catalog_setup
    records = [row(), row(2), row(3)]
    if conflict in ('pipeline', 'invalid_duplicate'):
        records[1]['pipeline_code'] = records[0]['pipeline_code']
    else:
        records[1]['target_table'] = records[0]['dataset_code']
    if conflict == 'invalid_duplicate':
        records[1]['input_sample_csv'] = '../bad.csv'
    client.objects[CATALOG] = csv_bytes(records)
    actual_put = client.put_object
    def put(*args, **kwargs):
        assert args[2].endswith('/dmi_data3/1.0/input/config.yaml')
        return actual_put(*args, **kwargs)
    client.put_object = put
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert [r['status'] for r in results] == ['FAILED', 'FAILED', 'CREATED']
    assert all('Conflicting' in r['message'] for r in results[:2])
    assert len(client.puts) == 1


def test_duplicate_destinations_are_rejected_even_if_other_identities_differ(catalog_setup, monkeypatch):
    _, client = catalog_setup
    client.objects[CATALOG] = csv_bytes([row(), row(2)])
    monkeypatch.setattr(bulk_builder, 'config_uri', lambda *a: 'oci://out@ns/shared/config.yaml')
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert [r['status'] for r in results] == ['FAILED', 'FAILED']
    assert all('YAML destination' in r['message'] for r in results)
    assert not client.puts


@pytest.mark.parametrize('protected', ['profile', 'catalog', 'sample'])
def test_protected_paths_cannot_be_destinations(catalog_setup, monkeypatch, protected):
    _, client = catalog_setup
    uri = dict(profile=PROFILE, catalog=CATALOG,
               sample='oci://mdpf-samples@devns/dmi/data1/input.csv')[protected]
    monkeypatch.setattr(bulk_builder, 'config_uri', lambda *a: uri)
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert results[0]['status'] == 'FAILED' and 'collides' in results[0]['message']
    assert not client.puts


def test_existing_object_is_skipped_without_content_comparison(catalog_setup):
    _, client = catalog_setup
    first = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)[0]
    original = client.objects[first['yaml_uri']]
    record = row(file_name='different_{YYYYMMDD}.parquet')
    client.objects[CATALOG] = csv_bytes([record, row(2)])
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert [r['status'] for r in results] == ['SKIPPED', 'CREATED']
    assert client.objects[first['yaml_uri']] == original
    assert client.gets == [PROFILE, CATALOG, PROFILE, CATALOG]
    assert 'without comparing' in results[0]['message']


def test_oci_no_etag_match_from_conditional_create_is_skipped(catalog_setup):
    _, client = catalog_setup
    def put(*args, **options):
        assert options['if_none_match'] == '*'
        raise ServiceError(412, 'NoEtagMatch', {}, 'Conditional create failed')
    client.put_object = put
    result = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)[0]
    assert result['status'] == 'SKIPPED'


@pytest.mark.parametrize('error', [
    ServiceError(403, 'NotAuthorized', {}, 'Permission denied'),
    ServiceError(404, 'NotFound', {}, 'Bucket missing'),
    ServiceError(412, 'OtherFailure', {}, 'Not an object-exists response'),
    RuntimeError('Network failure'),
])
def test_only_object_exists_is_skipped_other_upload_errors_are_failures(catalog_setup, error):
    _, client = catalog_setup
    client.objects[CATALOG] = csv_bytes([row(), row(2)])
    actual_put = client.put_object
    def put(*args, **options):
        if '/dmi_data1/' in args[2]:
            raise error
        return actual_put(*args, **options)
    client.put_object = put
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert [r['status'] for r in results] == ['FAILED', 'CREATED']


@pytest.mark.parametrize('mutate', [
    lambda p: p.update(extra='unsupported'),
    lambda p: p.update(samples_root='/tmp/samples'),
    lambda p: p.update(artifacts_root='oci://out@ns/../bad'),
    lambda p: p['environments'].pop('PROD'),
    lambda p: p['storage'].update(raw_key_prefix=None),
    lambda p: p['environments']['DEV'].update(oracle_main_owner='bad-owner'),
])
def test_bad_shared_profile_is_a_global_error(catalog_setup, mutate):
    profile, client = catalog_setup
    mutate(profile)
    client.objects[PROFILE] = yaml.safe_dump(profile).encode()
    with pytest.raises(ValueError):
        bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
    assert client.gets == [PROFILE] and not client.puts


def test_profile_duplicate_keys_rejected(catalog_setup):
    _, client = catalog_setup
    client.objects[PROFILE] += b'landing_key_prefix: other\n'
    with pytest.raises(ValueError, match='unique'):
        bulk_builder.build_catalog(PROFILE, CATALOG, client=client)
    assert not client.puts


@pytest.mark.parametrize('value', ['false', 0, None])
def test_dry_run_must_be_boolean(catalog_setup, value):
    _, client = catalog_setup
    with pytest.raises(ValueError, match='boolean'):
        bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=value, client=client)
    assert not client.gets and not client.puts


def test_one_resource_principal_client_reused(catalog_setup, monkeypatch):
    _, client = catalog_setup
    calls = []
    monkeypatch.setattr(bulk_builder, 'object_client', lambda: calls.append(1) or client)
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False)
    assert results[0]['status'] == 'CREATED' and calls == [1]


def test_profile_not_mutated_and_single_pipeline_helpers_work(catalog_setup):
    _, client = catalog_setup
    profile = builder.load_profile(PROFILE, client=client)
    original = deepcopy(profile)
    config = builder.build_config(profile, **row())
    uri = builder.save_config(profile, config, client=client)
    assert profile == original
    assert builder.config_uri(profile, config) == uri
    assert load_config(uri, client=client) == config


def test_generated_input_runs_through_existing_sql_generator(catalog_setup, spark, tmp_path, monkeypatch):
    _, client = catalog_setup
    import mdpf_onboarding.onboard as onboard
    result = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)[0]
    config = load_config(result['yaml_uri'], client=client)
    config['sql_output']['generate_main_ddl'] = True
    config['dq_rules'] = [{'datasets': ['DMI_DATA1_DATA1_STAGE'],
                           'column': 'ID', 'check': 'NOT_NULL'}]
    client.objects[result['yaml_uri']] = yaml.safe_dump(config).encode()
    sample = tmp_path / 'sample.csv'
    sample.write_text('ID,AMOUNT\n1,10.50\n2,20.25\n')
    paths = {sample_uri(result['yaml_uri'], i['sample_csv'])
             for i in config['inputs'] + config['outputs']}
    original_read = onboard.read_sample
    def read(session, path):
        assert path in paths
        return original_read(session, str(sample))
    monkeypatch.setattr(onboard, 'read_sample', read)
    sql_uri = generate(result['yaml_uri'], spark=spark, client=client)
    assert 'POLICY_DEFINITION' in client.objects[sql_uri].decode()
    ddl_uri = onboard.main_ddl_uri(config)
    assert 'CREATE TABLE' in client.objects[ddl_uri].decode()
    complete = yaml.safe_load(client.objects[onboard.yaml_uri(config)])
    assert all('columns' in item for item in complete['inputs'] + complete['outputs'])
    assert set(complete['task_overrides']) == {'RAW', 'STAGE', 'MAIN'}


@pytest.mark.parametrize('dry_run', [True, False])
@pytest.mark.parametrize('sample', ['input', 'output'])
def test_missing_sample_fails_only_its_row(catalog_setup, dry_run, sample):
    profile, client = catalog_setup
    uri = f"{profile['samples_root']}/data1/{sample}.csv"
    del client.objects[uri]
    client.objects[CATALOG] = csv_bytes([row(), row(2)])
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=dry_run, client=client)
    assert [r['status'] for r in results] == ['FAILED', 'VALIDATED' if dry_run else 'CREATED']
    assert 'Sample existence check failed' in results[0]['message']
    assert uri in results[0]['message']
    assert uri in client.heads
    assert client.gets == [PROFILE, CATALOG]
    assert len(client.puts) == (0 if dry_run else 1)


@pytest.mark.parametrize('dry_run', [True, False])
@pytest.mark.parametrize('error', [
    ServiceError(403, 'NotAuthorized', {}, 'Permission denied'),
    ServiceError(404, 'NotAuthorizedOrNotFound', {}, 'Not found or not authorized'),
    ServiceError(412, 'PreconditionFailed', {}, 'HEAD failed, not a create collision'),
    RuntimeError('Network failure'),
])
def test_sample_head_errors_are_failures_not_skipped(catalog_setup, dry_run, error):
    profile, client = catalog_setup
    uri = f"{profile['samples_root']}/data1/output.csv"
    actual_head = client.head_object
    def head(namespace, bucket, key):
        if f'oci://{bucket}@{namespace}/{key}' == uri:
            raise error
        return actual_head(namespace, bucket, key)
    client.head_object = head
    client.objects[CATALOG] = csv_bytes([row(), row(2)])
    results = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=dry_run, client=client)
    assert [r['status'] for r in results] == ['FAILED', 'VALIDATED' if dry_run else 'CREATED']
    assert uri in results[0]['message'] and str(error) in results[0]['message']
    assert len(client.puts) == (0 if dry_run else 1)


def test_existence_check_does_not_validate_sample_contents(catalog_setup):
    profile, client = catalog_setup
    client.objects[f"{profile['samples_root']}/data1/input.csv"] = b'not,csv\xff'
    client.objects[f"{profile['samples_root']}/data1/output.csv"] = b''
    result = bulk_builder.build_catalog(PROFILE, CATALOG, dry_run=False, client=client)[0]
    assert result['status'] == 'CREATED'
    assert len(client.heads) == 2
    assert client.gets == [PROFILE, CATALOG]  # No sample GETs or decoding.


def test_failed_configuration_does_not_trigger_sample_head(catalog_setup):
    _, client = catalog_setup
    bad = row()
    bad['source_system'] = ''
    client.objects[CATALOG] = csv_bytes([bad])
    result = bulk_builder.build_catalog(PROFILE, CATALOG, client=client)[0]
    assert result['status'] == 'FAILED'
    assert not client.heads and not client.puts
