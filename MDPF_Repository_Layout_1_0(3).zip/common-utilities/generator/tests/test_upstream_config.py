"""Upstream metadata and new onboarding defaults; no IDMC/Oracle connection."""
from copy import deepcopy
import json

import pytest
import yaml

from conftest import ROOT, CatalogDb
from mdpf_runtime.db import require_main_database
from mdpf_runtime.pipeline import MetadataFramework
from mdpf_onboarding.builder import build_config
from mdpf_onboarding.config import validate_config
from mdpf_onboarding.metadata_generator import contract_model, schema_changes
from mdpf_onboarding.sql_renderer import render_sql, render_main_ddl
from test_bulk_builder import SampleOCI, PROFILE, CATALOG, csv_bytes, row
from mdpf_onboarding.bulk_builder import build_catalog


def config():
    return yaml.safe_load((ROOT/'examples/dmi_fee.yaml').read_text())


def upstream(kind='FILE'):
    return dict(type=kind, connection_reference='IDMC_DMI', directory='/dmi/fees',
                file_pattern='fee_{YYYYMMDD}.csv',
                original_oci_uri='oci://landing@ns/dmi/raw/fee/ingest_date={YYYYMMDD}/fee_{YYYYMMDD}.csv')


def test_defaults_and_exact_builder_paths():
    profile=yaml.safe_load((ROOT/'examples/shared_profile.yaml').read_text())
    c=build_config(profile,pipeline_code='DMI_FEE',dataset_code='FEE',source_system='DMI',
                   input_sample_csv='fee/input.csv',output_sample_csv='fee/output.csv',target_table='DMI_FEE')
    assert c['inputs'][0]['source_format']=='PARQUET'
    assert c['inputs'][0]['landing_key_prefix']=='dmi/inbound/fee/ingest_date={YYYYMMDD}'
    assert c['inputs'][0]['file_name']=='fee_{YYYYMMDD}.parquet'
    assert c['sql_output']['generate_main_ddl'] is True
    assert c['dq_rules']==[] and c['created_by']=='MDPF_ONBOARD'
    assert c['storage']['raw_path_template']=='dmi/{feed}/ingest_date={YYYYMMDD}/batch_id={batch_id}/{feed}_{YYYYMMDD}.parquet'
    assert c['storage']['stage_path_template']==c['storage']['raw_path_template']
    assert c['samples_root']=='oci://mdpf-samples@devns/dmi'
    assert c['outputs'][0]['target_table']=='DMI_FEE'
    assert profile['storage']['raw_key_prefix']=='{source}'  # No mutation.


@pytest.mark.parametrize('kind',['FILE','DATABASE','SNOWFLAKE','OTHER_SOURCE'])
def test_per_feed_json_roundtrip_and_no_runtime_source_kind_change(kind):
    c=config();value=upstream(kind)
    if kind!='FILE':
        value={k:v for k,v in value.items() if k in ('type','connection_reference')}
        value['object_name']='SCHEMA.FEES'
    c['inputs'][0]['upstream_config']=value
    model=contract_model(validate_config(c))
    assert model['tables']['SOURCE_CONFIG'][0]['source_type']=='FILE'
    rows=model['tables']['DATASET']
    populated=[r for r in rows if 'upstream_config' in r]
    assert len(populated)==1 and populated[0]['source_object_code']=='FEE'
    assert json.loads(populated[0]['upstream_config'])==value
    sql=render_sql(model,b'config')
    assert 'TO_CLOB(' in sql and 'SHA256' not in sql
    assert 'SHA256' not in render_main_ddl(model,b'config')
    db=CatalogDb()
    try:
        db.deploy(sql)
        result=db.one('SELECT upstream_config FROM METADATA.DATASET WHERE source_object_code=:code',code='FEE')
        assert json.loads(result['upstream_config'])==value
        assert db.one('SELECT COUNT(*) n FROM METADATA.DATASET WHERE upstream_config IS NOT NULL')['n']==1
        with pytest.raises(Exception):
            db.execute("UPDATE METADATA.DATASET SET upstream_config='invalid json' WHERE source_object_code='FEE'")
    finally:db.close()


@pytest.mark.parametrize('value',[None,{},[],{'type':'FILE'}, {'type':'FILE','connection_reference':''},
                                   {'type':'FILE','connection_reference':'IDMC','options':float('nan')}])
def test_invalid_upstream_metadata_fails_before_io(value):
    c=config();c['inputs'][0]['upstream_config']=value
    with pytest.raises(ValueError,match='upstream_config'):validate_config(c)


def test_optional_null_and_semantic_comparison():
    c=config();base=contract_model(validate_config(c))
    assert all('upstream_config' not in r for r in base['tables']['DATASET'])
    c['inputs'][0]['upstream_config']=upstream()
    first=contract_model(validate_config(c));second=deepcopy(first)
    row=next(r for r in second['tables']['DATASET'] if 'upstream_config' in r)
    row['upstream_config']=json.dumps(dict(reversed(list(upstream().items()))),indent=2)
    assert schema_changes(second,first)==['No release metadata changes.']
    assert schema_changes(first,base)!=['No release metadata changes.']
    row['upstream_config']=json.dumps({**upstream(),'directory':'/changed'})
    assert schema_changes(second,first)!=['No release metadata changes.']


def test_bulk_optional_json_and_independent_invalid_row():
    client=SampleOCI();p=yaml.safe_load((ROOT/'examples/shared_profile.yaml').read_text())
    client.objects[PROFILE]=yaml.safe_dump(p).encode()
    client.objects[CATALOG]=csv_bytes([row(1,upstream_config=json.dumps(upstream())),row(2,upstream_config='{bad')])
    for name in ('input','output'):client.objects[p['samples_root']+'/data1/'+name+'.csv']=b''
    results=build_catalog(PROFILE,CATALOG,client=client,dry_run=False)
    assert [r['status'] for r in results]==['CREATED','FAILED']
    result=yaml.safe_load(client.objects[results[0]['yaml_uri']])
    assert result['inputs'][0]['upstream_config']==upstream()


def test_missing_main_config_fails_before_raw_attempt_or_io(monkeypatch):
    import os
    for name in list(os.environ):
        if name.startswith('MDPF_MAIN_DB_'):monkeypatch.delenv(name)
    fw=MetadataFramework(object(),'P')
    with pytest.raises(ValueError,match='Separate ADW connection required'):fw.execute_task(1,'RAW')
    for name in ('USER','PASSWORD','DSN'):monkeypatch.setenv('MDPF_MAIN_DB_'+name,'value')
    require_main_database(fw.db)  # Does not open a connection.
    with pytest.raises(ValueError,match='same connection'):MetadataFramework(fw.db,'P',main_db=fw.db)


def test_multiple_feed_metadata_stays_on_each_own_input(models):
    from mdpf_onboarding.metadata_generator import build_metadata
    c=deepcopy(models['many_to_one']['config'])
    values=[]
    for index,item in enumerate(c['inputs']):
        value=dict(type='DATABASE' if index==0 else 'FILE',connection_reference='IDMC_'+item['code'],
                   object_name='SOURCE.'+item['code'])
        item['upstream_config']=value;values.append(value)
    # Reuse reviewed schemas; no baseline samples or upstream connections.
    profiles={code:(None,spec['columns']) for code,spec in models['many_to_one']['datasets'].items()
              if code.endswith(('_LANDING','_MAIN'))}
    model=build_metadata(validate_config(c),profiles,validate_samples=False)
    rows=[r for r in model['tables']['DATASET'] if 'upstream_config' in r]
    assert len(rows)==len(c['inputs'])==2
    assert [json.loads(r['upstream_config']) for r in rows]==values
