from copy import deepcopy
import importlib.util
import sqlite3

import pytest

from conftest import ROOT,CatalogDb,prepare_execution
from mdpf_onboarding.metadata_generator import render_sql


@pytest.mark.parametrize('name,count_datasets,count_tasks',[('one_to_one',4,3),('many_to_one',6,3),('one_to_many',6,3)])
def test_paired_schemas_ids_and_ddl(models,name,count_datasets,count_tasks):
    model=models[name]
    assert len(model['tables']['DATASET'])==count_datasets and len(model['tasks'])==count_tasks
    for code,spec in model['datasets'].items():
        if code.endswith('_LANDING'):
            assert spec['columns']==model['datasets'][code[:-8]+'_RAW']['columns']
            assert all(c['data_type']=='VARCHAR2' for c in spec['columns'])
        if code.endswith('_STAGE'):
            assert spec['columns']==model['datasets'][code[:-6]+'_MAIN']['columns']
    db=CatalogDb();db.deploy(render_sql(model,b'config'))
    assert db.one('SELECT COUNT(*) n FROM METADATA.CONFIG_RELEASE')['n']==1
    assert db.one('SELECT release_status FROM METADATA.CONFIG_RELEASE')['release_status']=='DRAFT'
    for table,rows in model['tables'].items():
        assert db.one(f'SELECT COUNT(*) n FROM METADATA.{table}')['n']==len(rows)
    db.close()


def handlers():
    spec=importlib.util.spec_from_file_location('example_handlers',ROOT/'examples/custom_handlers.py')
    module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    return {'JOIN_CLIENT':module.join_client,'ROUTE_MAIN':module.route_main}


@pytest.mark.parametrize('name',['one_to_one','many_to_one','one_to_many'])
def test_generated_plans_execute_with_actual_framework(models,spark,tmp_path,name):
    model=models[name];fw,db=prepare_execution(model,tmp_path,spark)
    batch=fw.start_batch('job-'+name,'2026-10-15','MANUAL')
    for task in model['tasks']:
        result=fw.execute_task(batch['batch_id'],task['row']['task_code'],custom_steps=handlers())
        assert result['status']=='COMPLETED'
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='COMPLETED'
    assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n']==0
    assert db.one('SELECT COUNT(*) n FROM RUNTIME.INGESTION_ITEM')['n']==len(model['config']['inputs'])
    for dataset in model['datasets'].values():
        if dataset['row']['storage_type']=='ADB_TABLE':
            table=dataset['row']['physical_object_name']['DEV']
            assert fw.main_db.one(f'SELECT COUNT(*) n FROM {table}')['n']==2
            assert fw.main_db.one(f'SELECT LOAN_ID FROM {table} ORDER BY ROW_NUMBER')['LOAN_ID'.lower()]=='000123'
    db.close()


def test_no_unnecessary_main_direct_map(models):
    for name in ['one_to_one','many_to_one','one_to_many']:
        assert 'DIRECT_MAP' not in models[name]['tasks'][-1]['steps']
        assert 'DIRECT_MAP' in next(t for t in models[name]['tasks'] if t['role']=='STAGE')['steps']


def test_failed_stage_repair_generated_metadata(models,spark,tmp_path):
    model=models['many_to_one'];fw,db=prepare_execution(model,tmp_path,spark)
    b=fw.start_batch('repair','2026-10-15','MANUAL')['batch_id']
    raw=[t for t in model['tasks'] if t['role']=='RAW']
    for t in raw:fw.execute_task(b,t['row']['task_code'])
    stage=next(t for t in model['tasks'] if t['role']=='STAGE')
    def fail(*a):raise RuntimeError('Injected notebook failure')
    with pytest.raises(RuntimeError):fw.execute_task(b,stage['row']['task_code'],custom_steps={'JOIN_CLIENT':fail})
    failed=db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE status='FAILED'")
    result=fw.execute_task(b,stage['row']['task_code'],custom_steps=handlers())
    fw.execute_task(b,model['tasks'][-1]['row']['task_code'])
    assert result['attempt_number']==2 and result['batch_id']==b
    assert db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id',id=failed['task_run_id'])==failed
    assert db.one('SELECT status FROM OPERATIONS.WORK_QUEUE')['status']=='OPEN'
    assert db.one('SELECT COUNT(*) n FROM RUNTIME.TASK_RUN WHERE task_id=1')['n']==1
    db.close()


@pytest.mark.parametrize('env',['DEV','STAGE','PROD'])
def test_identical_sql_selects_environment_safely(models,env):
    model=deepcopy(models['one_to_one'])
    model['tables']['CONFIG_RELEASE'][0]['pipeline_name']="Loan & O'Brien"
    db=CatalogDb();sql=render_sql(model,b'config')
    db.deploy(sql,env=env)
    assert db.one('SELECT pipeline_name FROM METADATA.CONFIG_RELEASE')['pipeline_name']=="Loan & O'Brien"
    row=db.one("SELECT physical_object_name FROM METADATA.DATASET WHERE storage_type='CSV'")
    assert env.lower()+'-landing@'+env.lower()+'ns' in row['physical_object_name']
    assert 'SET DEFINE OFF' in sql and '&1' not in sql and ':target_env' in sql
    db.close()


def test_duplicate_release_rolls_back(models):
    db=CatalogDb();sql=render_sql(models['one_to_one'],b'config');db.deploy(sql)
    before={t:db.one(f'SELECT COUNT(*) n FROM METADATA.{t}')['n'] for t in models['one_to_one']['tables']}
    with pytest.raises(sqlite3.IntegrityError):db.deploy(sql,release=901)
    assert before=={t:db.one(f'SELECT COUNT(*) n FROM METADATA.{t}')['n'] for t in before}
    db.close()


def test_json_and_long_literals_round_trip(models):
    model=deepcopy(models['many_to_one'])
    row=next(r for r in model['tables']['TASK_STEP'] if r['step_type']=='CUSTOM_PYTHON')
    row['parameter_json']='{"text": "'+("O'Brien & v_env 😀"*500)+'"}'
    sql=render_sql(model,b'config');db=CatalogDb();db.deploy(sql)
    actual=db.one("SELECT parameter_json FROM METADATA.TASK_STEP WHERE step_type='CUSTOM_PYTHON'")
    assert actual['parameter_json']==row['parameter_json']
    assert max(len(line) for line in sql.splitlines())<2499
    db.close()


def test_identical_string_contracts_execute_without_stage_mapping(models,spark,tmp_path):
    from mdpf_onboarding.metadata_generator import build_metadata
    model=deepcopy(models['one_to_one']);config=model['config'];profiles={}
    names=['LOAN_ID','CLIENT_ID','BALANCE','AS_OF_DATE','STATUS']
    df=spark.createDataFrame([('000123','C001','1250.75','2026-10-15','ACTIVE')],names)
    source=deepcopy(model['datasets']['DEMO_LOAN_LOAN_LANDING']['columns'])
    target=[dict(c,data_type='VARCHAR2',length_precision_scale='50 CHAR') for c in model['datasets']['DEMO_LOAN_LOAN_MAIN']['columns']]
    profiles['DEMO_LOAN_LOAN_LANDING']=(df,source);profiles['DEMO_LOAN_LOAN_MAIN']=(df,target)
    generated=build_metadata(config,profiles)
    assert 'DIRECT_MAP' not in next(t for t in generated['tasks'] if t['role']=='STAGE')['steps']
    fw,db=prepare_execution(generated,tmp_path,spark)
    batch=fw.start_batch('all-strings','2026-10-15','MANUAL')['batch_id']
    for task in generated['tasks']:fw.execute_task(batch,task['row']['task_code'])
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='COMPLETED'
    db.close()
