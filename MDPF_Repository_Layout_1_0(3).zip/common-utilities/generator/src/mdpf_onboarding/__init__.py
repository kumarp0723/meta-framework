"""OCI onboarding for MDPF 1.0 Spark tasks and Oracle metadata."""
__version__ = '1.0'
