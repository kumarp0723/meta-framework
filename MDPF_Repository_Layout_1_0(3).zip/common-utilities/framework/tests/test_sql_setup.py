"""Offline dependency/inventory checks; Oracle execution is tested separately."""
from pathlib import Path
import re
from mdpf_test_support import framework_ddl

ROOT=Path(__file__).resolve().parents[1]
SQL=ROOT/'sql'


def test_sql_inventory_and_fixture():
    assert {p.name for p in SQL.glob('*.sql')}=={
        '00_create_schemas.sql','01_framework.sql','02_grants.sql','03_inspect.sql','dev_reset.sql'}
    assert (SQL/'01_framework.sql').read_bytes()==framework_ddl().encode('utf-8')


def test_all_original_tables_constraints_indexes_and_trigger_names_are_preserved():
    s=(SQL/'01_framework.sql').read_text()
    assert len(re.findall(r'^CREATE TABLE ',s,re.M))==17
    bodies=re.findall(r'CREATE TABLE \w+\.\w+ \(\n(.*?)\n\);',s,re.S)
    assert sum(len(re.findall(r'^    \w+ (?:NUMBER|VARCHAR2|CHAR|CLOB|DATE|TIMESTAMP)\b',body,re.M)) for body in bodies)==234
    assert len(re.findall(r'FOREIGN KEY',s))==46
    assert len(re.findall(r'CONSTRAINT \w+ CHECK',s))==75
    assert len(re.findall(r'CONSTRAINT \w+ UNIQUE',s))==25
    assert len(re.findall(r'    create_immutability_trigger\(',s))==9
    for name in ('TRG_BATCH_TERMINAL','TRG_TASK_RUN_TERMINAL_IMM','TRG_CONFIG_RELEASE_LIFECYCLE'):
        assert 'CREATE OR REPLACE TRIGGER '+('METADATA.' if 'RELEASE' in name else 'RUNTIME.')+name in s


def test_cross_schema_references_granted_after_parent_and_before_child():
    s=(SQL/'01_framework.sql').read_text();seen=set();grants=set()
    for match in re.finditer(r'GRANT REFERENCES ON (\w+\.\w+) TO (\w+);|CREATE TABLE (\w+\.\w+) \(\n(.*?)\n\);',s,re.S):
        if match[1]:
            assert match[1] in seen
            grants.add((match[1],match[2]))
        else:
            owner=match[3].split('.')[0]
            for parent in re.findall(r'REFERENCES (\w+\.\w+)',match[4]):
                if parent!=match[3]:assert parent in seen
                if parent.split('.')[0]!=owner:assert (parent,owner) in grants
            seen.add(match[3])
    assert len(grants)==11


def test_sequences_and_runtime_permissions_match_framework_usage():
    ddl=(SQL/'01_framework.sql').read_text();grants=(SQL/'02_grants.sql').read_text()
    sequences=set(re.findall(r'CREATE SEQUENCE (\w+\.\w+)',ddl))
    assert len(sequences)==8 and 'METADATA.SEQ_CONFIG_RELEASE' in sequences
    for owner,table in [('RUNTIME','BATCH'),('RUNTIME','TASK_RUN'),('RUNTIME','INGESTION_ITEM'),('RUNTIME','POLICY_RESULT'),('OPERATIONS','EVENT_LOG'),('OPERATIONS','WORK_QUEUE')]:
        assert f'GRANT SELECT ON {owner}.SEQ_{table}_ID TO MDPF_RUNTIME;' in grants
    assert not re.search(r'GRANT .*\b(?:DBA|DWROLE|ANY|DELETE)\b',grants)
    assert 'GRANT SELECT ON METADATA.SEQ_CONFIG_RELEASE TO MDPF_RUNTIME' not in grants
    assert not re.search(r'GRANT [^;]*(?:INSERT|UPDATE|DELETE)[^;]*ON METADATA\.',grants)


def test_account_setup_and_reset_are_explicit_and_credential_safe():
    create=(SQL/'00_create_schemas.sql').read_text();reset=(SQL/'dev_reset.sql').read_text()
    assert 'MDPF accounts already exist; stop.' in create
    assert 'PASSWORD MDPF_RUNTIME' in create
    assert 'IDENTIFIED BY' not in create
    assert create.count('NO AUTHENTICATION')==4
    assert not re.search(r'GRANT CREATE SESSION TO (METADATA|RUNTIME|OPERATIONS);',create)
    assert 'ACCEPT reset_confirmation NUMBER DEFAULT 0' in reset
    assert reset.index('IF &&reset_confirmation <> 170234')<reset.index("'DROP USER '")
    assert reset.count("UNION ALL SELECT '")==3
    assert 'DROP USER' not in create and 'FORCE' not in reset
    assert not any('DROP ' in line and 'ADW' in line for line in reset.splitlines())


def test_existing_triggers_have_only_the_required_lifecycle_protections():
    s=(SQL/'01_framework.sql').read_text()
    assert 'BEFORE UPDATE OR DELETE ON RUNTIME.BATCH' in s
    assert s.count(':NEW.effective_from <> :OLD.effective_from')==2
    assert ":NEW.release_status <> 'RETIRED' AND :NEW.effective_to IS NOT NULL" in s
    assert ':NEW.effective_to IS NULL OR :NEW.effective_to < :OLD.effective_from' in s
