"""Shared MAIN launcher: built-in metadata steps only; one invocation runs one task."""
import argparse

from mdpf_runtime.dataflow import execute_task
from mdpf_runtime.schema import sql_identifier


def main(argv=None, *, spark=None):
    """Select pipeline/task and forward execution arguments to the existing adapter."""
    parser = argparse.ArgumentParser(
        description=__doc__, allow_abbrev=False,
        epilog="Remaining flags go to mdpf_runtime.dataflow: --execution-key (required), "
               "--cycle-date, --execution-mode, --run-id.")
    parser.add_argument("--pipeline-code", required=True)
    parser.add_argument("--task-code", help="Defaults to <pipeline-code>_MAIN_LOAD.")
    args, execution_args = parser.parse_known_args(argv)
    pipeline = sql_identifier(args.pipeline_code.strip())
    task = sql_identifier((args.task_code or f"{pipeline}_MAIN_LOAD").strip())
    return execute_task(pipeline_code=pipeline, task_code=task,
                        spark=spark, argv=execution_args)


if __name__ == "__main__":
    result = main(spark=globals().get("spark"))

