-- DESTRUCTIVE DEVELOPMENT RESET ONLY. SQLcl/SQL*Plus as ATP ADMIN.
-- Stops on errors. Stop MDPF workers, schedulers and metadata publishers first.
-- Deletes all objects/data in these three dedicated ATP schemas and the dedicated
-- application account. No ADW connection or business-table statements are present.
SET ECHO OFF
SET VERIFY OFF
SET DEFINE OFF
SET SERVEROUTPUT ON
WHENEVER OSERROR EXIT FAILURE ROLLBACK
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
BEGIN
    IF SYS_CONTEXT('USERENV','SESSION_USER') <> 'ADMIN' THEN
        RAISE_APPLICATION_ERROR(-20100, 'Connect as ATP ADMIN for this script.');
    END IF;
END;
/
SELECT SYS_CONTEXT('USERENV','DB_NAME') database_name,
       SYS_CONTEXT('USERENV','CON_NAME') container_name,
       SYS_CONTEXT('USERENV','SERVICE_NAME') service_name FROM DUAL;
SET DEFINE ON
ACCEPT reset_confirmation NUMBER DEFAULT 0 PROMPT 'Confirm the displayed ATP database. Enter 170234 to delete MDPF development data (0 cancels): '
-- ACCEPT NUMBER limits substitution to numeric input; schema names are fixed.
BEGIN
    IF &&reset_confirmation <> 170234 THEN
        RAISE_APPLICATION_ERROR(-20106, 'Reset cancelled; no accounts were dropped.');
    END IF;
END;
/
UNDEFINE reset_confirmation
SET DEFINE OFF
DECLARE
    present NUMBER;
BEGIN
    FOR account IN (SELECT 'MDPF_RUNTIME' username,1 position FROM DUAL
                    UNION ALL SELECT 'OPERATIONS',2 FROM DUAL
                    UNION ALL SELECT 'RUNTIME',3 FROM DUAL
                    UNION ALL SELECT 'METADATA',4 FROM DUAL ORDER BY position) LOOP
        SELECT COUNT(*) INTO present FROM ALL_USERS WHERE username=account.username;
        IF present=1 THEN
            EXECUTE IMMEDIATE 'DROP USER '||account.username||' CASCADE';
        END IF;
    END LOOP;
END;
/
PROMPT Development ATP reset complete. Reinstall with 00_create_schemas, 01_framework, 02_grants, then 03_inspect.
