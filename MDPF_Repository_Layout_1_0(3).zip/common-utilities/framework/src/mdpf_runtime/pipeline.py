"""Metadata-selected Spark task loop and Oracle execution lifecycle."""
from datetime import date, datetime, timezone
import json
from types import MappingProxyType
import uuid

from pyspark.sql import DataFrame, SparkSession

from .storage import ObjectStorage
from .dq import policy_result
from .metadata import _json_object
from . import metadata, runtime
from .db import OracleDb, require_main_database


class MainReconciliationError(ValueError):
    """Carry policy evidence out of the rolled-back MAIN transaction."""

    def __init__(self, message, results):
        super().__init__(message)
        self.results = results


class MetadataFramework:
    def __init__(self, db, pipeline_code, spark=None, *, main_db=None):
        if not isinstance(pipeline_code, str) or not pipeline_code.strip() or "{{" in pipeline_code:
            raise ValueError("Explicit pipeline_code is required.")
        self.db = db
        if main_db is not None:
            require_main_database(db, main_db)
        self.main_db = main_db
        self.pipeline_code = pipeline_code.strip()
        self.spark = spark
        self.storage = ObjectStorage()

    def start_batch(self, execution_key, cycle_date=None, execution_mode=None, *,
                    orchestrator_run_id=None, triggered_by='SCHEDULER'):
        """Create or resolve a RUNNING batch under a stable workflow key.

        New batches pin the ACTIVE release and require an explicit ISO cycle date.
        Conflicting overrides and terminal batches raise ValueError. This facade
        owns the batch/event transaction; callers must not nest it in a transaction.
        Returns the persisted batch row, including its generated batch_id."""
        if not isinstance(execution_key,str) or not execution_key.strip() or '{{' in execution_key or len(execution_key.encode('utf-8'))>300:
            raise ValueError('A resolved stable workflow execution_key is required (maximum 300 UTF-8 bytes).')
        execution_key=execution_key.strip()
        if execution_mode is not None and execution_mode not in ("SCHEDULED", "MANUAL"):
            raise ValueError("Only SCHEDULED and MANUAL execution modes are supported.")
        mode = execution_mode or "SCHEDULED"
        with self.db.transaction():
            existing = runtime.batch_by_execution_key(self.db, self.pipeline_code, execution_key)
            if existing:
                if execution_mode is not None and existing["batch_type"] != mode:
                    raise ValueError("Execution mode conflicts with the existing batch.")
                if cycle_date and str(existing["cycle_date"])[:10] != cycle_date:
                    raise ValueError("Execution key already belongs to another cycle date.")
                if orchestrator_run_id and existing["orchestrator_run_id"] != orchestrator_run_id:
                    raise ValueError("Execution key already belongs to another scheduler job.")
                if existing["status"] != "RUNNING":
                    raise ValueError("Terminal batches cannot restart; use a new execution key.")
                return existing
            release = metadata.active_release(self.db, self.pipeline_code)
            if release is None:
                raise ValueError("Pipeline requires an ACTIVE metadata release.")
            if not cycle_date or date.fromisoformat(cycle_date).isoformat() != cycle_date:
                raise ValueError("A new batch requires cycle_date in YYYY-MM-DD format.")
            batch_id = runtime.insert_batch(self.db, dict(
                config_release_id=release["config_release_id"], pipeline_code=self.pipeline_code,
                batch_type=mode,
                cycle_date=date.fromisoformat(cycle_date),
                execution_key=execution_key, correlation_id=str(uuid.uuid4()),
                orchestrator_run_id=orchestrator_run_id, status="RUNNING", triggered_by=triggered_by))
            batch = self._batch(batch_id)
            self._event(batch, None, "BATCH_STARTED", "Started pipeline " + self.pipeline_code)
            return batch

    def get_batch_by_job_run_id(self, job_run_id):
        rows = runtime.batches_by_job_run_id(self.db, self.pipeline_code, job_run_id)
        if len(rows) > 1:
            raise ValueError("Ambiguous scheduler job-to-batch correlation.")
        return rows[0] if rows else None

    def get_batch_by_execution_key(self, execution_key):
        return runtime.batch_by_execution_key(self.db, self.pipeline_code, execution_key)

    def _batch(self, batch_id):
        batch = runtime.locked_batch(self.db, batch_id)
        if not batch or batch["pipeline_code"] != self.pipeline_code:
            raise ValueError("Batch does not belong to the requested pipeline.")
        return batch

    def _task(self, batch, task_code):
        return metadata.task(self, batch, task_code)

    def _latest(self, batch_id, task_id):
        return runtime.latest_attempt(self.db, batch_id, task_id)

    def _datasets(self, batch, task, role):
        return metadata.datasets(self, batch, task, role)

    def _columns(self, release_id, dataset_id):
        return metadata.columns(self, release_id, dataset_id)

    def _producer(self, release_id, dataset_id):
        return metadata.producer(self, release_id, dataset_id)

    def _is_main_task(self, batch, task):
        return any(d['storage_type']=='ADB_TABLE' for d in self._datasets(batch,task,'OUTPUT'))

    def output_path(self, batch, dataset):
        return metadata.output_path(self, batch, dataset)

    def execute_task(self, batch_id, task_code, custom_steps=None,
                     orchestrator_task_run_id=None, orchestrator_attempt_number=None,
                     main_retry_reviewed_run_id=None):
        """Execute one configured task attempt and return its persisted TASK_RUN row.

        Resolve the pinned plan/contracts before data I/O, then call each handler.
        Custom handlers receive a read-only public context and must return a nonempty
        dict of dataset code to Spark DataFrame. A retry creates a new attempt in
        the same RUNNING batch. Exceptions record guarded failure evidence and
        propagate; completed tasks and active writers cannot be restarted here."""
        if orchestrator_attempt_number is not None and (
                not orchestrator_task_run_id or orchestrator_attempt_number < 1):
            raise ValueError("External execution count requires its task-run ID and must be positive.")
        if main_retry_reviewed_run_id is not None and (
                isinstance(main_retry_reviewed_run_id,bool) or not isinstance(main_retry_reviewed_run_id,int) or main_retry_reviewed_run_id<=0):
            raise ValueError('main_retry_reviewed_run_id must identify one positive exact failed task run.')
        require_main_database(self.db, self.main_db)
        with self.db.transaction():
            batch = self._batch(batch_id)
            task = self._task(batch, task_code)
            latest = self._latest(batch_id, task["task_id"])
            if latest and latest["status"] == "COMPLETED":
                raise ValueError("Task already COMPLETED; restart only failed/downstream scheduler tasks.")
            if batch["status"] != "RUNNING":
                raise ValueError("New attempts require a RUNNING batch.")
            if latest and latest["status"] == "RUNNING":
                raise ValueError("Attempt still RUNNING; stop its writer and fail that exact attempt before restarting.")
            separate_main = self._is_main_task(batch,task)
            review_required = latest and latest['status']=='FAILED' and (
                separate_main or latest.get('error_code')=='MAIN_RECOVERY_REQUIRED')
            if review_required and main_retry_reviewed_run_id != latest['task_run_id']:
                raise ValueError('MAIN recovery review required for failed task run '+str(latest['task_run_id'])+
                    '; confirm writer stopped and resolve ADW rows before supplying main_retry_reviewed_run_id.')
            if main_retry_reviewed_run_id is not None and (not review_required or main_retry_reviewed_run_id!=latest['task_run_id']):
                raise ValueError('Review acknowledgement must match the latest failed separate-database MAIN attempt.')
            run_id = runtime.insert_task_attempt(self.db, dict(batch_id=batch_id,
                config_release_id=batch["config_release_id"], task_id=task["task_id"],
                attempt_number=int(latest["attempt_number"])+1 if latest else 1,
                original_task_run_id=latest["task_run_id"] if latest else None, status="RUNNING",
                orchestrator_task_run_id=orchestrator_task_run_id,
                orchestrator_attempt_number=orchestrator_attempt_number))
            self._event(batch, run_id, "TASK_STARTED", task_code)
            if review_required:
                self._event(batch,run_id,'MAIN_RETRY_REVIEWED','Operator acknowledged ADW recovery review',
                            details={'previous_task_run_id':main_retry_reviewed_run_id})
        ctx = dict(batch=batch, task=task, run_id=run_id, state={}, input_count=0, output_count=0,
                   step_code=None, framework=self)
        owned_main = None
        try:
            plan = self._resolve_plan(ctx, {} if custom_steps is None else custom_steps)
            self._prepare_dataflow(ctx, plan)
            if separate_main:
                owned_main = OracleDb(prefix='MDPF_MAIN_DB') if self.main_db is None else None
                ctx['main_db'] = self.main_db if self.main_db is not None else owned_main
            public_context = MappingProxyType(dict(batch_id=batch_id, task_run_id=run_id,
                pipeline_code=self.pipeline_code, task_code=task_code,
                config_release_id=batch["config_release_id"], cycle_date=batch["cycle_date"],
                input_locations=MappingProxyType({k: v["location"] for k, v in ctx["inputs"].items()}),
                output_locations=MappingProxyType({k: v["location"] for k, v in ctx["outputs"].items()})))
            print(json.dumps(dict(event="TASK_PLAN", **public_context,
                steps=[dict(sequence=s["step_sequence_number"], code=s["step_code"], type=s["step_type"])
                       for s, _, _ in plan]), default=lambda v: dict(v) if isinstance(v, MappingProxyType) else str(v)), flush=True)
            if self.spark is None:
                self.spark = SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()
            frames = None
            for step, handler, params in plan:
                ctx["step_code"] = step["step_code"]
                print(f"STEP_STARTED run={run_id} step={ctx['step_code']}", flush=True)
                frames = handler(frames, public_context if step["step_type"] == "CUSTOM_PYTHON" else ctx, params)
                if (not isinstance(frames, dict) or not frames or
                        any(not isinstance(k, str) or not k or not isinstance(v, DataFrame)
                            for k, v in frames.items())):
                    raise TypeError(f"Step {ctx['step_code']} must return a nonempty dict[dataset_code, Spark DataFrame].")
            self._complete(ctx)
            return runtime.task_run(self.db, run_id)
        except Exception as exc:
            print(f"TASK_FAILED run={run_id} step={ctx['step_code']} error={type(exc).__name__}: {exc}", flush=True)
            if isinstance(exc, MainReconciliationError) and exc.results:
                self._record_policy_results(ctx, exc.results, failure_message=str(exc))
            else:
                self.fail_task_run(run_id, type(exc).__name__, str(exc), ctx["step_code"])
            raise
        finally:
            if owned_main is not None:
                owned_main.close()

    def _resolve_plan(self, ctx, custom_steps):
        return metadata.resolve_plan(self, ctx, custom_steps)

    def source_path(self, batch, config, dataset, input_count):
        return metadata.source_path(self, batch, config, dataset, input_count)

    def _prepare_dataflow(self, ctx, plan):
        return metadata.prepare_dataflow(self, ctx, plan)

    def _receive_source(self, ctx, spec, key):
        """Commit one RECEIVED source receipt before the CSV reader opens the object.

        Return (new_item_id, earliest_previous_receipt). The caller compares the
        prior URI/key after this transaction; identity conflicts fail the attempt.
        This facade owns the transaction; runtime helpers only execute its SQL."""
        batch, task, path = ctx['batch'], ctx['task'], spec['location']
        with self.db.transaction():
            previous = runtime.previous_source_receipt(self.db,
                batch['batch_id'], task['task_id'], spec['dataset']['dataset_id'])
            item_id = runtime.insert_source_receipt(self.db, dict(
                task_run_id=ctx['run_id'], config_release_id=batch['config_release_id'],
                source_config_id=task['source_config_id'], dataset_id=spec['dataset']['dataset_id'],
                item_role='DATA', ingestion_type='FILE', item_name=path.rsplit('/', 1)[-1], source_item_key=key,
                source_location=path, landing_location=path, status='RECEIVED'))
        return item_id, previous

    def _quarantine_source(self, ctx, spec, error):
        """Confirm a whole-file OCI copy, then audit quarantine for this exact attempt.

        The original object remains in landing. Copy errors propagate without a
        QUARANTINED claim. After copy confirmation, lock/check the RUNNING batch
        and attempt before committing the receipt location and event together."""
        destination = spec['quarantine_location']
        try:
            self.storage.quarantine_file(spec['location'], destination)
        except Exception as exc:
            raise RuntimeError(f'Source validation failed: {error}; quarantine copy failed: {exc}') from exc
        with self.db.transaction():
            batch = self._batch(ctx['batch']['batch_id'])
            run = runtime.locked_task_status(self.db, ctx['run_id'])
            if batch['status'] != 'RUNNING' or not run or run['status'] != 'RUNNING':
                raise ValueError('Quarantine audit requires the exact attempt and batch to remain RUNNING.')
            runtime.mark_source_quarantined(self.db, spec['ingestion_item_id'], ctx['run_id'], destination)
            self._event(ctx['batch'], ctx['run_id'], 'SOURCE_QUARANTINED', str(error),
                details=dict(ingestion_item_id=spec['ingestion_item_id'], source=spec['location'],
                             quarantine_location=destination), error_code='SOURCE_VALIDATION_FAILED')

    def _insert_policy_results(self, results):
        runtime.insert_policy_results(self.db, results)

    def _record_policy_results(self, ctx, results, failure_message=None):
        """Commit evaluated policy evidence and any blocking attempt failure together.

        Results use the dq.policy_result() format. Lock the exact RUNNING attempt
        and batch; FAIL facts also persist its failure/work item. Ordinary blocking
        DQ raises after commit. MAIN rollback evidence arrives separately through
        failure_message; none of this commits MAIN business rows."""
        failed = [r for r in results if r['result_status'] == 'FAIL']
        with self.db.transaction():
            batch = self._batch(ctx['batch']['batch_id'])
            run = runtime.task_run(self.db, ctx['run_id'], lock=True)
            if batch['status'] != 'RUNNING' or not run or run['status'] != 'RUNNING':
                raise ValueError('Policy recording requires the exact attempt and batch to remain RUNNING.')
            self._insert_policy_results(results)
            if failed or failure_message:
                self._fail_in_tx(run, batch, 'POLICY_FAILED',
                    failure_message or 'Blocking policy failed: ' + ', '.join(str(r['policy_id']) for r in failed),
                    ctx['step_code'])
        if failed and not failure_message:
            raise ValueError('Blocking policy failed: ' + ', '.join(str(r['policy_id']) for r in failed))

    def _insert_outputs(self, ctx, target_db):
        """Insert/reconcile all MAIN targets inside the caller's target transaction."""
        batch, run_id = ctx['batch'], ctx['run_id']
        loaded, reconciliations = 0, []
        stamp = datetime.now(timezone.utc)
        for code, output in ctx['state']['outputs'].items():
            spec = ctx['outputs'][code]
            count = output['count']
            if 'rows' in output:
                records = [dict(row, BATCH_ID=batch['batch_id'], TASK_RUN_ID=run_id, ROW_NUMBER=seq,
                                CREATED_AT=stamp, UPDATED_AT=stamp)
                           for seq, row in enumerate(output['rows'], 1)]
                types = {c['column_name']: c['data_type'] for c in spec['columns']}
                types.update(BATCH_ID='NUMBER', TASK_RUN_ID='NUMBER', ROW_NUMBER='NUMBER',
                             CREATED_AT='TIMESTAMP WITH TIME ZONE', UPDATED_AT='TIMESTAMP WITH TIME ZONE')
                actual = target_db.insert_many(spec['location'], list(types), records, types)
                confirmed = isinstance(actual, int) and not isinstance(actual, bool) and actual >= 0
                for policy in spec['policies']:
                    if policy['parameters']['check'] == 'ROW_COUNT':
                        expected = ctx['inputs'][policy['parameters']['source_dataset']]['count']
                        reconciliations.append(policy_result(ctx, policy,
                            abs(expected - actual) if confirmed else None,
                            expected, actual if confirmed else 'UNCONFIRMED'))
                if not confirmed or actual != count or any(r['result_status'] == 'FAIL' for r in reconciliations):
                    raise MainReconciliationError(
                        f'MAIN insert reconciliation failed for {code}: prepared={count}, actual={actual}.',
                        [r for r in reconciliations if r['result_status'] == 'FAIL'])
                count = actual
            loaded += count
        return loaded, reconciliations

    def _complete(self, ctx):
        """Complete ATP control records after reconciled business output writes.

        All MAIN inserts/reconciliation commit in ADW before ATP success facts.
        The two commits are independent; failures require controlled MAIN recovery.
        A pre-commit mismatch rolls back all ADW targets. Parquet remains external.
        """
        batch, task, run_id = ctx['batch'], ctx['task'], ctx['run_id']
        if set(ctx['state'].get('outputs', {})) != set(ctx['outputs']):
            raise ValueError('Task did not prepare all required outputs.')
        with self.db.transaction():
            current_batch = self._batch(batch['batch_id'])
            run = runtime.locked_task_status(self.db, run_id)
            if current_batch['status'] != 'RUNNING' or run['status'] != 'RUNNING':
                raise ValueError('Completion requires a RUNNING batch and exact attempt.')
            target_db = ctx.get('main_db')
            if target_db is None:
                if any('rows' in output for output in ctx['state']['outputs'].values()):
                    raise ValueError('MAIN requires a separate ADW target connection.')
                loaded, reconciliations = self._insert_outputs(ctx,None)
            else:
                # ADW commits first. A later ATP failure requires manual recovery;
                # closing/rolling back ATP cannot undo this committed ADW load.
                with target_db.transaction():
                    loaded, reconciliations = self._insert_outputs(ctx,target_db)
            for code, output in ctx['state']['outputs'].items():
                self._event(batch,run_id,'MAIN_TABLE_LOADED' if 'rows' in output else 'PARQUET_WRITTEN',
                    'Output written',details={'dataset_code':code,'path':ctx['outputs'][code]['location'],'rows':output['count']})
            self._insert_policy_results(reconciliations)
            for spec in ctx['inputs'].values():
                if 'ingestion_item_id' in spec:
                    runtime.mark_source_processed(self.db, spec['ingestion_item_id'], spec['count'])
            runtime.mark_task_completed(self.db, run_id, ctx['input_count'], loaded)
            self._event(batch, run_id, 'TASK_COMPLETED', task['task_code'])
            if task['close_batch_on_success'] == 'Y':
                runtime.mark_batch_completed(self.db, batch['batch_id'])
                self._event(batch, run_id, 'BATCH_COMPLETED', 'Terminal task completed')

    def fail_task_run(self, run_id, code, message, failed_step=None):
        """Fail the exact active attempt and commit its error/work-item evidence.

        The caller must first ensure its external writer has stopped. Duplicate
        or delayed callbacks for terminal attempts are no-ops. The batch remains
        RUNNING so the scheduler can retry or explicitly finalize it."""
        with self.db.transaction():
            run = runtime.task_run(self.db, run_id)
            if not run:
                raise ValueError("Unknown exact task run ID.")
            batch = self._batch(run["batch_id"])
            run = runtime.task_run(self.db, run_id, lock=True)
            if run["status"] != "RUNNING":
                return  # Delayed/duplicate callbacks never change terminal attempts.
            if batch["status"] != "RUNNING":
                raise ValueError("Cannot fail an attempt in a terminal batch.")
            self._fail_in_tx(run, batch, code, message, failed_step)

    def _fail_in_tx(self, run, batch, code, message, failed_step):
        """Persist attempt failure, unprocessed receipt failures and one work item.

        The caller already holds lifecycle locks and owns the transaction. Preserve
        PROCESSED/QUARANTINED receipts; emit TASK_FAILED without committing here."""
        run_id = run["task_run_id"]
        if self._is_main_task(batch,{'task_id':run['task_id']}):
            code = 'MAIN_RECOVERY_REQUIRED'
        runtime.mark_task_failed(self.db, run_id, code, message, failed_step)
        runtime.mark_unprocessed_sources_failed(self.db, run_id)
        runtime.insert_failure_work_item(self.db, run, code, message)
        self._event(batch, run_id, "TASK_FAILED", message, error_code=code)

    def fail_batch(self, batch_id):
        """Finalize an abandoned RUNNING batch after all attempts have stopped.

        This owns its transaction and refuses RUNNING attempts or a completed
        batch. It is a scheduler/operator failure finalizer, not a waiting-phase
        transition. An already FAILED batch is unchanged."""
        with self.db.transaction():
            batch = self._batch(batch_id)
            if batch["status"] == "FAILED":
                return
            if batch["status"] != "RUNNING":
                raise ValueError("Terminal batch cannot change status.")
            if runtime.running_attempt(self.db, batch_id):
                raise ValueError("Stop writers and terminalize exact active attempts first.")
            runtime.mark_batch_failed(self.db, batch_id)
            self._event(batch, None, "BATCH_FAILED", "Scheduler declared retries exhausted", error_code="RETRIES_EXHAUSTED")

    def _event(self, batch, run_id, code, message, details=None, error_code=None):
        runtime.insert_event(self.db, batch, run_id, code, message, details, error_code)
