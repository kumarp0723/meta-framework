"""Local test adapters only; not an Oracle/OCI runtime implementation.

SQLite does not execute Oracle triggers, locks, grants or distributed commits.
"""
from contextlib import contextmanager
from datetime import date, datetime
from decimal import Decimal
from importlib.resources import files
import re
import sqlite3
from types import SimpleNamespace

from mdpf_runtime.storage import object_address


def framework_ddl():
    """Return the versioned Oracle fixture shipped in this test-support wheel."""
    return files('mdpf_test_support').joinpath('framework_1_0.sql').read_text(encoding='utf-8')


class MemoryOCI:
    """CI-only SDK double. Samples still execute through actual Spark CSV reads."""
    def __init__(self):
        self.objects={};self.gets=[];self.puts=[]
    def get_object(self,namespace,bucket,key):
        uri=f'oci://{bucket}@{namespace}/{key}';self.gets.append(uri)
        return SimpleNamespace(data=SimpleNamespace(content=self.objects[uri]))
    def put_object(self,namespace,bucket,key,body,**options):
        from oci.exceptions import ServiceError
        uri=f'oci://{bucket}@{namespace}/{key}';self.puts.append((uri,options))
        if options.get('if_none_match')=='*' and uri in self.objects:
            raise ServiceError(412,'PreconditionFailed',{},'Object already exists')
        self.objects[uri]=body
        return SimpleNamespace(status=200)


class CatalogDb:
    """Actual generated SQL executed in SQLite, not a claim of Oracle PL/SQL validation."""
    def __init__(self):
        self.conn=sqlite3.connect(':memory:',isolation_level=None);self.conn.row_factory=sqlite3.Row
        self.conn.execute('PRAGMA foreign_keys=ON');self.ids={}
        self.conn.execute('CREATE TABLE DUAL (DUMMY TEXT)')
        self.conn.execute("INSERT INTO DUAL VALUES ('X')")
        for schema in ['METADATA','RUNTIME','OPERATIONS','DMI_MAIN_DEV','DMI_MAIN_STAGE','DMI_MAIN_PROD']:
            self.conn.execute(f"ATTACH DATABASE ':memory:' AS {schema}")
        self.conn.create_function('TO_CLOB',1,lambda s:s)
        ddl=framework_ddl()
        for table,body in re.findall(r'CREATE TABLE (\w+\.\w+) \(\n(.*?)\n\);',ddl,re.S):
            if table.startswith('METADATA.'):
                translated=re.sub(r'NUMBER\([^)]*\)','NUMERIC',body)
                translated=re.sub(r'TIMESTAMP\(6\) WITH TIME ZONE','TEXT',translated)
                translated=translated.replace('SYSTIMESTAMP','CURRENT_TIMESTAMP').replace('REFERENCES METADATA.','REFERENCES ')
                translated=re.sub(r'(\w+) IS JSON', r'(\1 IS NULL OR json_valid(\1))', translated)
                self.conn.execute(f'CREATE TABLE {table} ({translated})')
            else:
                columns=[]
                for line in body.splitlines():
                    match=re.match(r'    (\w+) (NUMBER|VARCHAR2|CHAR|CLOB|DATE|TIMESTAMP)\b',line)
                    if match:columns.append(match[1]+(' NUMERIC' if match[2]=='NUMBER' else ' TEXT'))
                self.conn.execute(f"CREATE TABLE {table} ({','.join(columns)})")
        self.conn.execute("CREATE UNIQUE INDEX METADATA.ONE_ACTIVE ON CONFIG_RELEASE (CASE WHEN release_status='ACTIVE' THEN pipeline_code END)")
        self.conn.execute("CREATE UNIQUE INDEX METADATA.ONE_CLOSER ON TASK (CASE WHEN close_batch_on_success='Y' THEN config_release_id END)")

    def deploy(self,sql,env='DEV',release=900):
        statements=[];current=[]
        for line in sql.splitlines():
            if line.startswith('  INSERT INTO'):current=[line]
            elif current:current.append(line)
            if current and sqlite3.complete_statement('\n'.join(current)):
                statements.append('\n'.join(current));current=[]
        assert statements
        def translate(m):
            token=m[0]
            return token if token.startswith("'") else {'v_release_id':':release','v_env':':env','SYSTIMESTAMP':'CURRENT_TIMESTAMP'}[token]
        with self.transaction():
            for statement in statements:
                statement=re.sub(r"'(?:''|[^'])*'|\bv_release_id\b|\bv_env\b|\bSYSTIMESTAMP\b",translate,statement)
                self.conn.execute(statement,dict(release=release,env=env))

    @staticmethod
    def value(v):return str(v) if isinstance(v,(date,datetime,Decimal)) else v
    def execute(self,sql,**params):
        sql=sql.replace(' FOR UPDATE','').replace('SYSTIMESTAMP','CURRENT_TIMESTAMP')
        cur=self.conn.execute(sql,{k:self.value(v) for k,v in params.items()})
        return [{k.lower():v for k,v in dict(r).items()} for r in cur.fetchall()] if cur.description else []
    def one(self,sql,**params):
        rows=self.execute(sql,**params);return rows[0] if rows else None
    def insert(self,table,values):
        self.execute(f"INSERT INTO {table} ({','.join(values)}) VALUES ({','.join(':'+k for k in values)})",**values)
    def insert_many(self,table,columns,records,types):
        for row in records:self.insert(table,row)
        return len(records)
    def next_id(self,table,column):
        self.ids[table]=self.ids.get(table,0)+1;return self.ids[table]
    @contextmanager
    def transaction(self):
        self.conn.execute('BEGIN')
        try:yield;self.conn.commit()
        except BaseException:self.conn.rollback();raise
    def close(self):
        if getattr(self, 'test_warehouse', None) is not None:self.test_warehouse.close()
        self.conn.close()


class SparkTestStorage:
    def __init__(self,root):self.root=root
    def path(self,uri):
        ns,bucket,key=object_address(uri);return self.root/ns/bucket/key
    def read_csv(self,spark,path):
        return spark.read.options(header=True,inferSchema=False,mode='FAILFAST',multiLine=True,escape='"').csv(str(self.path(path)))
    def read_parquet(self,spark,path):return spark.read.parquet(str(self.path(path)))
    def write_parquet(self,path,df):df.write.mode('overwrite').parquet(str(self.path(path)))


class WarehouseDb(CatalogDb):
    """CI-only independent business database; no metadata/runtime schemas."""
    def __init__(self, model):
        self.conn=sqlite3.connect(':memory:',isolation_level=None)
        self.conn.row_factory=sqlite3.Row
        for owner in sorted({d['row']['physical_object_name']['DEV'].split('.')[0]
                             for d in model['datasets'].values() if d['row']['storage_type']=='ADB_TABLE'}):
            self.conn.execute(f"ATTACH DATABASE ':memory:' AS {owner}")
        for spec in model['datasets'].values():
            row=spec['row']
            if row['storage_type']=='ADB_TABLE':
                columns=[c['column_name']+' TEXT' for c in spec['columns']]
                self.conn.execute(f"CREATE TABLE {row['physical_object_name']['DEV']} ({','.join(columns)}, BATCH_ID INTEGER,TASK_RUN_ID INTEGER,ROW_NUMBER INTEGER,CREATED_AT TEXT,UPDATED_AT TEXT)")
