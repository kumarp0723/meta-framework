"""Framework release packaging: complete assets, immutable output and stale wheels."""
import hashlib
import json
from pathlib import Path
import runpy
import shutil
import zipfile

import pytest


ROOT = Path(__file__).resolve().parents[1]


@pytest.fixture
def builder(tmp_path):
    root = tmp_path / 'framework'
    for folder in ('src', 'entrypoints', 'dist'):
        shutil.copytree(ROOT / folder, root / folder, ignore=shutil.ignore_patterns('__pycache__', '*.zip'))
    build = runpy.run_path(str(ROOT / 'scripts/package_release.py'))['build_release']
    build.__globals__['ROOT'] = root
    return build, root


def test_framework_release_manifest_and_immutable_output(builder, tmp_path):
    build, root = builder
    path = build(tmp_path / 'framework.zip')
    with zipfile.ZipFile(path) as archive:
        assert archive.testzip() is None and len(archive.namelist()) == 8
        manifest = json.loads(archive.read('release-manifest.json'))
        assert manifest['distribution'] == 'mdpf' and manifest['version']
        assert len(manifest['artifacts']) == 7
        for row in manifest['artifacts']:
            assert hashlib.sha256(archive.read(row['path'])).hexdigest() == row['sha256']
    original = path.read_bytes()
    with pytest.raises(FileExistsError):
        build(path)
    assert path.read_bytes() == original


def test_framework_release_rejects_stale_wheel(builder, tmp_path):
    build, root = builder
    source = next((root / 'src/mdpf').glob('*.py'))
    source.write_text(source.read_text() + '\n# Changed after wheel build\n')
    with pytest.raises(ValueError, match='stale'):
        build(tmp_path / 'framework.zip')
    assert not (tmp_path / 'framework.zip').exists()


def test_framework_release_rejects_ambiguous_versions(builder, tmp_path):
    build, root = builder
    wheel = next((root / 'dist').glob('*.whl'))
    shutil.copy2(wheel, root / 'dist/mdpf-another-version.whl')
    with pytest.raises(ValueError, match='exactly one'):
        build(tmp_path / 'framework.zip')
