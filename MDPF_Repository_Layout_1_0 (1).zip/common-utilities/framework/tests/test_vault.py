"""Credential flow and failure isolation without network or live secrets."""
import base64
import io
import json
from types import SimpleNamespace
from urllib.error import HTTPError

import pytest

from mdpf import vault


def bootstrap(**changes):
    config = dict(vault_url='https://vault.example.test',namespace='admin/team',
                  role_id='private-role',secret_id='private-secret',kv_mount='kv',secret_path='dmi/oracle')
    return {**config,**changes}


def client(config):
    encoded = base64.b64encode(json.dumps(config).encode()).decode()
    calls = []
    def get(ocid, **options):
        calls.append((ocid,options))
        return SimpleNamespace(data=SimpleNamespace(secret_bundle_content=SimpleNamespace(content=encoded)))
    return SimpleNamespace(get_secret_bundle=get),calls


def test_approle_then_kv2_and_namespace(monkeypatch):
    sdk,calls = client(bootstrap(auth_mount='custom-approle'))
    requests = []
    class Opener:
        def open(self,req,timeout):
            requests.append((req,timeout))
            body = {'auth':{'client_token':'private-token'}} if len(requests)==1 else {'data':{'data':{'password':'private-password'}}}
            return io.BytesIO(json.dumps(body).encode())
    monkeypatch.setattr(vault.request,'build_opener',lambda *handlers:Opener())
    assert vault.read_hcp_secret('ocid-secret',client=sdk,timeout=7)=={'password':'private-password'}
    assert calls==[('ocid-secret',{'stage':'CURRENT'})]
    login,read = [r for r,_ in requests]
    assert login.full_url=='https://vault.example.test/v1/auth/custom-approle/login'
    assert json.loads(login.data)=={'role_id':'private-role','secret_id':'private-secret'}
    assert read.full_url=='https://vault.example.test/v1/kv/data/dmi/oracle'
    assert dict(read.header_items())['X-vault-token']=='private-token'
    assert all(dict(r.header_items())['X-vault-namespace']=='admin/team' for r,_ in requests)
    assert all(t==7 for _,t in requests)


@pytest.mark.parametrize('changes',[
    {'vault_url':'http://vault.example.test'}, {'vault_url':'https://user:pass@vault.example.test'},
    {'vault_url':'https://vault.example.test/path'}, {'vault_url':'https://vault.example.test?token=x'},
    {'namespace':'admin\nAuthorization: x'}, {'secret_path':'../other'}, {'kv_mount':'/'},
    {'auth_mount':'../approle'}, {'secret_id':''}, {'unexpected':'value'},
])
def test_bad_bootstrap_never_contacts_hcp(monkeypatch,changes):
    sdk,_=client(bootstrap(**changes))
    monkeypatch.setattr(vault.request,'build_opener',lambda *a:pytest.fail('No HCP access'))
    with pytest.raises(RuntimeError,match='bootstrap JSON') as failure:
        vault.read_hcp_secret('ocid-secret',client=sdk)
    assert 'private-secret' not in str(failure.value)


@pytest.mark.parametrize('timeout',[0,-1,True,float('inf'),float('nan'),'30'])
def test_invalid_timeout(timeout):
    with pytest.raises(ValueError,match='timeout'):
        vault.read_hcp_secret('ocid-secret',timeout=timeout)


@pytest.mark.parametrize('stage',[1,2])
def test_remote_errors_do_not_expose_credentials(monkeypatch,stage):
    sdk,_=client(bootstrap())
    count=0
    class Opener:
        def open(self,req,timeout):
            nonlocal count
            count+=1
            if count==stage:
                raise HTTPError(req.full_url,403,'private-secret',{},io.BytesIO(b'private-password'))
            return io.BytesIO(b'{"auth":{"client_token":"private-token"}}')
    monkeypatch.setattr(vault.request,'build_opener',lambda *a:Opener())
    with pytest.raises(RuntimeError,match='HTTP 403') as failure:
        vault.read_hcp_secret('ocid-secret',client=sdk)
    assert 'private-' not in str(failure.value)
    assert failure.value.__suppress_context__


def test_redirects_are_not_followed():
    assert vault._NoRedirect().redirect_request(None,None,302,'',{},'https://other.test') is None
