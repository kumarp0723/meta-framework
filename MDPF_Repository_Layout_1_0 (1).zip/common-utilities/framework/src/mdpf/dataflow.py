"""Data Flow arguments; ActiveBatch supplies one stable key across its child runs."""
import argparse
import os
import re

from .runner import execute_task as run_task


def execute_task(*, pipeline_code, task_code, custom_steps=None, spark=None, argv=None):
    """Parse Data Flow arguments and return the shared runner's TASK_RUN dictionary.

    Require a stable --execution-key and a real run OCID from DATAFLOW_RUN_ID or
    --run-id; conflicting identities raise ValueError before a connection opens.
    argv=None reads process arguments. argparse exits for help or invalid arguments;
    runner/Spark/Oracle errors propagate. The runner owns connection cleanup and
    the MetadataFramework facade owns lifecycle transactions."""
    parser=argparse.ArgumentParser(description='Execute one metadata task in OCI Data Flow.')
    parser.add_argument('--execution-key',required=True)
    parser.add_argument('--cycle-date')
    parser.add_argument('--execution-mode',choices=('MANUAL','SCHEDULED'))
    parser.add_argument('--run-id',help='Bootstrap fallback when DATAFLOW_RUN_ID is unavailable.')
    args=parser.parse_args(argv)
    native=os.environ.get('DATAFLOW_RUN_ID')
    if native and args.run_id and native!=args.run_id:
        raise ValueError('Explicit run ID conflicts with DATAFLOW_RUN_ID.')
    run_id=native or args.run_id
    if not isinstance(run_id,str) or not re.fullmatch(r'ocid1\.dataflowrun\.[A-Za-z0-9._-]+',run_id):
        raise ValueError('A real Data Flow run OCID is required through DATAFLOW_RUN_ID or --run-id.')
    return run_task(pipeline_code=pipeline_code,task_code=task_code,
        execution_key=args.execution_key,task_run_id=run_id,cycle_date=args.cycle_date,
        execution_mode=args.execution_mode,triggered_by='DATAFLOW',custom_steps=custom_steps,spark=spark)
