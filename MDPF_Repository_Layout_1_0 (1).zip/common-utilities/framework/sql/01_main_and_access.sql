-- MDPF 1.0: generic 17-table runtime prerequisites
-- Run AFTER sql/00_framework.sql in a fresh POC environment.
-- Fresh installation only. MAIN target setup is separate; see generator/REFERENCE.md.

--------------------------------------------------------------------------------
-- Runtime ID sequences: create/bump above current MAX(primary_key).
--------------------------------------------------------------------------------
DECLARE
    PROCEDURE ensure_seq(
        p_owner VARCHAR2,
        p_seq   VARCHAR2,
        p_table VARCHAR2,
        p_pk    VARCHAR2
    ) IS
        l_target NUMBER;
        l_curr   NUMBER;
        l_exists NUMBER;
        l_diff   NUMBER;
    BEGIN
        EXECUTE IMMEDIATE 'SELECT NVL(MAX('||p_pk||'),0)+1 FROM '||p_owner||'.'||p_table INTO l_target;
        SELECT COUNT(*) INTO l_exists
          FROM ALL_SEQUENCES
         WHERE SEQUENCE_OWNER=UPPER(p_owner)
           AND SEQUENCE_NAME=UPPER(p_seq);

        IF l_exists=0 THEN
            EXECUTE IMMEDIATE 'CREATE SEQUENCE '||p_owner||'.'||p_seq||
                              ' START WITH '||TO_CHAR(l_target)||
                              ' INCREMENT BY 1 CACHE 100 NOCYCLE';
        ELSE
            EXECUTE IMMEDIATE 'SELECT '||p_owner||'.'||p_seq||'.NEXTVAL FROM DUAL' INTO l_curr;
            IF l_curr < l_target THEN
                l_diff := l_target - l_curr;
                EXECUTE IMMEDIATE 'ALTER SEQUENCE '||p_owner||'.'||p_seq||' INCREMENT BY '||TO_CHAR(l_diff);
                EXECUTE IMMEDIATE 'SELECT '||p_owner||'.'||p_seq||'.NEXTVAL FROM DUAL' INTO l_curr;
                EXECUTE IMMEDIATE 'ALTER SEQUENCE '||p_owner||'.'||p_seq||' INCREMENT BY 1';
            END IF;
        END IF;
    END;
BEGIN
    ensure_seq('RUNTIME','SEQ_BATCH_ID','BATCH','BATCH_ID');
    ensure_seq('RUNTIME','SEQ_TASK_RUN_ID','TASK_RUN','TASK_RUN_ID');
    ensure_seq('RUNTIME','SEQ_INGESTION_ITEM_ID','INGESTION_ITEM','INGESTION_ITEM_ID');
    ensure_seq('RUNTIME','SEQ_POLICY_RESULT_ID','POLICY_RESULT','POLICY_RESULT_ID');
    ensure_seq('RUNTIME','SEQ_PIPELINE_STATE_ID','PIPELINE_STATE','PIPELINE_STATE_ID');
    ensure_seq('OPERATIONS','SEQ_EVENT_LOG_ID','EVENT_LOG','EVENT_LOG_ID');
    ensure_seq('OPERATIONS','SEQ_WORK_QUEUE_ID','WORK_QUEUE','WORK_QUEUE_ID');
END;
/


--------------------------------------------------------------------------------

-- MAIN target DDL, keys and target grants are reviewed separately.
-- Run as DBA. Change this DEFINE if your POC service user has another name.
DEFINE runtime_user = MDPF_RUNTIME
GRANT SELECT ON METADATA.CONFIG_RELEASE TO &&runtime_user;
GRANT SELECT ON METADATA.SOURCE_CONFIG TO &&runtime_user;
GRANT SELECT ON METADATA.DATASET TO &&runtime_user;
GRANT SELECT ON METADATA.DATASET_COLUMN TO &&runtime_user;
GRANT SELECT ON METADATA.TASK TO &&runtime_user;
GRANT SELECT ON METADATA.TASK_DATASET TO &&runtime_user;
GRANT SELECT ON METADATA.TASK_STEP TO &&runtime_user;
GRANT SELECT ON METADATA.POLICY_DEFINITION TO &&runtime_user;
GRANT SELECT, INSERT, UPDATE ON RUNTIME.BATCH TO &&runtime_user;
GRANT SELECT, INSERT, UPDATE ON RUNTIME.TASK_RUN TO &&runtime_user;
GRANT SELECT, INSERT, UPDATE ON RUNTIME.INGESTION_ITEM TO &&runtime_user;
GRANT SELECT, INSERT ON RUNTIME.POLICY_RESULT TO &&runtime_user;
GRANT SELECT, INSERT ON OPERATIONS.EVENT_LOG TO &&runtime_user;
GRANT SELECT, INSERT ON OPERATIONS.WORK_QUEUE TO &&runtime_user;
GRANT SELECT ON RUNTIME.SEQ_BATCH_ID TO &&runtime_user;
GRANT SELECT ON RUNTIME.SEQ_TASK_RUN_ID TO &&runtime_user;
GRANT SELECT ON RUNTIME.SEQ_INGESTION_ITEM_ID TO &&runtime_user;
GRANT SELECT ON RUNTIME.SEQ_POLICY_RESULT_ID TO &&runtime_user;
GRANT SELECT ON OPERATIONS.SEQ_EVENT_LOG_ID TO &&runtime_user;
GRANT SELECT ON OPERATIONS.SEQ_WORK_QUEUE_ID TO &&runtime_user;
