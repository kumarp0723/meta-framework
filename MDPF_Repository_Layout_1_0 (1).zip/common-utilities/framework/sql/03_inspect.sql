-- Reusable Oracle diagnostics. SQLcl/SQL*Plus script mode; read-only queries.
-- Set these example binds to exact inspected identities. NULL batch/run means all.
-- MAIN owner/table use reviewed SQL-client substitution, never value binds.
SET DEFINE ON
DEFINE main_owner = DMI_MAIN_DEV
DEFINE main_table = DMI_FEE
VARIABLE pipeline_code VARCHAR2(100)
VARIABLE batch_id NUMBER
VARIABLE run_id NUMBER
EXEC :pipeline_code := 'DMI_FEE';
EXEC :batch_id := NULL;
EXEC :run_id := NULL;

SELECT config_release_id, pipeline_code, pipeline_direction, release_version, release_status
  FROM METADATA.CONFIG_RELEASE
 WHERE pipeline_code=:pipeline_code
 ORDER BY config_release_id;

SELECT batch_id, orchestrator_run_id, execution_key, config_release_id, cycle_date,
       status, start_timestamp, end_timestamp
  FROM RUNTIME.BATCH
 WHERE pipeline_code=:pipeline_code AND (:batch_id IS NULL OR batch_id=:batch_id)
 ORDER BY batch_id;

SELECT tr.batch_id, t.task_code, tr.task_run_id, tr.attempt_number,
       tr.original_task_run_id, tr.status, tr.input_count, tr.output_count,
       tr.orchestrator_task_run_id, tr.orchestrator_attempt_number,
       tr.error_code, tr.error_message, tr.failed_step_code
  FROM RUNTIME.TASK_RUN tr
  JOIN RUNTIME.BATCH b ON b.batch_id=tr.batch_id
  JOIN METADATA.TASK t ON t.config_release_id=tr.config_release_id AND t.task_id=tr.task_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR tr.batch_id=:batch_id)
   AND (:run_id IS NULL OR tr.task_run_id=:run_id)
 ORDER BY tr.batch_id,t.task_id,tr.attempt_number;

SELECT ie.ingestion_item_id, ie.task_run_id, ie.item_name, ie.source_item_key,
       ie.dataset_id, ie.source_location, ie.source_record_count, ie.status,
       ie.quarantine_location
  FROM RUNTIME.INGESTION_ITEM ie
  JOIN RUNTIME.TASK_RUN tr ON tr.task_run_id=ie.task_run_id
  JOIN RUNTIME.BATCH b ON b.batch_id=tr.batch_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR tr.batch_id=:batch_id)
   AND (:run_id IS NULL OR tr.task_run_id=:run_id)
 ORDER BY ie.ingestion_item_id;

SELECT q.batch_id,q.task_run_id,q.reason_code,q.description,q.status,q.idempotency_key
  FROM OPERATIONS.WORK_QUEUE q JOIN RUNTIME.BATCH b ON b.batch_id=q.batch_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR q.batch_id=:batch_id)
   AND (:run_id IS NULL OR q.task_run_id=:run_id)
 ORDER BY q.work_queue_id;

SELECT e.batch_id,e.task_run_id,e.event_code,e.details_json
  FROM OPERATIONS.EVENT_LOG e JOIN RUNTIME.BATCH b ON b.batch_id=e.batch_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR e.batch_id=:batch_id)
   AND (:run_id IS NULL OR e.task_run_id=:run_id)
 ORDER BY e.event_log_id;

SELECT pr.batch_id, pr.task_run_id, pd.policy_code, pr.dataset_id, pr.dataset_column_id,
       pr.result_level, pr.result_status, pr.expected_value, pr.actual_value,
       pr.threshold_value, pr.failed_record_count, pr.failure_action_taken
  FROM RUNTIME.POLICY_RESULT pr JOIN METADATA.POLICY_DEFINITION pd
    ON pd.config_release_id=pr.config_release_id AND pd.policy_id=pr.policy_id
  JOIN RUNTIME.BATCH b ON b.batch_id=pr.batch_id
 WHERE b.pipeline_code=:pipeline_code
   AND (:batch_id IS NULL OR pr.batch_id=:batch_id)
   AND (:run_id IS NULL OR pr.task_run_id=:run_id)
 ORDER BY pr.policy_result_id;

-- DMI_FEE-specific business total; adapt the metric for another target.
SELECT batch_id, task_run_id, COUNT(*) record_count, SUM(fee_tran_am) fee_amount
  FROM &&main_owner..&&main_table
 WHERE (:batch_id IS NULL OR batch_id=:batch_id)
   AND (:run_id IS NULL OR task_run_id=:run_id)
 GROUP BY batch_id,task_run_id ORDER BY batch_id;

SELECT batch_id, task_run_id, row_number, created_at, updated_at
  FROM &&main_owner..&&main_table
 WHERE (:batch_id IS NULL OR batch_id=:batch_id)
   AND (:run_id IS NULL OR task_run_id=:run_id)
 ORDER BY batch_id, row_number;
