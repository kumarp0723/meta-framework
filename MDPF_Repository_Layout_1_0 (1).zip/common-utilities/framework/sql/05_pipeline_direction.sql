-- Existing MDPF 1.0 databases only. Review and run once as METADATA owner.
-- Fresh installations use 00_framework.sql; do not run both paths.
-- Existing releases default to INBOUND. Review historical classification before
-- rollout; do not edit ACTIVE release contracts to relabel them. New releases can
-- explicitly select OUTBOUND. No task, retry or transaction behavior changes.
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
ALTER TABLE METADATA.CONFIG_RELEASE ADD (
    pipeline_direction VARCHAR2(8) DEFAULT 'INBOUND' NOT NULL
);
ALTER TABLE METADATA.CONFIG_RELEASE ADD CONSTRAINT CK_CONFIG_RELEASE_DIRECTION
    CHECK (pipeline_direction IN ('INBOUND','OUTBOUND'));
COMMENT ON COLUMN METADATA.CONFIG_RELEASE.pipeline_direction IS 'Pipeline classification: INBOUND or OUTBOUND; does not change execution behavior.';

-- Preserve release immutability for the added classification column.
CREATE OR REPLACE TRIGGER METADATA.TRG_CONFIG_RELEASE_LIFECYCLE
BEFORE INSERT OR UPDATE OR DELETE ON METADATA.CONFIG_RELEASE
FOR EACH ROW
BEGIN
    IF INSERTING THEN
        IF :NEW.release_status <> 'DRAFT' THEN
            RAISE_APPLICATION_ERROR(-20040, 'CONFIG_RELEASE must be created in DRAFT status.');
        END IF;
    ELSIF DELETING THEN
        IF :OLD.release_status <> 'DRAFT' THEN
            RAISE_APPLICATION_ERROR(-20041, 'Only DRAFT CONFIG_RELEASE rows may be deleted.');
        END IF;
    ELSIF UPDATING THEN
        IF :OLD.release_status = 'DRAFT' THEN
            IF :NEW.release_status NOT IN ('DRAFT','APPROVED') THEN
                RAISE_APPLICATION_ERROR(-20042, 'Allowed CONFIG_RELEASE transition: DRAFT -> APPROVED.');
            END IF;
        ELSIF :OLD.release_status = 'APPROVED' THEN
            IF :NEW.release_status <> 'ACTIVE' THEN
                RAISE_APPLICATION_ERROR(-20043, 'Allowed CONFIG_RELEASE transition: APPROVED -> ACTIVE.');
            END IF;
            IF :NEW.pipeline_code <> :OLD.pipeline_code OR
               :NEW.pipeline_name <> :OLD.pipeline_name OR
               :NEW.pipeline_direction <> :OLD.pipeline_direction OR
               NVL(:NEW.pipeline_description,CHR(0)) <> NVL(:OLD.pipeline_description,CHR(0)) OR
               :NEW.release_version <> :OLD.release_version OR
               :NEW.release_desc <> :OLD.release_desc OR
               :NEW.created_by <> :OLD.created_by OR
               :NEW.created_timestamp <> :OLD.created_timestamp THEN
                RAISE_APPLICATION_ERROR(-20044, 'Approved CONFIG_RELEASE content is immutable.');
            END IF;
        ELSIF :OLD.release_status = 'ACTIVE' THEN
            IF :NEW.release_status <> 'RETIRED' THEN
                RAISE_APPLICATION_ERROR(-20045, 'Allowed CONFIG_RELEASE transition: ACTIVE -> RETIRED.');
            END IF;
            IF :NEW.pipeline_code <> :OLD.pipeline_code OR
               :NEW.pipeline_name <> :OLD.pipeline_name OR
               :NEW.pipeline_direction <> :OLD.pipeline_direction OR
               NVL(:NEW.pipeline_description,CHR(0)) <> NVL(:OLD.pipeline_description,CHR(0)) OR
               :NEW.release_version <> :OLD.release_version OR
               :NEW.release_desc <> :OLD.release_desc OR
               :NEW.created_by <> :OLD.created_by OR
               :NEW.created_timestamp <> :OLD.created_timestamp THEN
                RAISE_APPLICATION_ERROR(-20046, 'Active CONFIG_RELEASE content is immutable.');
            END IF;
        ELSE
            RAISE_APPLICATION_ERROR(-20047, 'RETIRED CONFIG_RELEASE is immutable.');
        END IF;
    END IF;
END;
/
