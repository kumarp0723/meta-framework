# MDPF 1.0 — operations

- [Two-phase scheduling](#two-phase-scheduling)
- [OCI permissions](#oci-permissions)
- [Troubleshooting](#troubleshooting)
- [Worked investigations](#worked-investigations)
- [Live validation checklist](#live-validation-checklist)
- [Development rollout](#development-rollout)

Shared operations guidance for the framework and generator. Extract the ZIPs into
sibling `framework/` and `generator/` folders so the documentation links resolve.
Start with the [developer guide](DEVELOPER_GUIDE.md) for setup and the distinction
between local tests and real OCI/Oracle execution. The procedures below labeled
Oracle/OCI require provisioned infrastructure; otherwise they are conceptual.

## Two-phase scheduling

The default remains RAW → STAGE → MAIN in one scheduled workflow. Two-phase
scheduling uses the same tasks and metadata, with a scheduling gap after RAW.
MDPF does not launch the second phase or introduce a PAUSED state.

### Data Flow / ActiveBatch

Phase 1 launches only RAW with these arguments (substitute actual identifiers):

```text
--execution-key ACTIVEBATCH:<unique-workflow-instance>
--cycle-date 2026-10-15
--execution-mode SCHEDULED
```

Persist the exact key in scheduler state across both phases. Later launch STAGE,
then MAIN only on STAGE success, each with the same `--execution-key`. Omit cycle
and mode overrides or pass their original values; a new business date does not
change the batch cycle date. Each actual Data Flow run supplies its own real run
OCID through DATAFLOW_RUN_ID or --run-id. Never generate a new workflow key per
phase or per retry. A date alone is not a unique workflow identity.

### AIDP across separate job runs

Keep real `job_run_id`, `task_run_id`, `execution_count` bindings for every task.
Add `workflow_execution_key` with one scheduler-supplied resolved workflow key
shared across Phase 1 RAW-only and Phase 2 STAGE → MAIN jobs. Do not use
`{{job.run_id}}` for that shared key: it changes between jobs. The key supports
up to 300 UTF-8 bytes and rejects unresolved templates/control characters.

The same `mdpf.aidp.execute_task(...)` API reads the additional widget. Empty/omitted
values retain `AIDP:<job_run_id>` for existing single-job workflows. The original
job correlation stays on BATCH; every task attempt keeps its real external task ID.
Use the [starter parameter table](REFERENCE.md#run-the-supplied-dmi-example).
Phase 1 contains RAW only. In Phase 2, STAGE has no RAW task dependency inside that
separate job; MAIN depends on STAGE success. Omit cycle/mode overrides in Phase 2.
This is manual UI guidance; platform bindings still need validation in your OCI setup.

### State and restart rules

RAW-only success leaves RAW COMPLETED and BATCH RUNNING. Phase 2 resolves the same
batch by key, uses its original pinned release and reads only retained RAW. Changing
the ACTIVE release while waiting does not change that batch. A wrong/new key cannot
start STAGE; changed cycle/mode overrides fail. Missing/malformed Parquet lineage,
audit fields or noncompleted producers fail safely. Completed RAW cannot rerun.

After STAGE/MAIN failure, retry failed/downstream tasks with the same key and fresh
attempt identities; earlier failed attempts/error history remain. MAIN success
closes the batch. Terminal batches cannot reopen. Keep RAW/STAGE files, pinned
metadata and compatible application code for the supported continuation period.

Only after writers stop and the execution is deliberately abandoned:

```python
from mdpf.aidp import finalize_failed_job
finalize_failed_job(pipeline_code='MY_PIPELINE', workflow_execution_key='MY_STABLE_KEY')
# Existing single-job workflows can still use job_run_id='...'. Supply one identity.
```

Data Flow uses `mdpf.runner.finalize_failed_batch(pipeline_code=..., execution_key=...)`.
These are failure finalizers, not phase-transition calls. No waiting-batch dashboard
or automatic timeout/finalization is implemented.

## OCI permissions

Example only: same tenancy/region, Oracle-managed encryption, dedicated development
compartment `MDPF_DEV`. Substitute actual compartment, group, region and bucket names.
A platform administrator must validate effective access in the deployment environment.
Do not reuse this dedicated-compartment example as tenancy-wide production policy.

For Data Flow, an example dynamic-group rule is:

```text
ALL {resource.type='dataflowrun', resource.compartment.id='<DATAFLOW_COMPARTMENT_OCID>'}
```

Create a separate dynamic group for the actual OCI notebook Resource Principal
according to that notebook service's identity model. Do not assume AIDP has the
same dynamic-group rule as Data Flow. In the example below both groups receive
read access; workers can write RAW/STAGE while notebooks write onboarding artifacts.
Read object-family also covers metadata and copy work-request inspection in this
single dedicated compartment; bucket-scoped policies alone may not cover work requests.

```text
Allow dynamic-group MDPF_NOTEBOOKS to read object-family in compartment MDPF_DEV
Allow dynamic-group MDPF_RUNS to read object-family in compartment MDPF_DEV
Allow dynamic-group MDPF_NOTEBOOKS to manage objects in compartment MDPF_DEV where target.bucket.name='mdpf-dev-artifacts'
Allow dynamic-group MDPF_RUNS to manage objects in compartment MDPF_DEV where any {target.bucket.name='dev-raw', target.bucket.name='dev-stage'}
Allow dynamic-group MDPF_RUNS to manage objects in compartment MDPF_DEV where all {target.bucket.name='dev-quarantine', request.permission='OBJECT_CREATE'}
```

Object Storage also needs permission to perform server-side copy on your behalf.
Adapt this Oracle service-policy example to the actual region/compartment:

```text
Allow service objectstorage-us-ashburn-1 to manage object-family in compartment MDPF_DEV where any {request.permission='OBJECT_READ', request.permission='OBJECT_INSPECT', request.permission='OBJECT_CREATE', request.permission='OBJECT_OVERWRITE', request.permission='OBJECT_DELETE'}
```

The runtime requests source ETag matching and create-only quarantine destinations;
landing is retained. Give notebook-run pipelines the corresponding runtime object
permissions only when they execute ingestion as well as generate YAML. OCI SDK
Resource Principal configuration and Spark driver/worker connector configuration
are separate. KMS, cross-tenancy/region access, extra compartments and platform
job-launch permissions need additional reviewed policies.

Official references:

- [Object Storage permissions](https://docs.oracle.com/en-us/iaas/Content/Identity/Reference/objectstoragepolicyreference.htm)
- [Object copy and service permissions](https://docs.oracle.com/en-us/iaas/Content/Object/Tasks/copyingobjects.htm)
- [Data Flow resource principals](https://docs.oracle.com/en-us/iaas/Content/data-flow/using/resource-principal-policies.htm)

## Troubleshooting

| Symptom | Check/action |
|---|---|
| Bulk row FAILED for a sample | Check the exact OCI URI and HEAD access. Fix the object/permissions, then rerun; do not add schema checks to the builder. |
| Existing YAML skipped | Save is create-only. Edit a maintained configuration explicitly or choose a new release-specific destination. |
| Batch RUNNING after RAW success | Expected when Phase 2 is intentionally delayed. Reuse the same key; do not call a failure finalizer for waiting. |
| Phase 2 says INGESTION must create batch | Wrong/new execution key or wrong pipeline/environment. Use the original key. |
| Cycle conflicts | Use the original batch cycle date or omit the downstream override. |
| Completed task cannot restart | Retry only failed/downstream tasks. New intentional deliveries need new execution keys. |
| Attempt still RUNNING after worker loss | Stop its external writer; fail that exact internal task_run_id before retrying. Do not guess from elapsed time. |
| RAW technical validation failure | Inspect header/CSV/type/length/nonempty/source contract. Only proven data failures qualify for whole-file quarantine. |
| Quarantine copy failed | Inspect both original validation and copy errors; check region, ETag, bucket/service permissions and work request. Unconfirmed copies do not mark QUARANTINED. |
| STAGE DQ fails | Inspect POLICY_RESULT by task_run_id, correct deterministic business logic/configuration, retry STAGE and downstream with the same key. RAW remains intact. |
| WARN recorded but task fails | WARN cannot bypass required schema, conversion or Oracle constraints. Inspect the actual task error. |
| Parquet audit/lineage rejected | Check exact producer/run/batch/receipt fields and layer schema. Old-format files require the old runtime; see the Development rollout section of OPERATIONS.md. |
| MAIN row limit exceeded | No rows inserted. Review input size/driver memory; configure a suitable cap and retry MAIN in the same batch. No truncation occurs. |
| MAIN insert reconciliation failed | All MAIN target inserts/completion were rolled back. Inspect expected/actual policy evidence and adapter row counts; fix and retry MAIN. |
| Oracle uniqueness/check error | Review actual target constraints and cross-batch data. STAGE UNIQUE does not guarantee cross-batch uniqueness. |
| Sample conversion fails during onboarding | Review explicit datatypes/capacity or custom parsing. Sample validation belongs to onboarding, not the pre-builder. |

Use existing RUNTIME.TASK_RUN, RUNTIME.POLICY_RESULT, RUNTIME.INGESTION_ITEM,
OPERATIONS.EVENT_LOG and OPERATIONS.WORK_QUEUE, filtered by batch/task attempt.
Retain failed attempts and error history after a successful retry. Inspect
framework `sql/03_inspect.sql`; no waiting dashboard or new operational tables exist.

## Worked investigations

**Oracle — use a read-only investigation session first.** These are focused versions
of the patterns in [sql/03_inspect.sql](sql/03_inspect.sql), whose supplied pipeline
and DEV business table are DMI_FEE. For another pipeline, use its actual
pipeline, execution key and MAIN target. Find the batch and attempt before inspecting related facts:

```sql
VARIABLE workflow_key VARCHAR2(300)
EXEC :workflow_key := 'PASTE_THE_PRINTED_WORKFLOW_KEY';
SELECT batch_id, config_release_id, cycle_date, status
  FROM RUNTIME.BATCH
 WHERE pipeline_code='DMI_FEE' AND execution_key=:workflow_key;
SELECT tr.task_run_id, tr.batch_id, t.task_code, tr.attempt_number,
       tr.original_task_run_id, tr.status, tr.failed_step_code,
       tr.error_code, tr.error_message
  FROM RUNTIME.TASK_RUN tr
  JOIN RUNTIME.BATCH b ON b.batch_id=tr.batch_id
  JOIN METADATA.TASK t ON t.config_release_id=tr.config_release_id AND t.task_id=tr.task_id
 WHERE b.pipeline_code='DMI_FEE' AND b.execution_key=:workflow_key
 ORDER BY tr.task_run_id;
```

Set a bind to the **exact attempt you just inspected**. The following numeric value
is illustrative; replace it, including for every later investigation query:

```sql
VARIABLE run_id NUMBER
EXEC :run_id := 12345;
```

### RAW: technical source failure or quarantine-copy error

Symptom: RAW fails at READ_SOURCE; STAGE never starts.

```sql
SELECT ingestion_item_id, item_name, source_location, status, quarantine_location
  FROM RUNTIME.INGESTION_ITEM WHERE task_run_id=:run_id;
SELECT event_code, error_code, message, details_json
  FROM OPERATIONS.EVENT_LOG WHERE task_run_id=:run_id ORDER BY event_log_id;
```

Expected: a confirmed quarantine copy produces QUARANTINED, an exact destination
and SOURCE_QUARANTINED, followed by TASK_FAILED/work-queue evidence. Landing stays
intact. A missing quarantine configuration or unconfirmed copy does not produce
that successful quarantine claim. Inspect both the original validation error and
any copy error in the attempt/worker log. **OCI:** confirm original/destination
objects and copy work-request outcome; check region, source ETag and permissions.

Recovery: for an access/platform failure, restore access and retry only the failed
task with the same key and a fresh attempt identity, keeping the delivery immutable.
For invalid data, prepare a corrected delivery at a new immutable URI and use an
appropriate new execution/configuration identity. Do not replace the original
bytes under an existing batch or silently change its pinned source location.

### STAGE: blocking business DQ

Symptom: RAW is COMPLETED, STAGE fails at VALIDATE_DQ and MAIN does not run.

```sql
SELECT pd.policy_code, pr.result_status, pr.expected_value, pr.actual_value,
       pr.failed_record_count, pr.failure_action_taken
  FROM RUNTIME.POLICY_RESULT pr JOIN METADATA.POLICY_DEFINITION pd
    ON pd.config_release_id=pr.config_release_id AND pd.policy_id=pr.policy_id
 WHERE pr.task_run_id=:run_id ORDER BY pr.policy_result_id;
SELECT idempotency_key, reason_code, description, status
  FROM OPERATIONS.WORK_QUEUE WHERE task_run_id=:run_id;
```

Expected: a blocking rule has FAIL/FAILED_TASK evidence, a FAILED attempt and an
OPEN work item; the batch stays RUNNING for the scheduler decision. A configured
WARN fact alone is nonblocking, but schema/required-column guards can still fail.
STAGE business failure does not quarantine the landing object.

Recovery: fix a handler defect within the same reviewed contract, then retry STAGE
and downstream tasks using the same key/fresh attempt identities. Preserve RAW.
If policy/schema metadata must change, publish a new release and start a suitable
new execution; changing ACTIVE does not change the existing batch's pinned release.
Keep previous facts and error history after success.

### MAIN: actual insert-count mismatch

Symptom: MAIN fails with MAIN insert reconciliation, while RAW/STAGE remain completed.
Use the policy query above when MAIN ROW_COUNT is configured, then inspect events:

```sql
SELECT event_code, error_code, message, details_json
  FROM OPERATIONS.EVENT_LOG WHERE task_run_id=:run_id ORDER BY event_log_id;
SELECT COUNT(*) rows_from_failed_attempt
  FROM DMI_MAIN_DEV.DMI_FEE WHERE task_run_id=:run_id;
```

Expected for a count mismatch: zero MAIN rows from this failed attempt, no committed
MAIN_TABLE_LOADED/TASK_COMPLETED/BATCH_COMPLETED success event for it, and durable
TASK_FAILED/work-queue evidence. Configured failed ROW_COUNT evidence survives the
separate failure transaction. Without that policy, or if Oracle DML itself raised,
investigate TASK_RUN/error events rather than expecting a policy result that was
never evaluated. Inspect the affected-row count and target/adapter error.

Recovery: correct the adapter/target/constraint issue while preserving the contract,
then retry failed MAIN with the original key and a fresh attempt identity. Never
insert rows manually to make counts appear correct. The driver cap is task-wide;
review size/memory before changing MDPF_MAIN_MAX_ROWS. The cap does not truncate.

For any layer, an attempt stuck RUNNING after a killed worker needs confirmed writer
shutdown and exact-run terminalization before retry. Only after retries are abandoned
and active attempts are terminal should the scheduler call the documented failure
finalizer. A deliberately waiting batch is not a failure.

## Live validation checklist

Local `python -m pytest -q` uses Spark/SQLite/OCI doubles. It does not execute the
checks below or prove actual grants, concurrent sessions, SDK credentials or AIDP
bindings. Use a prepared isolated development environment and the exact commands
in the [walkthrough](../generator/README.md#end-to-end-quick-start):

| Action | Expected evidence |
|---|---|
| SDK HEAD / Spark sample read | Correct exact sample is accessible through both connections |
| Generate through either onboarding route | Reviewed complete YAML, optional DDL and DRAFT metadata SQL in the configured OCI destination |
| Deploy and invoke Oracle target gate | Visible compatible MAIN table; no DDL/activation performed by the gate |
| Manually approve/activate, then run the sample | One pinned batch, completed RAW/STAGE/MAIN attempts, two example MAIN rows and managed audit fields |
| Exercise real quarantine and STAGE failure on separate test deliveries | Confirmed copy/retained landing for eligible RAW error; durable STAGE facts without quarantine |
| Validate MAIN rollback with a controlled test adapter/failure | No failed-attempt MAIN/success evidence survives; failure/work item is durable |
| Validate platform retry and writer shutdown | Same batch/key, new exact attempt, old history retained; no overlapping writer |

Real Oracle multi-session/concurrency and hard-kill scenarios need deployment tests;
there are no invented `--live` flags in this package. Record actual identities,
outcomes and issues in your test evidence without credentials. All these live
checks are **pending for this documentation build**. The unfamiliar-developer
walkthrough in [the guide](DEVELOPER_GUIDE.md#learning-path-acceptance) is also pending.

## Development rollout

For development installations moving from an earlier build to this build.
Software packages retain version 1.0; the wheel checksum identifies this build.

1. Stop launching new development batches. Finish existing batches with the older
   runtime, or deliberately abandon them after stopping writers. Keep the older
   runtime available for any retained old-format batch that must still finish.
   Configuration pinning does not pin Python application code.
2. Install both 1.0 wheels and restart notebook/worker sessions. Replace runtime
   dependency archives/wheels for Data Flow as well. The package version is 1.0;
   pipeline metadata release_version remains independently chosen text.
3. The framework retains 17 tables but adds CONFIG_RELEASE.pipeline_direction.
   Review/run `sql/05_pipeline_direction.sql` once for an existing database; it
   also replaces the lifecycle trigger to protect this field. **Do not rerun fresh-install DDL**
   against an existing framework. For new development MAIN tables, use regenerated
   CREATE proposals. Existing targets need CREATED_AT/UPDATED_AT TIMESTAMP(6) WITH
   TIME ZONE NOT NULL. Review framework `sql/04_main_audit_columns.sql`, a manual
   preserving proposal for one existing MAIN target. Historical timestamps use
   recorded attempt completion as an approximation, explicitly documented there.
   Review missing history/backfill cases before enforcing NOT NULL. DDL commits
   independently and is never run by the utility.
4. Move legacy MAIN column DQ entries to their matching STAGE dataset in a new
   DRAFT configuration. Use [DQ and audit contracts in the framework reference](REFERENCE.md#dq-reconciliation-and-audit-contracts) for severity/rule syntax.
   Existing published metadata remains immutable. Complete-YAML baseline comparison
   remains strict: first make a reviewed configuration compatible with this build; do not
   silently rewrite published definitions. A legacy baseline containing MAIN column
   DQ needs a separately reviewed conversion before comparison with this build can validate it.
5. Generate/review/deploy/approve/activate the new release. Configure the MAIN worker's
   MDPF_MAIN_MAX_ROWS if a reviewed value above the 100,000-row default is necessary.
   Set Spark session timeZone=UTC for consistent audit display. Run the read-only
   Oracle target gate to check timestamp fields/types/precision as well as business
   columns and required grants.
6. Start a **new execution key/batch** for the new physical audit contract. Old RAW
   or STAGE Parquet lacks the new required fields and is rejected by this build's readers.
   Never manufacture receipt IDs or overwrite completed old-batch output to add
   fields. This development release intentionally does not infer missing lineage.
7. Verify same-day success, delayed continuation, warning/failure evidence, MAIN
   rollback and one real OCI quarantine test before enabling normal scheduling.

No deployment, schema migration or metadata activation is performed by these ZIPs.

## Parquet, direction and Vault rollout

Stop affected schedules and finish existing batches with their approved runtime.
Install the paired rebuilt 1.0 wheels and restart sessions. Existing Oracle control
schemas need reviewed `sql/05_pipeline_direction.sql`; fresh schemas use the updated
`00_framework.sql`. The upgrade defaults existing releases to INBOUND, retains 17
tables and replaces the lifecycle trigger. Verify the constraint and trigger are
valid in Oracle before deploying newly generated SQL. Review historical direction;
use new metadata releases for changed published contracts.

Generate a new DRAFT pipeline release for changed Parquet landing/output paths,
review it and activate through the existing procedure. Do not overwrite a published
release or move paths for in-flight batches. Verify one real exact landing Parquet
object, RAW/STAGE part files and audit fields, all four DMI_FEE policies and MAIN
rollback/retry. CSV reference fixtures and existing prefix paths remain supported.

For Vault, grant bootstrap-secret read permission and provide HTTPS routing to HCP.
Confirm AppRole/KV v2 namespace, mount, policy and SecretID lifetime without printing
credentials. HTTP 403 means investigate auth/policy/namespace; it does not justify
hardcoded fallback credentials. Test one SecretID rotation and an access denial.
For incomplete templates, fill placeholders/samples and remove `template_status`
before normal generation; template-only success does not prove sample access.
