# common-utilities

Shared utilities owned by the centralized data engineering team.

| Folder | Python distribution/import | Purpose |
|---|---|---|
| [framework](framework/README.md) | `mdpf` / `mdpf` | Metadata-driven pipeline execution |
| [generator](generator/README.md) | `mdpf-onboarding` / `mdpf_onboarding` | Pre-onboarding input YAML and complete YAML/SQL generation |

The supplied packages are version 1.0. Core runtime modules, Oracle SQL and the
original utility wheels are unchanged; launchers, tests, documentation and package
manifests have been updated. Preserve these
sibling folders: existing imports, tests, developer instructions and links work
from this arrangement. There is no new umbrella Python package.

## Local setup and verification

Use Python 3.10+ and Java 17. From this repository's root:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e './framework[test]' -e './generator[test]'
python -m pip check
python -c "import mdpf, mdpf_onboarding; print(mdpf.__version__, mdpf_onboarding.__version__)"
python -m pip wheel --no-deps --wheel-dir framework/dist ./framework
python -m pytest -q framework/tests
cd generator
python -m pytest -q
```

Expected imports print `1.0 1.0`. The test extras retain the supplied PySpark 3.5.7
profile. These local tests use Spark with SQLite/OCI test adapters; they require
no live OCI/Oracle credentials. They do not prove live platform behavior.
Build the Framework wheel before running its packaging tests. A source-only Git
clone has no `dist/` artifacts; the downloadable distribution includes them.

Read [framework/DEVELOPER_GUIDE.md](framework/DEVELOPER_GUIDE.md) for the existing
module flow, setup and troubleshooting. Run its commands that mention both
`framework/` and `generator/` from this repository's root. The generator's local
file examples likewise use this root as their working directory.

## Source and distribution files

The two original wheels remain under each package's `dist/` folder in this bundle
for compatibility and existing installation instructions. The repository ignore
file excludes generated distributions from Git. Use editable source installation
above for a source-only clone; publish wheels separately when release management
is introduced. Package checksum files describe the current distribution,
including those wheels, and are not Git file inventories.

Keep shared source, installation SQL, tests and small example fixtures here.
Provider production configuration/code belongs in `data-pipelines`. The first
implementation is [DMI/FEE](../data-pipelines/providers/dmi/README.md).
DMI_FEE examples remain here as working examples and regression assets; they are
not a second production source of truth.

CI/CD and package-publication setup are deferred. Framework runtime code, Oracle
schema and generator behavior remain unchanged.

## Shared launchers

The six launchers under `framework/entrypoints/` run built-in metadata steps
across providers. They register no provider functions. Each invocation runs one
task; the scheduler controls ordering, dependencies and retry limits.

| Layer | Data Flow application script | AIDP notebook |
|---|---|---|
| RAW | [raw.py](framework/entrypoints/dataflow/raw.py) | [raw.ipynb](framework/entrypoints/aidp/raw.ipynb) |
| STAGE | [stage.py](framework/entrypoints/dataflow/stage.py) | [stage.ipynb](framework/entrypoints/aidp/stage.ipynb) |
| MAIN | [main.py](framework/entrypoints/dataflow/main.py) | [main.ipynb](framework/entrypoints/aidp/main.ipynb) |

Choose the shared launcher only when that task's plan contains built-ins. A plan
requiring a custom handler fails before source/sink I/O, with its failure recorded
by the existing framework. Select a provider launcher explicitly for custom tasks;
there is no automatic fallback or dynamic import from YAML. The two older
starters were removed; the table above lists the canonical entry points. Existing
platform jobs using removed paths must be repointed to their layer's canonical
launcher. Supply pipeline_code and retain explicit task_code overrides when used.

Data Flow launchers accept `--pipeline-code` and optional `--task-code`.
The default task code is `<pipeline-code>_RAW_LOAD`, `_STAGE_LOAD` or `_MAIN_LOAD`
according to the selected file. Set `--task-code` for a metadata task with a
different name. The launcher consumes these selection flags and forwards all
remaining arguments to the unchanged `mdpf.dataflow` adapter:

```text
--pipeline-code PROVIDER_DATA --execution-key <stable-workflow-key>
--cycle-date 2026-10-15 --execution-mode MANUAL
```

That is a RAW example. Supply a real `DATAFLOW_RUN_ID` or `--run-id` run OCID.
Downstream tasks retain the same execution key; omit cycle/mode overrides unless
they match the existing batch. Normal scheduler retries use the same workflow key
and the new attempt identity. Unknown adapter flags fail through its existing parser.
`--help` shows launcher selection and the forwarded flag names without connecting.

AIDP launchers read a required `pipeline_code` widget and optional `task_code`
widget with the same defaults. The unchanged adapter reads `job_run_id`,
`task_run_id`, positive `execution_count`, `cycle_date`, `execution_mode` and
optional `workflow_execution_key`. Configure resolved scheduler values; a new
workflow key for each attempt would create a different logical workflow.

The filename supplies a task-name default, not a second processing recipe.
Explicit task-code overrides must select the intended metadata task. Existing
framework task ownership, pinned-plan, schema and lifecycle checks still apply.

Install `mdpf==1.0` and its runtime dependencies using the platform's supported
mechanism; Spark/Java come from the platform. Launchers are separate script/notebook
assets, outside the unchanged wheel. Pin their released bytes alongside the wheel;
do not execute an unpinned repository branch. The provider release ZIP is an
artifact container, not a Data Flow dependency archive or a job-creation payload.

From `common-utilities/`, run `python -m pytest -q framework/tests` to check shared
launcher argument/widget forwarding and failure propagation. Provider tests also
exercise the actual RAW/custom-STAGE/MAIN launchers with local Spark/CI adapters.

## Framework artifact bundle

From common-utilities, after building/selecting one approved mdpf wheel in framework/dist:

```bash
python framework/scripts/package_release.py --output framework/dist/review/mdpf-1.0-release.zip
```

The script reads the version from wheel METADATA, verifies its code against source,
and creates a new ZIP containing the wheel, six launchers and release-manifest.json.
It prints the ZIP SHA256. Keep the approved ZIP and SHA256 together in release
records. Provider packaging requires both and rejects mismatched versions/hashes;
it does not require this source checkout. No latest-version lookup is performed.
Registry publishing/downloading remains deferred. dist files are ignored by Git.
The example uses a fresh `review/` destination so it can also be run from the
supplied ZIP, which already contains a release at `framework/dist/`. Use a new
unused output path on repeat runs; no release ZIP is overwritten.

Deployment references are grouped under [examples/dataflow](framework/examples/dataflow/):
[create_run.json](framework/examples/dataflow/create_run.json) and
[requirements.txt](framework/examples/dataflow/requirements.txt). Replace all
placeholders; the JSON demonstrates a built-in task and is not an automatic deployer.
The package does not inspect/repoint live jobs. Update any deployed legacy paths
before switching releases. Task-code defaults follow the layer's naming convention;
keep an explicit override when migrating a nonstandard metadata task name.

## Deployment handoff

Extract the selected release ZIP first; its manifest lists the exact task/launcher
paths. A repository path is a source location. Publish that version's launcher to
the platform's execution location and install the released wheel dependencies.
No extra Python wrapper is required.

| Platform | Publish the entry point | Bind the task |
|---|---|---|
| Data Flow | Upload the selected `.py` launcher to a versioned OCI Object Storage key | Set the application's `file_uri` to its `oci://bucket@namespace/key` URI. Set `archive_uri` to a compatible Data Flow dependency archive containing the runtime packages. Supply launcher/run arguments and reference the application from the scheduler. |
| AIDP | Import the selected `.ipynb` into a versioned shared workspace folder | Choose that workspace notebook path as the workflow's Notebook task source, select its configured compute, and set its task widgets/parameters. Several provider tasks can reference the same common notebook. |

For example, a common RAW script can be published as
`oci://artifacts@namespace/mdpf/1.0/entrypoints/dataflow/raw.py`, or its notebook
imported as `/Shared/mdpf/1.0/raw.ipynb`. These locations are illustrative; use
your actual bucket, namespace and workspace path. Common launchers need mdpf;
provider custom launchers also need the provider package. Supply the pipeline
selection and stable workflow/attempt identities described above. Keep the task
ordering and retries in the scheduler.

The release ZIP itself is not a Data Flow dependency archive. Prepare dependencies
for the selected platform runtime before execution. Credentials, IAM, networking
and Oracle targets must already be configured. These steps describe the manual
handoff; this package does not publish files or create/repoint live jobs.

Oracle references: [Data Flow application fields](https://docs.oracle.com/en-us/iaas/tools/python/latest/api/data_flow/models/oci.data_flow.models.CreateApplicationDetails.html),
[Data Flow dependency archives](https://docs.oracle.com/en-us/iaas/Content/data-flow/using/third-party-provide-archive.htm),
and [AIDP notebook tasks](https://docs.oracle.com/en/cloud/paas/ai-data-platform/aidug/configure-tasks.html).
