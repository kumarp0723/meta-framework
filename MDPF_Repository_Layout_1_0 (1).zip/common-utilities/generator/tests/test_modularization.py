"""Compatibility and transaction checks for the six-module refactor."""
import pytest

from conftest import ROOT, prepare_execution


def test_established_imports_still_resolve_to_shared_implementations():
    from mdpf import dq, metadata, pipeline, steps
    from mdpf_onboarding import config, onboard, metadata_generator, oracle_gate, sql_renderer
    assert steps.validate_dq_parameters is dq.validate_dq_parameters
    assert steps._policy_failures is dq._policy_failures
    assert steps.policy_result is dq.policy_result
    assert pipeline._json_object is metadata._json_object
    for name in ('UniqueLoader', 'validate_config', 'expand_parameters', 'oci_uri',
                 'sample_uri', 'output_uri', 'main_ddl_uri', 'yaml_uri'):
        assert getattr(onboard, name) is getattr(config, name)
    for name in ('render_sql', 'render_main_ddl', 'literal', 'clob_literal', 'expression'):
        assert getattr(metadata_generator, name) is getattr(sql_renderer, name)
    assert metadata_generator.verify_main_targets is oracle_gate.verify_main_targets


def test_control_ddl_matches_pinned_generator_fixture():
    companion = ROOT.parent / 'framework/sql/00_framework.sql'
    assert companion.read_bytes() == (ROOT / 'tests/fixtures/framework_1_0.sql').read_bytes()


def test_completion_event_failure_rolls_back_main_and_all_success_evidence(models, spark, tmp_path, monkeypatch):
    from mdpf import runtime
    from test_enhancements import enhanced_model, row_rule, task_codes, MAIN, STAGE

    model = enhanced_model(models, spark, [row_rule(MAIN, STAGE)])
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('completion-event-failure', '2026-10-15')['batch_id']
        raw, stage, main = task_codes(model)
        fw.execute_task(batch, raw)
        fw.execute_task(batch, stage)
        insert_event = runtime.insert_event

        def fail_completion(db, batch, run_id, code, message, details=None, error_code=None):
            if code == 'BATCH_COMPLETED':
                raise RuntimeError('Injected completion-event failure')
            return insert_event(db, batch, run_id, code, message, details, error_code)

        monkeypatch.setattr(runtime, 'insert_event', fail_completion)
        with pytest.raises(RuntimeError, match='completion-event failure'):
            fw.execute_task(batch, main)
        failed = db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_id=3")
        assert failed['status'] == 'FAILED'
        assert db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n'] == 0
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        assert db.one('SELECT COUNT(*) n FROM RUNTIME.POLICY_RESULT')['n'] == 0
        assert db.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE task_run_id=:id AND event_code IN ('MAIN_TABLE_LOADED','TASK_COMPLETED','BATCH_COMPLETED')",
                      id=failed['task_run_id'])['n'] == 0
        assert db.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE task_run_id=:id AND event_code='TASK_FAILED'",
                      id=failed['task_run_id'])['n'] == 1
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE WHERE task_run_id=:id',
                      id=failed['task_run_id'])['n'] == 1
        monkeypatch.setattr(runtime, 'insert_event', insert_event)
        retry = fw.execute_task(batch, main)
        assert retry['attempt_number'] == 2 and retry['original_task_run_id'] == failed['task_run_id']
        assert db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n'] == 2
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
    finally:
        db.close()
