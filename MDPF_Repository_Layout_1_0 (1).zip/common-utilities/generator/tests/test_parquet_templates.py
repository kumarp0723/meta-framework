"""Parquet contracts, date/batch layout and explicitly incomplete onboarding."""
from copy import deepcopy
from datetime import date
from decimal import Decimal

import pytest
import yaml

from conftest import ROOT, CatalogDb, MemoryOCI, prepare_execution
from test_bulk_builder import SampleOCI, PROFILE, CATALOG, csv_bytes, row
from mdpf import metadata
from mdpf.schema import convert_frame
from mdpf_onboarding.builder import build_config
from mdpf_onboarding.bulk_builder import build_catalog
from mdpf_onboarding.config import incomplete_template, validate_config
from mdpf_onboarding.metadata_generator import contract_model, build_metadata, dataset_codes, render_sql
from mdpf_onboarding.onboard import generate
from mdpf_onboarding.schema_discovery import discover, explicit_columns, read_sample, validate_sample


def parquet_config():
    c=yaml.safe_load((ROOT/'examples/dmi_fee.yaml').read_text())
    c['pipeline']['direction']='INBOUND'
    i=c['inputs'][0]
    i.update(source_format='PARQUET',landing_key_prefix='dmi/inbound/fee/ingest_date={YYYYMMDD}',file_name='fee_{YYYYMMDD}.parquet')
    i['columns']=deepcopy(c['outputs'][0]['columns'])
    for column in i['columns']:
        column['is_nullable']='Y'
    for layer in ('raw','stage'):
        c['storage'][layer+'_path_template']='dmi/{feed}/ingest_date={YYYYMMDD}/batch_id={batch_id}/{feed}_{YYYYMMDD}.parquet'
    return validate_config(c)


def test_path_resolution_and_direction_in_sql():
    c=parquet_config();c['pipeline']['direction']='OUTBOUND'
    model=contract_model(c)
    raw=model['datasets']['DMI_FEE_FEE_RAW']['row'].copy()
    raw['physical_object_name']=raw['physical_object_name']['DEV']
    b={'batch_id':1234,'cycle_date':date(2026,10,15)}
    assert metadata.output_path(None,b,raw)=='oci://dev-raw@devns/dmi/fee/ingest_date=20261015/batch_id=1234/fee_20261015.parquet'
    landing=model['datasets']['DMI_FEE_FEE_LANDING']['row'].copy()
    landing['physical_object_name']=landing['physical_object_name']['DEV']
    config=model['tables']['SOURCE_CONFIG'][0].copy();config['landing_path']=config['landing_path']['DEV']
    assert metadata.source_path(None,b,config,landing,1)=='oci://dev-landing@devns/dmi/inbound/fee/ingest_date=20261015/fee_20261015.parquet'
    assert 'pipeline_direction' in render_sql(model,b'test')
    db=CatalogDb()
    try:
        db.deploy(render_sql(model,b'test'))
        assert db.one('SELECT pipeline_direction FROM METADATA.CONFIG_RELEASE')['pipeline_direction']=='OUTBOUND'
    finally:
        db.close()


@pytest.mark.parametrize('template',[
    'dmi/{feed}/file.parquet', 'dmi/{feed}/{unknown}/{batch_id}/file.parquet',
    'dmi/{feed}/{batch_id}/../file.parquet', 'dmi/{feed}/{batch_id}/file.csv',
])
def test_invalid_output_templates_fail_before_io(template):
    c=parquet_config();c['storage']['raw_path_template']=template
    with pytest.raises(ValueError):validate_config(c)


def test_template_only_no_spark_no_sql_and_refuses_normal_generation(monkeypatch):
    import mdpf_onboarding.onboard as onboard
    c=parquet_config()
    for item in c['inputs']+c['outputs']:
        del item['sample_csv'];del item['columns']
    client=MemoryOCI();uri='oci://config@devns/input/dmi_fee.yaml'
    client.objects[uri]=yaml.safe_dump(c).encode()
    monkeypatch.setattr(onboard.SparkSession,'getActiveSession',lambda:pytest.fail('No Spark'))
    monkeypatch.setattr(onboard,'read_sample',lambda *a:pytest.fail('No sample read'))
    target=generate(uri,client=client,template_only=True)
    assert target.endswith('_input_template.yaml')
    result=yaml.safe_load(client.objects[target])
    assert result['template_status']=='INCOMPLETE'
    assert result['inputs'][0]['sample_csv']=='<REQUIRED_SAMPLE_URI>'
    assert len(client.puts)==1 and client.puts[0][1]['if_none_match']=='*'
    with pytest.raises(ValueError,match='Incomplete template'):
        generate(target,client=client)


def test_bulk_template_allows_missing_samples_without_heads(monkeypatch):
    client=SampleOCI();profile=yaml.safe_load((ROOT/'examples/shared_profile.yaml').read_text())
    client.objects[PROFILE]=yaml.safe_dump(profile).encode()
    record=row();record.update(input_sample_csv='',output_sample_csv='',source_format='PARQUET',target_table='DMI_FEE')
    client.objects[CATALOG]=csv_bytes([record])
    results=build_catalog(PROFILE,CATALOG,dry_run=False,client=client,template_only=True)
    assert results[0]['status']=='CREATED' and not client.heads
    assert results[0]['yaml_uri'].endswith('/input/config_template.yaml')
    result=yaml.safe_load(client.objects[results[0]['yaml_uri']])
    assert result['template_status']=='INCOMPLETE'
    assert result['outputs'][0]['target_table']=='DMI_FEE'


def test_bulk_parquet_samples_use_exact_head_checks():
    client=SampleOCI();profile=yaml.safe_load((ROOT/'examples/shared_profile.yaml').read_text())
    client.objects[PROFILE]=yaml.safe_dump(profile).encode()
    record=row();record.update(input_sample_csv='fee/input.parquet',output_sample_csv='fee/output.parquet',source_format='PARQUET')
    client.objects[CATALOG]=csv_bytes([record])
    for path in ('fee/input.parquet','fee/output.parquet'):
        client.objects[profile['samples_root']+'/'+path]=b''
    result=build_catalog(PROFILE,CATALOG,client=client)[0]
    assert result['status']=='VALIDATED' and len(client.heads)==2 and not client.puts


def test_template_cli_and_direction_immutability(monkeypatch):
    import mdpf_onboarding.onboard as onboard
    calls=[]
    monkeypatch.setattr(onboard,'generate',lambda uri,**kw:calls.append((uri,kw)) or 'oci://config@devns/template.yaml')
    assert onboard.main(['--config','oci://config@devns/input.yaml','--template-only'])==0
    assert calls[0][1]=={'baseline_yaml':None,'template_only':True}
    fresh=(ROOT.parent/'framework/sql/00_framework.sql').read_text()
    upgrade=(ROOT.parent/'framework/sql/05_pipeline_direction.sql').read_text()
    for content in (fresh,upgrade):
        assert content.count(':NEW.pipeline_direction <> :OLD.pipeline_direction')==2
        assert "CHECK (pipeline_direction IN ('INBOUND','OUTBOUND'))" in content


@pytest.mark.parametrize('error,quarantined',[(ValueError('storage unavailable'),False),
                                           (None,True)])
def test_parquet_quarantine_only_proven_data_errors(error,quarantined):
    from types import SimpleNamespace
    from mdpf.schema import DataValidationError
    from mdpf.steps import read_source
    error=error or DataValidationError('source schema mismatch')
    copies=[]
    def fail(*a):raise error
    fw=SimpleNamespace(pipeline_code='DMI_FEE',spark=None,
        storage=SimpleNamespace(read_parquet=fail),_receive_source=lambda *a:(7,None),
        _quarantine_source=lambda *a:copies.append(True))
    ctx={'framework':fw,'source_config':{'source_system_name':'DMI','quarantine_path':'oci://q@ns/prefix'},
         'inputs':{'FEE':{'dataset':{'storage_type':'PARQUET'},'location':'oci://landing@ns/fee.parquet','columns':[]}}}
    with pytest.raises(type(error)):read_source({},ctx,{})
    assert bool(copies)==quarantined


def test_native_parquet_discovery_preserves_types(spark,tmp_path):
    df=spark.createDataFrame([(123,'00123',date(2026,10,15),Decimal('12.50'))],
        'LN_NO long, CLIENT_NO string, MSP_CYCLE_DATE date, AMOUNT decimal(18,2)')
    path=str(tmp_path/'sample.parquet');df.write.parquet(path)
    sample=read_sample(spark,path)
    columns=discover(sample,source=True,overrides={},parquet=True)
    assert [(c['data_type'],c['length_precision_scale']) for c in columns]==[
        ('NUMBER','19,0'),('VARCHAR2','7 CHAR'),('DATE',None),('NUMBER','18,2')]
    assert convert_frame(sample,columns).first().CLIENT_NO=='00123'


def test_typed_parquet_end_to_end_preserves_fee_behaviour(spark,tmp_path):
    from test_dmi_fee import fee_handlers
    c=parquet_config();codes=dataset_codes(c);profiles={}
    for role,suffix in (('inputs','landing'),('outputs','main')):
        item=c[role][0];columns=explicit_columns(item['columns'],source=False)
        df=convert_frame(read_sample(spark,str(ROOT/'examples'/item['sample_csv'])),columns)
        validate_sample(df,columns,source=role=='inputs')
        profiles[codes[role][0][suffix]]=(df,columns)
    model=build_metadata(c,profiles)
    fw,db=prepare_execution(model,tmp_path,spark)
    try:
        b=fw.start_batch('typed-parquet','2026-10-15','MANUAL')['batch_id']
        for task in model['tasks']:
            result=fw.execute_task(b,task['row']['task_code'],custom_steps=fee_handlers())
            assert result['status']=='COMPLETED'
        assert [r['client_no'] for r in db.execute('SELECT CLIENT_NO FROM DMI_MAIN_DEV.DMI_FEE ORDER BY ROW_NUMBER')]==['C001','C002']
        assert [r['result_status'] for r in db.execute('SELECT result_status FROM RUNTIME.POLICY_RESULT')]==['PASS']*4
        raw=model['datasets']['DMI_FEE_FEE_RAW']['row'].copy();raw['physical_object_name']=raw['physical_object_name']['DEV']
        location=fw.output_path(db.one('SELECT * FROM RUNTIME.BATCH'),raw)
        assert '/ingest_date=20261015/batch_id=' in location and location.endswith('/fee_20261015.parquet')
        frame=fw.storage.read_parquet(spark,location)
        assert {'_batch_id','_run_id','_ingestion_item_id','_ingested_at'}<=set(frame.columns)
        assert frame.count()==2
    finally:
        db.close()


def test_public_generator_reads_parquet_sample_and_publishes_typed_contract(spark,tmp_path,monkeypatch):
    import mdpf_onboarding.onboard as onboard
    c=parquet_config();item=c['inputs'][0]
    sample=convert_frame(read_sample(spark,str(ROOT/'examples'/item['sample_csv'])),
                         explicit_columns(item['columns'],source=False))
    path=str(tmp_path/'input.parquet');sample.write.parquet(path)
    item['sample_csv']='oci://samples@devns/fee/input.parquet'
    del item['columns']
    client=MemoryOCI();uri='oci://config@devns/input/config.yaml'
    client.objects[uri]=yaml.safe_dump(c).encode()
    actual=read_sample
    monkeypatch.setattr(onboard,'read_sample',lambda session,location:actual(session,
        path if location.endswith('.parquet') else str(ROOT/'examples'/c['outputs'][0]['sample_csv'])))
    sql=generate(uri,spark=spark,client=client)
    complete=yaml.safe_load(client.objects[onboard.yaml_uri(c)])
    columns={col['column_name']:col for col in complete['inputs'][0]['columns']}
    assert columns['LN_NO']['data_type']=='NUMBER'
    assert columns['MSP_CYCLE_DATE']['data_type']=='DATE'
    assert columns['CLIENT_NO']['data_type']=='VARCHAR2'
    assert complete['inputs'][0]['source_format']=='PARQUET'
    assert len(client.puts)==3 and sql.endswith('_metadata_draft.sql')
    assert b'pipeline_direction' in client.objects[sql]
