# MDPF SQL Generator 1.0

Prepare input YAML from an optional CSV catalog, or edit an existing YAML. Then
generate complete YAML, DRAFT metadata SQL and optional reviewed MAIN DDL.
The generator does not execute DDL, activate metadata or launch pipeline tasks.

New developers: read the [developer guide](../framework/DEVELOPER_GUIDE.md), then
follow the example below. Extract both ZIPs into sibling `framework/` and
`generator/` folders for shared links. If this ZIP is opened alone, its own
[reference](REFERENCE.md) and supplied examples still describe its APIs/configuration;
obtain the companion Framework 1.0 wheel before installing.

| Reading path | Purpose |
|---|---|
| [Developer guide](../framework/DEVELOPER_GUIDE.md) | Local setup, actual calls, module ownership and tests |
| [Generator reference](REFERENCE.md) | Catalog/profile/YAML fields, schemas, DQ, comparison and DDL |
| [API and CLI contracts](REFERENCE.md#public-api-and-cli-contracts) | Return values, exceptions, client/session ownership and exit codes |
| [Operations](../framework/OPERATIONS.md) | OCI permissions, scheduling and worked investigations |
| [Current bundle validation](../../VALIDATION.txt) | Latest completed checks and pending live validation; dated release-note counts are historical |

## Parquet and planning without samples

Production DMI_FEE now uses Parquet landing deliveries and dated/batch-scoped Spark
output folders. The existing utility walkthrough below remains a CSV regression
reference. See [Parquet and template settings](REFERENCE.md#parquet-direction-and-incomplete-templates)
for both formats, bulk catalog columns, `pipeline.direction` and `--template-only`.
Template-only mode creates an explicitly incomplete YAML without Spark/sample I/O
or SQL/DDL. Normal generation still requires samples. The shared
[Vault helper](../framework/REFERENCE.md#oci-vault-to-hcp-vault-dedicated) reads HCP
AppRole/KV v2 secrets using bootstrap settings stored in OCI Vault.

## End-to-end quick start

This walkthrough uses `examples/dmi_fee.yaml`: pipeline `DMI_FEE`, dataset `FEE`,
source `DMI`, DEV target `DMI_MAIN_DEV.DMI_FEE`. It preserves the original twelve
business columns, required CLIENT_NO trim, two STAGE NOT_NULL policies and two
row-count reconciliations. Two sample rows total 15.25 in FEE_TRAN_AM. See the
[contract and target constraints](REFERENCE.md#dmi_fee-contract-and-bootstrap-replacement).
Alternative LOAN/JOIN/SPLIT/DQ examples remain fixtures; they are not setup steps.

### 1. Identify what can run

| Label | Actions you can execute |
|---|---|
| Local | Install development dependencies, edit/validate YAML and run tests with local Spark/SQLite/OCI doubles |
| OCI | Upload/read profile/catalog/config/samples and generate artifacts; generation needs Spark OCI access as well as the Python SDK |
| Oracle | Provision schemas/grants, deploy SQL/DDL, verify targets and activate a release |
| OCI + Oracle | Run RAW/STAGE/MAIN in a configured Spark environment and inspect actual outputs |
| Conceptual | Without provisioned infrastructure, read the remaining walkthrough after running local tests; the full example is not an offline CLI mode |

**Local — from the parent of the two extracted folders, Linux/bash:**

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e './framework[test]' -e './generator[test]'
python -m pip check
python -c "import mdpf, mdpf_onboarding; print(mdpf.__version__, mdpf_onboarding.__version__)"
mdpf-onboard --help
```

Use Python 3.10+ and Java 17. Expected: `1.0 1.0`, no dependency conflicts and CLI
help. From `generator/`, run `python -m pytest -q`. Tests need no live credentials.
Detailed setup and focused commands are in the developer guide.

### 2. Prepare the live development environment

**OCI + Oracle prerequisites:** an OCI Spark runtime; accessible landing/RAW/STAGE
and sample/artifact buckets; an Oracle connection; the 17-table framework, runtime
sequences/grants and the metadata release sequence. A DBA reviews fresh-install
`framework/sql/00_framework.sql`, `framework/sql/01_main_and_access.sql` and
`generator/sql/01_release_sequence.sql`. MAIN business DDL is generated separately; the DBA also reviews the original
DMI_FEE keys, REFERENCES privileges and target SELECT/INSERT grants documented
in the [contract](REFERENCE.md#dmi_fee-contract-and-bootstrap-replacement).
Do not rerun fresh-install DDL against an existing framework.

Install both supplied wheels together using approved dependency sources, then
restart notebook/worker sessions. For an existing same-version installation:

```bash
python -m pip install --force-reinstall ./framework/dist/mdpf-1.0-py3-none-any.whl ./generator/dist/mdpf_onboarding-1.0-py3-none-any.whl
```

Use platform Spark/Java. Add `--no-deps` only when dependencies are already present.
The generator declares `mdpf==1.0`; both companion wheels are needed.

Supply Oracle settings securely: `MDPF_DB_USER`, `MDPF_DB_PASSWORD`,
`MDPF_DB_DSN`, plus wallet settings when required. Configure Python OCI SDK
authentication separately from Spark's driver/worker bucket access. Default SDK
creation uses Resource Principal; if your notebook does not expose it, pass an
existing approved SDK client using `client=`. See the developer guide's connection
checks and [OCI permissions](../framework/OPERATIONS.md#oci-permissions).

The following OCI notebook blocks assume the parent folder containing both
extracted packages is available as the working directory, and `spark` is the
configured session. Replace illustrative OCI values; no credentials belong in YAML.
Only DEV objects are read/written during this example; every environment's path
settings must still pass configuration validation.

Create/reuse the SDK client before choosing either route. **OCI notebook Python:**

```python
from pathlib import Path
from mdpf.storage import object_address
from mdpf_onboarding.onboard import object_client

client = object_client()  # Or use your existing approved ObjectStorageClient.
```

### 3. Choose one onboarding starting point

**Route A — existing YAML (used by the rest of this walkthrough). Local:**

```bash
cp generator/examples/dmi_fee.yaml generator/examples/dmi_fee_dev.yaml
```

Edit the copy's `environments`, `sql_output` and sample locations for your tenancy.
Use a new metadata release/destination if DMI_FEE release `1.0` already exists.
Keep both explicit business schemas, the custom STAGE/MAIN plans, all four
policies and `generate_main_ddl: true`. These preserve the original DMI_FEE behavior.

**Local — validate the edited copy without accessing buckets or Oracle:**

```python
import yaml
from pathlib import Path
from mdpf_onboarding.config import UniqueLoader, validate_config

config = validate_config(yaml.load(
    Path('generator/examples/dmi_fee_dev.yaml').read_text(), Loader=UniqueLoader))
print(config['pipeline']['code'])
```

Expected: `DMI_FEE`. This checks configuration contracts for all environments;
it does not prove that any bucket exists or that its permissions are correct.

With relative `samples/fee_input.csv` and `samples/fee_output.csv`, upload the
samples beneath the input YAML's OCI directory. **OCI — notebook Python:**

```python
INPUT_YAML = 'oci://mdpf-dev-artifacts@devns/onboarding/dmi_fee/1.0/input/dmi_fee.yaml'
INPUT_ROOT = INPUT_YAML.rsplit('/', 1)[0]
uploads = [
    (INPUT_YAML, 'generator/examples/dmi_fee_dev.yaml', 'application/yaml'),
    (INPUT_ROOT + '/samples/fee_input.csv', 'generator/examples/samples/fee_input.csv', 'text/csv'),
    (INPUT_ROOT + '/samples/fee_output.csv', 'generator/examples/samples/fee_output.csv', 'text/csv'),
]
for uri, path, kind in uploads:
    client.put_object(*object_address(uri), Path(path).read_bytes(),
                      content_type=kind, if_none_match='*')
print(INPUT_YAML)
```

Expected: three objects exist and the input URI is printed. A 412 means an object
already exists; inspect it or choose a new destination rather than blindly overwrite.

**Route B — bulk builder, an alternative to Route A. OCI:**

Edit/upload `examples/shared_profile.yaml` and a catalog containing the existing
DMI_FEE row below. Keep the shared samples root `oci://mdpf-samples@devns/dmi`.
Upload packaged `fee_input.csv` as `fee/input.csv` and `fee_output.csv` as
`fee/output.csv` beneath that root. The sample uploader needs create permission.

```csv
pipeline_code,dataset_code,source_system,input_sample_csv,output_sample_csv,target_table
DMI_FEE,FEE,DMI,fee/input.csv,fee/output.csv,DMI_FEE
```

The explicit target prevents the builder's default table name `FEE`. The supplied
full catalog retains LOAN/CLIENT rows and their targets/relative paths. To run all
three, supply all six actual sample objects; otherwise rows with missing samples
fail independently. For this single-pipeline walkthrough upload only the FEE row.

```python
from pprint import pprint
from mdpf_onboarding.bulk_builder import build_catalog
from mdpf_onboarding.config import validate_config
from mdpf_onboarding.onboard import load_config

PROFILE = 'oci://mdpf-dev-artifacts@devns/profiles/shared.yaml'
CATALOG = 'oci://mdpf-dev-artifacts@devns/catalogs/dmi_fee.csv'
pprint(build_catalog(PROFILE, CATALOG, dry_run=True, client=client))
results = build_catalog(PROFILE, CATALOG, dry_run=False, client=client)
pprint(results)
```

Expected per valid row: VALIDATED in preview, then CREATED or SKIPPED on save.
The builder creates `onboarding/dmi_fee/1.0/input/config.yaml`; it does not create
`input/dmi_fee.yaml`. It sets the target from the catalog, but does **not** create
the DMI_FEE business schemas, custom plan or DQ policies. Review the saved input
and add them before generation. This small example copies those contracts from
the supplied YAML and writes a **new reviewed input** without overwriting the
builder's original (run only for the intended FEE row):

```python
import yaml

row = next(r for r in results if r['pipeline_code'] == 'DMI_FEE')
assert row['status'] in ('CREATED', 'SKIPPED')
built = load_config(row['yaml_uri'], client=client)
template = yaml.safe_load(Path('generator/examples/dmi_fee.yaml').read_text())
assert built['outputs'][0]['target_table'] == 'DMI_FEE'
for role in ('inputs', 'outputs'):
    built[role][0]['columns'] = template[role][0]['columns']
built['task_overrides'] = template['task_overrides']
built['dq_rules'] = template['dq_rules']
built['sql_output']['generate_main_ddl'] = True
built = validate_config(built)
INPUT_YAML = row['yaml_uri'].rsplit('/', 1)[0] + '/config_reviewed.yaml'
client.put_object(*object_address(INPUT_YAML),
                  yaml.safe_dump(built, sort_keys=False).encode(),
                  content_type='application/yaml', if_none_match='*')
```

`SKIPPED` only means the original object exists; inspect its settings before copying.
Do not rerun conditional uploads blindly. A pre-existing release/input needs an
explicitly reviewed new destination. Both routes generate complete YAML at
`onboarding/dmi_fee/1.0/generated/dmi_fee.yaml`, with separate metadata SQL and
optional MAIN DDL objects. All artifacts must differ from inputs/samples/baseline.
The two routes may resolve samples differently; byte-identical artifacts are not
promised for differently configured inputs.

**Choose A or B, then continue.** The builder performs sample HEAD checks without
reading sample contents. It does not infer schemas. Direct-YAML generation does
not require `build_catalog()`.

### 4. Generate and review artifacts

**OCI — Oracle is not required for generation:**

```python
from mdpf_onboarding.onboard import generate

sql_uri = generate(INPUT_YAML, spark=spark, client=client)
print(sql_uri)
```

Expected: schema/task summary, complete YAML, optional MAIN DDL and metadata SQL
URI. The supplied Route A config emits `dmi_fee.yaml`,
`dmi_fee_main_ddl.sql` and `dmi_fee_metadata_draft.sql` under
`sql_output.path`. Review all resolved schemas and DEV/STAGE/PROD locations.

Generation prints its summary before uploading YAML → optional DDL → metadata SQL.
Uploads are independent and create-only unless overwrite is deliberately enabled.
A later upload failure may leave earlier objects. Empty-column inference can return
`None` and print required overrides; supply them and generate again.

To download this example's generated artifacts for manual review, in the same
notebook and working directory:

```python
from mdpf_onboarding.onboard import load_config, main_ddl_uri, yaml_uri

config = load_config(INPUT_YAML, client=client)
assert sql_uri is not None
artifacts = [sql_uri, yaml_uri(config)]
if config['sql_output']['generate_main_ddl']:
    artifacts.append(main_ddl_uri(config))
for uri in artifacts:
    filename = uri.rsplit('/', 1)[-1]
    Path(filename).write_bytes(client.get_object(*object_address(uri)).data.content)
    print(filename)
```

For later pipeline enhancements, use a new metadata release and
`generate(..., baseline_yaml=previous_complete_yaml_uri)`. Baseline comparison uses
explicit complete contracts and does not read baseline samples. Published metadata
remains immutable; software version and metadata release_version are independent.

### 5. Deploy, verify and activate manually

**Oracle — use a reviewed SQLcl/SQL*Plus deployment session in the directory
containing the downloaded artifacts, connected through your approved secure method.**
The target owner must exist. Review DDL against the actual table and have a DBA
review the separately documented keys/REFERENCES privileges and grant the
runtime account INSERT/SELECT access to the example target. Generated DDL does
not add these constraints or grants. For an existing table, review/skip CREATE
rather than rerun it; verify its actual contract before metadata activation.

```sql
VARIABLE target_env VARCHAR2(10)
EXEC :target_env := 'DEV';
@dmi_fee_main_ddl.sql
@dmi_fee_metadata_draft.sql
SELECT config_release_id, pipeline_code, release_version, release_status
  FROM METADATA.CONFIG_RELEASE WHERE pipeline_code='DMI_FEE';
```

Expected: target `DMI_MAIN_DEV.DMI_FEE` exists and the new metadata release is DRAFT.
Oracle DDL commits independently; it is not rolled back with later deployment SQL.

**Oracle — separate read-only target gate, notebook Python:**

```python
from mdpf.db import OracleDb
from mdpf_onboarding.oracle_gate import verify_main_targets

db = OracleDb()
try:
    print(verify_main_targets(db, pipeline_code='DMI_FEE', release_version='1.0'))
finally:
    db.close()
```

Expected for the unmodified DEV example: `['DMI_MAIN_DEV.DMI_FEE']`. Use the actual
metadata version if changed. This checks visible table/column compatibility, not
all runtime grants or live insert/concurrency behavior.

After approval, use the deployment session to promote the reviewed release.
**Oracle — initial isolated DEV example, adapt version and review any prior ACTIVE:**

```sql
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
VARIABLE demo_release_id NUMBER
BEGIN
  SELECT config_release_id INTO :demo_release_id
    FROM METADATA.CONFIG_RELEASE
   WHERE pipeline_code='DMI_FEE' AND release_version='1.0';
END;
/
UPDATE METADATA.CONFIG_RELEASE SET release_status='APPROVED'
 WHERE config_release_id=:demo_release_id AND release_status='DRAFT';
UPDATE METADATA.CONFIG_RELEASE SET release_status='RETIRED'
 WHERE pipeline_code='DMI_FEE' AND release_status='ACTIVE'
   AND config_release_id<>:demo_release_id;
UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE'
 WHERE config_release_id=:demo_release_id AND release_status='APPROVED';
COMMIT;
SELECT config_release_id, release_status FROM METADATA.CONFIG_RELEASE
 WHERE config_release_id=:demo_release_id;
```

Expected: the reviewed release is ACTIVE, with at most one ACTIVE per pipeline.
Follow controlled deployment/approval procedures; the generator performs none of
these changes. Existing batches retain their pinned release.

### 6. Run RAW, STAGE and MAIN

**OCI + Oracle — prepared Spark notebook.** Put the actual landing delivery at the
configured DEV input path. For the supplied cycle it is
`oci://dev-landing@devns/landing/dmi_fee/fee_20261015.csv`; adjust the namespace/bucket
to match your reviewed configuration. The sample object used during generation is
not automatically a landing delivery:

```python
LANDING = 'oci://dev-landing@devns/landing/dmi_fee/fee_20261015.csv'
client.put_object(*object_address(LANDING),
                  Path('generator/examples/samples/fee_input.csv').read_bytes(),
                  content_type='text/csv', if_none_match='*')
spark.conf.set('spark.sql.session.timeZone', 'UTC')
```

Expected: one dated landing object exists. For this small manual notebook demo,
the shared runner can execute one task at a time:

```python
from uuid import uuid4
from mdpf.runner import execute_task
from pyspark.sql import functions as F

# Reference example only; production imports the provider package.
def trim_fee(frames, context, params):
    return {'DMI_FEE_FEE_STAGE': frames['DMI_FEE_FEE_RAW'].withColumn(
        params['column'], F.trim(F.col(params['column'])))}

custom_steps = {'CUSTOM_FEE_TRANSFORM': trim_fee}
KEY = 'MANUAL_DMI_FEE:' + str(uuid4())
print('Keep this workflow key for inspection/retry:', KEY)
for role in ('RAW', 'STAGE', 'MAIN'):
    result = execute_task(
        pipeline_code='DMI_FEE', task_code='DMI_FEE_' + role + '_LOAD',
        execution_key=KEY, task_run_id='MANUAL_NOTEBOOK:' + str(uuid4()),
        cycle_date='2026-10-15', execution_mode='MANUAL',
        triggered_by='MANUAL_NOTEBOOK', spark=spark, custom_steps=custom_steps)
    print(role, result['batch_id'], result['task_run_id'], result['status'])
```

Each manual invocation has a fresh identity. If a task fails, the loop stops;
retain KEY and retry only failed/downstream tasks with fresh attempt identities.
Do not rerun completed tasks or regenerate KEY for a retry.

For scheduled operation, use the supplied AIDP/Data Flow adapters instead, binding
actual platform run identities. Supply explicit pipeline/task codes to generic
RAW/MAIN starters. Register the required trim only in a provider-owned STAGE launcher. Do not forge Data Flow run OCIDs. See [platform execution](../framework/REFERENCE.md#run-from-data-flow--activebatch)
and [two-phase scheduling](../framework/OPERATIONS.md#two-phase-scheduling).

### 7. Verify results

**Oracle — inspection session:**

```sql
SELECT batch_id, execution_key, config_release_id, cycle_date, status
  FROM RUNTIME.BATCH WHERE pipeline_code='DMI_FEE' ORDER BY batch_id;
SELECT tr.batch_id, tr.task_run_id, tr.attempt_number, t.task_code,
       tr.status, tr.input_count, tr.output_count
  FROM RUNTIME.TASK_RUN tr JOIN METADATA.TASK t
    ON t.config_release_id=tr.config_release_id AND t.task_id=tr.task_id
 WHERE t.task_code LIKE 'DMI_FEE_%' ORDER BY tr.batch_id, tr.task_run_id;
SELECT batch_id, COUNT(*) rows_loaded FROM DMI_MAIN_DEV.DMI_FEE GROUP BY batch_id;
SELECT ln_no, client_no, fee_tran_am, created_at, updated_at
  FROM DMI_MAIN_DEV.DMI_FEE ORDER BY batch_id, row_number;
```

For the unchanged two-row sample, each task completes with two inputs/outputs;
the new batch is COMPLETED and its MAIN count is two. CLIENT_NO values are
`C001` and `C002`, with surrounding spaces removed; total FEE_TRAN_AM is 15.25. RAW/STAGE Parquet is under its configured dataset prefix plus
`/batch_<batch_id>`. Source receipts are PROCESSED. Expect four passing POLICY_RESULT rows: two STAGE NOT_NULL checks,
STAGE count versus RAW and MAIN actual inserts versus STAGE.

After RAW alone the batch is RUNNING; this is valid for delayed STAGE/MAIN.
MAIN checks actual affected-row counts and closes the batch on success. Inspect
by the printed key/batch/attempt rather than assuming numeric IDs.

Use the [worked investigations](../framework/OPERATIONS.md#worked-investigations)
for RAW quarantine, STAGE DQ and MAIN count mismatch. The default MAIN cap is
100,000 rows across all outputs per task. Five managed audit fields belong to the
framework; they are not business YAML columns. Archive, row rejection, MERGE and
a waiting dashboard remain outside scope. A ZIP of unrelated CSV datasets is
represented by independent catalog rows using extracted samples; this builder
does not unpack ZIP deliveries.
