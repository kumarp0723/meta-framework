"""Explicit read-only verification of deployed Oracle MAIN targets."""
import re

from mdpf import schema as mdpf_schema
from mdpf.schema import sql_identifier, spark_type


def verify_main_targets(db, *, pipeline_code, release_version):
    """Read deployed MAIN contracts for one pipeline/release using the supplied db.

    Return verified qualified target names. Missing/incompatible columns, capacity,
    audit timestamps, extra required columns or character sets raise ValueError.
    Database/access errors propagate. No DDL, metadata activation or commit occurs;
    the caller owns the connection. This gate is explicitly separate from generate()."""
    release=db.one('SELECT config_release_id FROM METADATA.CONFIG_RELEASE WHERE pipeline_code=:p AND release_version=:v',
        p=pipeline_code,v=release_version)
    if not release:raise ValueError('Unknown pipeline/release for Oracle verification.')
    charset=db.one("SELECT value FROM NLS_DATABASE_PARAMETERS WHERE parameter='NLS_CHARACTERSET'")
    if not charset or charset['value']!='AL32UTF8':
        raise ValueError('This POC gate requires AL32UTF8, matching MDPF UTF-8 byte validation; other database character sets need DBA review.')
    targets=db.execute("SELECT * FROM METADATA.DATASET WHERE config_release_id=:r AND layer='GOLD' AND storage_type='ADB_TABLE'",
        r=release['config_release_id'])
    if not targets:raise ValueError('Release has no Oracle MAIN targets.')
    checked=[]
    for target in targets:
        full=sql_identifier(target['physical_object_name'],qualified=True)
        owner,table=full.split('.')
        if not db.one('SELECT table_name FROM ALL_TABLES WHERE owner=:o AND table_name=:t',o=owner,t=table):
            raise ValueError(f'{full}: physical Oracle table is missing or inaccessible.')
        actual=db.execute('''SELECT c.column_name,c.data_type,c.data_length,c.char_length,c.char_used,
            c.data_precision,c.data_scale,c.nullable,c.data_default,c.identity_column,c.virtual_column,
            c.user_generated,i.generation_type FROM ALL_TAB_COLS c
            LEFT JOIN ALL_TAB_IDENTITY_COLS i ON i.owner=c.owner AND i.table_name=c.table_name AND i.column_name=c.column_name
            WHERE c.owner=:o AND c.table_name=:t''',o=owner,t=table)
        actual={c['column_name']:c for c in actual}
        expected=db.execute('SELECT * FROM METADATA.DATASET_COLUMN WHERE config_release_id=:r AND dataset_id=:d ORDER BY column_sequence',
            r=release['config_release_id'],d=target['dataset_id'])
        mdpf_schema.validate_columns(expected)
        expected += [dict(column_name=n,data_type='NUMBER',length_precision_scale='19,0',is_nullable='N')
                     for n in ('BATCH_ID','TASK_RUN_ID','ROW_NUMBER')]
        expected += [dict(column_name=n, data_type='TIMESTAMP WITH TIME ZONE', is_nullable='N')
                     for n in ('CREATED_AT','UPDATED_AT')]
        for e in expected:
            name=e['column_name'];a=actual.get(name)
            actual_type = re.sub(r'^TIMESTAMP\([0-9]+\) WITH TIME ZONE$', 'TIMESTAMP WITH TIME ZONE', a['data_type']) if a else None
            if not a or actual_type!=e['data_type']:
                raise ValueError(f'{full}.{name}: missing column or incompatible datatype.')
            if e['data_type']=='TIMESTAMP WITH TIME ZONE':
                declared = re.fullmatch(r'TIMESTAMP\(([0-9]+)\) WITH TIME ZONE', a['data_type'])
                precision = a.get('data_scale')
                if precision is None:
                    precision = int(declared[1]) if declared else 6
                if int(precision)<6:
                    raise ValueError(f'{full}.{name}: timestamp precision must be at least 6.')
            if a.get('virtual_column')=='YES' or a.get('generation_type')=='ALWAYS':
                raise ValueError(f'{full}.{name}: column cannot accept the framework INSERT value.')
            if a['nullable']=='N' and e['is_nullable']=='Y':
                raise ValueError(f'{full}.{name}: Oracle NOT NULL requires metadata is_nullable=N.')
            if e['data_type']=='VARCHAR2':
                limit,unit=mdpf_schema.string_limit(e)
                # AL32UTF8 uses up to four bytes per character. Check both limits.
                bytes_required=limit*4 if unit=='CHAR' else limit
                if a['data_length']<bytes_required or (a['char_used']=='C' and a['char_length']<limit):
                    raise ValueError(f'{full}.{name}: insufficient character/byte capacity for the metadata contract.')
            elif e['data_type']=='NUMBER' and not (a['data_precision'] is None and a['data_scale'] is None):
                typ=spark_type(e);precision=int(a['data_precision'] or 38);scale=int(a['data_scale'] or 0)
                if scale<typ.scale or precision-scale<typ.precision-typ.scale:
                    raise ValueError(f'{full}.{name}: insufficient precision/scale; Oracle could overflow or round.')
        supplied={e['column_name'] for e in expected}
        for name,a in actual.items():
            if name in supplied or a['nullable']=='Y' or a.get('virtual_column')=='YES' or a.get('identity_column')=='YES' or a.get('user_generated')=='NO':
                continue
            default=str(a.get('data_default') or '').strip()
            if not default or default.upper() in ('NULL','(NULL)'):
                raise ValueError(f'{full}.{name}: required extra column has no usable default or generated value.')
        checked.append(full)
    return checked
