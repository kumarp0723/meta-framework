"""Profile CSV/Parquet samples and reuse MDPF's exact schema/conversion checks."""
import math
import re

from pyspark.sql import functions as F, types as T
from mdpf.schema import RESERVED, convert_frame, spark_type, sql_identifier, validate_columns, validate_frame


class SchemaOverridesRequired(ValueError):
    """All empty target columns that still need an explicit schema contract."""
    def __init__(self, columns):
        self.columns = columns
        super().__init__('All-null target columns require datatype/length overrides: ' + ', '.join(columns))


def read_sample(spark, path):
    if path.lower().endswith('.parquet'):
        df = spark.read.parquet(path)
        if not df.columns or len({c.upper() for c in df.columns}) != len(df.columns):
            raise ValueError('Duplicate or missing Parquet columns.')
        return df
    # Keep these options identical to mdpf.storage.ObjectStorage.read_csv.
    df = spark.read.options(header=True, inferSchema=False, mode='FAILFAST',
                            multiLine=True, escape='"').csv(path)
    if not df.columns or len({c.upper() for c in df.columns}) != len(df.columns):
        raise ValueError(f'Duplicate or missing CSV headers: {path}')
    return df


def validate_overrides(overrides, *, source):
    """Check YAML settings now; sample discovery checks column existence and values."""
    if not isinstance(overrides, dict):
        raise ValueError('Column overrides must be a mapping.')
    for name, override in overrides.items():
        sql_identifier(name)
        if name in RESERVED or not isinstance(override, dict) or set(override) - {
                'data_type', 'length_precision_scale', 'is_nullable', 'is_pii'}:
            raise ValueError(f'Invalid column override: {name}')
        for flag in ('is_nullable', 'is_pii'):
            if flag in override and override[flag] not in ('Y', 'N'):
                raise ValueError(f'{flag} must be Y or N: {name}')
        kind, spec = override.get('data_type'), override.get('length_precision_scale')
        if 'data_type' in override and kind not in ('VARCHAR2', 'NUMBER', 'DATE'):
            raise ValueError(f'Unsupported override data_type: {name}')
        if source and kind not in (None, 'VARCHAR2'):
            raise ValueError('LANDING/RAW overrides must preserve VARCHAR2 source representation.')
        if spec is not None and (not isinstance(spec, str) or not spec.strip() or len(spec.encode('utf-8')) > 100):
            raise ValueError(f'length_precision_scale must be text of at most 100 bytes: {name}')
        if kind and (spec is not None or kind == 'DATE'):
            spark_type(override)


def explicit_columns(entries, *, source):
    """A complete ordered contract; never fill its missing fields through inference."""
    if not isinstance(entries, list) or not entries:
        raise ValueError('columns must be a nonempty ordered list.')
    result = []
    for index, entry in enumerate(entries, 1):
        if (not isinstance(entry, dict) or not {'column_name', 'data_type'} <= entry.keys() or
                set(entry) - {'column_name', 'data_type', 'length_precision_scale', 'is_nullable', 'is_pii'}):
            raise ValueError('columns entries require column_name/data_type; optional length_precision_scale/is_nullable/is_pii.')
        column = {'length_precision_scale': None, 'is_nullable': 'Y', 'is_pii': 'N', **entry}
        if column['is_pii'] not in ('Y', 'N'):
            raise ValueError('is_pii must be Y or N.')
        if source and column['data_type'] != 'VARCHAR2':
            raise ValueError('LANDING/RAW columns must preserve VARCHAR2 source representation.')
        result.append(dict(column_sequence=index, **column))
    validate_columns(result)
    return result


def validate_sample(df, columns, *, source):
    """Validate the declared contract without changing it from sample statistics."""
    from mdpf.schema import require_columns
    require_columns(df, columns, 'Sample schema')
    converted = convert_frame(df, columns)
    validate_frame(converted, columns, 'Sample', source=source, oracle=not source)
    if not df.limit(1).count():
        raise ValueError('CSV sample must contain at least one data row.')
    return columns


def discover(df, *, source, overrides, growth=25, nullable='Y', parquet=False):
    """Profile CSV strings or preserve supported native Parquet types."""
    if parquet:
        native = {}
        for field in df.schema:
            kind = field.dataType
            if isinstance(kind, T.StringType):
                continue
            if isinstance(kind, T.DecimalType) and kind.scale >= 0:
                native[field.name] = dict(data_type='NUMBER', length_precision_scale=f'{kind.precision},{kind.scale}')
            elif isinstance(kind, (T.ByteType, T.ShortType, T.IntegerType, T.LongType)):
                precision = {T.ByteType:3, T.ShortType:5, T.IntegerType:10, T.LongType:19}[type(kind)]
                native[field.name] = dict(data_type='NUMBER', length_precision_scale=f'{precision},0')
            elif isinstance(kind, T.DateType):
                native[field.name] = dict(data_type='DATE')
            else:
                raise ValueError(f'Unsupported Parquet type for {field.name}: {kind.simpleString()}; normalize to string, decimal/integer or date first.')
        merged = {name: {**value, **overrides.get(name,{})} for name,value in native.items()}
        merged.update({name:value for name,value in overrides.items() if name not in merged})
        # String columns retain string identity (including leading zeroes).
        for field in df.schema:
            if isinstance(field.dataType,T.StringType):
                merged[field.name] = {'data_type':'VARCHAR2', **merged.get(field.name,{})}
        strings = df.select(*[F.col(n).cast('string').alias(n) for n in df.columns])
        columns = discover(strings,source=False,overrides=merged,growth=growth,nullable=nullable)
        return validate_sample(df,columns,source=source)
    validate_overrides(overrides, source=source)
    unknown = set(overrides) - set(df.columns)
    if unknown:
        raise ValueError(f'Column overrides reference missing CSV columns: {sorted(unknown)}')
    measures = [F.count('*').alias('rows')]
    for i, name in enumerate(df.columns):
        # Validate identifiers before using them in quoted Spark expressions.
        validate_columns([dict(column_name=name, column_sequence=1, data_type='VARCHAR2',
                               length_precision_scale='1 CHAR', is_nullable='Y')])
        v = F.col(name)
        number = v.rlike(r'^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)$')
        whole = F.regexp_replace(F.regexp_extract(v, r'^[+-]?([0-9]*)', 1), '^0+', '')
        fraction = F.regexp_extract(v, r'\.([0-9]*)$', 1)
        iso = v.rlike(r'^[0-9]{4}-[0-9]{2}-[0-9]{2}$') & ~v.startswith('0000')
        as_date = F.expr(f'try_cast(`{name}` AS DATE)')
        measures += [F.count(v).alias(f'n{i}'), F.max(F.length(v)).alias(f'l{i}'),
            F.sum(F.when(v.isNotNull() & ~number, 1).otherwise(0)).alias(f'badnum{i}'),
            F.max(F.length(whole)).alias(f'p{i}'), F.max(F.length(fraction)).alias(f's{i}'),
            F.sum(F.when(v.rlike(r'^[+-]?0[0-9]+(?:\.|$)'), 1).otherwise(0)).alias(f'zero{i}'),
            F.sum(F.when(v.isNotNull() & (~iso | as_date.isNull()), 1).otherwise(0)).alias(f'baddate{i}')]
    stats = df.agg(*measures).first().asDict()
    if not stats['rows']:
        raise ValueError('CSV sample must contain at least one data row.')
    result, missing = [], {}
    for i, name in enumerate(df.columns):
        override = overrides.get(name, {})
        if not source and not stats[f'n{i}']:
            kind = override.get('data_type')
            if not kind:
                missing[name] = dict(data_type='<VARCHAR2, NUMBER or DATE>',
                    length_precision_scale='<length or precision,scale; omit for DATE>')
                continue
            if kind in ('VARCHAR2', 'NUMBER') and not override.get('length_precision_scale'):
                missing[name] = dict(data_type=kind, length_precision_scale=(
                    '<length BYTE or CHAR>' if kind == 'VARCHAR2' else '<precision,scale>'))
                continue
        size = max(1, math.ceil((stats[f'l{i}'] or 0) * (1 + growth / 100)))
        kind, spec = 'VARCHAR2', f'{size} CHAR'
        identifier = re.search(r'(^|_)(ID|NO|CODE|CD|ZIP|PHONE|ACCOUNT|NUMBER)$', name)
        if not source and stats[f'n{i}'] and not identifier and not stats[f'zero{i}']:
            if not stats[f'baddate{i}']:
                kind, spec = 'DATE', None
            elif not stats[f'badnum{i}']:
                scale = int(stats[f's{i}'] or 0)
                precision = max(1, int(stats[f'p{i}'] or 0) + scale)
                if precision <= 38:
                    kind, spec = 'NUMBER', f'{precision},{scale}'
        inferred = kind
        kind = override.get('data_type', kind)
        if kind != inferred:
            spec = f'{size} CHAR' if kind == 'VARCHAR2' else None
        if kind == 'DATE':spec = None
        spec = override.get('length_precision_scale', spec)
        column = dict(column_sequence=i+1, column_name=name, data_type=kind,
            length_precision_scale=spec, is_nullable=override.get('is_nullable', 'Y' if source else nullable),
            is_pii=override.get('is_pii', 'N'))
        result.append(column)
    if missing:
        raise SchemaOverridesRequired(missing)
    validate_columns(result)
    # The same two functions used by MDPF, including nullability, lengths and conversion loss.
    converted = convert_frame(df, result)
    validate_frame(converted, result, 'Sample', source=source, oracle=not source)
    return result


def validate_conversion(df, columns, *, oracle=False):
    converted = convert_frame(df, columns)
    validate_frame(converted, columns, 'Built-in sample conversion', oracle=oracle)
    return converted
