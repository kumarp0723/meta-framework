"""Turn an OCI CSV catalog into independent onboarding input YAMLs."""
from collections import Counter, defaultdict
import csv
import io

from oci.exceptions import ServiceError

from mdpf.storage import object_address
from .builder import build_config, config_uri, load_profile, save_config
from .config import oci_uri, sample_uri
from .onboard import object_client


REQUIRED = ('pipeline_code', 'dataset_code', 'source_system',
            'input_sample_csv', 'output_sample_csv')
OPTIONAL = ('release_version', 'file_name', 'target_table', 'source_format', 'pipeline_direction')


def _read_catalog(catalog_uri, client):
    data = client.get_object(*object_address(catalog_uri)).data.content
    reader = csv.DictReader(io.StringIO(data.decode('utf-8-sig'), newline=''), strict=True)
    headers = reader.fieldnames
    if headers is None:
        raise ValueError('Catalog is empty; the required header and at least one row are needed.')
    headers = [name.strip() for name in headers]
    if (len(set(headers)) != len(headers) or not set(REQUIRED) <= set(headers)
            or set(headers) - set(REQUIRED + OPTIONAL)):
        raise ValueError(f'Catalog headers: required {REQUIRED}; optional {OPTIONAL}; duplicates are not allowed.')
    reader.fieldnames = headers
    records = []
    for record in reader:
        if None in record or any(value is None for value in record.values()):
            raise ValueError('Every catalog record must have the same number of fields as the header.')
        records.append({key: value.strip() for key, value in record.items()})
    if not records:
        raise ValueError('Catalog must contain at least one dataset row.')
    return records


def build_catalog(profile_uri, catalog_uri, *, dry_run=True, client=None, template_only=False):
    """Preview or create independent input YAMLs from an OCI profile and CSV catalog.

    dry_run defaults to True. Validate conflicts and HEAD exact input/output samples
    before writes, without downloading samples or inferring schemas. Return row
    dictionaries: row, pipeline_code, status, yaml_uri, message. Valid rows continue
    independently; existing YAMLs become SKIPPED. Global profile/catalog errors
    propagate. template_only=True permits unknown samples and writes marked
    placeholders without sample HEADs. Reuse client when supplied; otherwise use
    Resource Principal auth."""
    if not isinstance(dry_run, bool) or not isinstance(template_only,bool):
        raise ValueError('dry_run and template_only must be boolean.')
    profile_uri, catalog_uri = oci_uri(profile_uri), oci_uri(catalog_uri)
    if not catalog_uri.lower().endswith('.csv'):
        raise ValueError('Catalog must be an OCI .csv object.')
    client = client if client is not None else object_client()
    profile = load_profile(profile_uri, client=client)
    records = _read_catalog(catalog_uri, client)
    results, configs = [], []
    groups = {name: defaultdict(list) for name in ('pipeline', 'target table', 'YAML destination')}
    protected = {profile_uri, catalog_uri}
    for index, record in enumerate(records):
        result = dict(row=index + 1, pipeline_code=record['pipeline_code'],
                      status='VALIDATED', yaml_uri=None, message='Configuration valid; sample existence not yet checked.')
        config = None
        try:
            missing = [field for field in REQUIRED if not record[field] and
                       not (template_only and field.endswith('_sample_csv'))]
            if missing:
                raise ValueError('Required values are blank: ' + ', '.join(missing))
            config = build_config(profile, **{field: record[field] for field in REQUIRED},
                                  **{field: record[field] for field in OPTIONAL if record.get(field)},
                                  template_only=template_only)
            result['yaml_uri'] = config_uri(profile, config)
            groups['YAML destination'][result['yaml_uri']].append(index)
        except Exception as exc:
            result.update(status='FAILED', message=str(exc))
        results.append(result)
        configs.append(config)
        for field, value in (('pipeline', record['pipeline_code']),
                             ('target table', record.get('target_table') or record['dataset_code'])):
            if value:
                groups[field][value.upper()].append(index)
        for field in ('input_sample_csv', 'output_sample_csv'):
            if record[field]:
                try:
                    protected.add(sample_uri(profile_uri, record[field], profile['samples_root']))
                except ValueError:
                    pass  # The row's configuration validation reports invalid sample paths.

    # Finish all conflict checks before publishing any row.
    for label, identities in groups.items():
        for value, indexes in identities.items():
            if len(indexes) > 1:
                for index in indexes:
                    result = results[index]
                    message = f'Conflicting {label}: {value}; catalog rows ' + ', '.join(str(i + 1) for i in indexes)
                    if result['status'] == 'FAILED':
                        message = result['message'] + '; ' + message
                    result.update(status='FAILED', message=message)
    for result in results:
        if result['yaml_uri'] in protected:
            result.update(status='FAILED', message='YAML destination collides with the profile, catalog or a sample.')

    # HEAD checks confirm the exact objects without downloading their contents.
    # Run in preview and save mode, before any YAML uploads.
    for result, config in zip(results, configs):
        if result['status'] == 'FAILED':
            continue
        if template_only:
            result['message'] = 'INCOMPLETE template valid; sample existence and schema not checked. No SQL/DDL.'
            continue
        try:
            for item in config['inputs'] + config['outputs']:
                uri = item['sample_csv']
                client.head_object(*object_address(uri))
        except Exception as exc:
            result.update(status='FAILED', message=f'Sample existence check failed for {uri}: {exc}')
        else:
            result['message'] = 'Configuration valid; sample objects exist. Contents not checked.'

    if not dry_run:
        for result, config in zip(results, configs):
            if result['status'] == 'FAILED':
                continue
            try:
                save_config(profile, config, client=client,template_only=template_only)
                result.update(status='CREATED', message='INCOMPLETE template created; fill placeholders before generation.' if template_only else 'Input YAML created.')
            except ServiceError as exc:
                if exc.status == 412 and exc.code in ('PreconditionFailed', 'NoEtagMatch'):
                    result.update(status='SKIPPED', message='Destination exists; preserved without comparing its contents.')
                else:
                    result.update(status='FAILED', message=str(exc))
            except Exception as exc:
                result.update(status='FAILED', message=str(exc))
    counts = Counter(result['status'] for result in results)
    print('Catalog results: ' + ', '.join(f'{name}={counts[name]}' for name in ('VALIDATED', 'CREATED', 'SKIPPED', 'FAILED')))
    return results
