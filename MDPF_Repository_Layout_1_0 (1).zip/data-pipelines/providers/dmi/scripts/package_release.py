"""Assemble a provider release from reviewed outputs and a pinned Framework ZIP."""
import argparse
from email.parser import Parser
import hashlib
import io
import json
from pathlib import Path
import re
import zipfile

import yaml
from mdpf_onboarding.config import UniqueLoader, main_ddl_uri, output_uri, validate_config, yaml_uri
from mdpf_onboarding.metadata_generator import contract_model


ROOT = Path(__file__).resolve().parents[1]


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def wheel_metadata(data):
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        names = [n for n in archive.namelist() if n.endswith('.dist-info/METADATA')]
        if len(names) != 1:
            raise ValueError('Expected one wheel METADATA file.')
        return Parser().parsestr(archive.read(names[0]).decode())


def framework_assets(path, expected_sha256, expected_version):
    """Check the caller's trusted archive pin, manifest hashes and exact dependency."""
    data = Path(path).read_bytes()
    if not re.fullmatch(r'[0-9a-fA-F]{64}', expected_sha256) or sha256(data) != expected_sha256.lower():
        raise ValueError('Framework bundle SHA256 does not match the approved pin.')
    with zipfile.ZipFile(io.BytesIO(data)) as archive:
        manifest = json.loads(archive.read('release-manifest.json'))
        if manifest['distribution'] != 'mdpf' or manifest['version'] != expected_version:
            raise ValueError('Framework bundle version does not match the provider dependency pin.')
        wheel_path = manifest['wheel']
        if not re.fullmatch(r'wheels/mdpf-[A-Za-z0-9_.+!-]+\.whl', wheel_path):
            raise ValueError('Invalid Framework wheel path.')
        expected = {f'entrypoints/{platform}/{role}.{extension}'
                    for platform, extension in (('dataflow', 'py'), ('aidp', 'ipynb'))
                    for role in ('raw', 'stage', 'main')} | {wheel_path}
        rows = manifest['artifacts']
        if (len(rows) != len(expected) or {r['path'] for r in rows} != expected or
                len(archive.namelist()) != len(expected) + 1 or
                set(archive.namelist()) != expected | {'release-manifest.json'}):
            raise ValueError('Framework bundle must contain one wheel and six canonical launchers.')
        assets = {row['path']: archive.read(row['path']) for row in rows}
        if any(sha256(assets[row['path']]) != row['sha256'] for row in rows):
            raise ValueError('Framework artifact SHA256 does not match its manifest.')
        metadata = wheel_metadata(assets[wheel_path])
        if metadata['Name'] != 'mdpf' or metadata['Version'] != expected_version:
            raise ValueError('Framework wheel metadata does not match its release manifest.')
    return assets, manifest


def build_release(generated_dir, output, *, framework_bundle, framework_sha256):
    """Create a new ZIP without a Framework checkout, cloud access or SQL execution.

    Versions come from the provider wheel and its exact mdpf requirement. The
    caller supplies the approved Framework ZIP and its independently trusted SHA256.
    Generated YAML/SQL must match the current source contract and provenance.
    """
    generated_dir, output = Path(generated_dir), Path(output)
    wheels = list((ROOT / 'dist').glob('provider_dmi-*.whl'))
    if len(wheels) != 1:
        raise ValueError('Keep exactly one provider wheel in dist before packaging.')
    provider_wheel = wheels[0]
    provider_data = provider_wheel.read_bytes()
    metadata = wheel_metadata(provider_data)
    if metadata['Name'] != 'provider-dmi' or not metadata['Version']:
        raise ValueError('Expected a versioned provider-dmi wheel.')
    pins = [match[1] for value in metadata.get_all('Requires-Dist', [])
            if (match := re.fullmatch(r'mdpf\s*==\s*([A-Za-z0-9_.+!-]+)', value.strip()))]
    if len(pins) != 1:
        raise ValueError('Provider wheel must declare one exact mdpf==version dependency.')
    with zipfile.ZipFile(provider_wheel) as wheel:
        for source in (ROOT / 'src/provider_dmi').glob('*.py'):
            if wheel.read('provider_dmi/' + source.name) != source.read_bytes():
                raise ValueError('Provider wheel is stale; rebuild it before packaging.')
    common, framework = framework_assets(framework_bundle, framework_sha256, pins[0])
    original = (ROOT / 'datasets/fee/onboarding.yaml').read_bytes()
    config = validate_config(yaml.load(original, Loader=UniqueLoader))
    model = contract_model(config)
    names = [uri(config).rsplit('/', 1)[1] for uri in (yaml_uri, output_uri, main_ddl_uri)]
    generated = {name: (generated_dir / name).read_bytes() for name in names}
    complete = validate_config(yaml.load(generated[names[0]], Loader=UniqueLoader))
    if model['tables'] != contract_model(complete)['tables']:
        raise ValueError('Generated YAML does not match the current provider business contract.')
    for name in names[1:]:
        text = generated[name].decode('utf-8')
        if ('-- YAML SHA256: ' + sha256(original) not in text or
                '-- GENERATED YAML SHA256: ' + sha256(generated[names[0]]) not in text):
            raise ValueError(f'{name}: generation provenance does not match the input/complete YAML.')
    assets = {'config/input/onboarding.yaml': original, 'wheels/' + provider_wheel.name: provider_data}
    assets.update({'config/generated/' + name: data for name, data in generated.items()})
    for path in (ROOT / 'datasets/fee/samples').glob('*.csv'):
        assets['config/input/samples/' + path.name] = path.read_bytes()
    for name, data in common.items():
        assets[name if name.startswith('wheels/') else 'common/' + name] = data
    for platform, extension in (('dataflow', 'py'), ('aidp', 'ipynb')):
        name = f'entrypoints/{platform}/stage.{extension}'
        assets['provider/' + name] = (ROOT / name).read_bytes()
    tasks = []
    for task in model['tasks']:
        role = task['role']
        owner = 'provider' if role == 'STAGE' else 'common'
        tasks.append(dict(task_code=task['row']['task_code'], entrypoints={
            platform: f'{owner}/entrypoints/{platform}/{role.lower()}.{extension}'
            for platform, extension in (('dataflow', 'py'), ('aidp', 'ipynb'))}))
    manifest = dict(provider='dmi', provider_version=metadata['Version'], pipeline_code=config['pipeline']['code'],
                    metadata_release=config['pipeline']['release_version'],
                    framework_bundle_sha256=framework_sha256.lower(),
                    dependencies={'mdpf': framework['version'], 'provider-dmi': metadata['Version']}, tasks=tasks,
                    artifacts=[dict(path=name, sha256=sha256(data)) for name, data in sorted(assets.items())])
    assets['release-manifest.json'] = (json.dumps(manifest, indent=2) + '\n').encode()
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('xb') as handle:
        try:
            with zipfile.ZipFile(handle, 'w', zipfile.ZIP_DEFLATED) as archive:
                for name, data in sorted(assets.items()):
                    archive.writestr(name, data)
        except BaseException:
            output.unlink(missing_ok=True)
            raise
    return output


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--generated-dir', type=Path, required=True)
    parser.add_argument('--framework-bundle', type=Path, required=True, help='Approved Framework release ZIP.')
    parser.add_argument('--framework-sha256', required=True, help='Trusted SHA256 pin for that exact ZIP.')
    parser.add_argument('--output', type=Path, required=True, help='New release ZIP; existing files are rejected.')
    args = parser.parse_args(argv)
    print(build_release(args.generated_dir, args.output,
                        framework_bundle=args.framework_bundle, framework_sha256=args.framework_sha256))


if __name__ == '__main__':
    main()
