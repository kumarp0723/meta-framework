"""The custom launchers bind the fixed task and the installed provider function."""
import json
from pathlib import Path
import runpy
from types import SimpleNamespace

import pytest

from provider_dmi.fee import custom_fee_transform


ROOT = Path(__file__).resolve().parents[1] / 'entrypoints'


@pytest.mark.parametrize('platform', ['dataflow', 'aidp'])
def test_stage_launchers_register_provider_function(monkeypatch, platform):
    calls = []
    monkeypatch.setattr(f'mdpf.{platform}.execute_task', lambda **kw: calls.append(kw) or {'status': 'COMPLETED'})
    spark = object()
    if platform == 'dataflow':
        args = ['--execution-key', 'SCHEDULER:17', '--run-id', 'ocid1.dataflowrun.oc1.test.attempt17']
        result = runpy.run_path(str(ROOT / 'dataflow/stage.py'))['main'](args, spark=spark)
        assert calls[0]['argv'] is args
    else:
        scope = {'aidputils': SimpleNamespace(widgets=object()), 'spark': spark}
        for cell in json.loads((ROOT / 'aidp/stage.ipynb').read_text())['cells']:
            if cell['cell_type'] == 'code':
                exec(''.join(cell['source']), scope)
        result = scope['result']
    assert result == {'status': 'COMPLETED'}
    assert calls[0]['pipeline_code'] == 'DMI_FEE'
    assert calls[0]['task_code'] == 'DMI_FEE_STAGE_LOAD'
    assert calls[0]['spark'] is spark
    assert calls[0]['custom_steps'] == {'CUSTOM_FEE_TRANSFORM': custom_fee_transform}


@pytest.mark.parametrize('platform', ['dataflow', 'aidp'])
def test_custom_launcher_propagates_failure(monkeypatch, platform):
    def failure(**kwargs):
        raise RuntimeError('custom step failed')
    monkeypatch.setattr(f'mdpf.{platform}.execute_task', failure)
    with pytest.raises(RuntimeError, match='custom step failed'):
        if platform == 'dataflow':
            runpy.run_path(str(ROOT / 'dataflow/stage.py'))['main']([])
        else:
            scope = {'aidputils': object()}
            for cell in json.loads((ROOT / 'aidp/stage.ipynb').read_text())['cells']:
                if cell['cell_type'] == 'code':
                    exec(''.join(cell['source']), scope)
