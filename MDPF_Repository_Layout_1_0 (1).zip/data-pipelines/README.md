# data-pipelines

Provider-owned data pipelines maintained by the centralized data engineering team.
The first implementation is [DMI/FEE](providers/dmi/README.md).

| Path | Contents |
|---|---|
| `providers/dmi/src/provider_dmi/` | Provider-specific Python transformations |
| `providers/dmi/tests/` | Tests for provider-specific Python |
| `providers/dmi/datasets/fee/onboarding.yaml` | Canonical production DMI_FEE input configuration |
| `providers/dmi/datasets/fee/samples/` | Small sanitized or synthetic samples |
| `providers/dmi/datasets/fee/tests/` | Dataset schema and configuration contract tests |

`providers/dmi/pyproject.toml` builds `provider-dmi==1.0`, depending on `mdpf==1.0`.
The wheel contains the custom trim handler. Two provider-owned STAGE entry points
register it on Data Flow and AIDP; RAW/MAIN use the shared utility entry points.
Configuration and synthetic samples
remain source assets and are uploaded separately for onboarding. Follow the
provider README for installation, tests, generation, launcher selection and release packaging.

Reference DMI_FEE YAML and samples remain under
`common-utilities/generator/examples/`; tests and documentation retain labeled
business examples. Shared executable scripts/notebooks contain no DMI_FEE defaults
or handlers. Production configuration and transformation changes
belong here; those examples are not competing production configurations.

Keep shared framework/generator code in `common-utilities`. Keep actual provider
schemas, transformations and processing rules with the appropriate provider.
One provider can be built and tested independently from this structure. Add other
providers or datasets when needed. No repository-wide Python umbrella package or
new configuration engine is introduced. CI/CD and deployment automation are deferred.
