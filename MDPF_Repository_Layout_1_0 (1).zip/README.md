# MDPF repository layout

This bundle contains three folders intended to become separate GitLab repositories.
Use each folder's contents as that repository's root. GitLab projects/remotes have
not been created or pushed by this package.

| Repository folder | Current contents |
|---|---|
| [common-utilities](common-utilities/README.md) | Supplied Framework and SQL Generator, preserved as sibling packages |
| [data-pipelines](data-pipelines/README.md) | Provider-owned DMI/FEE configuration, transformation, samples, tests and 1.0 wheel |
| [platform-deployments](platform-deployments/README.md) | README placeholder for future deployment work |

Shared runtime modules, SQL, business fixtures and both original 1.0 utility wheels
remain unchanged. The two legacy starters were removed after migrating local
callers to the six canonical entry points. Their regression tests,
documentation and package checksums were updated accordingly. The existing `mdpf` and
`mdpf_onboarding` import names and versions remain 1.0.

Start with the [common-utilities setup](common-utilities/README.md). Its existing
documentation and cross-package tests assume sibling `framework/` and `generator/`
directories; that layout is preserved here. Run commands that reference both
packages from `common-utilities/`.

The production DMI_FEE source is now in
[data-pipelines/providers/dmi](data-pipelines/providers/dmi/README.md). It starts
from the reviewed schema, trim behavior and four policies. Existing DMI_FEE
examples remain self-contained reference/regression fixtures in the utilities.
Make production changes in the provider; no automatic synchronization of example
YAML is required. Review the illustrative environment bindings before deployment.

Six shared launchers under `common-utilities/framework/entrypoints` serve generic
RAW/STAGE/MAIN tasks. Two provider STAGE launchers register DMI_FEE's custom
transformation. The function remains reusable without a task-context restriction.
The provider uses the existing framework APIs on both AIDP and Data Flow.
Its release-packaging script assembles wheels, launchers and matching generator
outputs using a pinned Framework artifact ZIP and its trusted SHA256; see the provider README. The included release
uses synthetic samples and illustrative environment bindings, with metadata DRAFT.
CI/CD, job creation and deployment automation remain deferred;
`platform-deployments` still contains only its README.

`VALIDATION.txt` records utility preservation and provider checks. The root
`SHA256SUMS.txt` covers the delivered files other than itself. The two original
package checksum files cover their current distributions;
the root manifest covers the complete repository bundle.

Current 1.0 enhancements: Parquet landing, date/batch RAW/STAGE output folders,
OCI-to-HCP AppRole/KV v2 secret retrieval, pipeline direction and explicit no-sample
planning templates. See `common-utilities/generator/REFERENCE.md` and
`common-utilities/framework/REFERENCE.md`. Existing Oracle installs require the
reviewed `common-utilities/framework/sql/05_pipeline_direction.sql` upgrade.
The provider DMI_FEE YAML uses the new paths; utility CSV examples stay regression
references. Validation evidence is in `VALIDATION.txt`.
