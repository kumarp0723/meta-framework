# MDPF Framework 1.0 verification

Verified 2026-10-20: **323 automated checks passed in 81.17 seconds; no failures or skips**.
Python 3.12, actual Spark 3.5.7 and Java 17; Oracle and OCI use test doubles.
The SQLite catalog is test infrastructure, not a deployment backend.

## Verified changes

Fixed column policies NOT_NULL, UNIQUE and numeric RANGE share validation with
onboarding. RANGE bounds are inclusive; UNIQUE counts all rows sharing non-null
duplicates; neither treats null as a failure without NOT_NULL. Invalid check
parameters and nonnumeric RANGE columns fail preflight. Actual Spark tests cover
boundary values and columns named COUNT. Failures prevent Stage output, persist
policy evidence and WORK_QUEUE, and retain the immutable failed attempt after a
successful same-batch restart. Metadata still owns policy scope/action/threshold.

The shared runner preserves AIDP and OCI Data Flow entry points. AIDP job.run_id
maps to AIDP:<id>; ActiveBatch supplies one parent execution key to independent
Data Flow applications. Internal Oracle IDs remain distinct from scheduler IDs.
Normal execution, failed Stage/restart, missing external identity, connection
cleanup and terminal-batch guards are tested. The Data Flow example contains its
optional demo failure; framework built-ins contain no demo-failure branches.

## Preserved scope

All six built-ins, ordered metadata task plans, multi-input/output frame contract,
source/producer lineage, release pinning, schema/value protections, immutable
attempts and MAIN/lifecycle transaction behavior remain covered by the companion
generator test suite. Oracle SQL/schema scripts, notebooks and DB connection code
are unchanged: **17 tables / 232 columns**, environment-variable DB configuration.
No Iceberg, reprocess, step retry/checkpointing, production bulk loader or automatic
hard-timeout recovery is added. MAIN remains small-data driver-collected POC code;
Parquet outputs overwrite deterministic batch paths and are not jointly atomic.

The supplied 1.0 wheel is preserved byte-for-byte and matches its nine runtime modules. Compilation, wheel RECORD,
direct imports, ZIP integrity and package manifests pass. Tests are maintained in
the companion generator package; there is no deployable local storage/DB backend.

## Live validation outstanding

These checks use actual Spark with Oracle/OCI test doubles; they do not execute
Oracle PL/SQL/grants/triggers or validate concurrent Oracle sessions. Run actual
AIDP success/failure/Repair and verify job correlation, then Data Flow applications
through ActiveBatch REST with stable parent keys. Confirm OCI Spark permissions,
Data Flow DATAFLOW_RUN_ID (or explicit bootstrap fallback), DB network/wallet and
real transactions. Hard-killed writers require explicit shutdown/exact-run failure
before retry. Framework does not auto-declare an old RUNNING attempt stale.

Wheel SHA256: `5ab097b9de2b68e6b971f5dc0517b1e0ae9254b031bc953e737a424af7ec7df8`.

## Companion release-comparison correction

The companion generator now compares resolved task plans/parameters, DQ rules,
source settings, dataset associations and execution flags alongside schemas and
locations. All 323 companion checks pass. Only this package's existing README,
verification report and manifest change; runtime code/wheel, SQL, notebooks and
Data Flow applications remain byte-identical. Version stays 1.0. Target DDL
proposals still require review against actual Oracle tables before deployment.
