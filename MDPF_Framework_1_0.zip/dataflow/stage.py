"""STAGE Data Flow application; demo failure belongs here, outside MDPF."""
import argparse

from pyspark.sql import functions as F
from mdpf.dataflow import execute_task


def custom_fee_transform(frames, context, params):
    return {name:df.withColumn(params.get('column','CLIENT_NO'),F.trim(F.col(params.get('column','CLIENT_NO'))))
            for name,df in frames.items()}


if __name__=='__main__':
    parser=argparse.ArgumentParser(add_help=False)
    parser.add_argument('--inject-failure',action='store_true')
    demo,arguments=parser.parse_known_args()
    def transform(frames,context,params):
        if demo.inject_failure:
            raise RuntimeError('Injected demonstration failure before Stage output')
        return custom_fee_transform(frames,context,params)
    execute_task(pipeline_code='DMI_FEE',task_code='DMI_FEE_STAGE_LOAD',argv=arguments,
        custom_steps={'CUSTOM_FEE_TRANSFORM':transform})
