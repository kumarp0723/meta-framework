"""MAIN Data Flow application; the runtime loads the configured Oracle target."""
from mdpf.dataflow import execute_task

if __name__=='__main__':
    execute_task(pipeline_code='DMI_FEE',task_code='DMI_FEE_MAIN_LOAD')
