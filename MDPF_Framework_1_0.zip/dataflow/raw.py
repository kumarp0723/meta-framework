"""RAW Data Flow application; pipeline identifiers belong in this application."""
from mdpf.dataflow import execute_task

if __name__=='__main__':
    execute_task(pipeline_code='DMI_FEE',task_code='DMI_FEE_RAW_LOAD')
