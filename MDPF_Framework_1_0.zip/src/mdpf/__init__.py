"""MDPF: metadata-driven Spark tasks with Oracle control and OCI Parquet I/O."""

__version__ = "1.0"
