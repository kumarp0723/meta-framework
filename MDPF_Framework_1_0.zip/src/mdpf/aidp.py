"""AIDP entry point. The scheduler owns dependencies and Repair selection."""
import json

from .db import OracleDb
from .pipeline import MetadataFramework


def _execute_task(pipeline_code, task_code, parameters, db, custom_steps=None, spark=None):
    values = {key: str(value).strip() for key, value in parameters.items() if value is not None}
    for key in ("job_run_id", "task_run_id", "execution_count"):
        if not values.get(key) or "{{" in values[key]:
            raise ValueError(f"Missing or unresolved AIDP task parameter: {key}")
    count = int(values["execution_count"])
    if count < 1:
        raise ValueError("AIDP execution_count must be positive.")
    from .runner import _run_task
    return _run_task(db, pipeline_code=pipeline_code, task_code=task_code,
        execution_key='AIDP:'+values['job_run_id'], task_run_id=values['task_run_id'],
        orchestrator_run_id=values['job_run_id'], orchestrator_attempt_number=count,
        cycle_date=values.get('cycle_date') or None,
        execution_mode=values.get('execution_mode','').upper() or None,
        triggered_by='AIDP', custom_steps=custom_steps, spark=spark)


def execute_task(*, pipeline_code, task_code, aidputils, custom_steps=None, spark=None):
    """Execute one metadata task. Call from each AIDP task notebook."""
    names = ("job_run_id", "task_run_id", "execution_count", "cycle_date", "execution_mode")
    for name in names:
        aidputils.widgets.text(name=name, defaultValue="", label=name)
    parameters = {name: aidputils.widgets.get(name) for name in names}
    db = OracleDb()
    try:
        result = _execute_task(pipeline_code, task_code, parameters, db, custom_steps, spark)
        print(json.dumps({key: result[key] for key in (
            "batch_id", "task_run_id", "status", "input_count", "output_count")}, default=str))
        return result
    finally:
        db.close()


def finalize_failed_job(*, pipeline_code, job_run_id):
    """Finalize only after the scheduler/operator gives up on restart."""
    db = OracleDb()
    try:
        fw = MetadataFramework(db, pipeline_code)
        batch = fw.get_batch_by_job_run_id(job_run_id)
        if not batch:
            raise ValueError("No batch exists for this pipeline and job run.")
        fw.fail_batch(batch["batch_id"])
    finally:
        db.close()
