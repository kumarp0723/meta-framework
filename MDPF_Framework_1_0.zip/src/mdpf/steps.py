"""Built-in Spark processing; notebooks supply business transformations."""
import hashlib
import json
from decimal import Decimal

from pyspark.sql import functions as F

from .schema import convert_frame, require_columns, validate_frame


def validate_dq_parameters(params, column=None):
    """Three fixed checks; scope, action and zero tolerance remain metadata-owned."""
    if not isinstance(params, dict) or params.get('check') not in ('NOT_NULL','UNIQUE','RANGE'):
        raise ValueError('Supported DQ checks: NOT_NULL, UNIQUE and numeric RANGE.')
    expected={'check','min','max'} if params['check']=='RANGE' else {'check'}
    if set(params)!=expected:
        raise ValueError('RANGE requires min/max; NOT_NULL and UNIQUE accept no additional parameters.')
    if params['check']=='RANGE':
        for value in (params['min'],params['max']):
            if isinstance(value,bool) or not isinstance(value,(int,float)):
                raise ValueError('RANGE min/max must be finite numeric YAML values.')
            number=Decimal(str(value))
            if (not number.is_finite() or
                    max(len(number.as_tuple().digits)+max(number.as_tuple().exponent,0),-number.as_tuple().exponent)>38):
                raise ValueError('RANGE bounds must fit Spark decimal precision/scale 38.')
        if params['min']>params['max']:
            raise ValueError('RANGE min must not exceed max.')
        if column is not None and column['data_type']!='NUMBER':
            raise ValueError('RANGE requires a NUMBER column.')
    return params


def _policy_failures(df, policy, nulls):
    params=policy['parameters'];name=policy['column_name']
    if params['check']=='NOT_NULL':
        return nulls[name],'0 nulls'
    values=df.where(F.col(name).isNotNull())
    if params['check']=='UNIQUE':
        duplicates=values.select(F.col(name).alias('_dq_value')).groupBy('_dq_value').agg(F.count('*').alias('_dq_count'))
        amount=duplicates.where(F.col('_dq_count')>1).agg(F.sum('_dq_count')).first()[0]
        return int(amount or 0),'0 rows with duplicate non-null values'
    invalid=(F.col(name)<F.lit(Decimal(str(params['min'])))) | (F.col(name)>F.lit(Decimal(str(params['max']))))
    return values.where(invalid).count(),f"0 rows outside [{params['min']}, {params['max']}]"


def read_source(frames, ctx, params):
    fw, batch, task = ctx["framework"], ctx["batch"], ctx["task"]
    result = {}
    for code, spec in ctx["inputs"].items():
        path = spec["location"]
        # Contract: a resolved landing URI identifies an immutable delivery, never overwritten.
        identity = [fw.pipeline_code, ctx["source_config"]["source_system_name"], code, path]
        key = "RECEIPT:" + hashlib.sha256(json.dumps(identity, separators=(",", ":")).encode()).hexdigest()
        with fw.db.transaction():
            previous = fw.db.one("""SELECT ie.source_location, ie.source_item_key FROM RUNTIME.INGESTION_ITEM ie
                JOIN RUNTIME.TASK_RUN tr ON tr.task_run_id=ie.task_run_id
                WHERE tr.batch_id=:b AND tr.task_id=:t AND ie.dataset_id=:d ORDER BY tr.attempt_number ASC""",
                b=batch["batch_id"], t=task["task_id"], d=spec["dataset"]["dataset_id"])
            item_id = fw.db.next_id("RUNTIME.INGESTION_ITEM", "ingestion_item_id")
            fw.db.insert("RUNTIME.INGESTION_ITEM", dict(ingestion_item_id=item_id,
                task_run_id=ctx["run_id"], config_release_id=batch["config_release_id"],
                source_config_id=task["source_config_id"], dataset_id=spec["dataset"]["dataset_id"],
                item_role="DATA", ingestion_type="FILE", item_name=path.rsplit("/", 1)[-1], source_item_key=key,
                source_location=path, landing_location=path, status="RECEIVED"))
            fw.db.execute("UPDATE RUNTIME.INGESTION_ITEM SET received_timestamp=SYSTIMESTAMP WHERE ingestion_item_id=:id", id=item_id)
        spec["ingestion_item_id"] = item_id
        if previous and (previous["source_location"] != path or previous["source_item_key"] != key):
            raise ValueError("Source delivery URI changed during restart; do not reuse this batch.")
        df = fw.storage.read_csv(fw.spark, path)
        require_columns(df, spec["columns"], "CSV header")
        df = convert_frame(df, spec["columns"])
        _, spec["count"] = validate_frame(df, spec["columns"], "Source", source=True)
        result[code] = df
    ctx["input_count"] = sum(s["count"] for s in ctx["inputs"].values())
    return result


def read_parquet(frames, ctx, params):
    fw, result = ctx["framework"], {}
    # Resolve all producers before reading any input object.
    for spec in ctx["inputs"].values():
        producers = fw.db.execute("""SELECT task_run_id FROM RUNTIME.TASK_RUN
            WHERE batch_id=:b AND config_release_id=:r AND task_id=:t AND status='COMPLETED'""",
            b=ctx["batch"]["batch_id"], r=ctx["batch"]["config_release_id"], t=spec["producer_task_id"])
        if len(producers) != 1:
            raise ValueError("Input requires exactly one completed producer attempt in the same batch and pinned release.")
        spec["producer_run_id"] = producers[0]["task_run_id"]
    for code, spec in ctx["inputs"].items():
        df = fw.storage.read_parquet(fw.spark, spec["location"])
        columns = spec["columns"]
        expected = {c["column_name"] for c in columns} | {"_batch_id", "_run_id"}
        if len(df.columns) != len(expected) or set(df.columns) != expected:
            raise ValueError("Input Parquet columns do not match DATASET_COLUMN and reserved lineage.")
        if any(df.schema[n].dataType.simpleString() != "bigint" for n in ("_batch_id", "_run_id")):
            raise ValueError("Input Parquet lineage columns must be bigint.")
        wrong_batch = F.col("_batch_id").isNull() | (F.col("_batch_id") != ctx["batch"]["batch_id"])
        wrong_run = F.col("_run_id").isNull() | (F.col("_run_id") != spec["producer_run_id"])
        if df.where(wrong_batch | wrong_run).limit(1).count():
            raise ValueError("Input Parquet lineage does not match the current batch and completed producer attempt.")
        df = df.drop("_batch_id", "_run_id")
        _, spec["count"] = validate_frame(df, columns, "Input Parquet")
        result[code] = df.select(*[c["column_name"] for c in columns])
    ctx["input_count"] = sum(s["count"] for s in ctx["inputs"].values())
    return result


def output_frames(frames, ctx):
    """Explicit output keys, validated RAW pairs, or a single-frame projection/fan-out."""
    outputs = ctx["outputs"]
    if set(frames) == set(outputs):
        return frames
    if "raw_pairs" in ctx and set(frames) == set(ctx["inputs"]):
        return {output: frames[source] for output, source in ctx["raw_pairs"].items()}
    if len(frames) == 1 and set(frames) == set(ctx["inputs"]):
        return {code: next(iter(frames.values())) for code in outputs}
    raise ValueError("Custom step must return exactly the output dataset codes; multiple inputs are never joined or routed automatically.")


def _check_output(df, ctx, spec, record_pass=False, oracle=False):
    """Enforce the contract; preserve configured blocking-policy evidence on failure."""
    nulls, count = validate_frame(df, spec["columns"], "Output", check_nulls=False, oracle=oracle)
    policies = spec["policies"]
    results=[(policy,*_policy_failures(df,policy,nulls)) for policy in policies]
    failed = [p['policy_code'] for p,amount,_ in results if amount]
    if failed or (record_pass and policies):
        fw = ctx["framework"]
        with fw.db.transaction():
            for policy,amount,expected in results:
                if not record_pass and not amount:
                    continue
                fw.db.insert("RUNTIME.POLICY_RESULT", dict(
                    policy_result_id=fw.db.next_id("RUNTIME.POLICY_RESULT", "policy_result_id"),
                    config_release_id=policy["config_release_id"], policy_id=policy["policy_id"],
                    batch_id=ctx["batch"]["batch_id"], task_run_id=ctx["run_id"],
                    dataset_id=policy["dataset_id"], dataset_column_id=policy["dataset_column_id"],
                    result_level=policy["policy_scope_type"], result_status="FAIL" if amount else "PASS",
                    expected_value=expected, actual_value=str(amount), threshold_value=policy["threshold_value"],
                    failed_record_count=amount, failure_action_taken="FAILED_TASK" if amount else None))
            if failed:
                run = fw.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id", id=ctx["run_id"])
                batch = fw._batch(run["batch_id"])
                fw._fail_in_tx(run, batch, "POLICY_FAILED", ", ".join(failed), ctx["step_code"])
    if failed:
        raise ValueError("Blocking policy failed: " + ", ".join(failed))
    if any(nulls[c["column_name"]] for c in spec["columns"] if c["is_nullable"] == "N"):
        raise ValueError("Required target column has nulls.")
    return count


def direct_map(frames, ctx, params):
    result = {}
    for code, df in output_frames(frames, ctx).items():
        spec = ctx["outputs"][code]
        result[code] = convert_frame(df, spec["columns"])
        _check_output(result[code], ctx, spec)
    return result


def validate_dq(frames, ctx, params):
    result = output_frames(frames, ctx)
    for code, df in result.items():
        _check_output(df, ctx, ctx["outputs"][code], record_pass=True)
    return result


def write_parquet(frames, ctx, params):
    fw, result = ctx["framework"], output_frames(frames, ctx)
    # Validate every output before the first external write; failed writes are retried in full.
    outputs = {code: {"count": _check_output(df, ctx, ctx["outputs"][code])}
               for code, df in result.items()}
    for code, df in result.items():
        spec = ctx["outputs"][code]
        data = df.select(*[c["column_name"] for c in spec["columns"]])
        data = data.withColumn("_batch_id", F.lit(ctx["batch"]["batch_id"]).cast("long"))
        data = data.withColumn("_run_id", F.lit(ctx["run_id"]).cast("long"))
        fw.storage.write_parquet(spec["location"], data)
    ctx["state"]["outputs"] = outputs
    ctx["output_count"] = sum(s["count"] for s in outputs.values())
    return result


def load_main(frames, ctx, params):
    result = output_frames(frames, ctx)
    for code, df in result.items():
        _check_output(df, ctx, ctx["outputs"][code], oracle=True)
    # Small POC only: all target inserts occur later on the lifecycle connection/transaction.
    outputs = {}
    for code, df in result.items():
        columns = ctx["outputs"][code]["columns"]
        rows = [r.asDict() for r in df.select(*[c["column_name"] for c in columns]).collect()]
        outputs[code] = {"rows": rows, "count": len(rows)}
    ctx["state"]["outputs"] = outputs
    ctx["output_count"] = sum(s["count"] for s in outputs.values())
    return result


BUILTINS = {"READ_SOURCE": read_source, "READ_PARQUET": read_parquet,
            "DIRECT_MAP": direct_map, "VALIDATE_DQ": validate_dq,
            "WRITE_PARQUET": write_parquet, "LOAD_MAIN": load_main}
