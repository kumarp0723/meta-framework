"""OCI paths and native Spark CSV/Parquet I/O for the sequential POC."""
from pathlib import PurePosixPath
from urllib.parse import urlsplit


def object_address(uri):
    parts = urlsplit(str(uri))
    if parts.scheme != "oci" or "@" not in parts.netloc or parts.query or parts.fragment:
        raise ValueError("Use oci://bucket@namespace/object-key (no query or fragment).")
    bucket, namespace = parts.netloc.split("@", 1)
    key = parts.path.lstrip("/")
    if not bucket or not namespace or ".." in PurePosixPath(key).parts:
        raise ValueError("Invalid OCI object address.")
    return namespace, bucket, key


class ObjectStorage:
    def read_csv(self, spark, location):
        key = object_address(location)[2]
        if not key.lower().endswith(".csv") or any(c in key for c in "*[]{}"):
            raise ValueError("An exact OCI .csv object key is required.")
        return spark.read.options(header=True, inferSchema=False, mode="FAILFAST",
                                  multiLine=True, escape='"').csv(location)

    def read_parquet(self, spark, location):
        if not object_address(location)[2]:
            raise ValueError("An exact OCI object prefix is required.")
        return spark.read.parquet(location)

    def write_parquet(self, location, df):
        """Spark replaces this batch's Parquet dataset on Repair."""
        if not object_address(location)[2]:
            raise ValueError("An exact OCI object prefix is required.")
        df.write.mode("overwrite").parquet(location)
