-- Oracle runtime evidence for the dedicated DMI_FEE pipeline.
SELECT batch_id, orchestrator_run_id, execution_key, config_release_id, cycle_date, status, start_timestamp, end_timestamp
  FROM RUNTIME.BATCH WHERE pipeline_code='DMI_FEE' ORDER BY batch_id;

SELECT tr.batch_id, t.task_code, tr.task_run_id, tr.attempt_number,
       tr.original_task_run_id, tr.status, tr.input_count, tr.output_count,
       tr.orchestrator_task_run_id, tr.orchestrator_attempt_number,
       tr.error_code, tr.error_message, tr.failed_step_code
  FROM RUNTIME.TASK_RUN tr
  JOIN RUNTIME.BATCH b ON b.batch_id=tr.batch_id
  JOIN METADATA.TASK t ON t.config_release_id=tr.config_release_id AND t.task_id=tr.task_id
 WHERE b.pipeline_code='DMI_FEE'
 ORDER BY tr.batch_id,t.task_id,tr.attempt_number;

SELECT ie.ingestion_item_id, ie.task_run_id, ie.item_name, ie.source_item_key,
       ie.dataset_id, ie.source_location, ie.source_record_count, ie.status
  FROM RUNTIME.INGESTION_ITEM ie JOIN RUNTIME.TASK_RUN tr ON tr.task_run_id=ie.task_run_id
  JOIN RUNTIME.BATCH b ON b.batch_id=tr.batch_id
 WHERE b.pipeline_code='DMI_FEE' ORDER BY ie.ingestion_item_id;

SELECT q.batch_id,q.task_run_id,q.reason_code,q.description,q.status,q.idempotency_key
  FROM OPERATIONS.WORK_QUEUE q JOIN RUNTIME.BATCH b ON b.batch_id=q.batch_id
 WHERE b.pipeline_code='DMI_FEE' ORDER BY q.work_queue_id;

SELECT e.batch_id,e.task_run_id,e.event_code,e.details_json
  FROM OPERATIONS.EVENT_LOG e JOIN RUNTIME.BATCH b ON b.batch_id=e.batch_id
 WHERE b.pipeline_code='DMI_FEE' ORDER BY e.event_log_id;

SELECT pr.batch_id, pr.task_run_id, pd.policy_code, pr.dataset_id, pr.dataset_column_id,
       pr.result_status, pr.threshold_value, pr.failed_record_count, pr.failure_action_taken
  FROM RUNTIME.POLICY_RESULT pr JOIN METADATA.POLICY_DEFINITION pd
    ON pd.config_release_id=pr.config_release_id AND pd.policy_id=pr.policy_id
  JOIN RUNTIME.BATCH b ON b.batch_id=pr.batch_id
 WHERE b.pipeline_code='DMI_FEE' ORDER BY pr.policy_result_id;

SELECT batch_id, task_run_id, COUNT(*) record_count, SUM(fee_tran_am) fee_amount
  FROM DMI_MAIN.DMI_FEE GROUP BY batch_id,task_run_id ORDER BY batch_id;
