# MDPF 1.0 — run and support a pipeline

MDPF runs metadata-defined Spark steps from OCI AIDP notebooks or OCI Data Flow
applications and records their execution in Oracle. AIDP or ActiveBatch owns
scheduling, dependencies and restart. Run each pipeline entirely on one platform.
This package and its wheel are version **1.0**.
For working links between packages, extract them into sibling folders named
`framework/` and `generator/`.

## How it works

```mermaid
flowchart TD
    A["AIDP or ActiveBatch workflow"] --> N["Notebook or Data Flow application"]
    N --> F["MDPF step runner"]
    M["Oracle metadata"] --> F
    F <-->|Spark I/O| O["Separate landing, RAW and STAGE buckets"]
    F --> D["Oracle MAIN tables"]
    F --> R["Runtime status and error history"]
```

The scheduler chooses which notebook/application runs. MDPF reads pinned metadata and runs that
task's steps; Spark handles CSV/Parquet I/O and Oracle records the outcome.

| Part | Responsibility |
|---|---|
| SQL Generator | Turns YAML and sample CSVs into DRAFT metadata; see the [onboarding README](../generator/README.md) |
| Oracle metadata | Defines datasets, columns, task inputs/outputs and ordered `TASK_STEP` rows |
| Notebook / Data Flow application | Registers custom business functions and calls its platform `execute_task()` |
| MDPF | Resolves/runs the plan and records status, errors and lineage |
| Spark / OCI | Reads landing CSVs and writes RAW/STAGE Parquet to their separate buckets |
| Oracle MAIN | Stores final rows; inserts, task completion and batch closure share one transaction |

Oracle generates internal `batch_id` and `task_run_id` values. AIDP uses
`AIDP:<job.run_id>` as the shared execution key; Data Flow tasks receive
`ACTIVEBATCH:<parent-workflow-instance-id>` from ActiveBatch. Each actual task
attempt gets a new `TASK_RUN`, with its external run ID recorded separately.
Restart retains the batch's pinned release/cycle and never reopens a terminal batch.

Before deploying a changed pipeline, use the onboarding utility's optional baseline
comparison. Review task plans, parameters, DQ rules, sources and associations as well
as schemas/locations. Deploy a new DRAFT release; existing batches keep their pinned
configuration. The utility proposes target DDL but never executes it.

## Set up once

1. Have a DBA provision `METADATA`, `RUNTIME`, `OPERATIONS`, the MAIN owner and
   runtime login. On a **fresh installation only**, run `sql/00_framework.sql`,
   then `sql/01_main_and_access.sql` in SQLcl/SQL*Plus script mode. The second
   script supplies sequences, runtime grants and example `DMI_MAIN.DMI_FEE`;
   adapt owner/login names before running it. Existing installations keep their tables.
2. Install `dist/mdpf-1.0-py3-none-any.whl` and its `oracledb>=2,<4` dependency
   on the AIDP cluster. Use cluster-provided PySpark. Replacing another build
   labelled 1.0 requires `pip install --force-reinstall --no-deps <wheel-path>`.
3. Configure Spark OCI access on **driver and workers**: landing read/list;
   RAW/STAGE read/list/write/overwrite/delete and required multipart permissions.
   Each layer can use its own bucket/namespace. Quarantine movement is outside scope.
4. Give every notebook driver Oracle network access and these environment variables
   through secure configuration:

   ```text
   MDPF_DB_USER
   MDPF_DB_PASSWORD
   MDPF_DB_DSN
   ```

   Wallets may also need `MDPF_DB_CONFIG_DIR`, `MDPF_DB_WALLET_LOCATION` and
   `MDPF_DB_WALLET_PASSWORD`. A catalog connection does not configure this direct
   connection. Keep credentials out of notebooks, YAML and job parameters.

## Run the supplied DMI example

1. Edit `sql/02_dmi_metadata.sql`: real landing/RAW/STAGE locations, MAIN target
   and column definitions. Use unused release ID/version values if already deployed.
   Review and execute it; its final statements approve and activate the example.
2. Upload a matching CSV to landing, for example `fee_20261005.csv`. Its header
   and values must match the LANDING columns. `fee_{YYYYMMDD}.csv` resolves from
   the explicit `cycle_date=2026-10-05`; there is no current-date fallback.
3. Import the three `notebooks/Task_*.ipynb` files and attach them to the configured
   cluster. Create `Job_DMI` with RAW → STAGE → MAIN dependencies and downstream
   condition **All success**. Set retries **0** for the Repair demo; disable retry-on-timeout.
4. Enter these parameters using `notebooks/job_parameters.json` as a UI reference
   (it is not an API import file):

| Scope | Parameters |
|---|---|
| Job | `cycle_date=2026-10-05`, `fail_first_stage=false` |
| Every task | `job_run_id={{job.run_id}}`, `task_run_id={{task.run_id}}`, `execution_count={{task.execution_count}}` |
| RAW | `cycle_date={{job.parameters.cycle_date}}`, `execution_mode={{job.trigger.type}}` |
| STAGE | `fail_first_stage={{job.parameters.fail_first_stage}}` |

5. Run the job. Expect RAW/STAGE Parquet below each dataset's `/batch_<batch_id>`
   prefix, MAIN rows, three completed task runs and a completed batch.
   Use `sql/03_inspect.sql` to inspect the example.

For the failure demo, start a **new job run** with `fail_first_stage=true`.
RAW completes, STAGE attempt 1 fails and MAIN does not run. The batch stays
RUNNING and `WORK_QUEUE` retains an OPEN error.

Choose **Repair on that same job run**, selecting STAGE and MAIN only. Keep the
flag true: the notebook function succeeds when `execution_count > 1`. Expect
STAGE attempt 2 and MAIN completion in the original batch. The old failure/error
remain. Confirm Repair preserves `job.run_id` in your environment.
**Run Now creates a new batch; it is not Repair.**

## Use your own pipeline

Follow the [SQL Generator README](../generator/README.md) to deploy/activate metadata and prepare MAIN
tables. Copy the notebooks, replace pipeline/task codes, and remove the example
business function/failure flag unless your metadata references them.

```python
from mdpf.aidp import execute_task

result = execute_task(
    pipeline_code="DEMO_LOAN",
    task_code="DEMO_LOAN_STAGE_LOAD",
    aidputils=aidputils,
    custom_steps={},
)
```

## Run from Data Flow / ActiveBatch

Create separate Data Flow applications for `dataflow/raw.py`, `stage.py` and
`main.py`. Change their example pipeline/task codes to match your metadata.
Register custom functions in the relevant application, as in a notebook.

1. Install the supplied wheel and Oracle driver in the Data Flow Python environment.
   Configure the same Spark OCI permissions, driver DB variables/network and wallet
   as AIDP. Bootstrap secrets through the platform; do not put them in REST arguments.
2. ActiveBatch launches RAW, waits for success, then STAGE, then MAIN through the
   OCI Data Flow REST API. `dataflow/create_run.json` is a request-body example;
   supply real application/compartment IDs and authenticate through your OCI setup.
3. Pass `--execution-key ACTIVEBATCH:<parent-workflow-instance-id>` to every run.
   RAW also needs `--cycle-date YYYY-MM-DD` and optional `--execution-mode MANUAL`.
   The key is generated from the scheduler's parent instance, not manually typed,
   and stays unchanged for failed-task retries. A new workflow gets a new key.
4. The adapter records the actual `DATAFLOW_RUN_ID`. If your environment does not
   expose it, bootstrap must supply the real run OCID through `--run-id`; the
   framework never invents an external run ID. Oracle's attempt counter increments.
5. On failure, ActiveBatch resubmits the failed application, then downstream work.
   RAW stays completed. Keep application code/wheel/metadata/source unchanged.
   ActiveBatch owns polling, retries and exhaustion; MDPF does not call its API.
   For the demo, add `--inject-failure` to the first STAGE run, then omit it on
   retry. The application code/wheel stay unchanged; the failure is custom code.

For example, every child run receives the same `--execution-key`, while its
Data Flow run OCID and internal TASK_RUN ID differ. After abandoning retry and
stopping active writers, call
`mdpf.runner.finalize_failed_batch(pipeline_code="...", execution_key="...")`.
Hard-killed attempts require explicit exact-run failure after writer shutdown;
there is no automatic stale-run or timeout recovery.

## Available Task Steps

Steps pass a dictionary of Spark DataFrames between them, keyed by dataset code.
INPUT/OUTPUT datasets come from `TASK_DATASET`; their locations and column rules
come from `DATASET` and `DATASET_COLUMN`. Built-ins use these settings and accept
empty parameters only. Their names cannot be overridden by notebook functions.

| Step | When to use it | Required inputs | What it does and produces |
|---|---|---|---|
| `READ_SOURCE` | Start RAW ingestion from landing CSVs | Header CSV INPUT datasets in OCI, matching column definitions, a FILE source configuration and cycle date | Reads each file with Spark, checks its schema/values and records `INGESTION_ITEM` receipts. Returns INPUT DataFrames. No previous DataFrame is needed. |
| `READ_PARQUET` | Start STAGE or MAIN from an earlier task's output | RAW/STAGE Parquet INPUT datasets and a completed producer attempt in the same batch | Checks columns and actual batch/run lineage. Returns INPUT DataFrames with the stored business types; removes the two file-lineage columns. |
| `DIRECT_MAP` | Convert types or select a subset of columns before output | DataFrames containing the target column names; OUTPUT column definitions | Selects columns in target order and converts to VARCHAR2, exact NUMBER(p,s) or date-only DATE. Returns OUTPUT DataFrames; invalid/lossy conversions fail. It does not rename, join or calculate business values. |
| `VALIDATE_DQ` | Check the final data before STAGE/MAIN output | DataFrames already matching OUTPUT columns/types; optional NOT_NULL/UNIQUE/RANGE policies | Checks column/value constraints and configured policies. Records `POLICY_RESULT` for configured checks and returns the validated OUTPUT DataFrames. A blocking failure stops the task. |
| `WRITE_PARQUET` | Finish RAW or STAGE | Validated output-shaped DataFrames and RAW/STAGE Parquet OUTPUT locations | Rechecks the output contract and writes a batch folder in OCI, adding `_batch_id` and `_run_id` to files. Repair overwrites that batch folder. Returns OUTPUT DataFrames. |
| `LOAD_MAIN` | Finish MAIN with an Oracle load | Output-shaped DataFrames and configured Oracle OUTPUT tables (`GOLD` / `ADB_TABLE`) | Validates and prepares rows; task completion inserts them into Oracle in the same transaction as runtime completion. Returns OUTPUT DataFrames. MAIN tables also need `BATCH_ID`, `TASK_RUN_ID`, `ROW_NUMBER`. |

For example, `DIRECT_MAP` can convert text `1250.75` to NUMBER(18,2) and
`2026-10-05` to DATE. A name change or a date such as `10/05/2026` needs custom
Python first. It never invents missing target columns or silently truncates values.

Multiple landing files are copied to their RAW datasets by matching
`TASK_DATASET.usage_sequence`. Built-ins do not automatically join multiple inputs;
custom joins/routing must return the configured OUTPUT dataset keys.

## Default task sequences

The SQL Generator creates these when YAML omits `task_steps`:

| Task | Default sequence |
|---|---|
| RAW | `READ_SOURCE` → `WRITE_PARQUET` |
| STAGE | `READ_PARQUET` → `DIRECT_MAP` (when needed) → `VALIDATE_DQ` → `WRITE_PARQUET` |
| MAIN | `READ_PARQUET` → `VALIDATE_DQ` → `LOAD_MAIN` |

RAW preserves input strings. STAGE needs `DIRECT_MAP` when input columns require
projection or datatype conversion; omit it if they already match the output.
MAIN normally needs no conversion because generated STAGE/MAIN schemas match.
If custom MAIN logic changes that, include `DIRECT_MAP` explicitly where needed.

A supplied `task_steps` list is used exactly. Keep one reader first, one final
write/load step, and `VALIDATE_DQ` immediately before STAGE/MAIN output—even with
no DQ policies. Any step failure fails the task. Repair reruns the whole task;
there are no internal step checkpoints.

## Custom task steps

Use custom Python for joins/routing, renaming, cleaning, filtering, business date
formats, derived columns or calculations. Built-ins handle generic reading,
matching-name conversion, validation and writing.
This example uses the SQL Generator's `DEMO_LOAN` sample metadata.

Add a reference inside the YAML `task_steps` list:

```yaml
- code: CLEAN_LOAN
  parameters:
    column: CLIENT_ID
```

See the [complete YAML plan](../generator/README.md#configure-task-steps).
Implement and register that exact code in the STAGE notebook:

```python
from pyspark.sql import functions as F
from mdpf.aidp import execute_task

def clean_loan(frames, context, params):
    df = frames["DEMO_LOAN_LOAN_RAW"]
    column = params["column"]
    return {"DEMO_LOAN_LOAN_STAGE": df.withColumn(column, F.trim(F.col(column)))}

result = execute_task(
    pipeline_code="DEMO_LOAN",
    task_code="DEMO_LOAN_STAGE_LOAD",
    aidputils=aidputils,
    spark=spark,
    custom_steps={"CLEAN_LOAN": clean_loan},
)
```

`frames` contains dataset-coded DataFrames; return a nonempty dictionary of
DataFrames. `context` is read-only and supplies IDs, cycle date and input/output
location maps. `params` contains the YAML `parameters` values. This example trims
CLIENT_ID, then the YAML plan runs `DIRECT_MAP`, DQ and the writer.

The generator creates the custom metadata reference; it does not implement or
test your function. The runtime checks every handler before data I/O. Missing or
non-callable registrations fail clearly. Raising an exception fails the task.
The notebook registers functions and invokes MDPF; it does not call each step.

## Supported DQ rules

Three simple column checks are supported. Configure exact output dataset codes:

```yaml
dq_rules:
  - datasets: [DEMO_LOAN_LOAN_STAGE, DEMO_LOAN_LOAN_MAIN]
    column: CLIENT_ID
    check: NOT_NULL
  - datasets: [DEMO_LOAN_LOAN_STAGE, DEMO_LOAN_LOAN_MAIN]
    column: LOAN_ID
    check: UNIQUE
  - datasets: [DEMO_LOAN_LOAN_STAGE, DEMO_LOAN_LOAN_MAIN]
    column: BALANCE
    check: RANGE
    min: 0
    max: 1000000
```

These are exact dataset codes, not layer names. Onboarding supports generated
STAGE/MAIN datasets and creates one `POLICY_DEFINITION` per dataset/column check.
The threshold is zero; a failure stops the task and creates error history.
NOT_NULL rejects nulls and empty strings. UNIQUE rejects every row sharing a
duplicate non-null value; it never deduplicates. RANGE checks inclusive numeric
min/max bounds on NUMBER columns. UNIQUE/RANGE ignore nulls; combine NOT_NULL
when required. Trim whitespace in custom code if spaces should count as empty. Output checks can block during `DIRECT_MAP` or writing too.

`DATASET_COLUMN` datatype, length and nullability checks still apply without
policies. With `dq_rules: []`, `VALIDATE_DQ` checks the schema/values but creates
no policy-result audit. It validates data; it does not convert or repair it.

Allowed values, regex, composite uniqueness, foreign-key checks and row-count
reconciliation are **not implemented as built-in DQ rules**.
Implement another check in a custom step and raise an exception on failure;
that does not automatically create a `POLICY_RESULT` row. See the generator's
[DQ configuration rules](../generator/README.md#optional-dq-rules).

## Find and resolve a failure

```mermaid
flowchart TD
    A["AIDP starts a notebook"] --> B["BATCH plus a new TASK_RUN"]
    B --> C["Validate plan, then run steps"]
    C -->|Success| D["Complete TASK_RUN"]
    C -->|Failure| E["Fail TASK_RUN and add WORK_QUEUE error"]
    E -->|Operator action| R["AIDP Repair"]
    R -->|Same job and batch, new attempt| B
```

A failed attempt leaves the batch RUNNING. Repair uses the same pinned metadata
and starts the selected task's whole plan again. The generated MAIN task closes
the batch on success; earlier failed attempts and errors remain visible.

Start with the failed notebook log: MDPF prints `TASK_PLAN`, `STEP_STARTED` and
`TASK_FAILED`. Find `BATCH` by pipeline and AIDP job ID, then inspect the attempt's
`TASK_RUN.failed_step_code`, `error_code`, `error_message` and attempt number.
`WORK_QUEUE` retains failures; `EVENT_LOG` records lifecycle/output paths;
`INGESTION_ITEM` records source receipts. Adapt `sql/03_inspect.sql` filters for your pipeline.

| Symptom | Check / next action |
|---|---|
| Oracle connection fails | Driver environment, DSN, network, wallet and grants |
| Source missing / OCI denied | Pinned cycle date, resolved URI and Spark driver/worker access |
| Task/handler missing | Pinned release, `TASK_STEP` code and notebook registration |
| Schema/DQ failure | `DATASET_COLUMN`, source values and `POLICY_RESULT` evidence when configured |
| Parquet input rejected | Producer's completed attempt and object lineage; do not replace batch files manually |
| Attempt still RUNNING | Confirm the old writer stopped; operator must fail that exact run before Repair |
| Task already COMPLETED | Exclude it from Repair; select failed/downstream tasks only |

Keep wheel, notebooks, metadata and deliveries unchanged during Repair. Changed
business logic or published metadata needs a new release/job run. Terminal batches
never reopen. If restart is abandoned, after writers stop and active attempts are
terminalized, call `mdpf.aidp.finalize_failed_job(pipeline_code="...", job_run_id="...")`.

## Where the code lives

| Module in `src/mdpf/` | Responsibility |
|---|---|
| `aidp.py` | Reads notebook parameters and supplies AIDP workflow/attempt identities |
| `dataflow.py` | Reads application arguments and the actual Data Flow run identity |
| `runner.py` | Shares task launch/finalization across platforms; manages the DB connection |
| `pipeline.py` | Resolves metadata, runs steps and records batch/task lifecycle |
| `steps.py` | Implements readers, direct mapping, DQ and output preparation |
| `schema.py` | Validates schemas/values and performs explicit conversions |
| `storage.py` | Validates OCI paths; uses Spark for CSV/Parquet I/O |
| `db.py` | Opens Oracle connections; handles binds, inserts and transactions |
| `__init__.py` | Identifies the package/version |

POC limits: MAIN collects small datasets on the driver. Parquet Repair overwrites
batch paths; multiple OCI writes are not atomic. Dated source URIs must be
immutable; automatic receipts provide lineage, not cross-batch deduplication.
DQ is limited to NOT_NULL, single-column UNIQUE and numeric RANGE. The 17-table model retains unused
MAPPING_RULE, PIPELINE_STATE and OUTBOUND_CONFIG. REPROCESS, Iceberg and automatic
hard-timeout recovery are outside scope. See `VERIFICATION_REPORT.md` for tests
and outstanding live AIDP/Oracle/OCI validation.
