# MDPF 1.0 — operations

- [Two-phase scheduling](#two-phase-scheduling)
- [OCI permissions](#oci-permissions)
- [Troubleshooting](#troubleshooting)
- [Development rollout](#development-rollout)

Shared operations guidance for the framework and generator. Extract the ZIPs into
sibling `framework/` and `generator/` folders so the documentation links resolve.

## Two-phase scheduling

The default remains RAW → STAGE → MAIN in one scheduled workflow. Two-phase
scheduling uses the same tasks and metadata, with a scheduling gap after RAW.
MDPF does not launch the second phase or introduce a PAUSED state.

### Data Flow / ActiveBatch

Phase 1 launches only RAW with these arguments (substitute actual identifiers):

```text
--execution-key ACTIVEBATCH:<unique-workflow-instance>
--cycle-date 2026-10-15
--execution-mode SCHEDULED
```

Persist the exact key in scheduler state across both phases. Later launch STAGE,
then MAIN only on STAGE success, each with the same `--execution-key`. Omit cycle
and mode overrides or pass their original values; a new business date does not
change the batch cycle date. Each actual Data Flow run supplies its own real run
OCID through DATAFLOW_RUN_ID or --run-id. Never generate a new workflow key per
phase or per retry. A date alone is not a unique workflow identity.

### AIDP across separate job runs

Keep real `job_run_id`, `task_run_id`, `execution_count` bindings for every task.
Add `workflow_execution_key` with one scheduler-supplied resolved workflow key
shared across Phase 1 RAW-only and Phase 2 STAGE → MAIN jobs. Do not use
`{{job.run_id}}` for that shared key: it changes between jobs. The key supports
up to 300 UTF-8 bytes and rejects unresolved templates/control characters.

The same `mdpf.aidp.execute_task(...)` API reads the additional widget. Empty/omitted
values retain `AIDP:<job_run_id>` for existing single-job workflows. The original
job correlation stays on BATCH; every task attempt keeps its real external task ID.
See framework `notebooks/two_phase_parameters.json` for a UI setup guide; it is
not an import payload. Platform bindings still need validation in your OCI setup.

### State and restart rules

RAW-only success leaves RAW COMPLETED and BATCH RUNNING. Phase 2 resolves the same
batch by key, uses its original pinned release and reads only retained RAW. Changing
the ACTIVE release while waiting does not change that batch. A wrong/new key cannot
start STAGE; changed cycle/mode overrides fail. Missing/malformed Parquet lineage,
audit fields or noncompleted producers fail safely. Completed RAW cannot rerun.

After STAGE/MAIN failure, retry failed/downstream tasks with the same key and fresh
attempt identities; earlier failed attempts/error history remain. MAIN success
closes the batch. Terminal batches cannot reopen. Keep RAW/STAGE files, pinned
metadata and compatible application code for the supported continuation period.

Only after writers stop and the execution is deliberately abandoned:

```python
from mdpf.aidp import finalize_failed_job
finalize_failed_job(pipeline_code='MY_PIPELINE', workflow_execution_key='MY_STABLE_KEY')
# Existing single-job workflows can still use job_run_id='...'. Supply one identity.
```

Data Flow uses `mdpf.runner.finalize_failed_batch(pipeline_code=..., execution_key=...)`.
These are failure finalizers, not phase-transition calls. No waiting-batch dashboard
or automatic timeout/finalization is implemented.

## OCI permissions

Example only: same tenancy/region, Oracle-managed encryption, dedicated development
compartment `MDPF_DEV`. Substitute actual compartment, group, region and bucket names.
A platform administrator must validate effective access in the deployment environment.
Do not reuse this dedicated-compartment example as tenancy-wide production policy.

For Data Flow, an example dynamic-group rule is:

```text
ALL {resource.type='dataflowrun', resource.compartment.id='<DATAFLOW_COMPARTMENT_OCID>'}
```

Create a separate dynamic group for the actual OCI notebook Resource Principal
according to that notebook service's identity model. Do not assume AIDP has the
same dynamic-group rule as Data Flow. In the example below both groups receive
read access; workers can write RAW/STAGE while notebooks write onboarding artifacts.
Read object-family also covers metadata and copy work-request inspection in this
single dedicated compartment; bucket-scoped policies alone may not cover work requests.

```text
Allow dynamic-group MDPF_NOTEBOOKS to read object-family in compartment MDPF_DEV
Allow dynamic-group MDPF_RUNS to read object-family in compartment MDPF_DEV
Allow dynamic-group MDPF_NOTEBOOKS to manage objects in compartment MDPF_DEV where target.bucket.name='mdpf-dev-artifacts'
Allow dynamic-group MDPF_RUNS to manage objects in compartment MDPF_DEV where any {target.bucket.name='dev-raw', target.bucket.name='dev-stage'}
Allow dynamic-group MDPF_RUNS to manage objects in compartment MDPF_DEV where all {target.bucket.name='dev-quarantine', request.permission='OBJECT_CREATE'}
```

Object Storage also needs permission to perform server-side copy on your behalf.
Adapt this Oracle service-policy example to the actual region/compartment:

```text
Allow service objectstorage-us-ashburn-1 to manage object-family in compartment MDPF_DEV where any {request.permission='OBJECT_READ', request.permission='OBJECT_INSPECT', request.permission='OBJECT_CREATE', request.permission='OBJECT_OVERWRITE', request.permission='OBJECT_DELETE'}
```

The runtime requests source ETag matching and create-only quarantine destinations;
landing is retained. Give notebook-run pipelines the corresponding runtime object
permissions only when they execute ingestion as well as generate YAML. OCI SDK
Resource Principal configuration and Spark driver/worker connector configuration
are separate. KMS, cross-tenancy/region access, extra compartments and platform
job-launch permissions need additional reviewed policies.

Official references:

- [Object Storage permissions](https://docs.oracle.com/en-us/iaas/Content/Identity/Reference/objectstoragepolicyreference.htm)
- [Object copy and service permissions](https://docs.oracle.com/en-us/iaas/Content/Object/Tasks/copyingobjects.htm)
- [Data Flow resource principals](https://docs.oracle.com/en-us/iaas/Content/data-flow/using/resource-principal-policies.htm)

## Troubleshooting

| Symptom | Check/action |
|---|---|
| Bulk row FAILED for a sample | Check the exact OCI URI and HEAD access. Fix the object/permissions, then rerun; do not add schema checks to the builder. |
| Existing YAML skipped | Save is create-only. Edit a maintained configuration explicitly or choose a new release-specific destination. |
| Batch RUNNING after RAW success | Expected when Phase 2 is intentionally delayed. Reuse the same key; do not call a failure finalizer for waiting. |
| Phase 2 says INGESTION must create batch | Wrong/new execution key or wrong pipeline/environment. Use the original key. |
| Cycle conflicts | Use the original batch cycle date or omit the downstream override. |
| Completed task cannot restart | Retry only failed/downstream tasks. New intentional deliveries need new execution keys. |
| Attempt still RUNNING after worker loss | Stop its external writer; fail that exact internal task_run_id before retrying. Do not guess from elapsed time. |
| RAW technical validation failure | Inspect header/CSV/type/length/nonempty/source contract. Only proven data failures qualify for whole-file quarantine. |
| Quarantine copy failed | Inspect both original validation and copy errors; check region, ETag, bucket/service permissions and work request. Unconfirmed copies do not mark QUARANTINED. |
| STAGE DQ fails | Inspect POLICY_RESULT by task_run_id, correct deterministic business logic/configuration, retry STAGE and downstream with the same key. RAW remains intact. |
| WARN recorded but task fails | WARN cannot bypass required schema, conversion or Oracle constraints. Inspect the actual task error. |
| Parquet audit/lineage rejected | Check exact producer/run/batch/receipt fields and layer schema. Old-format files require the old runtime; see the Development rollout section of OPERATIONS.md. |
| MAIN row limit exceeded | No rows inserted. Review input size/driver memory; configure a suitable cap and retry MAIN in the same batch. No truncation occurs. |
| MAIN insert reconciliation failed | All MAIN target inserts/completion were rolled back. Inspect expected/actual policy evidence and adapter row counts; fix and retry MAIN. |
| Oracle uniqueness/check error | Review actual target constraints and cross-batch data. STAGE UNIQUE does not guarantee cross-batch uniqueness. |
| Sample conversion fails during onboarding | Review explicit datatypes/capacity or custom parsing. Sample validation belongs to onboarding, not the pre-builder. |

Use existing RUNTIME.TASK_RUN, RUNTIME.POLICY_RESULT, RUNTIME.INGESTION_ITEM,
OPERATIONS.EVENT_LOG and OPERATIONS.WORK_QUEUE, filtered by batch/task attempt.
Retain failed attempts and error history after a successful retry. Inspect
framework `sql/03_inspect.sql`; no waiting dashboard or new operational tables exist.

## Development rollout

For development installations moving from an earlier build to this build.
Software packages retain version 1.0; the wheel checksum identifies this build.

1. Stop launching new development batches. Finish existing batches with the older
   runtime, or deliberately abandon them after stopping writers. Keep the older
   runtime available for any retained old-format batch that must still finish.
   Configuration pinning does not pin Python application code.
2. Install both 1.0 wheels and restart notebook/worker sessions. Replace runtime
   dependency archives/wheels for Data Flow as well. The package version is 1.0;
   pipeline metadata release_version remains independently chosen text.
3. The 17-table framework schema is unchanged. **Do not rerun fresh-install DDL**
   against an existing framework. For new development MAIN tables, use regenerated
   CREATE proposals. Existing targets need CREATED_AT/UPDATED_AT TIMESTAMP(6) WITH
   TIME ZONE NOT NULL. Review framework `sql/04_main_audit_columns.sql`, a manual
   preserving proposal for one existing MAIN target. Historical timestamps use
   recorded attempt completion as an approximation, explicitly documented there.
   Review missing history/backfill cases before enforcing NOT NULL. DDL commits
   independently and is never run by the utility.
4. Move legacy MAIN column DQ entries to their matching STAGE dataset in a new
   DRAFT configuration. Use [DQ and audit contracts in the framework reference](REFERENCE.md#dq-reconciliation-and-audit-contracts) for severity/rule syntax.
   Existing published metadata remains immutable. Complete-YAML baseline comparison
   remains strict: first make a reviewed configuration compatible with this build; do not
   silently rewrite published definitions. A legacy baseline containing MAIN column
   DQ needs a separately reviewed conversion before comparison with this build can validate it.
5. Generate/review/deploy/approve/activate the new release. Configure the MAIN worker's
   MDPF_MAIN_MAX_ROWS if a reviewed value above the 10,000-row default is necessary.
   Set Spark session timeZone=UTC for consistent audit display. Run the read-only
   Oracle target gate to check timestamp fields/types/precision as well as business
   columns and required grants.
6. Start a **new execution key/batch** for the new physical audit contract. Old RAW
   or STAGE Parquet lacks the new required fields and is rejected by this build's readers.
   Never manufacture receipt IDs or overwrite completed old-batch output to add
   fields. This development release intentionally does not infer missing lineage.
7. Verify same-day success, delayed continuation, warning/failure evidence, MAIN
   rollback and one real OCI quarantine test before enabling normal scheduling.

No deployment, schema migration or metadata activation is performed by these ZIPs.
