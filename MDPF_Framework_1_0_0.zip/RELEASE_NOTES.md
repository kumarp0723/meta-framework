# MDPF 1.0 — release notes

## Current build — 2026-10-28

Both distributions, Python __version__ values, wheel metadata and ZIP names are
version **1.0**, as requested. The complete current functionality and six-file
Markdown layout are retained. This is the latest build under the 1.0 label.

### Notebook output

examples/bulk_pre_onboarding.ipynb imports `from pprint import pprint` in its
imports cell. Both preview and save call `pprint(results)` directly on the returned
list of dictionaries. They do not call display or construct a DataFrame. The
matching technical-reference examples also use pprint.

### Install this build

Ensure dependencies are present, then replace both installed wheels and restart
Python/worker sessions. The same version label can identify an older build, so
use force-reinstall and the supplied wheel checksums:

```bash
pip install --force-reinstall --no-deps ./framework/dist/mdpf-1.0-py3-none-any.whl ./generator/dist/mdpf_onboarding-1.0-py3-none-any.whl
```

The package label does not change physical schema requirements. Existing MAIN
columns and the required RAW/STAGE audit fields still apply; follow
[development rollout](OPERATIONS.md#development-rollout) for earlier builds.
Metadata CONFIG_RELEASE.release_version is independent of the software version;
existing example/test release identities remain unchanged. Published metadata
must not be edited merely to match this software label.

### Verification

- **498 regression tests passed in 128.87 seconds**, without failures or skips.
- **3 installed-wheel checks passed**: version/import location, existence-only bulk
  sample checks, and Oracle affected-row reporting/timestamp bind types.
- The imports, preview and save notebook cells executed with a stub catalog builder
  and real pprint. Preview/save results were printed successfully with the correct
  dry-run settings, without a notebook display or DataFrame dependency.
- Both wheels match packaged source and their RECORD hashes/sizes. Python 3.10
  syntax and current documentation Python examples were checked.
- Six Markdown documents are retained; local file/section links, ZIP integrity
  and complete SHA256 manifests were verified after rebuilding.

Tests use real Spark 3.5.7 with the established CI-only SQLite/OCI doubles.
Live Oracle/OCI/AIDP validation is still required. The earlier test-only Spark
launcher/temp-directory workaround remains outside these deliverables.

### Current wheel SHA256

- mdpf-1.0-py3-none-any.whl: `78df94d1df6f7d2d8fc3b906dbefb7e5c088e8152cdc6e455d907c3c88ed282e`
- mdpf_onboarding-1.0-py3-none-any.whl: `19f259da88fcdf50def054b8c90b0a8e6751e1addb8e0883e53c8f6adc1611d7`

## Prior delivery history

The records below describe earlier deliveries and their original labels, filenames
and checksums. They are retained as historical evidence. Current installation uses
only the version 1.0 wheels listed above.

- [Documentation cleanup — 2026-10-27](#documentation-cleanup--2026-10-27)
- [Runtime changes — 1.1](#runtime-changes--11)
- [Runtime verification (2026-10-25)](#runtime-verification-2026-10-25)
- [Verified behavior](#verified-behavior)
- [Package checks](#package-checks)
- [Rollout and limits](#rollout-and-limits)
- [Wheel SHA256](#wheel-sha256)
- [Framework changed files before consolidation](#framework-changed-files-before-consolidation)
- [Generator changed files before consolidation](#generator-changed-files-before-consolidation)

### Documentation cleanup — 2026-10-27

This packaging revision consolidates 22 Markdown files into six, preserving all
14 unique source document bodies. Eight identical documents are retained once.
The framework owns shared operations and release notes; the generator links to them.

| Location | Contents |
|---|---|
| framework/README.md | Runtime overview and quick start |
| generator/README.md | Generator overview and end-to-end quick start |
| framework/REFERENCE.md | Runtime reference plus complete DQ, reconciliation and audit contracts |
| generator/REFERENCE.md | Catalog/profile, YAML/schema, API and generation reference |
| framework/OPERATIONS.md | Two-phase scheduling, IAM, troubleshooting and upgrade guidance |
| framework/RELEASE_NOTES.md | Changes, historical verification evidence and both original file-change lists |

Removed generated SQL examples from the generator ZIP: examples/metadata_draft.sql,
examples/dq_metadata_draft.sql and examples/main_ddl.sql. Generation still produces
metadata SQL and optional MAIN DDL in the configured OCI destination. YAML examples,
CSV samples, tests/fixtures/framework_1_0.sql, all deployment SQL and both wheels remain.

Runtime source, wheels, tests, dependencies, YAML/JSON/notebooks and retained SQL
are byte-identical to the supplied 1.1 packages. Package and wheel versions remain
1.1; no reinstall is needed for this documentation revision alone. No authentication
or other runtime behavior change is part of this cleanup.

Documentation bodies were checked for preservation; relative file/section links,
ZIP integrity and complete SHA256 manifests were verified. The 498 runtime tests
and 9 wheel checks recorded below are prior release evidence, not tests rerun for
this documentation-only revision. Source/wheel byte comparisons establish that
those tested runtime artifacts have not changed.

### Runtime changes — 1.1

- Added optional AIDP workflow_execution_key and documented same-batch two-phase scheduling.
- Added ALLOWED_VALUES, FAIL/WARN and explicit dataset-level ROW_COUNT policies.
- Moved column business DQ to STAGE and evaluate it once at VALIDATE_DQ; retained boundary schema checks.
- Reconcile actual MAIN inserts and roll back all target/completion changes on mismatch; retain failure evidence.
- Added RAW receipt/time, STAGE processing time and MAIN creation/update audit fields.
- Restored the 10,000-row default task-wide MAIN cap and concise operational documentation.
- Kept RAW whole-file quarantine, immutable landing delivery identities, producer guards and OCI sample HEAD checks.
- No waiting-batch dashboard, archive, row rejection, new framework tables or broad Spark optimization.

Core framework changes: src/mdpf/{aidp,db,pipeline,schema,steps,__init__}.py.
Core generator changes: src/mdpf_onboarding/{onboard,metadata_generator,schema_discovery,__init__}.py.
Supporting changes: examples, SQL, notebook parameter guide, tests, wheels and documentation.
Read the Development rollout section of OPERATIONS.md before switching runtimes; old Parquet audit contracts are not inferred.

### Runtime verification (2026-10-25)

The following evidence describes the tested 1.1 runtime release before this
documentation consolidation. References to the original packaging layout are historical.

**498 tests passed in 124.64 seconds, without failures or skips.**
**9 installed-wheel checks passed in 27.09 seconds.**

Tests use actual Spark 3.5.7, Java 17 and Python 3.12.14. OCI SDK 2.189.0,
python-oracledb 3.4.2 and pytest 9.1.1 were used. SQL metadata and transactional
failure checks run against the existing CI-only SQLite adapter; OCI operations
use test doubles. This is offline validation, not a live Oracle/OCI deployment.
The combined regression suite is in the companion generator package's tests/.

### Verified behavior

- Original same-day RAW/STAGE/MAIN success and existing failure/retry guards.
- RAW-only completion leaves BATCH RUNNING; a fresh phase-2 framework instance
  reuses the exact key, batch and release, even after a new release becomes ACTIVE.
  Landing files are removed in that test; phase 2 succeeds without rereading them.
- Wrong workflow keys/cycle overrides, completed RAW reruns, malformed producer
  lineage and missing/wrong system audit fields fail safely.
- AIDP's explicit workflow_execution_key spans separate job-run identities;
  the original job correlation remains pinned and task attempts retain real IDs.
  Existing single-job defaults and stable-key failure finalization are tested.
- ALLOWED_VALUES exact case/whitespace/empty-string/null behavior, numeric/date
  typing, precision/length limits and invalid/duplicate configuration.
- Existing NOT_NULL/UNIQUE/RANGE checks remain at STAGE. Instrumented tests prove
  each business policy is evaluated once, without repeated MAIN business checks.
- WARN records WARN/WARNED, keeps task status COMPLETED and reject_count zero,
  permits downstream reads, and cannot bypass mandatory schema constraints.
- Explicit RAW-to-STAGE and STAGE-to-MAIN ROW_COUNT pairing, per-output fan-out,
  joins/aggregation rejection for STAGE equality, and STAGE checks before writes.
- MAIN compares validated STAGE input counts against actual adapter insert counts,
  not only collected/prepared size. Partial/unknown/negative/boolean counts and
  multi-target mismatches roll back target rows/load events/completion together.
  Durable failure policy results, error history and same-batch retry are tested.
- Empty append outputs reconcile zero correctly. Main row caps are task-wide,
  fail before insert without truncation, reject invalid settings, bound every
  collect by remaining+1 and permit a reviewed-cap retry.
- RAW source receipt IDs are correct for each source in combined ingestion;
  RAW/STAGE timestamp and lineage types are checked and removed from business
  frames. MAIN creation/update values are UTC and equal on insert.
- Reserved audit names are rejected as business columns. Target checks recognize
  Oracle TIMESTAMP(6/9) WITH TIME ZONE dictionary types, require at least six-digit
  precision, reject wrong/missing types and keep the gate read-only.
- Public onboarding generation preserves new rules/scopes/severity in complete
  YAML, renders dataset reconciliation SQL, and includes timestamp target DDL.
- Existing whole-file RAW quarantine, confirmed-copy conditions/terminal guards,
  independent catalog rows and existence-only OCI HEAD checks remain passing.

### Package checks

Both wheels were built from the final source, installed into a clean local target,
and tested there. Their source bytes match the packaged source; wheel RECORD
hashes/sizes, Python 3.10 syntax, local documentation links, ZIP integrity and
SHA256SUMS.txt were checked. Old wheels, build trees, caches and test dependencies
are excluded from the ZIPs. the original changed-file sections of RELEASE_NOTES.md lists differences from the supplied
whole-file quarantine package for each component.

Framework sql/00_framework.sql is byte-identical to the attached baseline and
still defines 17 framework tables. RAW/STAGE system fields are physical Parquet
fields; MAIN audit changes belong to business tables. No new framework columns
or tables were added. Source storage.py and generator builder.py/bulk_builder.py
are also byte-identical to that baseline.

The example metadata/DDL and complete YAML were regenerated. Framework DMI example
metadata inserts, including both new count policies, passed the offline SQL
adapter. The optional preserving MAIN audit-column SQL is a review proposal only;
it has not been executed or validated against a real Oracle server.

The local test-only Spark launcher uses a temporary file instead of process
substitution because /proc/self/fd is unavailable here; Java temp paths were also
redirected to the workspace. Neither workaround changes shipped product code.

### Rollout and limits

Install both version 1.1 wheels, restart workers/notebooks and deploy a new reviewed
metadata release. Read the Development rollout section of OPERATIONS.md first. Existing MAIN targets need the two audit
timestamp columns. Old-format retained Parquet requires the old runtime; finish
those batches there or start a new development batch. Do not infer missing source
receipt IDs or overwrite completed files to add fields.

MDPF_MAIN_MAX_ROWS defaults to 10000 across all outputs of a MAIN task; it is a row
bound, not a byte-memory guarantee or distributed load implementation. Parquet
writes remain independent external writes and retries overwrite attempt/batch
outputs under the existing guards; no multi-object OCI transaction is claimed.
WARN never bypasses technical schema or Oracle constraints. MAIN column business
policies must move to STAGE in new configurations.

No deployment, metadata activation, credential change or live bucket operation
was performed. Validate real Oracle transactions/DDL/grants and concurrency,
Resource Principal and Object Storage service permissions/copy completion,
actual Data Flow/AIDP parameter bindings, and killed-worker writer-stop recovery
in the development environment before normal scheduling. There is no waiting
batch dashboard, archive, row rejection, MERGE or broad Spark optimization.

### Wheel SHA256

- mdpf-1.1-py3-none-any.whl: `66f5b27a7c4d3e974885336125925351406ac3c47d6e925689aa5c9d614e81b3`
- mdpf_onboarding-1.1-py3-none-any.whl: `1df4a14e45253a52e73b4e688b4fee53a90a4dac9caaf5f8fe4dfe8a458efbda`

Oracle affected-row behavior was checked against the official
[batch DML documentation](https://python-oracledb.readthedocs.io/en/v3.4.2/user_guide/batch_statement.html)
and [cursor API](https://python-oracledb.readthedocs.io/en/v3.4.2/api_manual/cursor.html).
See the OCI permissions section of OPERATIONS.md for official OCI permissions references.

### Framework changed files before consolidation

This original 1.1 file inventory predates the documentation cleanup above.
The former document filenames below are historical records, not additional shipped files.

Compared with the attached MDPF_Framework_1_0_Whole_File_Quarantine.zip.

| Change | Package-relative file |
|---|---|
| Added | `CHANGELOG.md` |
| Added | `FEATURES.md` |
| Added | `OCI_IAM_EXAMPLE.md` |
| Added | `QUICK_START.md` |
| Changed | `README.md` |
| Added | `REFERENCE.md` |
| Added | `TROUBLESHOOTING.md` |
| Added | `TWO_PHASE.md` |
| Added | `UPGRADE.md` |
| Changed | `VERIFICATION_REPORT.md` |
| Changed | `dataflow/requirements.txt` |
| Added | `dist/mdpf-1.1-py3-none-any.whl` |
| Changed | `notebooks/job_parameters.json` |
| Added | `notebooks/two_phase_parameters.json` |
| Changed | `pyproject.toml` |
| Changed | `sql/01_main_and_access.sql` |
| Changed | `sql/02_dmi_metadata.sql` |
| Changed | `sql/03_inspect.sql` |
| Added | `sql/04_main_audit_columns.sql` |
| Changed | `src/mdpf/__init__.py` |
| Changed | `src/mdpf/aidp.py` |
| Changed | `src/mdpf/db.py` |
| Changed | `src/mdpf/pipeline.py` |
| Changed | `src/mdpf/schema.py` |
| Changed | `src/mdpf/steps.py` |
| Removed | `dist/mdpf-1.0-py3-none-any.whl` |

SHA256SUMS.txt is regenerated for the final package.

### Generator changed files before consolidation

This original 1.1 file inventory predates the documentation cleanup above.
The former document filenames below are historical records, not additional shipped files.

Compared with the attached MDPF_SQL_Generator_1_0_Whole_File_Quarantine.zip.

| Change | Package-relative file |
|---|---|
| Added | `CHANGELOG.md` |
| Added | `FEATURES.md` |
| Added | `OCI_IAM_EXAMPLE.md` |
| Added | `QUICK_START.md` |
| Changed | `README.md` |
| Added | `REFERENCE.md` |
| Added | `TROUBLESHOOTING.md` |
| Added | `TWO_PHASE.md` |
| Added | `UPGRADE.md` |
| Changed | `VERIFICATION_REPORT.md` |
| Added | `dist/mdpf_onboarding-1.1-py3-none-any.whl` |
| Changed | `examples/bulk_pre_onboarding.ipynb` |
| Added | `examples/dq_and_reconciliation.yaml` |
| Added | `examples/dq_metadata_draft.sql` |
| Changed | `examples/main_ddl.sql` |
| Changed | `examples/metadata_draft.sql` |
| Changed | `examples/pipeline_complete.yaml` |
| Changed | `pyproject.toml` |
| Changed | `src/mdpf_onboarding/__init__.py` |
| Changed | `src/mdpf_onboarding/metadata_generator.py` |
| Changed | `src/mdpf_onboarding/onboard.py` |
| Changed | `src/mdpf_onboarding/schema_discovery.py` |
| Changed | `tests/conftest.py` |
| Changed | `tests/test_bulk_builder.py` |
| Changed | `tests/test_dq_basic.py` |
| Changed | `tests/test_dq_sql.py` |
| Added | `tests/test_enhancements.py` |
| Changed | `tests/test_main_ddl.py` |
| Changed | `tests/test_oci.py` |
| Changed | `tests/test_oracle_gate.py` |
| Changed | `tests/test_raw_repair.py` |
| Changed | `tests/test_release_comparison.py` |
| Changed | `tests/test_workflow.py` |
| Removed | `dist/mdpf_onboarding-1.0-py3-none-any.whl` |

SHA256SUMS.txt is regenerated for the final package.
