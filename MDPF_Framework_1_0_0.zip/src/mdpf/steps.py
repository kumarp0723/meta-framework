"""Built-in Spark boundaries and once-per-attempt business DQ evaluation."""
from datetime import date, datetime, timezone
from decimal import Decimal, localcontext
import hashlib
import json
import os

from pyspark.sql import functions as F

from .schema import DataValidationError, convert_frame, require_columns, spark_type, string_limit, validate_frame
from .storage import malformed_csv_error


def validate_dq_parameters(params, column=None):
    """Validate the fixed rule vocabulary; no expressions or implicit coercion."""
    checks = {'NOT_NULL': {'check'}, 'UNIQUE': {'check'},
              'RANGE': {'check', 'min', 'max'},
              'ALLOWED_VALUES': {'check', 'values'},
              'ROW_COUNT': {'check', 'source_dataset'}}
    if not isinstance(params, dict) or not isinstance(params.get('check'), str) or params['check'] not in checks:
        raise ValueError('Supported DQ checks: NOT_NULL, UNIQUE, RANGE, ALLOWED_VALUES and ROW_COUNT.')
    check = params['check']
    if set(params) != checks[check]:
        raise ValueError(f'{check} requires exactly {sorted(checks[check])}.')
    if check == 'ROW_COUNT':
        from .schema import sql_identifier
        sql_identifier(params['source_dataset'])
    if check == 'RANGE':
        for value in (params['min'], params['max']):
            if isinstance(value, bool) or not isinstance(value, (int, float)):
                raise ValueError('RANGE min/max must be finite numeric YAML values.')
            number = Decimal(str(value))
            if (not number.is_finite() or
                    max(len(number.as_tuple().digits) + max(number.as_tuple().exponent, 0), -number.as_tuple().exponent) > 38):
                raise ValueError('RANGE bounds must fit Spark decimal precision/scale 38.')
        if params['min'] > params['max']:
            raise ValueError('RANGE min must not exceed max.')
        if column is not None and column['data_type'] != 'NUMBER':
            raise ValueError('RANGE requires a NUMBER column.')
    if check == 'ALLOWED_VALUES':
        values = params['values']
        if not isinstance(values, list) or not values:
            raise ValueError('ALLOWED_VALUES requires a nonempty list of unique scalar values.')
        normalized = []
        for value in values:
            if isinstance(value, bool) or value is None or not isinstance(value, (str, int, float, date)) or isinstance(value, datetime):
                raise ValueError('ALLOWED_VALUES requires non-null string, numeric or date scalars; booleans are unsupported.')
            if isinstance(value, (int, float)) and not Decimal(str(value)).is_finite():
                raise ValueError('ALLOWED_VALUES numeric values must be finite.')
            if column is not None:
                kind = column['data_type']
                if kind == 'VARCHAR2':
                    if not isinstance(value, str):
                        raise ValueError('ALLOWED_VALUES requires string values for VARCHAR2.')
                    length, unit = string_limit(column)
                    if (len(value.encode('utf-8')) if unit == 'BYTE' else len(value)) > length:
                        raise ValueError('ALLOWED_VALUES value exceeds the column length.')
                elif kind == 'NUMBER':
                    if not isinstance(value, (int, float)):
                        raise ValueError('ALLOWED_VALUES requires numeric values for NUMBER.')
                    number, typ = Decimal(str(value)), spark_type(column)
                    with localcontext() as context:
                        context.prec = 80
                        if abs(number) >= Decimal(10) ** (typ.precision - typ.scale) or number != number.quantize(Decimal(1).scaleb(-typ.scale)):
                            raise ValueError('ALLOWED_VALUES number does not fit the column precision/scale.')
                elif kind == 'DATE':
                    if isinstance(value, date):
                        value = value.isoformat()
                    if not isinstance(value, str) or date.fromisoformat(value).isoformat() != value:
                        raise ValueError('ALLOWED_VALUES DATE values require YYYY-MM-DD dates.')
            if isinstance(value, date):
                value = value.isoformat()
            if value in normalized:
                raise ValueError('ALLOWED_VALUES values must be unique.')
            normalized.append(value)
        params['values'] = normalized
    return params


def _policy_failures(df, policy, nulls):
    params, name = policy['parameters'], policy['column_name']
    if params['check'] == 'NOT_NULL':
        return nulls[name], '0 nulls'
    values = df.where(F.col(name).isNotNull())
    if params['check'] == 'UNIQUE':
        duplicates = values.select(F.col(name).alias('_dq_value')).groupBy('_dq_value').agg(F.count('*').alias('_dq_count'))
        amount = duplicates.where(F.col('_dq_count') > 1).agg(F.sum('_dq_count')).first()[0]
        return int(amount or 0), '0 rows with duplicate non-null values'
    if params['check'] == 'ALLOWED_VALUES':
        kind = df.schema[name].dataType
        allowed = [F.lit(Decimal(str(v)) if kind.typeName() == 'decimal' else v).cast(kind) for v in params['values']]
        return values.where(~F.col(name).isin(allowed)).count(), '0 rows outside the allowed values'
    invalid = (F.col(name) < F.lit(Decimal(str(params['min'])))) | (F.col(name) > F.lit(Decimal(str(params['max']))))
    return values.where(invalid).count(), f"0 rows outside [{params['min']}, {params['max']}]"


def policy_result(ctx, policy, failed_count, expected, actual):
    failed = failed_count is None or failed_count != 0
    warning = failed and policy['failure_action'] == 'WARN'
    return dict(config_release_id=policy['config_release_id'], policy_id=policy['policy_id'],
        batch_id=ctx['batch']['batch_id'], task_run_id=ctx['run_id'], dataset_id=policy['dataset_id'],
        dataset_column_id=policy.get('dataset_column_id'), result_level=policy['policy_scope_type'],
        result_status=('WARN' if warning else 'FAIL') if failed else 'PASS',
        expected_value=str(expected), actual_value=str(actual), threshold_value=policy['threshold_value'],
        failed_record_count=failed_count, failure_action_taken=('WARNED' if warning else 'FAILED_TASK') if failed else None)


def read_source(frames, ctx, params):
    fw, batch, task = ctx['framework'], ctx['batch'], ctx['task']
    result = {}
    for code, spec in ctx['inputs'].items():
        path = spec['location']
        identity = [fw.pipeline_code, ctx['source_config']['source_system_name'], code, path]
        key = 'RECEIPT:' + hashlib.sha256(json.dumps(identity, separators=(',', ':')).encode()).hexdigest()
        with fw.db.transaction():
            previous = fw.db.one('''SELECT ie.source_location, ie.source_item_key FROM RUNTIME.INGESTION_ITEM ie
                JOIN RUNTIME.TASK_RUN tr ON tr.task_run_id=ie.task_run_id
                WHERE tr.batch_id=:b AND tr.task_id=:t AND ie.dataset_id=:d ORDER BY tr.attempt_number ASC''',
                b=batch['batch_id'], t=task['task_id'], d=spec['dataset']['dataset_id'])
            item_id = fw.db.next_id('RUNTIME.INGESTION_ITEM', 'ingestion_item_id')
            fw.db.insert('RUNTIME.INGESTION_ITEM', dict(ingestion_item_id=item_id,
                task_run_id=ctx['run_id'], config_release_id=batch['config_release_id'],
                source_config_id=task['source_config_id'], dataset_id=spec['dataset']['dataset_id'],
                item_role='DATA', ingestion_type='FILE', item_name=path.rsplit('/', 1)[-1], source_item_key=key,
                source_location=path, landing_location=path, status='RECEIVED'))
            fw.db.execute('UPDATE RUNTIME.INGESTION_ITEM SET received_timestamp=SYSTIMESTAMP WHERE ingestion_item_id=:id', id=item_id)
        spec['ingestion_item_id'] = item_id
        if previous and (previous['source_location'] != path or previous['source_item_key'] != key):
            raise ValueError('Source delivery URI changed during restart; do not reuse this batch.')
        try:
            df = fw.storage.read_csv(fw.spark, path)
            require_columns(df, spec['columns'], 'CSV header')
            df = convert_frame(df, spec['columns'])
            _, spec['count'] = validate_frame(df, spec['columns'], 'Source', source=True)
        except Exception as exc:
            if ctx['source_config'].get('quarantine_path') and (
                    isinstance(exc, DataValidationError) or malformed_csv_error(exc)):
                fw._quarantine_source(ctx, spec, exc)
            raise
        result[code] = df
    ctx['input_count'] = sum(s['count'] for s in ctx['inputs'].values())
    return result


def read_parquet(frames, ctx, params):
    fw, result = ctx['framework'], {}
    for spec in ctx['inputs'].values():
        producers = fw.db.execute('''SELECT task_run_id FROM RUNTIME.TASK_RUN
            WHERE batch_id=:b AND config_release_id=:r AND task_id=:t AND status='COMPLETED' ''',
            b=ctx['batch']['batch_id'], r=ctx['batch']['config_release_id'], t=spec['producer_task_id'])
        if len(producers) != 1:
            raise ValueError('Input requires exactly one completed producer attempt in the same batch and pinned release.')
        spec['producer_run_id'] = producers[0]['task_run_id']
    for code, spec in ctx['inputs'].items():
        df = fw.storage.read_parquet(fw.spark, spec['location'])
        columns = spec['columns']
        system = {'_batch_id': 'bigint', '_run_id': 'bigint'}
        if spec['dataset']['layer'] == 'RAW':
            system.update(_ingestion_item_id='bigint', _ingested_at='timestamp')
        else:
            system['_processed_at'] = 'timestamp'
        expected = {c['column_name'] for c in columns} | set(system)
        if len(df.columns) != len(expected) or set(df.columns) != expected:
            raise ValueError('Input Parquet columns do not match DATASET_COLUMN and reserved lineage/audit fields.')
        if any(df.schema[n].dataType.simpleString() != typ for n, typ in system.items()):
            raise ValueError('Input Parquet lineage/audit column types do not match the layer contract.')
        invalid = F.lit(False)
        for name in system:
            invalid = invalid | F.col(name).isNull()
        invalid = invalid | (F.col('_batch_id') != ctx['batch']['batch_id']) | (F.col('_run_id') != spec['producer_run_id'])
        if spec['dataset']['layer'] == 'RAW':
            receipts = fw.db.execute('''SELECT ie.ingestion_item_id FROM RUNTIME.INGESTION_ITEM ie
                JOIN METADATA.TASK_DATASET src ON src.config_release_id=ie.config_release_id
                    AND src.dataset_id=ie.dataset_id AND src.dataset_role='INPUT' AND src.is_enabled='Y'
                JOIN METADATA.TASK_DATASET dst ON dst.config_release_id=src.config_release_id
                    AND dst.task_id=src.task_id AND dst.usage_sequence=src.usage_sequence
                    AND dst.dataset_role='OUTPUT' AND dst.is_enabled='Y'
                WHERE ie.task_run_id=:run AND ie.config_release_id=:r AND ie.status='PROCESSED'
                    AND src.task_id=:task AND dst.dataset_id=:dataset''',
                run=spec['producer_run_id'], r=ctx['batch']['config_release_id'],
                task=spec['producer_task_id'], dataset=spec['dataset']['dataset_id'])
            if len(receipts) != 1:
                raise ValueError('RAW requires one processed source receipt from its paired completed producer.')
            invalid = invalid | (F.col('_ingestion_item_id') != receipts[0]['ingestion_item_id'])
        if df.where(invalid).limit(1).count():
            raise ValueError('Input Parquet lineage/audit does not match the current batch and completed producer attempt.')
        df = df.drop(*system)
        _, spec['count'] = validate_frame(df, columns, 'Input Parquet')
        result[code] = df.select(*[c['column_name'] for c in columns])
    ctx['input_count'] = sum(s['count'] for s in ctx['inputs'].values())
    return result


def output_frames(frames, ctx):
    outputs = ctx['outputs']
    if set(frames) == set(outputs):
        return frames
    if 'raw_pairs' in ctx and set(frames) == set(ctx['inputs']):
        return {output: frames[source] for output, source in ctx['raw_pairs'].items()}
    if len(frames) == 1 and set(frames) == set(ctx['inputs']):
        return {code: next(iter(frames.values())) for code in outputs}
    raise ValueError('Custom step must return exactly the output dataset codes; multiple inputs are never joined or routed automatically.')


def _check_output(df, ctx, spec, record_pass=False, oracle=False, check_nulls=True):
    """Business policies run only at VALIDATE_DQ; sink schema checks remain blocking."""
    nulls, count = validate_frame(df, spec['columns'], 'Output', check_nulls=False, oracle=oracle)
    if record_pass:
        results = []
        for policy in spec['policies']:
            if policy['parameters']['check'] == 'ROW_COUNT':
                if spec['dataset']['layer'] == 'GOLD':
                    continue  # Actual Oracle DML counts are available only in _complete.
                expected = ctx['inputs'][policy['parameters']['source_dataset']]['count']
                results.append(policy_result(ctx, policy, abs(expected - count), expected, count))
            else:
                amount, expected = _policy_failures(df, policy, nulls)
                results.append(policy_result(ctx, policy, amount, expected, amount))
        if results:
            ctx['framework']._record_policy_results(ctx, results)
    if check_nulls and any(nulls[c['column_name']] for c in spec['columns'] if c['is_nullable'] == 'N'):
        raise DataValidationError('Required target column has nulls.')
    return count


def direct_map(frames, ctx, params):
    result = {}
    for code, df in output_frames(frames, ctx).items():
        spec = ctx['outputs'][code]
        result[code] = convert_frame(df, spec['columns'])
        # Required target nullability is enforced after policy evidence at VALIDATE_DQ
        # and again at the sink; conversion/type/length checks remain here.
        _check_output(result[code], ctx, spec, check_nulls=False)
    return result


def validate_dq(frames, ctx, params):
    result = output_frames(frames, ctx)
    for code, df in result.items():
        _check_output(df, ctx, ctx['outputs'][code], record_pass=True)
    ctx['state']['validated_outputs'] = result
    return result


def _require_validated(result, ctx):
    if any(s['dataset']['layer'] in ('STAGE', 'GOLD') for s in ctx['outputs'].values()):
        validated = ctx['state'].get('validated_outputs', {})
        if set(result) != set(validated) or any(df is not validated[code] for code, df in result.items()):
            raise ValueError('Sink requires the exact outputs from VALIDATE_DQ.')


def write_parquet(frames, ctx, params):
    fw, result = ctx['framework'], output_frames(frames, ctx)
    _require_validated(result, ctx)
    outputs = {code: {'count': _check_output(df, ctx, ctx['outputs'][code])} for code, df in result.items()}
    stamp = datetime.now(timezone.utc)
    for code, df in result.items():
        spec = ctx['outputs'][code]
        data = df.select(*[c['column_name'] for c in spec['columns']])
        data = data.withColumn('_batch_id', F.lit(ctx['batch']['batch_id']).cast('long'))
        data = data.withColumn('_run_id', F.lit(ctx['run_id']).cast('long'))
        if spec['dataset']['layer'] == 'RAW':
            receipt = ctx['inputs'][ctx['raw_pairs'][code]]['ingestion_item_id']
            data = data.withColumn('_ingestion_item_id', F.lit(receipt).cast('long'))
            data = data.withColumn('_ingested_at', F.lit(stamp).cast('timestamp'))
        else:
            data = data.withColumn('_processed_at', F.lit(stamp).cast('timestamp'))
        fw.storage.write_parquet(spec['location'], data)
    ctx['state']['outputs'] = outputs
    ctx['output_count'] = sum(s['count'] for s in outputs.values())
    return result


def load_main(frames, ctx, params):
    setting = os.environ.get('MDPF_MAIN_MAX_ROWS', '10000')
    try:
        maximum = int(setting)
    except ValueError as exc:
        raise ValueError('MDPF_MAIN_MAX_ROWS must be a positive integer, at most 2147483646.') from exc
    if not 1 <= maximum <= 2147483646:
        raise ValueError('MDPF_MAIN_MAX_ROWS must be a positive integer, at most 2147483646.')
    result = output_frames(frames, ctx)
    _require_validated(result, ctx)
    for code, df in result.items():
        _check_output(df, ctx, ctx['outputs'][code], oracle=True)
    outputs, total = {}, 0
    for code, df in result.items():
        columns = ctx['outputs'][code]['columns']
        remaining = maximum - total
        rows = df.select(*[c['column_name'] for c in columns]).limit(remaining + 1).collect()
        if len(rows) > remaining:
            raise ValueError(f'MAIN row limit exceeded: MDPF_MAIN_MAX_ROWS={maximum}; output {code} exceeds the {remaining} rows remaining for this task.')
        outputs[code] = {'rows': [r.asDict() for r in rows], 'count': len(rows)}
        total += len(rows)
    ctx['state']['outputs'] = outputs
    ctx['output_count'] = total
    return result


BUILTINS = {'READ_SOURCE': read_source, 'READ_PARQUET': read_parquet,
            'DIRECT_MAP': direct_map, 'VALIDATE_DQ': validate_dq,
            'WRITE_PARQUET': write_parquet, 'LOAD_MAIN': load_main}
