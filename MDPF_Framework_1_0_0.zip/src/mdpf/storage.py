"""OCI paths and native Spark CSV/Parquet I/O for the sequential POC."""
from pathlib import PurePosixPath
from urllib.parse import urlsplit


def malformed_csv_error(exc):
    """Recognize Spark parser error codes; never classify generic I/O as bad data."""
    from py4j.protocol import Py4JError, Py4JJavaError
    cause = exc.java_exception if isinstance(exc, Py4JJavaError) else exc
    for _ in range(12):
        try:
            code = cause.getErrorClass()
        except (AttributeError, Py4JError):
            code = None
        if code and (code == 'MALFORMED_CSV_RECORD' or
                     code.startswith('MALFORMED_RECORD_IN_PARSING.')):
            return True
        if not isinstance(exc, Py4JJavaError):
            break
        try:
            cause = cause.getCause()
        except Py4JError:
            break
        if cause is None:
            break
    return False


def object_address(uri):
    parts = urlsplit(str(uri))
    if parts.scheme != "oci" or "@" not in parts.netloc or parts.query or parts.fragment:
        raise ValueError("Use oci://bucket@namespace/object-key (no query or fragment).")
    bucket, namespace = parts.netloc.split("@", 1)
    key = parts.path.lstrip("/")
    if not bucket or not namespace or ".." in PurePosixPath(key).parts:
        raise ValueError("Invalid OCI object address.")
    return namespace, bucket, key


class ObjectStorage:
    def quarantine_file(self, source, destination):
        """Copy one immutable delivery within the Resource Principal's OCI region."""
        import oci
        source_ns, source_bucket, source_key = object_address(source)
        dest_ns, dest_bucket, dest_key = object_address(destination)
        if not source_key or not dest_key or source == destination:
            raise ValueError('Quarantine requires distinct exact object locations.')
        signer = oci.auth.signers.get_resource_principals_signer()
        client = oci.object_storage.ObjectStorageClient({}, signer=signer)
        etag = client.head_object(source_ns, source_bucket, source_key).headers['etag']
        details = oci.object_storage.models.CopyObjectDetails(
            source_object_name=source_key, source_object_if_match_e_tag=etag,
            destination_region=signer.region, destination_namespace=dest_ns,
            destination_bucket=dest_bucket, destination_object_name=dest_key,
            destination_object_if_none_match_e_tag='*')
        response = oci.object_storage.ObjectStorageClientCompositeOperations(client).copy_object_and_wait_for_state(
            source_ns, source_bucket, details, wait_for_states=['COMPLETED', 'FAILED', 'CANCELED'],
            waiter_kwargs={'max_wait_seconds': 300, 'max_interval_seconds': 5})
        if getattr(response.data, 'status', None) != 'COMPLETED':
            raise RuntimeError('Quarantine copy did not complete successfully.')
        client.head_object(dest_ns, dest_bucket, dest_key)

    def read_csv(self, spark, location):
        key = object_address(location)[2]
        if not key.lower().endswith(".csv") or any(c in key for c in "*[]{}"):
            raise ValueError("An exact OCI .csv object key is required.")
        return spark.read.options(header=True, inferSchema=False, mode="FAILFAST",
                                  multiLine=True, escape='"').csv(location)

    def read_parquet(self, spark, location):
        if not object_address(location)[2]:
            raise ValueError("An exact OCI object prefix is required.")
        return spark.read.parquet(location)

    def write_parquet(self, location, df):
        """Spark replaces this batch's Parquet dataset on Repair."""
        if not object_address(location)[2]:
            raise ValueError("An exact OCI object prefix is required.")
        df.write.mode("overwrite").parquet(location)
