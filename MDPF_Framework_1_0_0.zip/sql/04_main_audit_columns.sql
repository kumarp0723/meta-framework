-- OPTIONAL MAIN AUDIT UPGRADE FOR EARLIER BUILDS WITHOUT THESE COLUMNS.
-- Never run on a table that already has CREATED_AT and UPDATED_AT.
-- Replace OWNER.TABLE below with one reviewed existing MAIN target, one at a time.
-- Stop writers first. Oracle DDL commits independently; take a backup before use.
-- Does not alter any of the 17 framework tables and is never run by the generator.
-- Regenerated CREATE DDL is sufficient for fresh development tables.
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
DEFINE main_target = OWNER.TABLE
ALTER TABLE &&main_target ADD (
    CREATED_AT TIMESTAMP(6) WITH TIME ZONE,
    UPDATED_AT TIMESTAMP(6) WITH TIME ZONE
);
-- Historical row creation time is approximated by its recorded attempt completion;
-- it is not claimed to be the original insert timestamp. Inspect the values.
UPDATE &&main_target t SET (CREATED_AT, UPDATED_AT) = (
    SELECT tr.end_timestamp AT TIME ZONE 'UTC', tr.end_timestamp AT TIME ZONE 'UTC'
    FROM RUNTIME.TASK_RUN tr
    WHERE tr.task_run_id=t.TASK_RUN_ID AND tr.batch_id=t.BATCH_ID
);
COMMIT;
-- Fails closed if historical attempts lack completion timestamps. Resolve those
-- rows explicitly; do not fabricate their original creation times.
ALTER TABLE &&main_target MODIFY (CREATED_AT NOT NULL, UPDATED_AT NOT NULL);
UNDEFINE main_target
