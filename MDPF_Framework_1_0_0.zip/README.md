# MDPF Framework 1.0

Run metadata-defined Spark tasks on OCI Data Flow or AIDP, with Oracle execution
history and transactional MAIN loading. The 17-table framework model is unchanged.

Start with the [end-to-end quick start](../generator/README.md#end-to-end-quick-start). Existing installations
must follow [development rollout](OPERATIONS.md#development-rollout) before switching runtimes.

- **Same-day or two-phase:** RAW can finish now and STAGE/MAIN later in the same
  batch and pinned release. Data Flow reuses its execution key; AIDP optionally
  accepts `workflow_execution_key` across separate jobs. [Scheduling](OPERATIONS.md#two-phase-scheduling)
- **Business DQ at STAGE:** NOT_NULL, UNIQUE, RANGE and ALLOWED_VALUES with FAIL/WARN.
  MAIN verifies actual Oracle inserts before commit. [Rules](REFERENCE.md#dq-reconciliation-and-audit-contracts)
- **Five audit fields:** RAW source receipt/time, STAGE processing time, MAIN
  creation/update times; populated and validated automatically. [Contract](REFERENCE.md#five-framework-managed-audit-fields)
- **Bounded MAIN loading:** default `MDPF_MAIN_MAX_ROWS=10000` across all task outputs.
  Exceeding the limit fails before inserts; nothing is truncated.
- **Whole-file quarantine:** proven RAW technical validation failures only;
  the source stays in landing. STAGE business failures retain normal failure behavior.

Install `dist/mdpf-1.0-py3-none-any.whl` with its dependencies and restart workers.
Use cluster-provided Spark/Java. No runtime deployment or metadata activation is
performed by this package.

| Reference | Contents |
|---|---|
| [Detailed reference](REFERENCE.md) | Setup, built-in plans, custom handlers and recovery |
| [OCI permissions example](OPERATIONS.md#oci-permissions) | Dedicated-compartment IAM example and official links |
| [Troubleshooting](OPERATIONS.md#troubleshooting) | Phase waits, DQ, lineage, limits and failed counts |
| [Verification report](RELEASE_NOTES.md#runtime-verification-2026-10-25) | Current test evidence and environment limitations |

Fresh installs use `sql/00_framework.sql` and `sql/01_main_and_access.sql` with
reviewed owners/grants. `sql/04_main_audit_columns.sql` is an optional reviewed
proposal for adding audit timestamps to an existing MAIN table. It does not change
framework tables. Keep credentials outside YAML/notebooks.

Waiting-batch dashboard, archive, row rejection and MERGE remain outside this release.

## Runtime quick start

1. Install the supplied 1.0 wheel and dependencies on notebook/runtime workers;
   configure Spark OCI access and the secure Oracle connection settings.
2. Follow [setup and execution](REFERENCE.md#set-up-once) for the runtime and
   [the end-to-end quick start](../generator/README.md#end-to-end-quick-start)
   for pre-onboarding, generation and deployment.
3. Run the configured RAW, STAGE and MAIN tasks with the shared workflow identity;
   see [operations](OPERATIONS.md) for delayed continuation, failure and upgrade rules.


Shared operations and release documentation is maintained here in the framework folder.

When replacing an existing install, force-reinstall both supplied 1.0 wheels and
restart Python/worker sessions. Install required dependencies before using --no-deps.
