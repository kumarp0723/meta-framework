"""Pin the reviewed business contract, independently of utility example files."""
import json

from mdpf_onboarding.metadata_generator import render_main_ddl


RAW, STAGE, MAIN = ('DMI_FEE_FEE_' + role for role in ('RAW', 'STAGE', 'MAIN'))


def test_fee_schema_plans_policies_and_target(fee_model):
    expected = [
        ('MSP_CYCLE_DATE', 'DATE', None, 'N'),
        ('DELTA_FILE_BYTE', 'VARCHAR2', '10 CHAR', 'Y'),
        ('LN_NO', 'NUMBER', '19', 'N'),
        ('FEE_TRAN_CD', 'NUMBER', '10', 'Y'),
        ('FEE_TRAN_TY', 'VARCHAR2', '20 CHAR', 'Y'),
        ('FEE_CD', 'NUMBER', '10', 'Y'),
        ('FEE_TRAN_DT', 'DATE', None, 'Y'),
        ('FEE_TRAN_AM', 'NUMBER', '18,2', 'Y'),
        ('FEE_BATCH_CD', 'VARCHAR2', '20 CHAR', 'Y'),
        ('FEE_SUB_CD', 'VARCHAR2', '20 CHAR', 'Y'),
        ('CLIENT_NO', 'VARCHAR2', '50 CHAR', 'Y'),
        ('DMI_TIME_STAMP', 'VARCHAR2', '30 CHAR', 'Y'),
    ]
    fields = ('column_name', 'data_type', 'length_precision_scale', 'is_nullable')
    for code in (STAGE, MAIN):
        assert [tuple(c[k] for k in fields) for c in fee_model['datasets'][code]['columns']] == expected
    raw_columns = fee_model['datasets'][RAW]['columns']
    assert [c['column_name'] for c in raw_columns] == [c[0] for c in expected]
    assert all((c['data_type'], c['length_precision_scale'], c['is_nullable']) ==
               ('VARCHAR2', '100 CHAR', 'Y') for c in raw_columns)
    assert [t['row']['task_code'] for t in fee_model['tasks']] == [
        'DMI_FEE_RAW_LOAD', 'DMI_FEE_STAGE_LOAD', 'DMI_FEE_MAIN_LOAD']
    assert [t['steps'] for t in fee_model['tasks']] == [
        ['READ_SOURCE', 'WRITE_PARQUET'],
        ['READ_PARQUET', 'CUSTOM_FEE_TRANSFORM', 'DIRECT_MAP', 'VALIDATE_DQ', 'WRITE_PARQUET'],
        ['READ_PARQUET', 'DIRECT_MAP', 'VALIDATE_DQ', 'LOAD_MAIN']]
    custom = [s for s in fee_model['tables']['TASK_STEP'] if s['step_type'] == 'CUSTOM_PYTHON']
    assert len(custom) == 1 and custom[0]['step_code'] == 'CUSTOM_FEE_TRANSFORM'
    assert json.loads(custom[0]['parameter_json']) == {'column': 'CLIENT_NO'}
    policies = fee_model['tables']['POLICY_DEFINITION']
    assert len(policies) == 4
    assert [p['policy_code'] for p in policies] == [
        STAGE + '_MSP_CYCLE_DATE_NOT_NULL', STAGE + '_LN_NO_NOT_NULL',
        STAGE + '_ROW_COUNT', MAIN + '_ROW_COUNT']
    assert [json.loads(p['parameter_json']) for p in policies] == [
        {'check': 'NOT_NULL'}, {'check': 'NOT_NULL'},
        {'check': 'ROW_COUNT', 'source_dataset': RAW},
        {'check': 'ROW_COUNT', 'source_dataset': STAGE}]
    assert all((p['policy_severity'], p['threshold_value'], p['failure_action']) ==
               ('ERROR', '0', 'FAIL_TASK') for p in policies)
    source = fee_model['tables']['SOURCE_CONFIG'][0]
    assert (source['source_type'], source['ingestion_mode'], source['expected_input_count'],
            source['file_pattern']) == ('FILE', 'SINGLE_FILE', 1, 'fee_{YYYYMMDD}.csv')
    assert fee_model['datasets'][MAIN]['row']['physical_object_name'] == {
        'DEV': 'DMI_MAIN_DEV.DMI_FEE', 'STAGE': 'DMI_MAIN_STAGE.DMI_FEE', 'PROD': 'DMI_MAIN.DMI_FEE'}
    ddl = render_main_ddl(fee_model, b'provider contract test')
    for statement in ('MSP_CYCLE_DATE DATE NOT NULL', 'LN_NO NUMBER(19) NOT NULL',
                      'FEE_TRAN_AM NUMBER(18,2)', 'CLIENT_NO VARCHAR2(50 CHAR)',
                      'CREATED_AT TIMESTAMP(6) WITH TIME ZONE NOT NULL'):
        assert statement in ddl
