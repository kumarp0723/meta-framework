"""Provider fixtures; integration reuses existing CI adapters without copying them."""
import importlib.util
import os
from pathlib import Path
import sys

import pytest
import yaml
from pyspark.sql import SparkSession

from mdpf.pipeline import MetadataFramework
from mdpf_onboarding.config import UniqueLoader, validate_config
from mdpf_onboarding.metadata_generator import contract_model, render_sql


PROVIDER_ROOT = Path(__file__).resolve().parent
FEE_DIR = PROVIDER_ROOT / 'datasets' / 'fee'


@pytest.fixture(scope='session')
def spark():
    os.environ['SPARK_LOCAL_IP'] = '127.0.0.1'
    os.environ['PYSPARK_PYTHON'] = sys.executable
    session = (SparkSession.builder.master('local[1]').appName('provider-dmi-tests')
               .config('spark.ui.enabled', 'false')
               .config('spark.sql.shuffle.partitions', '1')
               .config('spark.sql.session.timeZone', 'UTC').getOrCreate())
    session.sparkContext.setLogLevel('ERROR')
    yield session
    session.stop()


@pytest.fixture(scope='session')
def fee_dir():
    return FEE_DIR


@pytest.fixture(scope='session')
def fee_config():
    return validate_config(yaml.load((FEE_DIR / 'onboarding.yaml').read_text(), Loader=UniqueLoader))


@pytest.fixture(scope='session')
def fee_model(fee_config):
    return contract_model(fee_config)


@pytest.fixture(scope='session')
def ci_adapters():
    path = PROVIDER_ROOT.parents[2] / 'common-utilities/generator/tests/conftest.py'
    if not path.is_file():
        pytest.skip('Integration requires the sibling common-utilities source checkout (CI adapters).')
    spec = importlib.util.spec_from_file_location('_mdpf_ci_support', path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


@pytest.fixture
def execution_case(fee_model, fee_dir, ci_adapters, spark, tmp_path):
    db = ci_adapters.CatalogDb()
    close = db.close
    try:
        db.deploy(render_sql(fee_model, (fee_dir / 'onboarding.yaml').read_bytes()))
        # Only the SQLite test catalog is activated here. Generation remains DRAFT.
        db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE'")
        main = fee_model['datasets']['DMI_FEE_FEE_MAIN']
        columns = [c['column_name'] + ' TEXT' for c in main['columns']]
        db.conn.execute('CREATE TABLE DMI_MAIN_DEV.DMI_FEE (' + ','.join(columns) +
                        ',BATCH_ID INTEGER,TASK_RUN_ID INTEGER,ROW_NUMBER INTEGER,CREATED_AT TEXT,UPDATED_AT TEXT)')
        storage = ci_adapters.SparkTestStorage(tmp_path)
        landing = fee_model['datasets']['DMI_FEE_FEE_LANDING']['row']['physical_object_name']['DEV']
        path = storage.path(landing.replace('{YYYYMMDD}', '20261015'))
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_bytes((fee_dir / 'samples/fee_input.csv').read_bytes())
        fw = MetadataFramework(db, 'DMI_FEE', spark=spark)
        fw.storage = storage
        yield fw, db, path
    finally:
        close()
