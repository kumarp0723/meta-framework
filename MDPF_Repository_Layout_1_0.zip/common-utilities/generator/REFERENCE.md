# MDPF SQL Generator 1.0 — technical reference

- [How it works](#how-it-works)
- [Public API and CLI contracts](#public-api-and-cli-contracts)
- [Prepare input YAMLs from a CSV catalog](#prepare-input-yamls-from-a-csv-catalog)
- [Optional RAW whole-file quarantine](#optional-raw-whole-file-quarantine)
- [First onboarding](#first-onboarding)
- [Make a change](#make-a-change)
- [YAML field reference](#yaml-field-reference)
- [Schemas and target DDL proposals](#schemas-and-target-ddl-proposals)
- [Configure task steps](#configure-task-steps)
- [Optional DQ rules](#optional-dq-rules)
- [Deploy and debug](#deploy-and-debug)
- [Where the code lives](#where-the-code-lives)

Prepare input YAMLs from an optional CSV catalog, or start with an existing YAML;
then generate a complete pipeline YAML,
DRAFT metadata SQL, and optional MAIN table schema proposals from OCI YAML and
sample CSVs. The utility never executes SQL,
queries Oracle during generation, activates releases, or updates Git.

Use the companion **MDPF 1.0** wheel. Extract the two packages into sibling
`framework/` and `generator/` folders for the [framework README](../framework/README.md)
links. MDPF runs on AIDP or Data Flow; onboarding configuration is platform-neutral.

Start with the [developer guide](../framework/DEVELOPER_GUIDE.md) for actual module
calls and local-versus-live setup, then the [DMI_FEE walkthrough](README.md#end-to-end-quick-start).
The catalog builder and supplied YAML are alternatives. Public generation requires
OCI; local tests use adapters and do not require OCI/Oracle credentials.

## How it works

```mermaid
flowchart TD
    CATALOG["CSV catalog and shared profile"] --> P["Preview and save input YAMLs"]
    P --> C
    C["Current YAML and samples in OCI"] --> G["Validate and generate"]
    B["Optional previous complete YAML"] --> G
    G --> Y["Reusable pipeline YAML"]
    G --> S["Metadata SQL and optional target DDL"]
    Y --> R["Review and commit to Git"]
    S --> D["Review, deploy DRAFT, verify and activate"]
```

No `baseline_yaml` means initial setup. Supplying it means comparison. The
baseline must be the previous complete generated YAML for the same pipeline;
its samples are not read. A missing/invalid baseline fails before sample reads.
Comparison requires a different metadata `release_version`.

## Public API and CLI contracts

| Entry point | Important inputs | Return | Side effects and failures |
|---|---|---|---|
| `onboard.load_config(uri, *, client=None)` | Exact OCI YAML URI; optional approved ObjectStorageClient | Expanded/defaulted configuration dictionary | Reads/validates config only; no sample reads or artifact writes. Validation/auth/SDK errors propagate. |
| `onboard.generate(config_uri, *, baseline_yaml=None, spark=None, client=None)` | OCI input YAML; optional separate complete baseline, caller Spark session and approved SDK client | Metadata SQL URI on success; `None` when explicit datatype overrides are required | Reads current samples and independently uploads complete YAML, optional DDL and metadata SQL. Prints required overrides and uploads nothing for the `None` result. Other validation/Spark/SDK errors raise; later upload failures may leave earlier objects. Never connects to Oracle or activates metadata. |

Generation validates the baseline/destinations before sample I/O and renders all
artifacts before publication. It stops only a Spark session created internally,
not a caller-provided or already active session. `object_client()` is a zero-argument
Resource Principal factory; pass an alternate approved client at the public entry
point, not to that factory. Spark bucket access and Python SDK authentication are
separate. Existing `onboard` validator and `metadata_generator` renderer/gate
imports remain compatibility aliases; implementation owners are listed
[below](#where-the-code-lives).

### CLI outcomes

Use `mdpf-onboard --config <oci-uri> [--baseline-yaml <oci-uri>]` or
`python -m mdpf_onboarding.onboard` with the same arguments. These commands require
OCI for generation; `--help` needs no cloud connection.

| Process exit code | Meaning and next action |
|---|---|
| `0` | Generation succeeded, or `--help` printed usage. Successful generation prints the summary/artifact locations; the Python API returns the SQL URI. |
| `1` | A parsed generation request raised an exception. CLI prints `ERROR: ...` to stderr without a traceback. Inspect the error and any artifacts already uploaded. |
| `2` | Generation returned `None` with required datatype overrides printed to stdout: review/add them and rerun. Also used by argparse for missing/invalid arguments; usage/error appears on stderr and generation does not start. |

When called as Python, `onboard.main(argv)` returns 0/1/2 for generation outcomes;
argparse raises SystemExit(0) for help and SystemExit(2) for argument errors.
`load_config()` and `generate()` themselves propagate errors; they do not return
CLI error codes. A `None` generation result is an action-required outcome, not an
exception. See [schema inference](#schemas-and-target-ddl-proposals) and the
[working walkthrough](README.md#end-to-end-quick-start) for the existing examples.

## Prepare input YAMLs from a CSV catalog

Use this optional first step for independent datasets: **one catalog row = one
pipeline = one input YAML**. It checks input/output sample existence using OCI
`head_object()` without downloading sample contents, inferring types, generating
SQL or starting pipeline jobs.

1. Install the framework and updated generator wheels as described below.
2. Edit `examples/shared_profile.yaml`: set your OCI sample/artifact roots,
   separate landing/RAW/STAGE buckets and Oracle owners for DEV/STAGE/PROD.
   `samples_root` resolves relative sample paths. `artifacts_root` is the output
   prefix. The builder appends the lowercase pipeline code to the landing,
   RAW and STAGE key prefixes. Profile settings are copied into each input YAML.
3. Fill `examples/bulk_catalog.csv` and upload both files to OCI. Use uppercase
   pipeline/dataset/table identifiers. Every row has its own input/output sample.

   | CSV column | Required? | Default when omitted or blank |
   |---|---|---|
   | `pipeline_code` | Yes | Independent pipeline identifier |
   | `dataset_code` | Yes | Input and output dataset code |
   | `source_system` | Yes | Source system name |
   | `input_sample_csv` | Yes | Full OCI URI or path relative to `samples_root` |
   | `output_sample_csv` | Yes | Full OCI URI or path relative to `samples_root` |
   | `release_version` | No | String `1.0` |
   | `file_name` | No | Lowercase dataset code + `_{YYYYMMDD}.csv` |
   | `target_table` | No | Dataset code |

   The existing DMI_FEE row is first and explicitly sets `target_table=DMI_FEE`.
   The builder otherwise defaults to dataset code `FEE`. Retained LOAN/CLIENT
   rows explicitly keep targets `LOAN`/`CLIENT`. Keep shared samples_root
   `oci://mdpf-samples@devns/dmi`; paths are `fee/input.csv`, `fee/output.csv`,
   `loan/input.csv`, `loan/output.csv`, `client/input.csv`, `client/output.csv`.
   Upload the two packaged FEE CSVs to their FEE object keys. LOAN/CLIENT rows
   require their own real sample objects; path validation does not prove existence.

4. Open `examples/bulk_pre_onboarding.ipynb`. Set the two OCI URIs and preview:

   ```python
   from mdpf_onboarding.bulk_builder import build_catalog
   from pprint import pprint

   PROFILE = "oci://mdpf-config@devns/profiles/shared_profile.yaml"
   CATALOG = "oci://mdpf-config@devns/catalogs/dmi_onboarding.csv"
   results = build_catalog(PROFILE, CATALOG)  # No writes; configuration + sample existence checks.
   pprint(results)
   ```

5. Review the results, then run the separate save cell:

   ```python
   results = build_catalog(PROFILE, CATALOG, dry_run=False)
   pprint(results)
   ```

   Example destination:
   `oci://mdpf-dev-artifacts@devns/onboarding/dmi_fee/1.0/input/config.yaml`.
   This is the builder filename; the hand-authored route uses `input/dmi_fee.yaml`.
   Generated SQL/complete YAML later go to the sibling `generated/` prefix.
6. Review/edit each input YAML when custom steps, datatype overrides, DQ rules
   or target DDL are needed. Then invoke `generate(yaml_uri, spark=spark)` for
   each selected pipeline using the existing onboarding flow below.

The notebook returns `row`, `pipeline_code`, `status`, `yaml_uri` and `message`.
`row` is the record number, excluding the CSV header. Status is `VALIDATED`
(preview only), `CREATED`, `SKIPPED` (object already exists) or `FAILED`.
Existing YAMLs are never overwritten or compared; `SKIPPED` does not mean their
contents match the catalog. Fix/update an established pipeline through its
maintained complete YAML and the existing baseline workflow, not this builder.

Malformed catalogs or invalid profiles stop before any writes. Duplicate pipeline
codes, conflicting target tables and YAML destinations reject every involved row;
other valid rows continue. Permission/network/upload errors are reported per row.
Each call rereads the profile/catalog once; keep them unchanged between preview
and save. Both calls issue OCI HEAD requests for each valid row's exact input and
output sample paths, after configuration/conflict checks and before any uploads.
A missing/inaccessible sample or other HEAD failure marks that row FAILED; other
valid rows continue. Errors identify the affected sample URI. Existing YAMLs stay
untouched, including when a sample check fails before the conditional create.
Preview does not verify sample contents, schema or YAML write permissions. Even
an empty sample object passes the existence check; onboarding still checks its data.
Use Resource Principal permissions for profile/catalog reads, sample object HEAD
requests and YAML creation. A successful HEAD proves current SDK metadata access,
not Spark driver/worker sample-read access or future sample availability.
No Spark session starts here, but the installed framework/PySpark dependencies
are still required by the existing validator. ZIP extraction is separate: a ZIP
of ten independent CSV datasets needs ten catalog rows and extracted samples.

## Optional RAW whole-file quarantine

Use the updated companion framework wheel together with this generator wheel.
The feature is opt-in; unchanged profiles and pipeline YAML retain fail-only
behavior. Bulk sample HEAD checks continue to check existence only.

1. In the shared profile, add `storage.quarantine_key_prefix: quarantine` and
   add a `quarantine` bucket alias in **each** DEV/STAGE/PROD environment.
   The existing example contains commented entries ready to fill in.
2. Run the builder for the intended pipeline/release. It appends the lowercase
   pipeline code to the profile prefix, just as for RAW/STAGE paths.
3. Run normal onboarding to generate metadata SQL. For established pipelines,
   edit the maintained complete YAML, bump the release version and use the
   existing baseline comparison workflow instead of re-inferring schemas.
4. Review/deploy the new DRAFT metadata and activate it through the existing
   process. The running batch must use a release with `SOURCE_CONFIG.quarantine_path`;
   changing a profile alone does not change deployed or already pinned metadata.
5. Install the updated framework on workers and configure OCI server-side copy
   permissions. No Oracle table/schema changes are required.

For a directly edited pipeline YAML, the additional settings are:

```yaml
storage:
  raw_key_prefix: raw/dmi_fee
  stage_key_prefix: stage/dmi_fee
  quarantine_key_prefix: quarantine/dmi_fee
# Within each environments.<ENV>.buckets mapping, add:
# quarantine: <that environment's quarantine bucket>
```

`examples/whole_file_rejection.yaml` is a complete example. Generation validates
quarantine prefixes/buckets in all environments and rejects overlapping landing,
RAW or STAGE locations. It populates the existing per-environment
`SOURCE_CONFIG.quarantine_path` and preserves this setting in complete YAML and
baseline comparisons. It does not create buckets or perform runtime copies.

At runtime, proven invalid source CSVs are copied to quarantine during RAW
validation and their ingestion items are marked QUARANTINED; the task fails.
The original landing object is preserved for investigation and retries. No
partial-row loading, archival or automatic source quarantine on downstream
STAGE/MAIN DQ/transformation failures is added. See the framework README for
copy failure handling and same-region/IAM requirements.

## First onboarding

1. Install the companion `mdpf-1.0-py3-none-any.whl`, then
   `dist/mdpf_onboarding-1.0-py3-none-any.whl`. Use cluster PySpark and Java.
   Replacing another build of the same version needs `pip install --force-reinstall --no-deps`.
2. Copy `examples/dmi_fee.yaml`. Set pipeline/input/output identifiers,
   separate landing/RAW/STAGE buckets, Oracle owners/targets and artifact settings.
   Keep DEV/STAGE/PROD entries; deployment selects one using `:target_env`.
3. Upload the YAML and representative nonempty input/output CSV samples to OCI.
   Configure SDK Resource Principal read/create permissions for YAML/artifacts
   and Spark OCI driver/worker read/list access for samples. These are separate
   access paths. There is no local-file fallback.
4. Generate from your Spark notebook:

   ```python
   from mdpf_onboarding.onboard import generate

   metadata_uri = generate(
       "oci://mdpf-dev-artifacts@devns/onboarding/dmi_fee/1.0/input/dmi_fee.yaml",
       spark=spark,
   )
   ```

5. Review the printed datasets, schemas, task sequences, DQ rules and paths.
   Download metadata SQL, the complete YAML and optional target DDL from OCI.
   `generate()` still returns the metadata SQL URI. Commit the complete YAML as
   the maintained pipeline configuration; it describes intended metadata, not
   actual deployed Oracle state. `examples/pipeline_complete.yaml` shows its shape.
6. Review/provision target tables, deploy metadata as DRAFT, verify it, then activate.
   Follow the framework README to configure AIDP tasks or Data Flow applications.

## Make a change

1. Keep the previous approved YAML as the baseline (for example a prior Git revision).
2. Edit the current complete YAML: add/remove/rename columns or change their types,
   lengths, nullability, locations, steps or DQ rules. Update representative samples.
3. Choose a new `pipeline.release_version` and release-specific artifact destination.
   Upload both YAML files to OCI and run:

   ```python
   metadata_uri = generate(
       "oci://artifacts@devns/dmi_fee/current.yaml",
       baseline_yaml="oci://artifacts@devns/dmi_fee/previous.yaml",
       spark=spark,
   )
   ```

4. Review the release-change summary and all proposed SQL. Deploy a **complete new
   DRAFT release**. Published metadata and existing batches are never changed.

Both YAML files have the same format; the input parameter identifies their role.
Comparison requires explicit `columns` on every input/output. Samples must match
those contracts; they do not silently resize or re-infer them. No rename guessing:
a renamed column is reported as one removal and one addition.


The comparison covers the **resolved release**, using the same metadata builder
for current and baseline configuration:

| Area | Changes reported |
|---|---|
| Datasets | Columns, order/types/constraints, layers, storage types and physical locations |
| Tasks and steps | Task identity/type, batch closure, step additions/removals/order, handler type and JSON parameters |
| DQ policies | Added/removed checks, scope, numeric bounds, threshold and failure action |
| Sources | Source system, delivery pattern, landing root and expected input count |
| Associations | Task inputs/outputs, usage sequence, requiredness and enabled status |

Numeric IDs are matched through logical task/dataset/column/step codes. Equivalent
explicit/default plans and JSON formatting do not create false changes. The release
version bump, publishing details, sample paths and artifact filenames are ignored.
Only settings that affect generated metadata are compared; the utility does not
inspect custom Python function bodies or live Oracle state. Target DDL proposals
still depend only on target schema differences: plan/DQ-only changes produce no
ALTER statements. Both inputs remain unchanged.

## YAML field reference

Unknown settings are rejected. Versions are quoted strings. `<ROLE>` is RAW,
STAGE or MAIN. Fields below retain the existing input format.

| Field | Required? | Default / meaning |
|---|---|---|
| `pipeline` | Yes | `code`, `name`, `release_version` |
| `inputs[]` | Yes | `code`, `source_system`, `sample_csv`, `landing_key_prefix`, `file_name` |
| `inputs[].bucket_ref` | No | `landing`; bucket alias in every environment |
| `outputs[]` | Yes | `code`, `sample_csv`, `target_table` |
| `inputs[].columns`, `outputs[].columns` | For comparison | Ordered explicit schema; initial generation can infer it |
| Each `columns[]` | When explicit | `column_name`, `data_type`; optional `length_precision_scale`, `is_nullable` (`Y`), `is_pii` (`N`) |
| `samples_root` | No | Full OCI prefix for relative sample paths |
| `storage` | Yes | `raw_key_prefix`, `stage_key_prefix`; optional `quarantine_key_prefix` |
| `environments` | Yes | DEV, STAGE, PROD; each has `namespace`, `buckets` (landing/raw/stage), `oracle_main_owner` |
| `inference.varchar_growth_percent` | No | `25`; initial text-length headroom |
| `inference.default_nullable` | No | `Y`; initial inference only |
| `inference.column_overrides` | No | LANDING/MAIN dataset → column overrides; cannot coexist with explicit columns for that dataset |
| `task_overrides.<ROLE>.task_code` | No | `<PIPELINE>_<ROLE>_LOAD` |
| `task_overrides.<ROLE>.task_steps` | No | Complete ordered sequence; omitted means automatic defaults |
| `dq_rules` | No | `[]`; see examples below |
| `created_by` | No | `MDPF_ONBOARD` |
| `sql_output` | Yes | `namespace`, `bucket`, `path`, metadata SQL `filename` |
| `sql_output.yaml_filename` | No | Lowercase pipeline code + `.yaml` |
| `sql_output.main_ddl_filename` | No | Derived from SQL stem as `<name>_main_ddl.sql` |
| `sql_output.generate_main_ddl` | No | `false`; create target schema proposals when true |
| `sql_output.overwrite` | No | `false`; preserve existing artifact objects |

### Reuse values and control paths

Only `${pipeline.code}`, `${pipeline.release_version}` and `${samples_root}`
are supported references. They work in values and mapping keys (including dataset
references); undefined/recursive references and resulting duplicate keys fail.
There are no expressions or environment-variable substitutions. YAML anchors
can also reuse entire values. Runtime `{YYYYMMDD}` stays unchanged.

```yaml
pipeline:
  code: DMI_FEE
  name: Fee pipeline
  release_version: '1.1'
samples_root: oci://mdpf-samples@devns/dmi
# Within an input/output entry:
# sample_csv: '${samples_root}/fee/input.csv'
sql_output:
  namespace: devns
  bucket: mdpf-dev-artifacts
  path: 'onboarding/${pipeline.code}/${pipeline.release_version}'
  filename: '${pipeline.code}_metadata.sql'
  main_ddl_filename: '${pipeline.code}_target_changes.sql'
  yaml_filename: '${pipeline.code}.yaml'
  generate_main_ddl: true
  overwrite: false
```

This is a settings excerpt; use a complete supplied YAML as the starting point.
Full sample OCI URIs are used directly. Relative paths use `samples_root` when
provided, otherwise the input YAML's directory; no DMI prefix is hardcoded.
Generated YAML contains full sample URIs so moving it does not change resolution.
All artifacts share the configured OCI destination and must be distinct from
input YAML, baseline and samples, even with overwrite enabled. Uploads are
independent: YAML first, optional DDL next, metadata last. Inspect partial output
if a conditional upload fails; there is no cross-object transaction.

## Schemas and target DDL proposals

LANDING/RAW share input-file columns as VARCHAR2. STAGE/MAIN share expected-output
columns/types: VARCHAR2, exact NUMBER(p,s), date-only DATE. Explicit column order
becomes metadata order. Sample values, lengths and conversions are checked using
MDPF's existing schema helpers. Business parsing/renaming stays in custom code.

DMI_FEE supplies explicit ordered `columns` to preserve the existing business
contract. For newly inferred pipelines, use `inference.column_overrides` to correct types/bounds. All-null target
columns require a type and applicable length/precision/scale. Generation lists
all unresolved columns and prints override guidance; it returns `None`, uploads
nothing and CLI exits 2. The complete generated YAML replaces inference overrides
with explicit contracts and the resolved task sequences. Future samples cannot
silently change those definitions. Edit the explicit plan when a schema change
requires DIRECT_MAP or another processing step.

`generate_main_ddl: true` produces review-only scripts, **without Oracle access**:

| Situation | Proposal |
|---|---|
| Initial setup / new target dataset | CREATE TABLE with business columns, BATCH_ID/TASK_RUN_ID/ROW_NUMBER and CREATED_AT/UPDATED_AT audit timestamps |
| Added nullable column | ALTER TABLE ADD |
| Increased VARCHAR2 length, same BYTE/CHAR semantics | ALTER TABLE MODIFY |
| Relaxed NOT NULL | ALTER TABLE MODIFY ... NULL |
| Removal, possible rename, narrowing, numeric/type changes, new NOT NULL, target owner/name change | MANUAL REVIEW comment; no automatic destructive statement |

A baseline is intended configuration, not deployed state. Verify every proposal
against actual Oracle tables before running it. Existing data may require
backfills/defaults. No keys/indexes/grants or automatic ALTER/DROP/rename decisions
are inferred. DDL assumes STANDARD/AL32UTF8 capacity up to 4000 BYTE or 1000 CHAR;
larger contracts need separate reviewed DDL. DDL commits independently in Oracle.

### DMI_FEE contract and bootstrap replacement

For this package's example, the source baseline is the uploaded Framework 1.0
`sql/01_main_and_access.sql` business DDL and matching STAGE/MAIN definitions in
`sql/02_dmi_metadata.sql`. Their twelve business columns agree in order, Oracle
type, precision/scale, CHAR semantics and nullability. This is the reviewed
package baseline, not certification of a production source schema. Compare the
actual target before deployment. Source SHA256 values for tracing the retired assets:

```text
01_main_and_access.sql: 703640f6948cedfcb237fc2cee6416a2ec3d3bdf2b23ad3cbf75926f71d8a671
02_dmi_metadata.sql: 61787a6de368aa0c54b52a0c66bfd60e8193f9914a4711e828e4df18456473a2
```

`examples/dmi_fee.yaml` captures the full contract: source/RAW values remain nullable
VARCHAR2(100 CHAR); STAGE/MAIN use the original business types, including LN_NO
NUMBER(19), FEE_TRAN_AM NUMBER(18,2), date-only dates and CLIENT_NO VARCHAR2(50 CHAR).
Only MSP_CYCLE_DATE and LN_NO are required business columns. Framework audit columns
remain outside the business YAML. Two samples include padded CLIENT_NO inputs;
the required CUSTOM_FEE_TRANSFORM trims them before DIRECT_MAP.

The original three task plans and all four ERROR/threshold-zero/FAIL_TASK policies
are preserved: both NOT_NULL checks at STAGE, STAGE count versus RAW, and MAIN
actual-insert count versus STAGE. Dataset/policy IDs and generated policy names
change. Dataset keys are now `DMI_FEE_FEE_LANDING/RAW/STAGE/MAIN`, replacing
`DMI_FEE_LANDING/RAW/STAGE/MAIN`. Handlers must use the generated keys.

Other intentional example changes: source-system name is `DMI`; RAW/STAGE roots
gain the generator's `/fee` dataset suffix; owners/buckets use reviewed DEV/STAGE/PROD
settings. Release `1.0` is an initial example only: choose a new release/destination
when one already exists. Generated SQL creates a new DRAFT through the release
sequence, replacing the old hardcoded ID and automatic activation. Manual review,
target verification and approval/activation remain required. Existing published
metadata, MAIN tables, retained data and grants are not changed by package cleanup.

The generator deliberately does not infer keys/indexes/grants. To retain the
original DMI_FEE target constraints, a DBA reviews these **separate** statements
for a new DEV target; adapt the owner and do not rerun constraints on an existing
table. The runtime SELECT/INSERT target grant is also separate from generic setup:

```sql
GRANT REFERENCES ON RUNTIME.BATCH TO DMI_MAIN_DEV;
GRANT REFERENCES ON RUNTIME.TASK_RUN TO DMI_MAIN_DEV;
ALTER TABLE DMI_MAIN_DEV.DMI_FEE ADD CONSTRAINT PK_DMI_FEE
  PRIMARY KEY (BATCH_ID, ROW_NUMBER);
ALTER TABLE DMI_MAIN_DEV.DMI_FEE ADD CONSTRAINT FK_DMI_FEE_BATCH
  FOREIGN KEY (BATCH_ID) REFERENCES RUNTIME.BATCH (BATCH_ID);
ALTER TABLE DMI_MAIN_DEV.DMI_FEE ADD CONSTRAINT FK_DMI_FEE_RUN
  FOREIGN KEY (TASK_RUN_ID) REFERENCES RUNTIME.TASK_RUN (TASK_RUN_ID);
GRANT SELECT, INSERT ON DMI_MAIN_DEV.DMI_FEE TO MDPF_RUNTIME;
```

These are Oracle deployment steps, not local-test commands. Optional existing-table
audit SQL and the reusable diagnostic SQL remain in the Framework ZIP. Alternative
LOAN/JOIN/SPLIT/DQ YAMLs and their custom handlers remain regression fixtures.

## Configure task steps

The generator always creates RAW, STAGE and MAIN tasks. Input/output counts select
ONE_TO_ONE, MANY_TO_ONE or ONE_TO_MANY; many-to-many is rejected. Combined RAW
pairs LANDING/RAW through `usage_sequence` and retries the entire task. Inputs
share a source system and landing bucket/root. MANY_TO_ONE needs a STAGE custom
combiner; ONE_TO_MANY needs MAIN custom routing.

Omit `task_steps` for defaults. When present, it is the complete exact sequence:

```yaml
task_overrides:
  STAGE:
    task_steps:
      - READ_PARQUET
      - code: CUSTOM_FEE_TRANSFORM
        parameters: {column: CLIENT_NO}
      - DIRECT_MAP
      - VALIDATE_DQ
      - WRITE_PARQUET
```

One reader first, one sink last; VALIDATE_DQ immediately precedes STAGE/MAIN
output. Custom parameters are a JSON-compatible mapping; built-ins use `{}`.
Include DIRECT_MAP when conversion/projection is needed. Register the matching
Python function in the notebook/application. See the framework's
[Available Task Steps](../framework/REFERENCE.md#available-task-steps),
[default sequences](../framework/REFERENCE.md#default-task-sequences) and
[custom function example](../framework/REFERENCE.md#custom-task-steps).
YAML `custom_steps` and `output_is_typed` remain rejected; migrate to explicit
`task_steps`. The notebook/application `custom_steps` registry remains supported.

## Optional DQ rules

See [DQ and audit contracts in the framework reference](../framework/REFERENCE.md#dq-reconciliation-and-audit-contracts) and `examples/dq_and_reconciliation.yaml`.
NOT_NULL, UNIQUE, RANGE and ALLOWED_VALUES target STAGE; omitted datasets defaults
to every generated STAGE output. Severity defaults to FAIL, with WARN supported.
ROW_COUNT requires explicit adjacent-layer dataset pairs; MAIN counts cannot WARN.
All checks retain zero tolerance. `dq_rules: []` emits no policy rows; schema checks
and mandatory actual-versus-prepared MAIN insert verification still apply.


## Deploy and debug

1. Provision the framework once. A DBA runs `sql/01_release_sequence.sql` once
   with publishers paused; never reset the sequence. Deployment needs metadata
   INSERT and sequence SELECT grants, plus POLICY_DEFINITION INSERT for DQ.
2. Review target proposals against the actual table, provision owner/runtime
   grants, then deploy target DDL and metadata SQL in SQLcl/SQL*Plus script mode:

   ```sql
   VARIABLE target_env VARCHAR2(10)
   EXEC :target_env := 'DEV';
   @dmi_fee_main_ddl.sql
   @dmi_fee_metadata_draft.sql
   ```

3. Run the existing optional read-only `verify_main_targets()` gate against the
   deployed DRAFT release, test runtime access, then promote DRAFT → APPROVED →
   ACTIVE. This separate gate requires Oracle access; generation does not.
   Retire the previous ACTIVE in the activation transaction. Never edit published
   metadata or reinstall the fresh framework DDL for an enhancement.

| Problem | Check |
|---|---|
| Missing sample | Full URI, explicit samples_root, otherwise input YAML folder |
| Invalid baseline | Previous complete YAML, same pipeline, different release version |
| Unexpected/missing column | Edit explicit schema and representative samples deliberately |
| Conversion fails | Values and datatype bounds; business parsing needs custom code |
| Bad plan | Required reader/sink/DQ and registered custom handler |
| Existing artifact | New release destination, or deliberate overwrite |
| Oracle target differs | Review proposals; run the separate deployed-target gate |

## Where the code lives

| Module | Responsibility |
|---|---|
| `bulk_builder.py` | Reads the CSV catalog, checks conflicts, previews or saves each row independently |
| `builder.py` | Reads the shared profile and builds/saves one input YAML using the existing validator |
| `onboard.py` | Public generation/CLI coordinator, sample/baseline loading, complete YAML and ordered publication |
| `config.py` | Strict YAML/configuration validation, parameter expansion and OCI/sample/artifact URI validation |
| `sql_renderer.py` | Offline metadata SQL and reviewed MAIN DDL rendering with shared quoting helpers |
| `oracle_gate.py` | Explicit read-only verification of deployed MAIN targets; never invoked by generation |
| `schema_discovery.py` | Infers initial columns or validates explicit contracts using MDPF schema helpers |
| `metadata_generator.py` | Builds metadata and compares resolved releases; re-exports rendering/verification functions for compatibility |
| `__init__.py` | Package version |

CLI: `python -m mdpf_onboarding.onboard --config <oci-uri> [--baseline-yaml <oci-uri>]`.
The generator declares `mdpf==1.0` as a dependency. Install the supplied companion
Framework wheel together with this generator; use approved sources for dependencies
and platform-provided Spark/Java. Existing `onboard` validator imports and
`metadata_generator` rendering/verification imports remain supported. Metadata
model construction and release comparison stay in `metadata_generator.py` for
this phase. Builders import validators from `config.py`.

Run source regression tests with both packages extracted into sibling `framework/`
and `generator/` folders: install the Framework and Generator test extras, then
run `python -m pytest -q` inside `generator/`. The suite includes framework
integration tests and an equality check against the companion control DDL.

All runs create a complete new DRAFT release; baseline comparison never generates
in-place metadata UPDATEs. Software is 1.0; metadata release versions change.
Source tests are included in `tests/`; see [current bundle validation](../../VALIDATION.txt) for actual
checks and outstanding live Oracle/AIDP/Data Flow/OCI validation.
