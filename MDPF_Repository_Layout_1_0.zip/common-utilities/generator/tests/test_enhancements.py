"""Acceptance: same-batch continuation, DQ, transactional counts and audit fields."""
from copy import deepcopy
from datetime import date, datetime, timezone
from decimal import Decimal
import json
from types import SimpleNamespace

import pytest
from pyspark.sql import functions as F

from conftest import CatalogDb, prepare_execution
from mdpf.pipeline import MetadataFramework
from mdpf.steps import _policy_failures, load_main, validate_dq_parameters
from mdpf.schema import RESERVED, validate_columns
from mdpf_onboarding.metadata_generator import build_metadata, dataset_codes, render_sql
from mdpf_onboarding.onboard import validate_config
from mdpf_onboarding.schema_discovery import discover
from test_cleanup import profiles_for
from test_templates import handlers

RAW = 'DEMO_LOAN_LOAN_RAW'
STAGE = 'DEMO_LOAN_LOAN_STAGE'
MAIN = 'DEMO_LOAN_LOAN_MAIN'


def enhanced_model(models, spark, rules=(), steps=None, base='one_to_one'):
    original = models[base]
    config = deepcopy(original['config'])
    config['dq_rules'] = list(rules)
    if steps:
        config['task_overrides']['STAGE'] = {'task_steps': [
            'READ_PARQUET', {'code': 'PREPARE'}, 'DIRECT_MAP', 'VALIDATE_DQ', 'WRITE_PARQUET']}
    return build_metadata(validate_config(config), profiles_for(original, spark))


def task_codes(model):
    return [t['row']['task_code'] for t in model['tasks']]


def row_rule(target=STAGE, source=RAW, severity='FAIL'):
    return dict(datasets=[target], check='ROW_COUNT', source_dataset=source, severity=severity)


@pytest.mark.parametrize('values', [[], None, 'ACTIVE', [None], [True], [{}], [[]],
    ['ACTIVE', 'ACTIVE'], [1, 1.0], [float('nan')], [float('inf')]])
def test_allowed_values_bad_configuration(values):
    with pytest.raises(ValueError):
        validate_dq_parameters(dict(check='ALLOWED_VALUES', values=values))


@pytest.mark.parametrize('column,values', [
    ({'data_type': 'VARCHAR2', 'length_precision_scale': '6 CHAR'}, [1]),
    ({'data_type': 'VARCHAR2', 'length_precision_scale': '1 BYTE'}, ['é']),
    ({'data_type': 'NUMBER', 'length_precision_scale': '4,2'}, ['1']),
    ({'data_type': 'NUMBER', 'length_precision_scale': '4,2'}, [100]),
    ({'data_type': 'NUMBER', 'length_precision_scale': '4,2'}, [1.001]),
    ({'data_type': 'DATE'}, ['2026-02-30']),
    ({'data_type': 'DATE'}, [20261015]),
])
def test_allowed_values_type_contract(column, values):
    with pytest.raises(ValueError):
        validate_dq_parameters(dict(check='ALLOWED_VALUES', values=values), column)


def test_allowed_values_decimal38_and_yaml_dates():
    validate_dq_parameters(dict(check='ALLOWED_VALUES', values=[10**37]),
        dict(data_type='NUMBER', length_precision_scale='38,0'))
    params = validate_dq_parameters(dict(check='ALLOWED_VALUES', values=[date(2026, 10, 15)]), dict(data_type='DATE'))
    assert json.loads(json.dumps(params))['values'] == ['2026-10-15']


@pytest.mark.parametrize('schema,data,values,expected', [
    ('VALUE string', [('ACTIVE',), ('INACTIVE',), ('active',), ('ACTIVE ',), ('',), (None,)], ['ACTIVE', 'INACTIVE'], 3),
    ('VALUE decimal(8,2)', [(Decimal('1.00'),), (Decimal('2.00'),), (None,)], [1], 1),
    ('VALUE date', [(date(2026, 10, 15),), (date(2026, 10, 16),), (None,)], ['2026-10-15'], 1),
    ('VALUE string', [('',), (None,)], [''], 0),
])
def test_allowed_values_exact_matching_and_null_handling(spark, schema, data, values, expected):
    df = spark.createDataFrame(data, schema)
    amount, _ = _policy_failures(df, dict(column_name='VALUE', parameters=dict(check='ALLOWED_VALUES', values=values)), {})
    assert amount == expected


@pytest.mark.parametrize('rule', [
    dict(check='ROW_COUNT', source_dataset=RAW),
    dict(datasets=[STAGE], check='ROW_COUNT', source_dataset=RAW, column='STATUS'),
    row_rule(MAIN, STAGE, 'WARN'), row_rule(STAGE, STAGE), row_rule(MAIN, RAW),
    dict(column='STATUS', check='ALLOWED_VALUES', values=['ACTIVE'], severity='ERROR'),
    dict(datasets=[MAIN], column='STATUS', check='ALLOWED_VALUES', values=['ACTIVE']),
    dict(datasets=[MAIN], column='STATUS', check='NOT_NULL'),
])
def test_rule_scope_and_severity_preflight(models, rule):
    config = deepcopy(models['one_to_one']['config']); config['dq_rules'] = [rule]
    with pytest.raises(ValueError):
        validate_config(config)


def test_default_stage_scope_policy_sql_and_reconciliation_scope(models, spark):
    model = enhanced_model(models, spark, [
        dict(column='STATUS', check='ALLOWED_VALUES', values=['ACTIVE', 'CLOSED'], severity='WARN'),
        row_rule(), row_rule(MAIN, STAGE)])
    policies = model['tables']['POLICY_DEFINITION']
    assert len(policies) == 3
    assert policies[0]['failure_action'] == 'WARN' and policies[0]['policy_severity'] == 'WARN'
    assert policies[0]['policy_scope_type'] == 'DATASET_COLUMN'
    assert all(p['policy_scope_type'] == 'DATASET' and p['dataset_column_id'] is None and p['policy_type'] == 'RECONCILIATION' for p in policies[1:])
    db = CatalogDb()
    try:
        db.deploy(render_sql(model, b'enhanced'))
        assert db.one('SELECT COUNT(*) n FROM METADATA.POLICY_DEFINITION')['n'] == 3
    finally:
        db.close()


def test_fail_and_warn_dq_run_once_without_raw_quarantine(models, spark, tmp_path, monkeypatch):
    import mdpf.steps as steps
    model = enhanced_model(models, spark, [
        dict(column='STATUS', check='ALLOWED_VALUES', values=['ACTIVE', 'CLOSED'], severity='WARN'),
        dict(column='CLIENT_ID', check='NOT_NULL', severity='WARN'),
        dict(column='LOAN_ID', check='UNIQUE', severity='WARN'),
        dict(column='BALANCE', check='RANGE', min=0, max=100, severity='WARN'),
        row_rule(), row_rule(MAIN, STAGE)], steps=True)
    fw, db = prepare_execution(model, tmp_path, spark)
    calls = []; original = steps._policy_failures
    def count_checks(*args):
        calls.append(args[1]['parameters']['check']); return original(*args)
    monkeypatch.setattr(steps, '_policy_failures', count_checks)
    def prepare(frames, ctx, params):
        return {STAGE: next(iter(frames.values())).withColumn('STATUS', F.lit('BAD')).withColumn('CLIENT_ID', F.lit(None).cast('string')).withColumn('LOAN_ID', F.lit('DUPLICATE'))}
    try:
        batch = fw.start_batch('warn', '2026-10-15')['batch_id']
        fw.storage.quarantine_file = lambda *a: pytest.fail('STAGE DQ must not quarantine a source')
        raw, stage, main = task_codes(model)
        fw.execute_task(batch, raw)
        result = fw.execute_task(batch, stage, custom_steps={'PREPARE': prepare})
        assert result['status'] == 'COMPLETED' and result['reject_count'] == 0
        fw.execute_task(batch, main)
        assert sorted(calls) == ['ALLOWED_VALUES', 'NOT_NULL', 'RANGE', 'UNIQUE']
        rows = db.execute('SELECT * FROM RUNTIME.POLICY_RESULT ORDER BY policy_result_id')
        assert [r['result_status'] for r in rows] == ['WARN'] * 4 + ['PASS', 'PASS']
        assert all(r['failure_action_taken'] == 'WARNED' and r['failed_record_count'] == 2 for r in rows[:4])
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 0
        assert db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n'] == 2
    finally:
        db.close()


def test_allowed_values_fail_preserves_raw_and_retry(models, spark, tmp_path):
    model = enhanced_model(models, spark, [dict(column='STATUS', check='ALLOWED_VALUES', values=['ACTIVE', 'CLOSED'])], steps=True)
    fw, db = prepare_execution(model, tmp_path, spark); invalid = [True]
    def prepare(frames, ctx, params):
        df = next(iter(frames.values()))
        return {STAGE: df.withColumn('STATUS', F.lit('active')) if invalid[0] else df}
    try:
        batch = fw.start_batch('allowed-fail', '2026-10-15')['batch_id']; raw, stage, main = task_codes(model)
        source = fw.execute_task(batch, raw)
        original = fw.storage.write_parquet
        fw.storage.write_parquet = lambda *a: pytest.fail('Failed DQ must prevent STAGE writes')
        with pytest.raises(ValueError, match='Blocking policy'):
            fw.execute_task(batch, stage, custom_steps={'PREPARE': prepare})
        failed = db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE status='FAILED'")
        assert db.one('SELECT failed_record_count FROM RUNTIME.POLICY_RESULT')['failed_record_count'] == 2
        assert db.one('SELECT status FROM RUNTIME.INGESTION_ITEM')['status'] == 'PROCESSED'
        assert db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id', id=source['task_run_id']) == source
        invalid[0] = False; fw.storage.write_parquet = original
        retry = fw.execute_task(batch, stage, custom_steps={'PREPARE': prepare}); fw.execute_task(batch, main)
        assert retry['original_task_run_id'] == failed['task_run_id'] and retry['attempt_number'] == 2
    finally:
        db.close()


def test_warn_does_not_bypass_required_schema(models, spark, tmp_path):
    model = enhanced_model(models, spark, [dict(column='LOAN_ID', check='NOT_NULL', severity='WARN')], steps=True)
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('warn-contract', '2026-10-15')['batch_id']; raw, stage, _ = task_codes(model)
        fw.execute_task(batch, raw)
        with pytest.raises(ValueError, match='Required target'):
            fw.execute_task(batch, stage, custom_steps={'PREPARE': lambda frames, ctx, p: {STAGE: next(iter(frames.values())).withColumn('LOAN_ID', F.lit(None).cast('string'))}})
        assert db.one('SELECT result_status FROM RUNTIME.POLICY_RESULT')['result_status'] == 'WARN'
        assert db.one("SELECT status FROM RUNTIME.TASK_RUN WHERE task_id=2")['status'] == 'FAILED'
    finally:
        db.close()


@pytest.mark.parametrize('severity', ['FAIL', 'WARN'])
def test_stage_row_count_before_write(models, spark, tmp_path, severity):
    model = enhanced_model(models, spark, [row_rule(severity=severity), row_rule(MAIN, STAGE)], steps=True)
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('stage-count-' + severity, '2026-10-15')['batch_id']; raw, stage, main = task_codes(model)
        fw.execute_task(batch, raw)
        transform = {'PREPARE': lambda frames, ctx, p: {STAGE: next(iter(frames.values())).limit(1)}}
        if severity == 'FAIL':
            fw.storage.write_parquet = lambda *a: pytest.fail('Reconciliation must precede STAGE writes')
            with pytest.raises(ValueError, match='Blocking policy'):
                fw.execute_task(batch, stage, custom_steps=transform)
        else:
            fw.execute_task(batch, stage, custom_steps=transform); fw.execute_task(batch, main)
        result = db.one('SELECT * FROM RUNTIME.POLICY_RESULT ORDER BY policy_result_id')
        assert result['expected_value'] == '2' and result['actual_value'] == '1' and result['failed_record_count'] == 1
        assert result['result_status'] == severity
    finally:
        db.close()


def test_join_count_contract_rejected(models, spark):
    names = dataset_codes(models['many_to_one']['config'])
    with pytest.raises(ValueError, match='joins/aggregation'):
        enhanced_model(models, spark, [row_rule(names['outputs'][0]['stage'], names['inputs'][0]['raw'])], base='many_to_one')


def test_row_count_fanout_is_per_pair_not_sum(models, spark, tmp_path):
    original = models['one_to_many']; codes = dataset_codes(original['config'])
    rules = [row_rule(n['stage'], codes['inputs'][0]['raw']) for n in codes['outputs']]
    rules += [row_rule(n['main'], n['stage']) for n in codes['outputs']]
    model = enhanced_model(models, spark, rules, base='one_to_many')
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('fanout', '2026-10-15')['batch_id']
        for task in task_codes(model): fw.execute_task(batch, task, custom_steps=handlers())
        rows = db.execute('SELECT * FROM RUNTIME.POLICY_RESULT')
        assert len(rows) == 4 and all(r['actual_value'] == r['expected_value'] == '2' for r in rows)
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
    finally:
        db.close()


@pytest.mark.parametrize('actual', [1, None, -1, True])
def test_main_count_rollback_durable_failure_and_retry(models, spark, tmp_path, actual):
    model = enhanced_model(models, spark, [row_rule(MAIN, STAGE)])
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('main-count-' + str(actual), '2026-10-15')['batch_id']; raw, stage, main = task_codes(model)
        fw.execute_task(batch, raw); fw.execute_task(batch, stage)
        original = db.insert_many
        def partial(table, columns, records, types):
            original(table, columns, records[:1], types)
            return actual
        db.insert_many = partial
        with pytest.raises(ValueError, match='MAIN insert reconciliation'):
            fw.execute_task(batch, main)
        assert db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n'] == 0
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        assert db.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE event_code='MAIN_TABLE_LOADED'")['n'] == 0
        failed = db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_id=3")
        assert failed['status'] == 'FAILED' and failed['end_timestamp']
        assert db.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE task_run_id=:id AND event_code='TASK_COMPLETED'",
                      id=failed['task_run_id'])['n'] == 0
        assert db.one("SELECT COUNT(*) n FROM OPERATIONS.EVENT_LOG WHERE task_run_id=:id AND event_code='TASK_FAILED'",
                      id=failed['task_run_id'])['n'] == 1
        result = db.one('SELECT * FROM RUNTIME.POLICY_RESULT')
        assert result['expected_value'] == '2' and result['result_status'] == 'FAIL'
        assert result['actual_value'] == ('1' if actual == 1 and not isinstance(actual, bool) else 'UNCONFIRMED')
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 1
        db.insert_many = original
        retry = fw.execute_task(batch, main)
        assert retry['attempt_number'] == 2 and retry['original_task_run_id'] == failed['task_run_id'] and retry['output_count'] == 2
        assert db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n'] == 2
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
    finally:
        db.close()


def test_main_multi_target_count_failure_rolls_back_all_targets(models, spark, tmp_path):
    original = models['one_to_many']; codes = dataset_codes(original['config'])
    model = enhanced_model(models, spark, [row_rule(n['main'], n['stage']) for n in codes['outputs']], base='one_to_many')
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('multi-count', '2026-10-15')['batch_id']; raw, stage, main = task_codes(model)
        fw.execute_task(batch, raw); fw.execute_task(batch, stage)
        insert = db.insert_many
        db.insert_many = lambda table, cols, rows, types: insert(table, cols, rows[:1] if table.endswith('LOAN_STATUS') else rows, types)
        with pytest.raises(ValueError, match='MAIN insert reconciliation'):
            fw.execute_task(batch, main, custom_steps=handlers())
        for n in codes['outputs']:
            table = model['datasets'][n['main']]['row']['physical_object_name']['DEV']
            assert db.one(f'SELECT COUNT(*) n FROM {table}')['n'] == 0
        assert [r['result_status'] for r in db.execute('SELECT * FROM RUNTIME.POLICY_RESULT')] == ['FAIL']
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
    finally:
        db.close()


def test_two_phase_retains_release_and_does_not_read_landing(models, spark, tmp_path, monkeypatch):
    from mdpf.runner import _run_task
    model = models['one_to_one']; fw, db = prepare_execution(model, tmp_path, spark)
    monkeypatch.setattr('mdpf.runner.MetadataFramework', lambda *a, **kw: fw)
    raw, stage, main = task_codes(model); key = 'ACTIVEBATCH:two-phase'
    try:
        first = _run_task(db, pipeline_code=fw.pipeline_code, task_code=raw, execution_key=key,
            task_run_id='phase1-raw', cycle_date='2026-10-15', spark=spark)
        batch = first['batch_id']
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        fresh = deepcopy(model); fresh['tables']['CONFIG_RELEASE'][0]['release_version'] = 'next'
        db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='RETIRED'")
        db.deploy(render_sql(fresh, b'next'), release=901)
        db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE' WHERE config_release_id=901")
        for names in dataset_codes(model['config'])['inputs']:
            location = model['datasets'][names['landing']]['row']['physical_object_name']['DEV'].replace('{YYYYMMDD}', '20261015')
            fw.storage.path(location).unlink()
        fw.storage.read_csv = lambda *a: pytest.fail('Phase 2 must not access landing')
        with pytest.raises(ValueError, match='INGESTION task'):
            _run_task(db, pipeline_code=fw.pipeline_code, task_code=stage, execution_key='wrong-key', task_run_id='bad')
        with pytest.raises(ValueError, match='Cycle date conflicts'):
            _run_task(db, pipeline_code=fw.pipeline_code, task_code=stage, execution_key=key, task_run_id='bad', cycle_date='2026-10-16')
        with pytest.raises(ValueError, match='already COMPLETED'):
            _run_task(db, pipeline_code=fw.pipeline_code, task_code=raw, execution_key=key, task_run_id='raw-again')
        # A fresh framework instance simulates a separately launched phase-2 worker.
        resumed = MetadataFramework(db, fw.pipeline_code, spark=spark); resumed.storage = fw.storage
        monkeypatch.setattr('mdpf.runner.MetadataFramework', lambda *a, **kw: resumed)
        for code in (stage, main):
            result = _run_task(db, pipeline_code=fw.pipeline_code, task_code=code, execution_key=key, task_run_id='phase2-' + code)
            assert result['batch_id'] == batch and result['config_release_id'] == 900
        assert db.one('SELECT COUNT(*) n FROM RUNTIME.BATCH')['n'] == 1
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
    finally:
        db.close()


def test_aidp_shared_key_spans_job_runs_and_finalizer_uses_key(models, spark, tmp_path, monkeypatch):
    from mdpf import aidp
    model = models['one_to_one']; fw, db = prepare_execution(model, tmp_path, spark)
    monkeypatch.setattr('mdpf.runner.MetadataFramework', lambda *a, **kw: fw)
    try:
        for i, task in enumerate(task_codes(model)):
            result = aidp._execute_task(fw.pipeline_code, task, dict(job_run_id='phase1' if i == 0 else 'phase2',
                task_run_id='real-task-' + str(i), execution_count='1', workflow_execution_key='SCHEDULER:workflow-42',
                cycle_date='2026-10-15' if i == 0 else ''), db, spark=spark)
            assert result['batch_id'] == 1
        batch = db.one('SELECT * FROM RUNTIME.BATCH')
        assert batch['execution_key'] == 'SCHEDULER:workflow-42' and batch['orchestrator_run_id'] == 'phase1'
        assert batch['status'] == 'COMPLETED'
        fw.start_batch('SCHEDULER:abandoned', '2026-10-15')
        monkeypatch.setattr(aidp, 'OracleDb', lambda: db)
        monkeypatch.setattr(db, 'close', lambda: None)
        aidp.finalize_failed_job(pipeline_code=fw.pipeline_code, workflow_execution_key='SCHEDULER:abandoned')
        assert fw.get_batch_by_execution_key('SCHEDULER:abandoned')['status'] == 'FAILED'
    finally:
        db.conn.close()


@pytest.mark.parametrize('key', ['{{job.parameters.key}}', 'x' * 301, 'key\ninvalid'])
def test_aidp_shared_key_validation(key):
    from mdpf.aidp import _execute_task
    with pytest.raises(ValueError, match='workflow_execution_key'):
        _execute_task('P', 'T', dict(job_run_id='j', task_run_id='t', execution_count='1', workflow_execution_key=key), None)


def test_audit_fields_and_correct_multi_source_receipts(models, spark, tmp_path):
    model = models['many_to_one']; fw, db = prepare_execution(model, tmp_path, spark)
    try:
        before = datetime.now(timezone.utc).timestamp()
        batch = fw.start_batch('audits', '2026-10-15')['batch_id']; raw, stage, main = task_codes(model)
        source = fw.execute_task(batch, raw)
        ids = []
        for names in dataset_codes(model['config'])['inputs']:
            dataset = dict(model['datasets'][names['raw']]['row'])
            dataset['physical_object_name'] = dataset['physical_object_name']['DEV']
            df = fw.storage.read_parquet(spark, fw.output_path(fw._batch(batch), dataset))
            assert {n: df.schema[n].dataType.simpleString() for n in ('_batch_id','_run_id','_ingestion_item_id','_ingested_at')} == dict(_batch_id='bigint', _run_id='bigint', _ingestion_item_id='bigint', _ingested_at='timestamp')
            row = df.select('_batch_id', '_run_id', '_ingestion_item_id', F.col('_ingested_at').cast('double').alias('ts')).distinct().first()
            receipt = db.one('SELECT * FROM RUNTIME.INGESTION_ITEM WHERE ingestion_item_id=:i', i=row['_ingestion_item_id'])
            assert receipt['task_run_id'] == source['task_run_id'] and receipt['status'] == 'PROCESSED'
            assert receipt['dataset_id'] == model['datasets'][names['landing']]['row']['dataset_id']
            assert row['_batch_id'] == batch and row['_run_id'] == source['task_run_id'] and row['ts'] >= before
            ids.append(row['_ingestion_item_id'])
        assert len(set(ids)) == 2
        fw.execute_task(batch, stage, custom_steps=handlers()); fw.execute_task(batch, main)
        output = dataset_codes(model['config'])['outputs'][0]
        df = fw.storage.read_parquet(spark, model['datasets'][output['stage']]['row']['physical_object_name']['DEV'] + '/batch_' + str(batch))
        assert '_processed_at' in df.columns and '_ingestion_item_id' not in df.columns and '_ingested_at' not in df.columns
        assert df.schema['_processed_at'].dataType.simpleString() == 'timestamp'
        table = model['datasets'][output['main']]['row']['physical_object_name']['DEV']
        for row in db.execute('SELECT CREATED_AT,UPDATED_AT,ROW_NUMBER FROM ' + table):
            assert row['created_at'] == row['updated_at'] and row['created_at'].endswith('+00:00')
            assert row['row_number'] in (1, 2)
    finally:
        db.close()


@pytest.mark.parametrize('damage', ['missing', 'type', 'null', 'receipt', 'run', 'batch'])
def test_raw_read_rejects_malformed_audit_lineage(models, spark, tmp_path, damage):
    fw, db = prepare_execution(models['one_to_one'], tmp_path, spark)
    try:
        raw, stage, _ = task_codes(models['one_to_one']); batch = fw.start_batch('damage-' + damage, '2026-10-15')['batch_id']
        fw.execute_task(batch, raw)
        read = fw.storage.read_parquet
        def damaged(*args):
            df = read(*args)
            if damage == 'missing': return df.drop('_ingested_at')
            if damage == 'type': return df.withColumn('_ingested_at', F.col('_ingested_at').cast('string'))
            if damage == 'null': return df.withColumn('_ingested_at', F.lit(None).cast('timestamp'))
            field = {'receipt': '_ingestion_item_id', 'run': '_run_id', 'batch': '_batch_id'}[damage]
            return df.withColumn(field, F.lit(999).cast('long'))
        fw.storage.read_parquet = damaged
        with pytest.raises(ValueError, match='Parquet'):
            fw.execute_task(batch, stage)
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
    finally:
        db.close()


@pytest.mark.parametrize('name', ['CREATED_AT', 'UPDATED_AT', '_INGESTED_AT', '_PROCESSED_AT', '_INGESTION_ITEM_ID'])
def test_system_audit_columns_cannot_be_business_columns(name):
    assert name in RESERVED
    with pytest.raises(ValueError):
        validate_columns([dict(column_name=name, column_sequence=1, data_type='VARCHAR2', length_precision_scale='50 CHAR', is_nullable='Y')])


def test_source_default_nullable_stays_technical(spark):
    df = spark.createDataFrame([('A',), (None,)], 'VALUE string')
    assert discover(df, source=True, overrides={}, nullable='N')[0]['is_nullable'] == 'Y'
    with pytest.raises(ValueError):
        discover(df, source=True, overrides={'VALUE': {'is_nullable': 'N'}}, nullable='N')


@pytest.mark.parametrize('value', ['', '0', '-1', 'bad', '1.5', '2147483647'])
def test_main_limit_invalid_setting_before_frame_access(monkeypatch, value):
    monkeypatch.setenv('MDPF_MAIN_MAX_ROWS', value)
    with pytest.raises(ValueError, match='MDPF_MAIN_MAX_ROWS'):
        load_main(None, {}, {})


def test_main_limit_is_task_wide_and_all_collects_are_bounded(monkeypatch):
    import mdpf.steps as steps
    calls = []
    class Frame:
        def __init__(self, n): self.n = n
        def select(self, *cols): return self
        def limit(self, n): calls.append(n); return Frame(min(n, self.n))
        def collect(self): return [SimpleNamespace(asDict=lambda: {'VALUE': 'x'}) for _ in range(self.n)]
    monkeypatch.setattr(steps, '_check_output', lambda *a, **kw: 0)
    frames = {'A': Frame(2), 'B': Frame(2)}
    ctx = dict(outputs={n: dict(dataset={'layer': 'GOLD'}, columns=[{'column_name': 'VALUE'}]) for n in frames}, state={'validated_outputs': frames})
    monkeypatch.setenv('MDPF_MAIN_MAX_ROWS', '3')
    with pytest.raises(ValueError, match='MAIN row limit exceeded'):
        load_main(frames, ctx, {})
    assert calls == [4, 2] and 'outputs' not in ctx['state']
    calls.clear(); monkeypatch.delenv('MDPF_MAIN_MAX_ROWS')
    load_main(frames, ctx, {})
    assert calls == [10001, 9999] and ctx['output_count'] == 4


def test_main_limit_end_to_end_failure_then_reviewed_retry(models, spark, tmp_path, monkeypatch):
    model = models['one_to_one']; fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('limit', '2026-10-15')['batch_id']; raw, stage, main = task_codes(model)
        fw.execute_task(batch, raw); fw.execute_task(batch, stage)
        monkeypatch.setenv('MDPF_MAIN_MAX_ROWS', '1')
        with pytest.raises(ValueError, match='MAIN row limit exceeded'):
            fw.execute_task(batch, main)
        assert db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n'] == 0
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        monkeypatch.setenv('MDPF_MAIN_MAX_ROWS', '2')
        assert fw.execute_task(batch, main)['output_count'] == 2
    finally:
        db.close()


def test_oracle_adapter_reports_driver_count_and_binds_utc_timestamps():
    import oracledb
    from mdpf.db import OracleDb
    calls = []
    class Cursor:
        rowcount = 1
        def setinputsizes(self, **kw): calls.append(kw)
        def executemany(self, sql, records): calls.append((sql, records))
        def close(self): calls.append('closed')
    db = OracleDb.__new__(OracleDb); db.conn = SimpleNamespace(cursor=Cursor)
    records = [dict(VALUE='A', CREATED_AT=datetime.now(timezone.utc))] * 2
    assert db.insert_many('BIZ.TARGET', ['VALUE', 'CREATED_AT'], records, {'VALUE': 'VARCHAR2', 'CREATED_AT': 'TIMESTAMP WITH TIME ZONE'}) == 1
    assert calls[0]['CREATED_AT'] == oracledb.DB_TYPE_TIMESTAMP_TZ and calls[-1] == 'closed'
    assert records[0]['CREATED_AT'].utcoffset().total_seconds() == 0
    db.conn = SimpleNamespace(cursor=lambda: pytest.fail('No cursor for zero rows'))
    assert db.insert_many('BIZ.TARGET', ['VALUE'], [], {'VALUE': 'VARCHAR2'}) == 0


def test_main_count_uses_stage_input_not_just_prepared_count(models, spark, tmp_path):
    original = models['one_to_one']; config = deepcopy(original['config'])
    config['dq_rules'] = [row_rule(MAIN, STAGE)]
    config['task_overrides']['MAIN'] = {'task_steps': ['READ_PARQUET', {'code': 'FILTER'}, 'VALIDATE_DQ', 'LOAD_MAIN']}
    model = build_metadata(validate_config(config), profiles_for(original, spark))
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('main-input-count', '2026-10-15')['batch_id']; raw, stage, main = task_codes(model)
        fw.execute_task(batch, raw); fw.execute_task(batch, stage)
        with pytest.raises(ValueError, match='MAIN insert reconciliation'):
            fw.execute_task(batch, main, custom_steps={'FILTER': lambda frames, ctx, p: {MAIN: next(iter(frames.values())).limit(1)}})
        result = db.one('SELECT * FROM RUNTIME.POLICY_RESULT')
        assert result['expected_value'] == '2' and result['actual_value'] == '1'
        assert db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.LOAN')['n'] == 0
    finally:
        db.close()


@pytest.mark.parametrize('change', ['main_warn', 'wrong_scope', 'wrong_source', 'main_column', 'raw_column'])
def test_runtime_rejects_unsupported_policy_metadata_before_data_io(models, spark, tmp_path, change):
    model = enhanced_model(models, spark, [row_rule(MAIN, STAGE), dict(column='STATUS', check='ALLOWED_VALUES', values=['ACTIVE', 'CLOSED'])])
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('metadata-' + change, '2026-10-15')['batch_id']; raw, stage, main = task_codes(model)
        if change != 'raw_column':
            fw.execute_task(batch, raw); fw.execute_task(batch, stage)
        if change == 'main_warn':
            db.execute("UPDATE METADATA.POLICY_DEFINITION SET failure_action='WARN',policy_severity='WARN' WHERE policy_id=1")
        elif change == 'wrong_scope':
            db.execute("UPDATE METADATA.POLICY_DEFINITION SET policy_type='DQ' WHERE policy_id=1")
        elif change == 'wrong_source':
            db.execute('UPDATE METADATA.POLICY_DEFINITION SET parameter_json=:p WHERE policy_id=1', p=json.dumps(dict(check='ROW_COUNT', source_dataset=RAW)))
        else:
            name = RAW if change == 'raw_column' else MAIN
            dataset = db.one('SELECT * FROM METADATA.DATASET WHERE dataset_code=:c', c=name)
            column = db.one("SELECT * FROM METADATA.DATASET_COLUMN WHERE dataset_id=:d AND column_name='STATUS'", d=dataset['dataset_id'])
            db.execute('UPDATE METADATA.POLICY_DEFINITION SET dataset_id=:d,dataset_column_id=:c WHERE policy_id=2', d=dataset['dataset_id'], c=column['dataset_column_id'])
        fw.storage.read_csv = fw.storage.read_parquet = lambda *a: pytest.fail('Invalid metadata must fail before storage reads')
        with pytest.raises(ValueError):
            fw.execute_task(batch, raw if change == 'raw_column' else main)
    finally:
        db.close()


def test_main_empty_append_reconciles_zero(models, spark, tmp_path):
    original = models['one_to_one']; config = deepcopy(original['config'])
    config['dq_rules'] = [row_rule(MAIN, STAGE)]
    config['task_overrides']['STAGE'] = {'task_steps': ['READ_PARQUET', {'code': 'EMPTY'}, 'DIRECT_MAP', 'VALIDATE_DQ', 'WRITE_PARQUET']}
    model = build_metadata(validate_config(config), profiles_for(original, spark))
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        batch = fw.start_batch('empty-output', '2026-10-15')['batch_id']; raw, stage, main = task_codes(model)
        fw.execute_task(batch, raw)
        fw.execute_task(batch, stage, custom_steps={'EMPTY': lambda frames, ctx, p: {STAGE: next(iter(frames.values())).limit(0)}})
        result = fw.execute_task(batch, main)
        assert result['output_count'] == 0
        policy = db.one('SELECT * FROM RUNTIME.POLICY_RESULT')
        assert policy['expected_value'] == policy['actual_value'] == '0' and policy['result_status'] == 'PASS'
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
    finally:
        db.close()


def test_public_generation_preserves_new_rules_and_managed_ddl(oci_setup, spark):
    import yaml
    from mdpf_onboarding.onboard import generate, main_ddl_uri, yaml_uri
    config, uri, client, _ = oci_setup
    config['dq_rules'] = [dict(column='STATUS', check='ALLOWED_VALUES', values=['ACTIVE', 'CLOSED'], severity='WARN'), row_rule(), row_rule(MAIN, STAGE)]
    config['sql_output']['generate_main_ddl'] = True
    client.objects[uri] = yaml.safe_dump(config).encode()
    target = generate(uri, spark=spark, client=client)
    complete = yaml.safe_load(client.objects[yaml_uri(config)])
    assert complete['dq_rules'][0]['datasets'] == [STAGE] and complete['dq_rules'][0]['severity'] == 'WARN'
    assert complete['dq_rules'][2]['source_dataset'] == STAGE
    sql = client.objects[target].decode()
    assert 'RECONCILIATION' in sql and 'ALLOWED_VALUES' in sql and "'WARN'" in sql
    ddl = client.objects[main_ddl_uri(config)].decode()
    assert 'CREATED_AT TIMESTAMP(6) WITH TIME ZONE NOT NULL' in ddl and 'UPDATED_AT TIMESTAMP(6) WITH TIME ZONE NOT NULL' in ddl
    assert all(c['column_name'] not in RESERVED for item in complete['inputs'] + complete['outputs'] for c in item['columns'])
