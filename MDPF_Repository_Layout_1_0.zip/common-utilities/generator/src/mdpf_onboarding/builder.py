"""Build one onboarding input YAML from a shared OCI profile; no sample reads."""
from copy import deepcopy

import yaml

from mdpf.storage import object_address
from .config import UniqueLoader, keys, oci_uri, sample_uri, text, validate_config
from .onboard import object_client


def load_profile(profile_uri, *, client=None):
    """Read one OCI profile and validate shared settings using a representative config.

    Return the profile dictionary. No sample contents are read and no YAML is saved;
    a supplied client is reused, otherwise Resource Principal authentication is used."""
    profile_uri = oci_uri(profile_uri)
    if not profile_uri.lower().endswith(('.yaml', '.yml')):
        raise ValueError('Profile must be an OCI .yaml or .yml object.')
    client = client if client is not None else object_client()
    data = client.get_object(*object_address(profile_uri)).data.content
    profile = yaml.load(data.decode('utf-8-sig'), Loader=UniqueLoader)
    keys(profile, {'samples_root', 'artifacts_root', 'landing_key_prefix',
                   'storage', 'environments'}, set(), 'shared profile')
    keys(profile['storage'], {'raw_key_prefix', 'stage_key_prefix'}, {'quarantine_key_prefix'}, 'profile.storage')
    text(profile['landing_key_prefix'], 'landing_key_prefix', 1000)
    for name, value in profile['storage'].items():
        text(value, name, 1000)
    for field in ('samples_root', 'artifacts_root'):
        if not isinstance(profile[field], str):
            raise ValueError(f'{field} must be a full OCI prefix.')
        profile[field] = oci_uri(profile[field].rstrip('/'))
    build_config(profile, pipeline_code='PROFILE_CHECK', dataset_code='DATASET',
                 source_system='PROFILE', input_sample_csv='input.csv',
                 output_sample_csv='output.csv')
    return profile


def build_config(profile, *, pipeline_code, dataset_code, source_system,
                 input_sample_csv, output_sample_csv, release_version='1.0',
                 file_name=None, target_table=None):
    """Build and validate one input/output pipeline config from an in-memory profile.

    Append pipeline-specific prefixes; copy environment settings without mutating
    the profile. Return a config dictionary. No external reads or writes occur."""
    if not isinstance(release_version, str) or '/' in release_version:
        raise ValueError('release_version must be text without directories.')
    namespace, bucket, root = object_address(profile['artifacts_root'])
    prefix = f'{root}/{pipeline_code.lower()}/{release_version}'
    config = {
        'pipeline': {'code': pipeline_code, 'name': f'{pipeline_code} pipeline',
                     'release_version': release_version},
        'samples_root': profile['samples_root'],
        'inputs': [{
            'code': dataset_code, 'source_system': source_system,
            'sample_csv': sample_uri(profile['samples_root'] + '/config.yaml',
                                     input_sample_csv, profile['samples_root']),
            'landing_key_prefix': profile['landing_key_prefix'].rstrip('/') + '/' + pipeline_code.lower(),
            'file_name': file_name or dataset_code.lower() + '_{YYYYMMDD}.csv',
        }],
        'outputs': [{
            'code': dataset_code,
            'sample_csv': sample_uri(profile['samples_root'] + '/config.yaml',
                                     output_sample_csv, profile['samples_root']),
            'target_table': target_table or dataset_code,
        }],
        'storage': {name: value.rstrip('/') + '/' + pipeline_code.lower()
                    for name, value in profile['storage'].items()},
        'environments': deepcopy(profile['environments']),
        'sql_output': {'namespace': namespace, 'bucket': bucket,
                       'path': prefix + '/generated',
                       'filename': pipeline_code.lower() + '_metadata_draft.sql',
                       'overwrite': False, 'generate_main_ddl': False},
    }
    return validate_config(config)


def config_uri(profile, config):
    """Input YAML destination, separate from the downstream generated artifacts."""
    pipeline = config['pipeline']
    return oci_uri(f"{profile['artifacts_root']}/{pipeline['code'].lower()}/"
                   f"{pipeline['release_version']}/input/config.yaml")


def save_config(profile, config, *, client=None):
    """Validate and conditionally create one OCI input YAML; return its exact URI.

    Existing objects are never overwritten; SDK precondition/access errors propagate.
    This API does not check sample existence; build_catalog() performs those HEADs."""
    config = validate_config(config)
    uri = config_uri(profile, config)
    client = client if client is not None else object_client()
    content = yaml.safe_dump(config, sort_keys=False, allow_unicode=True).encode('utf-8')
    client.put_object(*object_address(uri), content,
                      content_type='application/yaml', if_none_match='*')
    return uri
