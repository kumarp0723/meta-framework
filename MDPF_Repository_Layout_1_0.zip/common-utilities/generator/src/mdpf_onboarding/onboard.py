"""OCI YAML input, Spark samples, metadata SQL and optional MAIN DDL."""
import argparse
from copy import deepcopy
import hashlib
import json
import sys

import yaml
from pyspark.sql import SparkSession

from .schema_discovery import (SchemaOverridesRequired, discover, explicit_columns,
                               read_sample, validate_overrides, validate_sample)
from mdpf.storage import object_address
from .metadata_generator import (build_metadata, dataset_codes, physical_locations,
                                 relationship, render_main_ddl, render_sql, resolve_steps,
                                 contract_model, schema_changes)

from .config import (UniqueLoader, _mapping, keys, text, expand_parameters,
                     validate_config, oci_uri, sample_uri, output_uri,
                     main_ddl_uri, artifact_uri, yaml_uri)


def complete_config(model, sample_paths):
    """Copy the model config into a reusable YAML contract with explicit schemas/plans.

    sample_paths maps original sample references to resolved OCI URIs. The model
    is unchanged; inference overrides are replaced by the resolved column contracts."""
    config=deepcopy(model['config'])
    codes=dataset_codes(config)
    for role, suffix in (('inputs','landing'),('outputs','main')):
        for item,names in zip(config[role],codes[role]):
            item['sample_csv']=sample_paths[item['sample_csv']]
            item['columns']=[{k:v for k,v in column.items() if k!='column_sequence'}
                             for column in model['datasets'][names[suffix]]['columns']]
    config['inference']['column_overrides']={}
    config['sql_output']['yaml_filename']=yaml_uri(config).rsplit('/',1)[1]
    config['sql_output']['main_ddl_filename']=main_ddl_uri(config).rsplit('/',1)[1]
    for task in model['tasks']:
        steps=[step for step in model['tables']['TASK_STEP'] if step['task_id']==task['row']['task_id']]
        config['task_overrides'][task['role']]=dict(task_code=task['row']['task_code'],task_steps=[
            step['step_code'] if step['step_type']=='BUILTIN' else
            dict(code=step['step_code'],parameters=json.loads(step['parameter_json'])) for step in steps])
    return config


def object_client():
    """Create the default OCI ObjectStorageClient using Resource Principal credentials.

    Missing credentials or SDK setup errors propagate; no authentication fallback
    is attempted. To use another approved client, pass client= to load_config(),
    generate() or the builder entry points; this zero-argument factory takes no client.
    SDK authentication is separate from Spark's bucket-access configuration."""
    import oci
    return oci.object_storage.ObjectStorageClient({},signer=oci.auth.signers.get_resource_principals_signer())


def _load_config(uri, client):
    """One YAML read/validation path; retain original bytes and client for generation."""
    uri=oci_uri(uri)
    if not uri.lower().endswith(('.yaml','.yml')):
        raise ValueError('Config must be an OCI .yaml or .yml object.')
    namespace,bucket,key=object_address(uri)
    client=client or object_client()
    data=client.get_object(namespace,bucket,key).data.content
    return validate_config(yaml.load(data.decode('utf-8'),Loader=UniqueLoader)),data,client


def load_config(uri, *, client=None):
    """Read and strictly validate one OCI YAML object; return its expanded configuration.

    Use the supplied SDK client or the default Resource Principal client. This reads
    configuration bytes, not samples, and propagates validation/auth/access errors."""
    return _load_config(uri,client)[0]


def _print_summary(model, artifacts):
    config, tables = model['config'], model['tables']
    pipeline = config['pipeline']
    print(f"Generation summary: {pipeline['code']}, release {pipeline['release_version']}, DRAFT, {relationship(config)}")
    print(f"  {len(model['datasets'])} datasets, {len(tables['DATASET_COLUMN'])} columns, "
          f"{len(model['tasks'])} tasks, {len(tables['TASK_STEP'])} steps, "
          f"{len(tables['POLICY_DEFINITION'])} DQ rules")
    for code, definition in model['datasets'].items():
        columns = ', '.join(' '.join(filter(None, [c['column_name'], c['data_type'],
            c['length_precision_scale'], 'NOT NULL' if c['is_nullable'] == 'N' else None]))
            for c in definition['columns'])
        print(f'  {code}: {columns}')
    for task in model['tasks']:
        print('  '+task['row']['task_code']+': '+', '.join(task['inputs'])+' -> '+', '.join(task['outputs']))
        print('    steps: '+' -> '.join(task['steps']))
    for policy in tables['POLICY_DEFINITION']:
        print(f"  DQ: {policy['policy_name']} -> {policy['failure_action']}")
    for uri, _ in artifacts:
        print('  Artifact: '+uri)
    for warning in model['warnings']:
        print('NOTE: '+warning)


def generate(config_uri, *, baseline_yaml=None, spark=None, client=None):
    """Generate complete YAML, DRAFT metadata SQL and optional MAIN DDL in OCI.

    Validate configuration/baseline/destinations before Spark sample reads. Render
    everything and print the summary before independent create-only uploads (unless
    overwrite is enabled), with metadata SQL last. Return its URI, or None when
    explicit datatype overrides are required. Never contact Oracle or activate a
    release. Stop only an internally created Spark session; errors propagate."""
    config,config_bytes,client=_load_config(config_uri,client)
    baseline=None
    if baseline_yaml is not None:
        baseline_yaml=oci_uri(baseline_yaml)
        if baseline_yaml==config_uri:
            raise ValueError('baseline_yaml must be a separate previous configuration.')
        try:
            previous,_,client=_load_config(baseline_yaml,client)
        except Exception as exc:
            raise ValueError(f'Cannot read or validate baseline_yaml {baseline_yaml}: {exc}') from exc
        if previous['pipeline']['code']!=config['pipeline']['code']:
            raise ValueError('Baseline must belong to the same pipeline.')
        if previous['pipeline']['release_version']==config['pipeline']['release_version']:
            raise ValueError('Comparison requires a new release_version; published releases are never updated.')
        baseline=contract_model(previous)
        contract_model(config)  # Enhancement schemas must be explicit, never silently re-inferred.
    sql_uri=output_uri(config)
    sample_paths={i['sample_csv']:sample_uri(config_uri,i['sample_csv'],config.get('samples_root')) for i in config['inputs']+config['outputs']}
    targets=[sql_uri,yaml_uri(config)]+([main_ddl_uri(config)] if config['sql_output']['generate_main_ddl'] else [])
    if len(set(targets))!=len(targets) or set(targets)&{config_uri,baseline_yaml,*sample_paths.values()}:
        raise ValueError('Artifact outputs must be distinct from each other, input YAML, baseline and sample objects.')
    existing = spark or SparkSession.getActiveSession()
    session = existing or SparkSession.builder.appName('MDPF metadata onboarding').getOrCreate()
    profiles, codes, missing = {}, dataset_codes(config), {}
    try:
        for role in ('inputs','outputs'):
            for item, names in zip(config[role], codes[role]):
                path = sample_paths[item['sample_csv']]
                code = names['landing' if role=='inputs' else 'main']
                df = read_sample(session,path)
                try:
                    if 'columns' in item:
                        columns=validate_sample(df,explicit_columns(item['columns'],source=role=='inputs'),source=role=='inputs')
                    else:
                        columns = discover(df,source=role=='inputs',
                            overrides=config['inference']['column_overrides'].get(code,{}),
                            growth=config['inference']['varchar_growth_percent'], nullable=config['inference']['default_nullable'])
                except SchemaOverridesRequired as exc:
                    missing[code] = exc.columns
                    continue
                profiles[code] = (df, columns)
        if missing:
            print('Datatype input required; no SQL or DDL was uploaded. Empty target columns:')
            for code, columns in missing.items():
                print('  ' + code + ': ' + ', '.join(columns))
            print('Merge these overrides into your YAML, replace every <...> value, then generate again:')
            print(yaml.safe_dump({'inference': {'column_overrides': missing}}, sort_keys=False))
            return None
        model = build_metadata(config,profiles)
        yaml_bytes=yaml.safe_dump(complete_config(model,sample_paths),sort_keys=False,allow_unicode=True).encode('utf-8')
        provenance='-- GENERATED YAML SHA256: '+hashlib.sha256(yaml_bytes).hexdigest()+'\n'
        sql = render_sql(model,config_bytes).replace('\n','\n'+provenance,1)
        artifacts=[(yaml_uri(config),yaml_bytes.decode('utf-8'))]
        if config['sql_output']['generate_main_ddl']:
            artifacts.append((main_ddl_uri(config),render_main_ddl(model,config_bytes,baseline=baseline).replace('\n','\n'+provenance,1)))
        artifacts.append((sql_uri,sql))
        print('Mode: '+('INITIAL SETUP; no baseline comparison.' if baseline is None else 'COMPARISON; resolved release changes from baseline.'))
        if baseline is not None:
            for change in schema_changes(model,baseline):
                print('  CHANGE: '+change)
        _print_summary(model, artifacts)
        # Render everything before publication; upload metadata last. Uploads are independent.
        condition={} if config['sql_output']['overwrite'] else {'if_none_match':'*'}
        for uri,content in artifacts:
            namespace,bucket,key=object_address(uri)
            client.put_object(namespace,bucket,key,content.encode('utf-8'),
                content_type='application/yaml' if uri==yaml_uri(config) else 'application/sql',**condition)
            if uri!=sql_uri:
                print(f'Generated {uri}: '+('reusable configuration; intended metadata, not deployment state.' if uri==yaml_uri(config)
                    else 'proposed MAIN DDL for manual review; no DDL has been executed.'))
        print(f'Generated {sql_uri}: {relationship(config)}, three tasks, DRAFT only; Oracle has not been contacted.')
        return sql_uri
    finally:
        if existing is None:session.stop()


def main(argv=None):
    parser=argparse.ArgumentParser(description='Generate DRAFT metadata SQL and optional MAIN table DDL.')
    parser.add_argument('--config',required=True)
    parser.add_argument('--baseline-yaml',help='Previous complete generated YAML in OCI; omitted for initial setup.')
    args=parser.parse_args(argv)
    try:
        return 0 if generate(args.config,baseline_yaml=args.baseline_yaml) is not None else 2
    except Exception as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        return 1


if __name__=='__main__':
    raise SystemExit(main())
