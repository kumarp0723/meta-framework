# MDPF 1.0 — developer guide

MDPF turns a reviewed pipeline configuration into repeatable Spark tasks with
Oracle execution history. The SQL Generator prepares the configuration and SQL;
the Framework runs published metadata. A scheduler launches RAW, then STAGE, then
MAIN. Each Framework call executes **one task**, not the whole scheduler workflow.

Read this guide first, follow the [DMI_FEE walkthrough](../generator/README.md#end-to-end-quick-start),
then use [runtime contracts](REFERENCE.md) or [operations](OPERATIONS.md) as needed.
Extract the ZIPs into sibling `framework/` and `generator/` folders for cross-package
links. Each README includes its own basic setup. No extra service is required.

For exact inputs/returns/error behavior, use the [Framework public contracts](REFERENCE.md#public-api-contracts)
and [Generator API/CLI contracts](../generator/REFERENCE.md#public-api-and-cli-contracts).
The existing custom-step example is linked from the Framework contract section;
the execution/recovery and limitation explanations below remain authoritative.

## Vocabulary and overall flow

| Term | Meaning |
|---|---|
| Pre-onboarding builder | Optional profile/catalog utility that creates small input YAMLs and checks sample existence |
| SQL Generator | Reads input YAML and sample CSVs; produces complete YAML, DRAFT metadata SQL and optional MAIN DDL |
| Metadata release | Versioned pipeline contract in `METADATA`; a batch pins one release |
| Batch | One workflow execution, identified by a stable execution key and internal `batch_id` |
| Task attempt | One execution of a configured task; retries receive new `task_run_id` values |
| RAW | Source-preserving Parquet with receipt/attempt lineage |
| STAGE | Business transformation and DQ output in Parquet |
| MAIN | Final Oracle business tables; stored dataset layer values use the name `GOLD` |

This diagram shows dependencies and artifacts, **not a literal function call graph**:

```mermaid
flowchart TD
    B["Profile + catalog: optional builder"] --> Y["Input YAML"]
    E["Existing input YAML"] --> Y
    Y --> G["onboard.generate: read samples"]
    G --> A["Complete YAML + metadata SQL + optional DDL"]
    A --> D["Manual review, deployment and activation"]
    D --> M["Oracle metadata and MAIN targets"]
    M --> F["pipeline.py: execute one configured task"]
    S["Scheduler: RAW then STAGE then MAIN"] --> F
    F --> O["RAW / STAGE Parquet and MAIN rows"]
    F --> R["runtime.py: execution and audit records"]
```

The builder and supplied YAML are **alternative starting points**. Generation does
not create Oracle tables, deploy metadata, activate releases or launch workers.

## What you can run

| Label | Prerequisites | What it proves |
|---|---|---|
| Local | Python 3.10+, Java 17, supplied sources and test extras | Configuration and real local Spark tests using SQLite/OCI doubles |
| OCI | Object Storage, permissions, SDK authentication and Spark OCI access for generation | Actual profile/sample reads and artifact uploads |
| Oracle | Provisioned schemas/targets, network, grants and secure DB settings | Actual deployment/target checks and Oracle transactions |
| OCI + Oracle | Both above and a configured Spark notebook/Data Flow/AIDP runtime | Complete RAW/STAGE/MAIN execution |
| Conceptual | Infrastructure is unavailable | Read the remaining walkthrough; no claim it ran |

The full DMI_FEE example requires infrastructure. Its explicit twelve-column
contract, trim handler and four policies are supplied in `generator/examples/dmi_fee.yaml`. Local tests exercise equivalent
contracts with test adapters; they do not deploy OCI objects or Oracle schemas.

### Local setup and checks

**Local — Linux/bash, from the parent of `framework/` and `generator/`:**

```bash
python -m venv .venv
source .venv/bin/activate
python --version
java -version
python -m pip install -e './framework[test]' -e './generator[test]'
python -m pip check
python -c "import mdpf, mdpf_onboarding; print(mdpf.__version__, mdpf_onboarding.__version__)"
mdpf-onboard --help
python -m pip wheel --no-deps --wheel-dir framework/dist ./framework
python -m pytest -q framework/tests
cd generator
python -m pytest -q
```

Expected: Python 3.10+ and Java 17, no broken dependencies, `1.0 1.0`, CLI help and
a passing Framework test suite followed by the Generator regression suite. Build
the wheel first: Framework packaging tests need `framework/dist/`, which is not
committed to Git. No OCI/Oracle credentials are needed. Installation needs access
to an approved Python dependency source. Java must be on PATH or JAVA_HOME must
point to its installation. Spark must be able to use local temporary directories.

To run a focused check from `generator/`:

```bash
python -m pytest -q tests/test_modularization.py tests/test_enhancements.py
```

For the primary example, canonical platform launchers and custom STAGE registration:

```bash
python -m pytest -q tests/test_dmi_fee.py
```

These include real Spark and transaction-adapter tests, not live Oracle tests.
Observed counts and environment limitations are in the
[current bundle validation](../../VALIDATION.txt). Dated counts in
[release history](RELEASE_NOTES.md) describe those older builds only.

### Configure a prepared OCI/Oracle environment

**OCI — from the parent directory, in a runtime with platform Spark/Java:**

```bash
python -m pip install --force-reinstall ./framework/dist/mdpf-1.0-py3-none-any.whl ./generator/dist/mdpf_onboarding-1.0-py3-none-any.whl
python -m pip check
python -c "import mdpf, mdpf_onboarding; print(mdpf.__version__, mdpf_onboarding.__version__)"
```

Restart notebook/worker Python sessions after replacing same-version wheels.
Use the supplied companion wheels; do not rely on a public package named `mdpf`.
If dependencies are already provisioned, `--no-deps` may be added to the install.

There are three separate connections to establish:

| Connection | Configuration and smoke check |
|---|---|
| Python OCI SDK | Default builder/generator authentication is Resource Principal. Confirm the notebook service supplies it; otherwise pass an existing approved SDK client via `client=`. HEAD one exact sample. |
| Spark OCI connector | Configure driver/worker access to the relevant buckets. Read one sample CSV with Spark. SDK access alone does not configure Spark. |
| Oracle | Supply `MDPF_DB_USER`, `MDPF_DB_PASSWORD`, `MDPF_DB_DSN` securely; optionally `MDPF_DB_CONFIG_DIR`, `MDPF_DB_WALLET_LOCATION`, `MDPF_DB_WALLET_PASSWORD`. Run a read-only connection check. |

**Oracle — after secure settings are supplied, run in notebook Python:**

```python
from mdpf.db import OracleDb

db = OracleDb()
try:
    assert db.one('SELECT 1 ok FROM DUAL')['ok'] == 1
    print('Oracle connection OK')
finally:
    db.close()
```

Expected: `Oracle connection OK`. It proves connectivity, not deployment grants or
MAIN compatibility. See [OCI permissions](OPERATIONS.md#oci-permissions) and the
[walkthrough](../generator/README.md#end-to-end-quick-start) for actual objects,
target verification and execution. Public `generate()` accepts OCI config URIs;
there is no local-file generation mode. Never print credentials in a smoke check.

## Generation call flow

Follow the calls below in source, using one pipeline at a time:

| Caller / function | Next operation and result |
|---|---|
| Optional `bulk_builder.build_catalog()` | Reads the profile/catalog, calls builder/config helpers, checks conflicts and HEADs samples; returns row dictionaries and optionally saves input YAMLs |
| `onboard.generate()` → `_load_config()` | GETs input YAML and calls `config.validate_config()`; validation returns expanded/defaulted settings |
| `generate()` baseline handling | Validates a separate prior complete YAML and compiles its explicit contracts without reading its samples |
| `generate()` → `schema_discovery.read_sample()` | Spark reads current samples; `discover()` infers contracts or `validate_sample()` checks explicit columns |
| `generate()` → `metadata_generator.build_metadata()` | Builds release-local dataset/task/step/policy rows and validates sample conversions |
| `generate()` → `complete_config()` / `sql_renderer` | Prepares complete YAML; `render_sql()` and optional `render_main_ddl()` return text |
| `generate()` → `_print_summary()` / `client.put_object()` | Prints summary/comparison, then uploads complete YAML, optional DDL and metadata SQL last; returns the metadata SQL URI |

`onboard.py` coordinates these operations. `config.py → metadata_generator.py →
sql_renderer.py` is not a literal sequential call chain: config validation already
uses model helpers for plan/location checks. Rendering and verification imports
in `metadata_generator.py` are compatibility re-exports. Edit their implementations
in `sql_renderer.py` and `oracle_gate.py`.

`oracle_gate.verify_main_targets()` is an explicitly invoked, read-only deployment
check using an Oracle connection. Generation never invokes it. OCI uploads are
independent: if a later upload fails, earlier artifacts may exist. Create-only
behavior is preserved; there is no multi-object publication transaction.

## Execution call flow

1. The scheduler launches the configured RAW task, followed by STAGE and MAIN on
   success. Notebook code calls `mdpf.aidp.execute_task()`; Data Flow application
   code calls `mdpf.dataflow.execute_task()`. A small manual notebook demonstration
   can call `mdpf.runner.execute_task()` directly, as in the walkthrough.
2. The shared runner resolves the execution key and constructs `MetadataFramework`.
   Initial INGESTION calls `start_batch()` to pin the ACTIVE release. Downstream
   tasks reuse the batch and reject conflicting cycle/mode overrides.
3. `MetadataFramework.execute_task()` locks batch/attempt state and records a new
   attempt. `_resolve_plan()` delegates to `metadata.resolve_plan()`;
   `_prepare_dataflow()` delegates to `metadata.prepare_dataflow()`. Contracts,
   handlers and paths are checked before reading source data.
4. The loop calls the registered `steps.BUILTINS` handler or the explicitly
   registered custom callable. Built-ins receive internal `ctx`; custom handlers
   receive a read-only public context and return `dict[dataset_code, DataFrame]`.
5. `READ_SOURCE` calls the facade's `_receive_source()` before CSV I/O. Retained
   `READ_PARQUET` checks the exact completed producer and receipt lineage.
   Mapping/custom code prepares output frames. `VALIDATE_DQ` calls `_check_output()`
   and `dq` calculations, records policy facts and remembers exact validated frames.
6. `WRITE_PARQUET` writes batch paths and audit fields. `LOAD_MAIN` only prepares
   bounded rows; it does not insert. `_complete()` performs MAIN inserts, compares
   actual affected rows, records success and optionally closes the batch.
7. Failures propagate through the guarded failure path. A retry gets a new attempt
   linked to the failed one, in the same RUNNING batch. The scheduler owns retry
   limits and explicit failure finalization; completed tasks cannot restart.

Business DQ belongs to STAGE. MAIN ROW_COUNT uses actual Oracle insert counts in
completion. `runtime.py` is called **throughout** this flow, not as a final step.

## Platform starter adaptation

Use the canonical [AIDP RAW notebook](entrypoints/aidp/raw.ipynb) and
[Data Flow RAW script](entrypoints/dataflow/raw.py), or their STAGE/MAIN siblings.
Pipeline selection is required; an optional task-code override supports alternate
metadata names. These launchers contain no provider defaults or custom registrations. Use shared launchers for built-in tasks and provider-owned
launchers for custom tasks. Keep business functions outside these generic starters.
Use one platform for the whole pipeline.

The [runtime reference](REFERENCE.md#run-the-supplied-dmi-example) contains the
exact task codes and AIDP parameter bindings; the [Data Flow section](REFERENCE.md#run-from-data-flow--activebatch)
covers the real run OCID and scheduler arguments. [Operations](OPERATIONS.md#two-phase-scheduling)
preserves single-job/phase-job identities, retries and failure finalization.

## Transaction ownership

| Owner | Responsibility |
|---|---|
| `pipeline.py` facade | Lifecycle decisions, locks/guards and transaction scopes |
| `db.py` | Connection/binds and transaction context manager that commits or rolls back |
| `runtime.py` | SQL for batch/task/receipt state, policy facts, events and work items; no transaction opening, commit or rollback |
| `steps.py` / storage | Spark and OCI I/O; not part of an Oracle transaction |

Use facade methods for lifecycle operations. Internal runtime helpers assume the
facade's checks and existing transaction; they are not independent safe entry points.

For MAIN, inserts across all task targets, insert-count reconciliation, success
policy evidence/events, task completion and terminal batch closure share one Oracle
transaction. A mismatch rolls those changes back. The outer failure path then
records failure policy evidence, attempt failure, work item and error event in a
separate transaction. No successful load event should survive that rollback.

For RAW, the receipt commits before opening the CSV. A proven technical bad-file
failure may copy the source to quarantine; only confirmed copy success permits the
guarded quarantine status/event transaction. Landing remains intact. Parquet writes
occur before Oracle completion and are not atomic with Oracle or with each other.

`EVENT_LOG` contains database audit events. Verbose `TASK_PLAN`, `STEP_STARTED` and
failure prints go to worker/platform logs. DQ calculation formats evidence; it does
not own commits. See [contracts](REFERENCE.md#dq-reconciliation-and-audit-contracts).

## Which module should I change?

| Requirement | Starting / supporting files | Relevant local tests and invariant |
|---|---|---|
| DQ rule | Framework `dq.py`, `steps.py`; Generator `config.py`, `metadata_generator.py` | `test_dq_basic.py`, `test_dq_sql.py`, `test_enhancements.py`: scope, NULLs, FAIL/WARN and durable facts |
| Runtime audit fact | `runtime.py`; facade caller in `pipeline.py` | `test_modularization.py`, `test_enhancements.py`: rollback, events and attempt guards |
| Execution/retry | `pipeline.py`; runner/platform adapter if its input changes | `test_raw_repair.py`, `test_platforms.py`: terminal attempts, same batch and pinned release |
| Metadata resolution | `metadata.py`; generator model if the contract changes | `test_plans.py`, `test_raw_repair.py`: correct release and pre-I/O checks |
| YAML field | Generator `config.py`; builder/bulk/model as applicable | `test_config.py`, `test_workflow.py`, `test_bulk_builder.py`: strict keys, no premature I/O |
| Generated SQL/DDL | Generator `sql_renderer.py`; model inputs as applicable | `test_templates.py`, `test_main_ddl.py`, `test_baseline.py`: correct quoting, IDs and safe proposals |
| Oracle verification | Generator `oracle_gate.py` | `test_oracle_gate.py`: read-only compatibility checks |
| Custom transformation | Notebook/application handler and YAML `task_steps` | `test_plans.py`, `test_templates.py`: registration, output keys/schema and validated sink frames |

Run the listed files from `generator/tests/`; both packages share this suite.
Persisting a new field also requires reviewed DDL, caller/test updates and deployment
instructions. Keep published metadata immutable. Avoid a duplicate DQ engine,
SQL renderer or service/repository class for each table.

## Learning-path acceptance

A developer unfamiliar with MDPF, meeting the stated prerequisites, should complete
the documented path in a prepared development environment without verbal assistance.
Record any blocker, clarify the relevant instructions and repeat the affected step.
This human walkthrough is **pending**, not replaced by automated checks. Live
Oracle concurrency, OCI permissions/copy and AIDP/Data Flow bindings also require
the deployment environment; see [live validation](OPERATIONS.md#live-validation-checklist).
