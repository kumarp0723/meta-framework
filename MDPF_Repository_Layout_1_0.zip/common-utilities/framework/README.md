# MDPF Framework 1.0

Run metadata-defined Spark tasks on OCI Data Flow or AIDP, with Oracle execution
history and transactional MAIN loading. The 17-table framework model is unchanged.

Start with the [developer guide](DEVELOPER_GUIDE.md), follow the
[DMI_FEE walkthrough](../generator/README.md#end-to-end-quick-start), then use the
reference/operations sections below. Existing installations must follow
[development rollout](OPERATIONS.md#development-rollout) when changing physical
contracts from an earlier build; this cleanup leaves application Python and framework contracts unchanged.

- **Same-day or two-phase:** RAW can finish now and STAGE/MAIN later in the same
  batch and pinned release. Data Flow reuses its execution key; AIDP optionally
  accepts `workflow_execution_key` across separate jobs. [Scheduling](OPERATIONS.md#two-phase-scheduling)
- **Business DQ at STAGE:** NOT_NULL, UNIQUE, RANGE and ALLOWED_VALUES with FAIL/WARN.
  MAIN verifies actual Oracle inserts before commit. [Rules](REFERENCE.md#dq-reconciliation-and-audit-contracts)
- **Five audit fields:** RAW source receipt/time, STAGE processing time, MAIN
  creation/update times; populated and validated automatically. [Contract](REFERENCE.md#five-framework-managed-audit-fields)
- **Bounded MAIN loading:** default `MDPF_MAIN_MAX_ROWS=10000` across all task outputs.
  Exceeding the limit fails before inserts; nothing is truncated.
- **Whole-file quarantine:** proven RAW technical validation failures only;
  the source stays in landing. STAGE business failures retain normal failure behavior.

Install `dist/mdpf-1.0-py3-none-any.whl` with its dependencies and restart workers.
Use cluster-provided Spark/Java. No runtime deployment or metadata activation is
performed by this package.

| Reference | Contents |
|---|---|
| [Developer guide](DEVELOPER_GUIDE.md) | Complete flow, module calls, setup, transaction ownership and change/test map |
| [Detailed reference](REFERENCE.md) | Setup, built-in plans, custom handlers and recovery |
| [Public contracts](REFERENCE.md#public-api-contracts) | Lifecycle inputs/returns, exceptions and custom-step boundary |
| [OCI permissions example](OPERATIONS.md#oci-permissions) | Dedicated-compartment IAM example and official links |
| [Troubleshooting](OPERATIONS.md#troubleshooting) | Phase waits, DQ, lineage, limits and failed counts |
| [Current bundle validation](../../VALIDATION.txt) | Latest completed checks and pending live validation |
| [Release history](RELEASE_NOTES.md) | Historical changes and validation for their dated builds |

Fresh installs use `sql/00_framework.sql` and `sql/01_main_and_access.sql` with
reviewed owners/grants. MAIN business DDL, target keys/grants and DRAFT
metadata come from the [DMI_FEE onboarding path](../generator/README.md#end-to-end-quick-start).
Use the six canonical launchers under `entrypoints/aidp/` and
`entrypoints/dataflow/`, one per layer/platform. Pipeline selection is required;
task code defaults to the pipeline/layer convention and can be overridden.
Neither registers business transformations. Use provider-owned launchers for custom tasks.
`sql/04_main_audit_columns.sql` is an optional reviewed
proposal for adding audit timestamps to an existing MAIN table. It does not change
framework tables. Keep credentials outside YAML/notebooks.

Waiting-batch dashboard, archive, row rejection and MERGE remain outside this release.

## Runtime quick start

**Local — Linux/bash, in the extracted framework folder:** use Python 3.10+ and
Java 17. Install test extras only in a development environment:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[test]'
python -m pip check
python -c "import mdpf; print(mdpf.__version__)"
python -m pip wheel --no-deps --wheel-dir dist .
python -m pytest -q tests
```

Expected: dependencies are consistent, `1.0` is printed, the Framework wheel is
built and its local launcher/packaging tests pass. Build before testing because
packaging checks need a wheel in `dist/`, which is absent in a fresh source clone.
No OCI/Oracle connection is required. The full Spark/metadata regression suite is in the companion Generator
ZIP; see [local setup/tests](DEVELOPER_GUIDE.md#local-setup-and-checks). If this ZIP
is used alone, [set up once](REFERENCE.md#set-up-once), local source/docstrings and
[operations](OPERATIONS.md) remain usable without the Generator links.

**OCI + Oracle — runtime prerequisites:** provisioned metadata/runtime schemas,
MAIN targets and grants; secure `MDPF_DB_USER`, `MDPF_DB_PASSWORD`, `MDPF_DB_DSN`
(optional wallet settings); Spark OCI access and applicable SDK permissions.
Local tests do not provision these. Without infrastructure, review execution
conceptually after the local tests; the full example is not an offline mode.

1. Install the supplied 1.0 wheel and dependencies on notebook/runtime workers;
   configure Spark OCI access and the secure Oracle connection settings.
2. Follow [setup and execution](REFERENCE.md#set-up-once) for the runtime and
   [the end-to-end quick start](../generator/README.md#end-to-end-quick-start)
   for pre-onboarding, generation and deployment.
3. Run the configured RAW, STAGE and MAIN tasks with the shared workflow identity;
   see [operations](OPERATIONS.md) for delayed continuation, failure and upgrade rules.


Shared operations and release documentation is maintained here in the framework folder.

When replacing an existing install, force-reinstall both supplied 1.0 wheels and
restart Python/worker sessions. Install required dependencies before using --no-deps.

The modularized build keeps execution/transactions in `pipeline.py` and separates
metadata resolution, runtime persistence and DQ calculation. See
[module responsibilities](REFERENCE.md#where-the-code-lives) and
[current bundle validation](../../VALIDATION.txt). Counts in RELEASE_NOTES.md
belong to the dated historical builds, not automatically to this distribution.
