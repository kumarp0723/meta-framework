# MDPF Framework 1.0 — technical reference

- [How it works](#how-it-works)
- [Public API contracts](#public-api-contracts)
- [Optional whole-file quarantine during RAW ingestion](#optional-whole-file-quarantine-during-raw-ingestion)
- [Set up once](#set-up-once)
- [Run the supplied DMI example](#run-the-supplied-dmi-example)
- [Use your own pipeline](#use-your-own-pipeline)
- [Run from Data Flow / ActiveBatch](#run-from-data-flow--activebatch)
- [Available Task Steps](#available-task-steps)
- [Default task sequences](#default-task-sequences)
- [Custom task steps](#custom-task-steps)
- [Supported DQ rules](#supported-dq-rules)
- [Find and resolve a failure](#find-and-resolve-a-failure)
- [Where the code lives](#where-the-code-lives)
- [DQ, reconciliation and audit contracts](#dq-reconciliation-and-audit-contracts)

MDPF runs metadata-defined Spark steps from OCI AIDP notebooks or OCI Data Flow
applications and records their execution in Oracle. AIDP or ActiveBatch owns
scheduling, dependencies and restart. Run each pipeline entirely on one platform.
This package and its wheel are version **1.0**.
For working links between packages, extract them into sibling folders named
`framework/` and `generator/`.

New developers should first read the [developer guide](DEVELOPER_GUIDE.md) for
function-level generation/execution flows, transaction ownership, local setup and
the change/test map. This document retains the detailed runtime contracts.

## How it works

```mermaid
flowchart TD
    A["AIDP or ActiveBatch workflow"] --> N["Notebook or Data Flow application"]
    N --> F["MDPF step runner"]
    M["Oracle metadata"] --> F
    F <-->|Spark I/O| O["Separate landing, RAW and STAGE buckets"]
    F --> D["Oracle MAIN tables"]
    F --> R["Runtime status and error history"]
```

The scheduler chooses which notebook/application runs. MDPF reads pinned metadata and runs that
task's steps; Spark handles CSV/Parquet I/O and Oracle records the outcome.

| Part | Responsibility |
|---|---|
| SQL Generator | Turns YAML and sample CSVs into DRAFT metadata; see the [onboarding README](../generator/README.md) |
| Oracle metadata | Defines datasets, columns, task inputs/outputs and ordered `TASK_STEP` rows |
| Notebook / Data Flow application | Registers custom business functions and calls its platform `execute_task()` |
| MDPF | Resolves/runs the plan and records status, errors and lineage |
| Spark / OCI | Reads landing CSVs and writes RAW/STAGE Parquet to their separate buckets |
| Oracle MAIN | Stores final rows; inserts, task completion and batch closure share one transaction |

Oracle generates internal `batch_id` and `task_run_id` values. AIDP uses
`AIDP:<job.run_id>` as the shared execution key; Data Flow tasks receive
`ACTIVEBATCH:<parent-workflow-instance-id>` from ActiveBatch. Each actual task
attempt gets a new `TASK_RUN`, with its external run ID recorded separately.
Restart retains the batch's pinned release/cycle and never reopens a terminal batch.

Before deploying a changed pipeline, use the onboarding utility's optional baseline
comparison. Review task plans, parameters, DQ rules, sources and associations as well
as schemas/locations. Deploy a new DRAFT release; existing batches keep their pinned
configuration. The utility proposes target DDL but never executes it.

## Public API contracts

Use `MetadataFramework` from `mdpf.pipeline`. Construct it with an existing `db`,
an explicit `pipeline_code` and optionally the configured Spark session. Runtime
SQL helpers are internal participants, not independent lifecycle entry points.

| Method | Important inputs/context | Successful return | Failure and transaction contract |
|---|---|---|---|
| `start_batch(execution_key, cycle_date=None, execution_mode=None, *, orchestrator_run_id=None, triggered_by='SCHEDULER')` | Stable workflow key; new batches need an ISO cycle date and an ACTIVE release; modes are SCHEDULED/MANUAL | Persisted BATCH dictionary with generated `batch_id`, pinned release, cycle and state; resolves an existing compatible RUNNING batch | Owns the batch/event transaction. Conflicting overrides, invalid identity/date or terminal batch raise ValueError; DB errors propagate. |
| `execute_task(batch_id, task_code, custom_steps=None, orchestrator_task_run_id=None, orchestrator_attempt_number=None)` | Existing RUNNING batch and configured task; optional exact custom-callable registry and external attempt identity/count | Persisted TASK_RUN dictionary: includes `batch_id`, `task_run_id`, `attempt_number`, `status`, input/output counts and other recorded fields | Owns lifecycle/completion/failure scopes. Completed tasks or still-RUNNING writers are rejected. Errors after attempt creation follow guarded failure recording and propagate. |
| `fail_task_run(run_id, code, message, failed_step=None)` | Exact internal attempt ID; caller must confirm its external writer has stopped | `None`; terminal attempts are unchanged on duplicate/delayed callbacks | Owns the failure/work-item/event transaction, leaves BATCH RUNNING. Unknown attempt or an active attempt in a terminal batch raises ValueError; DB errors propagate. |
| `fail_batch(batch_id)` | Scheduler/operator has abandoned retries and stopped/terminalized active attempts | `None`; an already FAILED batch is unchanged | Owns finalization transaction. Refuses RUNNING attempts and other terminal batch states. This is not a waiting-phase transition. |

Do not wrap these lifecycle methods in another `db.transaction()`; there are no
nested-transaction/savepoint semantics. `OracleDb.transaction()` commits on normal
exit, rolls back and re-raises any BaseException. The facade chooses scopes;
`runtime.py` does not commit or roll back. MAIN DML, actual count reconciliation,
success evidence and completion share one scope, with failure evidence recorded
after rollback. Parquet/OCI I/O remains outside that Oracle atomicity guarantee.

Typical contract errors are ValueError; invalid handler return shapes raise
TypeError. Handler, Spark, OCI and Oracle errors propagate rather than being turned
into success values. Failure-recording errors can also propagate. A WARN policy
does not create a separate task-success status in this implementation: a task
whose remaining checks succeed is COMPLETED.

### Custom handler contract

The callable is `(frames, context, params)`. See the single
[CUSTOM_FEE_TRANSFORM implementation and registration example](#custom-task-steps) below.

| Value | Contract |
|---|---|
| `frames` | Dictionary of dataset codes to Spark DataFrames from the previous step. Use the actual configured keys; input/output routing depends on the task plan. |
| `context` | Read-only public mapping: `batch_id`, `task_run_id`, `pipeline_code`, `task_code`, `config_release_id`, `cycle_date`, `input_locations`, `output_locations`. It does not expose the framework or database. |
| `params` | Dictionary from this custom step's JSON/YAML parameters. Validate any business-specific values in the handler. |
| Return | Nonempty `dict[str, DataFrame]`. Multi-input joins and output routing are explicit; supply the keys required by the following configured steps/sink. |
| Errors | Raise to fail the attempt. None, empty dictionaries and non-DataFrame values cause TypeError. Missing/noncallable registry entries fail plan validation before data I/O. |

Keep the configured custom code identical to its `custom_steps` registry key.
STAGE/MAIN sinks require the exact frames retained by VALIDATE_DQ. For platform
identities use the [AIDP/Data Flow execution instructions](#run-from-data-flow--activebatch);
for recovery use [the existing failure guidance](#find-and-resolve-a-failure).

## Optional whole-file quarantine during RAW ingestion

Configure `METADATA.SOURCE_CONFIG.quarantine_path` in a new pinned configuration
release to enable quarantine. When it is NULL, existing fail-only behavior stays
unchanged. Use the updated companion generator to populate it from YAML.

During `READ_SOURCE`, a proven source validation failure rejects the whole CSV
before any RAW output writes. Supported failures include mismatched headers,
empty data, source length/null constraints and Spark errors explicitly classified
as malformed CSV. The whole original object is copied to:

`<quarantine_path>/batch_<batch_id>/run_<task_run_id>/<input_dataset_code>/<filename>`

The storage adapter performs a same-region OCI server-side copy using Resource
Principal authentication, a source ETag condition and destination create-only
protection. It waits for the copy work request to complete and verifies the
destination object before recording `QUARANTINED` and `quarantine_location` on the
exact `INGESTION_ITEM`. `SOURCE_QUARANTINED` in `EVENT_LOG` records the reason,
source path, destination and item ID. The task still fails and creates its normal
WORK_QUEUE error. The batch remains RUNNING for the scheduler's decision.

Landing is never deleted or moved. Each retry has a distinct quarantine path,
while previous attempts and their evidence stay unchanged. A still-invalid
immutable source will be rejected again; supply a corrected delivery through the
normal new-delivery workflow rather than overwriting the old source URI.

This first version quarantines RAW source validation failures only. STAGE/MAIN
conversion, custom-code and DQ failures retain normal task-failure behavior.
Network, missing-file, permission, database and unclassified Spark failures do
not automatically quarantine a source. No archive or row-level reject processing
is included. `TASK_STEP` actions remain `FAIL_TASK`; business policies now support `FAIL_TASK` or `WARN`; this feature does
not enable the otherwise unsupported `QUARANTINE` action values in those tables.

If copying fails or is uncertain, the ingestion item remains FAILED, with no
confirmed quarantine location; the error retains both the validation and copy
failure. A copy can physically complete before a database/audit failure: inspect
the deterministic destination before manual cleanup. Do not assume Oracle and OCI
are one transaction. An attempt terminalized while copying is never reopened or
marked quarantined by a delayed audit.

Quarantine must be disjoint from active landing/RAW/STAGE prefixes. Use a dedicated
bucket when practical. Source and quarantine buckets must be in the Resource
Principal's region in this implementation. Configure SDK source metadata/read,
destination create/inspect, copy/work-request permissions and the required OCI
Object Storage service permissions. Spark retains its existing sample/source
permissions. The source delivery URI must remain immutable during processing.
Install the OCI SDK dependency on the runtime as well as on the onboarding host.
No database DDL migration is needed; the existing 17-table columns are used.

Separate dataset pipelines fail independently. An existing combined RAW task
still fails as one task; only the file whose validation failed is quarantined.

## Set up once

1. Have a DBA provision `METADATA`, `RUNTIME`, `OPERATIONS`, the MAIN owner and
   runtime login. On a **fresh installation only**, run `sql/00_framework.sql`,
   then `sql/01_main_and_access.sql` in SQLcl/SQL*Plus script mode. The second
   script supplies generic sequences and runtime grants; adapt login names before
   running it. Review/provision the MAIN target separately from generated DDL,
   keys and grants in the [DMI_FEE contract](../generator/REFERENCE.md#dmi_fee-contract-and-bootstrap-replacement). Existing installations keep their tables.
2. Install `dist/mdpf-1.0-py3-none-any.whl` and its `oracledb>=2,<4` dependency
   on the AIDP cluster. Use cluster-provided PySpark. Replacing another build
   with the same version requires `pip install --force-reinstall --no-deps <wheel-path>`.
3. Configure Spark OCI access on **driver and workers**: landing read/list;
   RAW/STAGE read/list/write/overwrite/delete and required multipart permissions.
   Each layer can use its own bucket/namespace. Optional RAW whole-file quarantine is described below.
4. Give every notebook driver Oracle network access and these environment variables
   through secure configuration:

   ```text
   MDPF_DB_USER
   MDPF_DB_PASSWORD
   MDPF_DB_DSN
   ```

   Wallets may also need `MDPF_DB_CONFIG_DIR`, `MDPF_DB_WALLET_LOCATION` and
   `MDPF_DB_WALLET_PASSWORD`. A catalog connection does not configure this direct
   connection. Keep credentials out of notebooks, YAML and job parameters.

## Run the supplied DMI example

1. Follow the [DMI_FEE walkthrough](../generator/README.md#end-to-end-quick-start)
   using `generator/examples/dmi_fee.yaml`. Review target DDL/keys/grants and DRAFT
   metadata, verify the target, then approve/activate explicitly. This replaces
   the handwritten bootstrap; generation does not deploy or activate anything.
2. Deliver `fee_20261015.csv` to the configured landing prefix for explicit
   `cycle_date=2026-10-15`. Sample CSVs are separate objects; no current-date fallback.
3. Use the generic AIDP starter for RAW/MAIN with explicit `pipeline_code` and
   `task_code` widgets. Use a provider-owned STAGE notebook that registers the
   required trim handler (see Custom task steps below). Generic starters contain
   no business defaults or handlers. One invocation executes one task.
4. Set RAW → STAGE → MAIN dependencies to **All success**. Bind actual platform
   identities below. This is UI guidance, not an API import payload. Configure
   scheduler retry limits; disable retry-on-timeout until writer shutdown and
   exact-run recovery have been proven in your environment.

| Scope | Parameters |
|---|---|
| Job | `cycle_date=2026-10-15` |
| Every task | `job_run_id={{job.run_id}}`, `task_run_id={{task.run_id}}`, `execution_count={{task.execution_count}}`; count must resolve to a positive integer |
| RAW | `cycle_date={{job.parameters.cycle_date}}`; use `execution_mode=MANUAL` or `SCHEDULED`, mapping the trigger to a supported value |
| STAGE / MAIN | Omit cycle/mode overrides; reuse the original batch values |
| Separate phase jobs | Bind the same resolved `workflow_execution_key` to every task, while retaining each real job/task ID |

5. Run the workflow. Expect batch-scoped RAW/STAGE Parquet, two MAIN rows, four
   passing policy facts, three completed attempts and a completed batch. Inspect
   the printed identities using [sql/03_inspect.sql](sql/03_inspect.sql).

On failure, the failed attempt/error remain and the batch stays RUNNING. After
resolving the cause and confirming the writer stopped, Repair failed/downstream
tasks using the original workflow identity and fresh attempt identities. Confirm
platform Repair bindings in your environment. **Run Now creates a new workflow;
it is not Repair.** Demonstration failure injection is removed; the business trim
handler remains. See [two-phase scheduling](OPERATIONS.md#two-phase-scheduling).

## Use your own pipeline

Follow the [SQL Generator README](../generator/README.md) to deploy/activate metadata and prepare MAIN
tables. Supply the generic starter's pipeline/task selection explicitly. Register
custom handlers only in a provider-owned launcher, aligned with its dataset contract.

Use the [custom handler implementation and registration](#custom-task-steps)
below when your plan references business code; keep the call aligned with your
own pipeline/task codes. A missing registration fails before source I/O.

## Run from Data Flow / ActiveBatch

Use `entrypoints/dataflow/raw.py`, `stage.py` or `main.py` for built-in-only tasks.
Supply required `--pipeline-code` and optional `--task-code` selection flags.
The launcher derives the layer-specific task default and consumes these flags before calling
the existing adapter. Use a provider-owned script for custom tasks; generic starters
register no custom functions. Each invocation executes one task; ActiveBatch owns dependencies.

1. Install the supplied wheel and Oracle driver in the Data Flow Python environment.
   Configure the same Spark OCI permissions, driver DB variables/network and wallet
   as AIDP. Bootstrap secrets through the platform; do not put them in REST arguments.
2. ActiveBatch launches RAW, waits for success, then STAGE, then MAIN through the
   OCI Data Flow REST API. `examples/dataflow/create_run.json` is a request-body example;
   supply real application/compartment IDs and authenticate through your OCI setup.
3. Pass `--execution-key ACTIVEBATCH:<parent-workflow-instance-id>` to every run.
   RAW also needs `--cycle-date YYYY-MM-DD` and optional `--execution-mode MANUAL`.
   The key is generated from the scheduler's parent instance, not manually typed,
   and stays unchanged for failed-task retries. A new workflow gets a new key.
4. The adapter records the actual `DATAFLOW_RUN_ID`. If your environment does not
   expose it, bootstrap must supply the real run OCID through `--run-id`; the
   framework never invents an external run ID. Oracle's attempt counter increments.
5. On failure, ActiveBatch resubmits the failed application, then downstream work.
   RAW stays completed. Keep application code/wheel/metadata/source unchanged.
   ActiveBatch owns polling, retries and exhaustion; MDPF does not call its API.
   The starter has no failure-injection option. Handler errors must propagate
   to the platform as failed runs; do not catch them and return success.

For example, every child run receives the same `--execution-key`, while its
Data Flow run OCID and internal TASK_RUN ID differ. After abandoning retry and
stopping active writers, call
`mdpf.runner.finalize_failed_batch(pipeline_code="...", execution_key="...")`.
Hard-killed attempts require explicit exact-run failure after writer shutdown;
there is no automatic stale-run or timeout recovery.

## Available Task Steps

Steps pass a dictionary of Spark DataFrames between them, keyed by dataset code.
INPUT/OUTPUT datasets come from `TASK_DATASET`; their locations and column rules
come from `DATASET` and `DATASET_COLUMN`. Built-ins use these settings and accept
empty parameters only. Their names cannot be overridden by notebook functions.

| Step | When to use it | Required inputs | What it does and produces |
|---|---|---|---|
| `READ_SOURCE` | Start RAW ingestion from landing CSVs | Header CSV INPUT datasets in OCI, matching column definitions, a FILE source configuration and cycle date | Reads each file with Spark, checks its schema/values and records `INGESTION_ITEM` receipts. Returns INPUT DataFrames. No previous DataFrame is needed. |
| `READ_PARQUET` | Start STAGE or MAIN from an earlier task's output | RAW/STAGE Parquet INPUT datasets and a completed producer attempt in the same batch | Checks columns and actual batch/run lineage. Returns INPUT DataFrames with the stored business types; validates and removes the layer-specific system audit/lineage columns. |
| `DIRECT_MAP` | Convert types or select a subset of columns before output | DataFrames containing the target column names; OUTPUT column definitions | Selects columns in target order and converts to VARCHAR2, exact NUMBER(p,s) or date-only DATE. Returns OUTPUT DataFrames; invalid/lossy conversions fail. It does not rename, join or calculate business values. |
| `VALIDATE_DQ` | Check the final data before STAGE/MAIN output | DataFrames already matching OUTPUT columns/types; STAGE NOT_NULL/UNIQUE/RANGE/ALLOWED_VALUES and paired ROW_COUNT policies | Checks column/value constraints and configured policies. Records `POLICY_RESULT` for configured checks and returns the validated OUTPUT DataFrames. A blocking failure stops the task. |
| `WRITE_PARQUET` | Finish RAW or STAGE | Validated output-shaped DataFrames and RAW/STAGE Parquet OUTPUT locations | Rechecks the output contract and writes a batch folder in OCI, adding the layer-specific system audit fields (see DQ and audit contracts in the framework reference). Repair overwrites that batch folder. Returns OUTPUT DataFrames. |
| `LOAD_MAIN` | Finish MAIN with an Oracle load | Output-shaped DataFrames and configured Oracle OUTPUT tables (`GOLD` / `ADB_TABLE`) | Validates and prepares rows; task completion inserts them into Oracle in the same transaction as runtime completion. Returns OUTPUT DataFrames. MAIN tables also need `BATCH_ID`, `TASK_RUN_ID`, `ROW_NUMBER`, `CREATED_AT` and `UPDATED_AT`. |

For example, `DIRECT_MAP` can convert text `1250.75` to NUMBER(18,2) and
`2026-10-05` to DATE. A name change or a date such as `10/05/2026` needs custom
Python first. It never invents missing target columns or silently truncates values.

Multiple landing files are copied to their RAW datasets by matching
`TASK_DATASET.usage_sequence`. Built-ins do not automatically join multiple inputs;
custom joins/routing must return the configured OUTPUT dataset keys.

## Default task sequences

The SQL Generator creates these when YAML omits `task_steps`:

| Task | Default sequence |
|---|---|
| RAW | `READ_SOURCE` → `WRITE_PARQUET` |
| STAGE | `READ_PARQUET` → `DIRECT_MAP` (when needed) → `VALIDATE_DQ` → `WRITE_PARQUET` |
| MAIN | `READ_PARQUET` → `VALIDATE_DQ` → `LOAD_MAIN` |

RAW preserves input strings. STAGE needs `DIRECT_MAP` when input columns require
projection or datatype conversion; omit it if they already match the output.
MAIN normally needs no conversion because generated STAGE/MAIN schemas match.
DMI_FEE retains its original explicit MAIN DIRECT_MAP step for compatibility.
If custom MAIN logic changes that, include `DIRECT_MAP` explicitly where needed.

A supplied `task_steps` list is used exactly. Keep one reader first, one final
write/load step, and `VALIDATE_DQ` immediately before STAGE/MAIN output—even with
no DQ policies. Any step failure fails the task. Repair reruns the whole task;
there are no internal step checkpoints.

## Custom task steps

Use custom Python for joins/routing, renaming, cleaning, filtering, business date
formats, derived columns or calculations. Built-ins handle generic reading,
matching-name conversion, validation and writing.
This required transformation belongs to `generator/examples/dmi_fee.yaml`.
Register it in a provider-owned launcher. Generic AIDP/Data Flow starters do not
include or register this function. The implementation below is a reference example.

Add a reference inside the YAML `task_steps` list:

```yaml
- code: CUSTOM_FEE_TRANSFORM
  parameters:
    column: CLIENT_NO
```

See the [complete YAML plan](../generator/REFERENCE.md#configure-task-steps).
Implement and register that exact code in the STAGE notebook:

```python
from pyspark.sql import functions as F
from mdpf.aidp import execute_task

def custom_fee_transform(frames, context, params):
    df = frames["DMI_FEE_FEE_RAW"]
    column = params["column"]
    return {"DMI_FEE_FEE_STAGE": df.withColumn(column, F.trim(F.col(column)))}

result = execute_task(
    pipeline_code="DMI_FEE",
    task_code="DMI_FEE_STAGE_LOAD",
    aidputils=aidputils,
    spark=spark,
    custom_steps={"CUSTOM_FEE_TRANSFORM": custom_fee_transform},
)
```

`frames` contains dataset-coded DataFrames; return a nonempty dictionary of
DataFrames. `context` is read-only and supplies IDs, cycle date and input/output
location maps. `params` contains the YAML `parameters` values. This example trims
CLIENT_NO, then the YAML plan runs `DIRECT_MAP`, DQ and the writer.

The generator creates the custom metadata reference; it does not implement or
test your function. The runtime checks every handler before data I/O. Missing or
non-callable registrations fail clearly. Raising an exception fails the task.
The notebook registers functions and invokes MDPF; it does not call each step.

## Supported DQ rules

See [DQ and audit contracts in the framework reference](REFERENCE.md#dq-reconciliation-and-audit-contracts) for STAGE column rules, FAIL/WARN, paired row counts,
transactional MAIN reconciliation and the five audit columns. Column policies run
once at VALIDATE_DQ; schema/type constraints remain blocking at required boundaries.
MAIN enforces Oracle contracts/constraints and actual insert counts, without
repeating unchanged STAGE business DQ. MDPF_MAIN_MAX_ROWS defaults to 10,000 rows per task.


## Find and resolve a failure

```mermaid
flowchart TD
    A["AIDP starts a notebook"] --> B["BATCH plus a new TASK_RUN"]
    B --> C["Validate plan, then run steps"]
    C -->|Success| D["Complete TASK_RUN"]
    C -->|Failure| E["Fail TASK_RUN and add WORK_QUEUE error"]
    E -->|Operator action| R["AIDP Repair"]
    R -->|Same job and batch, new attempt| B
```

A failed attempt leaves the batch RUNNING. Repair uses the same pinned metadata
and starts the selected task's whole plan again. The generated MAIN task closes
the batch on success; earlier failed attempts and errors remain visible.

Start with the failed notebook log: MDPF prints `TASK_PLAN`, `STEP_STARTED` and
`TASK_FAILED`. Find `BATCH` by pipeline and AIDP job ID, then inspect the attempt's
`TASK_RUN.failed_step_code`, `error_code`, `error_message` and attempt number.
`WORK_QUEUE` retains failures; `EVENT_LOG` records lifecycle/output paths;
`INGESTION_ITEM` records source receipts. Adapt `sql/03_inspect.sql` filters for your pipeline.

| Symptom | Check / next action |
|---|---|
| Oracle connection fails | Driver environment, DSN, network, wallet and grants |
| Source missing / OCI denied | Pinned cycle date, resolved URI and Spark driver/worker access |
| Task/handler missing | Pinned release, `TASK_STEP` code and notebook registration |
| Schema/DQ failure | `DATASET_COLUMN`, source values and `POLICY_RESULT` evidence when configured |
| Parquet input rejected | Producer's completed attempt and object lineage; do not replace batch files manually |
| Attempt still RUNNING | Confirm the old writer stopped; operator must fail that exact run before Repair |
| Task already COMPLETED | Exclude it from Repair; select failed/downstream tasks only |

Keep wheel, notebooks, metadata and deliveries unchanged during Repair. Changed
business logic or published metadata needs a new release/job run. Terminal batches
never reopen. If restart is abandoned, after writers stop and active attempts are
terminalized, call `mdpf.aidp.finalize_failed_job(pipeline_code="...", job_run_id="...")`.

## Where the code lives

| Module in `src/mdpf/` | Responsibility |
|---|---|
| `aidp.py` | Reads notebook parameters and supplies AIDP workflow/attempt identities |
| `dataflow.py` | Reads application arguments and the actual Data Flow run identity |
| `runner.py` | Shares task launch/finalization across platforms; manages the DB connection |
| `pipeline.py` | Public facade, execution loop, lifecycle decisions and transaction coordination, including MAIN inserts/reconciliation |
| `metadata.py` | Batch-pinned task/dataset/schema/policy resolution and plan/path validation before external I/O |
| `runtime.py` | Runtime records, receipts, policy evidence, work queue and operational event SQL on the existing DB connection |
| `dq.py` | Shared rule-parameter validation, Spark rule calculations and result formatting |
| `steps.py` | Built-in registry, readers, direct mapping, DQ coordination and validated output preparation |
| `schema.py` | Validates schemas/values and performs explicit conversions |
| `storage.py` | Validates OCI paths; uses Spark for CSV/Parquet I/O |
| `db.py` | Opens Oracle connections; handles binds, inserts and transactions |
| `__init__.py` | Identifies the package/version |

Use `MetadataFramework` for lifecycle operations. Internal `runtime.py` helpers
never open transactions, commit or roll back; the facade checks allowed transitions
and calls them inside the existing transaction. MAIN rows, reconciliation, success
evidence and completion still commit together. Failed MAIN work rolls back before
the separate failure-evidence transaction. The source-receipt transaction still
finishes before opening a CSV. Operational event inserts move to `runtime.py`;
verbose task/step logging remains in the execution loop.

Existing facade methods, handler signatures and `mdpf.steps` DQ imports remain
available. Readers/writers stay in `steps.py`; no service or repository classes
were added. Stored MAIN layer values remain `GOLD`.

POC limits: MAIN collects at most the configured MDPF_MAIN_MAX_ROWS on the driver (default 10,000 across outputs). Parquet Repair overwrites
batch paths; multiple OCI writes are not atomic. Dated source URIs must be
immutable; automatic receipts provide lineage, not cross-batch deduplication.
DQ supports NOT_NULL, single-column UNIQUE, numeric RANGE, ALLOWED_VALUES and explicitly paired ROW_COUNT. The 17-table model retains unused
MAPPING_RULE, PIPELINE_STATE and OUTBOUND_CONFIG. REPROCESS, Iceberg and automatic
hard-timeout recovery are outside scope. See the [current bundle validation](../../VALIDATION.txt)
for completed checks and outstanding live AIDP/Oracle/OCI validation. Dated release
notes retain historical evidence for their own builds.

## DQ, reconciliation and audit contracts

### Layer ownership

RAW checks the exact source delivery, CSV/header/length/type contracts and nonempty
input. Proven technical failures still trigger optional whole-file quarantine.
LANDING/RAW inference now defaults to nullable strings even when the target default
is NOT NULL. An explicit source `is_nullable: N` remains a technical source contract;
do not use it for a business-only restriction. Put business DQ in STAGE.

STAGE supports `NOT_NULL`, `UNIQUE`, `RANGE` and `ALLOWED_VALUES`. Business policies
run once at `VALIDATE_DQ`. Conversion/type/length checks remain at boundaries;
required target nullability is enforced after DQ evidence and again at the sink.
MAIN checks the Oracle contract/constraints and actual insert counts. Column DQ
policies targeting MAIN are rejected; move them to the corresponding STAGE dataset
in a new DRAFT release. If MAIN custom code changes business values, move that
transformation and its business validation to STAGE. Do not load unvalidated
business changes under the assumption that prior STAGE DQ covers them.

### YAML

DMI_FEE configures two NOT_NULL and two ROW_COUNT policies. The excerpt below
also illustrates optional checks; it does not add them to the shipped DMI_FEE plan.
See `generator/examples/dq_and_reconciliation.yaml` for the separate DQ fixture.

```yaml
dq_rules:
  - column: LN_NO       # Omitted datasets means all generated STAGE outputs.
    check: NOT_NULL
    severity: FAIL       # Default; ERROR / FAIL_TASK in Oracle metadata.
  - column: LN_NO
    check: UNIQUE
  - datasets: [DMI_FEE_FEE_STAGE]
    column: FEE_TRAN_TY
    check: ALLOWED_VALUES
    values: [ASSESS, REVERSE]
  - datasets: [DMI_FEE_FEE_STAGE]
    column: FEE_TRAN_AM
    check: RANGE
    min: 0
    max: 1000000
    severity: WARN       # WARN / WARN in Oracle metadata.
  - datasets: [DMI_FEE_FEE_STAGE]
    check: ROW_COUNT
    source_dataset: DMI_FEE_FEE_RAW
  - datasets: [DMI_FEE_FEE_MAIN]
    check: ROW_COUNT
    source_dataset: DMI_FEE_FEE_STAGE
```

`column` is required for column checks, forbidden for `ROW_COUNT`. Each output can
have one `ROW_COUNT` rule and must explicitly name an input of the adjacent layer.
The rule declares that this mapping preserves rows: equality is intended. STAGE
count rules support one RAW input with one or several independently paired STAGE
outputs. Multi-input joins/aggregation are rejected for count equality. Custom
filters, joins and aggregations need their own explicitly reviewed reconciliation
contract; do not configure equality for them. MAIN append count rules pair each
output with a configured STAGE input; never compare summed fan-out counts.

`ALLOWED_VALUES` uses case-sensitive, untrimmed equality. Values must be a nonempty,
unique list compatible with the column: strings for VARCHAR2, finite YAML numbers
that fit NUMBER precision/scale, ISO YYYY-MM-DD dates for DATE. NULL is ignored;
use `NOT_NULL` separately. Empty string is a real value for this check; MAIN still
rejects empty strings because Oracle converts them to NULL. Booleans, NULL entries,
nested values and duplicates are invalid. RANGE is inclusive; UNIQUE counts every
row sharing a duplicate non-null value. Neither repairs nor drops rows.

WARN failures record `WARN` / `WARNED` and continue. Tasks remain `COMPLETED`, so
existing producer reads work. `reject_count` remains zero. FAIL records durable
`FAIL` / `FAILED_TASK`, fails the exact attempt, retains RAW and leaves the batch
RUNNING for the scheduler. A WARN never bypasses required schema or Oracle constraints.
STAGE DQ never copies landing files to quarantine.

### MAIN transaction and row limit

STAGE `ROW_COUNT` runs before any STAGE write. MAIN `ROW_COUNT` runs after DML and
before COMMIT using `cursor.rowcount` returned by `OracleDb.insert_many()`. Inserts,
successful reconciliation results, load events, task completion and batch closure
share one Oracle transaction. A mismatch rolls back the entire transaction across
all outputs. Failure policy evidence and failed-attempt/error history are then
recorded in a separate transaction. Unknown/negative affected counts fail closed.
Even without a configured count policy, actual inserts must equal prepared rows.
MAIN reconciliation cannot be WARN.

`MDPF_MAIN_MAX_ROWS` defaults to `10000` **across all MAIN outputs in one task**.
Every driver collection uses `limit(remaining + 1)`. Exceeding the cap fails before
any insert, without truncation. The setting must be 1–2147483646; no unlimited
sentinel is supported. A row cap does not bound bytes for unusually wide rows.
After reviewing driver capacity, raise the cap in the MAIN worker environment and
retry only failed MAIN in the same batch. This remains a bounded driver-load POC.

Generated MAIN DDL does not infer business keys/unique/check/FK constraints from DQ.
STAGE UNIQUE cannot prevent duplicates already in MAIN; review required Oracle
constraints separately. Affected-row counts prove DML counts, not post-trigger
business values or cross-batch uniqueness.

### Five framework-managed audit fields

| Layer | Existing fields | Added fields |
|---|---|---|
| RAW | `_batch_id`, `_run_id` | `_ingestion_item_id` BIGINT; `_ingested_at` TIMESTAMP |
| STAGE | `_batch_id`, `_run_id` | `_processed_at` TIMESTAMP |
| MAIN | `BATCH_ID`, `TASK_RUN_ID`, `ROW_NUMBER` | `CREATED_AT`, `UPDATED_AT` TIMESTAMP(6) WITH TIME ZONE |

Timestamps represent UTC instants; set Spark `spark.sql.session.timeZone=UTC` for
consistent display. MAIN timestamps use an explicit Oracle timestamp-with-time-zone
bind and are equal on insert. There is no UPDATE/MERGE implementation; a future
upsert must preserve CREATED_AT and change UPDATED_AT only for actual updates.
RAW receives the exact source receipt associated through its validated input/output
pair. Multi-input RAW custom transformations are rejected: place combinations in
STAGE so the receipt ID is never assigned arbitrarily.

Parquet readers require exactly the business columns plus the layer's system fields,
validate their types/non-null values, batch and completed producer IDs, and verify
RAW receipt ownership against the paired PROCESSED input in that producer attempt.
System fields are removed before transformations and DQ. All system names are
reserved; never put them in business YAML columns/overrides or DQ rules.

No new framework tables, scheduler states, archive, row rejection, MERGE or waiting
batch dashboard are included. See [upgrade instructions](OPERATIONS.md#development-rollout) before installing.
