"""Built-in Spark boundaries and once-per-attempt business DQ evaluation."""
from datetime import datetime, timezone
import hashlib
import json
import os

from pyspark.sql import functions as F

from .schema import DataValidationError, convert_frame, require_columns, spark_type, string_limit, validate_frame
from .storage import malformed_csv_error
from .dq import _policy_failures, policy_result, validate_dq_parameters
from . import runtime


def read_source(frames, ctx, params):
    """Read exact CSV inputs after committing source receipts; return frames by input code.

    Update ctx input counts/receipt identities. Proven technical source violations
    may copy the whole file to quarantine before the original exception propagates.
    Infrastructure failures are not classified as bad-file quarantine."""
    fw = ctx['framework']
    result = {}
    for code, spec in ctx['inputs'].items():
        path = spec['location']
        identity = [fw.pipeline_code, ctx['source_config']['source_system_name'], code, path]
        key = 'RECEIPT:' + hashlib.sha256(json.dumps(identity, separators=(',', ':')).encode()).hexdigest()
        item_id, previous = fw._receive_source(ctx, spec, key)
        spec['ingestion_item_id'] = item_id
        if previous and (previous['source_location'] != path or previous['source_item_key'] != key):
            raise ValueError('Source delivery URI changed during restart; do not reuse this batch.')
        try:
            df = fw.storage.read_csv(fw.spark, path)
            require_columns(df, spec['columns'], 'CSV header')
            df = convert_frame(df, spec['columns'])
            _, spec['count'] = validate_frame(df, spec['columns'], 'Source', source=True)
        except Exception as exc:
            if ctx['source_config'].get('quarantine_path') and (
                    isinstance(exc, DataValidationError) or malformed_csv_error(exc)):
                fw._quarantine_source(ctx, spec, exc)
            raise
        result[code] = df
    ctx['input_count'] = sum(s['count'] for s in ctx['inputs'].values())
    return result


def read_parquet(frames, ctx, params):
    """Read retained inputs only from one completed same-batch/pinned-release producer.

    Validate layer-specific audit/receipt lineage and business schemas, drop system
    fields, then return input-code frames and set ctx counts. No automatic joins."""
    fw, result = ctx['framework'], {}
    for spec in ctx['inputs'].values():
        producers = runtime.completed_producers(fw.db,
            ctx['batch']['batch_id'], ctx['batch']['config_release_id'], spec['producer_task_id'])
        if len(producers) != 1:
            raise ValueError('Input requires exactly one completed producer attempt in the same batch and pinned release.')
        spec['producer_run_id'] = producers[0]['task_run_id']
    for code, spec in ctx['inputs'].items():
        df = fw.storage.read_parquet(fw.spark, spec['location'])
        columns = spec['columns']
        system = {'_batch_id': 'bigint', '_run_id': 'bigint'}
        if spec['dataset']['layer'] == 'RAW':
            system.update(_ingestion_item_id='bigint', _ingested_at='timestamp')
        else:
            system['_processed_at'] = 'timestamp'
        expected = {c['column_name'] for c in columns} | set(system)
        if len(df.columns) != len(expected) or set(df.columns) != expected:
            raise ValueError('Input Parquet columns do not match DATASET_COLUMN and reserved lineage/audit fields.')
        if any(df.schema[n].dataType.simpleString() != typ for n, typ in system.items()):
            raise ValueError('Input Parquet lineage/audit column types do not match the layer contract.')
        invalid = F.lit(False)
        for name in system:
            invalid = invalid | F.col(name).isNull()
        invalid = invalid | (F.col('_batch_id') != ctx['batch']['batch_id']) | (F.col('_run_id') != spec['producer_run_id'])
        if spec['dataset']['layer'] == 'RAW':
            receipts = runtime.processed_source_receipts(fw.db,
                spec['producer_run_id'], ctx['batch']['config_release_id'],
                spec['producer_task_id'], spec['dataset']['dataset_id'])
            if len(receipts) != 1:
                raise ValueError('RAW requires one processed source receipt from its paired completed producer.')
            invalid = invalid | (F.col('_ingestion_item_id') != receipts[0]['ingestion_item_id'])
        if df.where(invalid).limit(1).count():
            raise ValueError('Input Parquet lineage/audit does not match the current batch and completed producer attempt.')
        df = df.drop(*system)
        _, spec['count'] = validate_frame(df, columns, 'Input Parquet')
        result[code] = df.select(*[c['column_name'] for c in columns])
    ctx['input_count'] = sum(s['count'] for s in ctx['inputs'].values())
    return result


def output_frames(frames, ctx):
    outputs = ctx['outputs']
    if set(frames) == set(outputs):
        return frames
    if 'raw_pairs' in ctx and set(frames) == set(ctx['inputs']):
        return {output: frames[source] for output, source in ctx['raw_pairs'].items()}
    if len(frames) == 1 and set(frames) == set(ctx['inputs']):
        return {code: next(iter(frames.values())) for code in outputs}
    raise ValueError('Custom step must return exactly the output dataset codes; multiple inputs are never joined or routed automatically.')


def _check_output(df, ctx, spec, record_pass=False, oracle=False, check_nulls=True):
    """Business policies run only at VALIDATE_DQ; sink schema checks remain blocking."""
    nulls, count = validate_frame(df, spec['columns'], 'Output', check_nulls=False, oracle=oracle)
    if record_pass:
        results = []
        for policy in spec['policies']:
            if policy['parameters']['check'] == 'ROW_COUNT':
                if spec['dataset']['layer'] == 'GOLD':
                    continue  # Actual Oracle DML counts are available only in _complete.
                expected = ctx['inputs'][policy['parameters']['source_dataset']]['count']
                results.append(policy_result(ctx, policy, abs(expected - count), expected, count))
            else:
                amount, expected = _policy_failures(df, policy, nulls)
                results.append(policy_result(ctx, policy, amount, expected, amount))
        if results:
            ctx['framework']._record_policy_results(ctx, results)
    if check_nulls and any(nulls[c['column_name']] for c in spec['columns'] if c['is_nullable'] == 'N'):
        raise DataValidationError('Required target column has nulls.')
    return count


def direct_map(frames, ctx, params):
    """Route output frames and explicitly convert them to configured column types.

    Return converted frames; business policies run later at VALIDATE_DQ."""
    result = {}
    for code, df in output_frames(frames, ctx).items():
        spec = ctx['outputs'][code]
        result[code] = convert_frame(df, spec['columns'])
        # Required target nullability is enforced after policy evidence at VALIDATE_DQ
        # and again at the sink; conversion/type/length checks remain here.
        _check_output(result[code], ctx, spec, check_nulls=False)
    return result


def validate_dq(frames, ctx, params):
    """Validate output contracts, persist business DQ facts and remember exact frames.

    Return output-code frames; blocking failures propagate after durable evidence.
    Later STAGE/MAIN sinks require these same DataFrame objects."""
    result = output_frames(frames, ctx)
    for code, df in result.items():
        _check_output(df, ctx, ctx['outputs'][code], record_pass=True)
    ctx['state']['validated_outputs'] = result
    return result


def _require_validated(result, ctx):
    if any(s['dataset']['layer'] in ('STAGE', 'GOLD') for s in ctx['outputs'].values()):
        validated = ctx['state'].get('validated_outputs', {})
        if set(result) != set(validated) or any(df is not validated[code] for code, df in result.items()):
            raise ValueError('Sink requires the exact outputs from VALIDATE_DQ.')


def write_parquet(frames, ctx, params):
    """Write batch-scoped Parquet with managed lineage/audit fields and set output counts.

    STAGE requires the exact validated frames. RAW preserves source-receipt pairing.
    Writes occur before Oracle completion and multiple OCI outputs are not atomic."""
    fw, result = ctx['framework'], output_frames(frames, ctx)
    _require_validated(result, ctx)
    outputs = {code: {'count': _check_output(df, ctx, ctx['outputs'][code])} for code, df in result.items()}
    stamp = datetime.now(timezone.utc)
    for code, df in result.items():
        spec = ctx['outputs'][code]
        data = df.select(*[c['column_name'] for c in spec['columns']])
        data = data.withColumn('_batch_id', F.lit(ctx['batch']['batch_id']).cast('long'))
        data = data.withColumn('_run_id', F.lit(ctx['run_id']).cast('long'))
        if spec['dataset']['layer'] == 'RAW':
            receipt = ctx['inputs'][ctx['raw_pairs'][code]]['ingestion_item_id']
            data = data.withColumn('_ingestion_item_id', F.lit(receipt).cast('long'))
            data = data.withColumn('_ingested_at', F.lit(stamp).cast('timestamp'))
        else:
            data = data.withColumn('_processed_at', F.lit(stamp).cast('timestamp'))
        fw.storage.write_parquet(spec['location'], data)
    ctx['state']['outputs'] = outputs
    ctx['output_count'] = sum(s['count'] for s in outputs.values())
    return result


def load_main(frames, ctx, params):
    """Prepare bounded MAIN rows in memory without inserting or committing them.

    Require exact validated frames and Oracle-compatible values. Apply the task-wide
    MDPF_MAIN_MAX_ROWS cap (default 10000) with bounded collects; exceeding it raises
    before any insert. The facade later inserts/reconciles all prepared outputs."""
    setting = os.environ.get('MDPF_MAIN_MAX_ROWS', '10000')
    try:
        maximum = int(setting)
    except ValueError as exc:
        raise ValueError('MDPF_MAIN_MAX_ROWS must be a positive integer, at most 2147483646.') from exc
    if not 1 <= maximum <= 2147483646:
        raise ValueError('MDPF_MAIN_MAX_ROWS must be a positive integer, at most 2147483646.')
    result = output_frames(frames, ctx)
    _require_validated(result, ctx)
    for code, df in result.items():
        _check_output(df, ctx, ctx['outputs'][code], oracle=True)
    outputs, total = {}, 0
    for code, df in result.items():
        columns = ctx['outputs'][code]['columns']
        remaining = maximum - total
        rows = df.select(*[c['column_name'] for c in columns]).limit(remaining + 1).collect()
        if len(rows) > remaining:
            raise ValueError(f'MAIN row limit exceeded: MDPF_MAIN_MAX_ROWS={maximum}; output {code} exceeds the {remaining} rows remaining for this task.')
        outputs[code] = {'rows': [r.asDict() for r in rows], 'count': len(rows)}
        total += len(rows)
    ctx['state']['outputs'] = outputs
    ctx['output_count'] = total
    return result


BUILTINS = {'READ_SOURCE': read_source, 'READ_PARQUET': read_parquet,
            'DIRECT_MAP': direct_map, 'VALIDATE_DQ': validate_dq,
            'WRITE_PARQUET': write_parquet, 'LOAD_MAIN': load_main}
