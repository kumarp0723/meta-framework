"""Batch-pinned metadata resolution and plan/path validation before external I/O."""
from datetime import date
import json

from .dq import validate_dq_parameters
from .schema import sql_identifier, validate_columns
from .steps import BUILTINS
from .storage import object_address


def active_release(db, pipeline_code):
    return db.one("SELECT * FROM METADATA.CONFIG_RELEASE WHERE pipeline_code=:p AND release_status='ACTIVE'", p=pipeline_code)


def _json_object(value, label):
    if value is None:
        return {}
    if isinstance(value, str):
        try:
            value = json.loads(value.strip() or "{}")
        except json.JSONDecodeError as exc:
            raise ValueError(f"{label} must contain valid JSON.") from exc
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a JSON object.")
    return value


def task(framework, batch, task_code):
    if not isinstance(task_code, str) or not task_code.strip():
        raise ValueError("Explicit task_code is required.")
    task = framework.db.one("SELECT * FROM METADATA.TASK WHERE config_release_id=:r AND task_code=:c",
        r=batch["config_release_id"], c=task_code)
    if not task:
        raise ValueError("Task is missing from the pinned release.")
    return task


def datasets(framework, batch, task, role):
    rows = framework.db.execute("""SELECT d.*, td.usage_sequence FROM METADATA.TASK_DATASET td JOIN METADATA.DATASET d
        ON d.config_release_id=td.config_release_id AND d.dataset_id=td.dataset_id
        WHERE td.config_release_id=:r AND td.task_id=:t AND td.dataset_role=:role AND td.is_enabled='Y' ORDER BY td.usage_sequence, d.dataset_id""",
        r=batch["config_release_id"], t=task["task_id"], role=role)
    if not rows:
        raise ValueError("Task requires at least one enabled dataset per input/output role.")
    return rows


def columns(framework, release_id, dataset_id):
    columns = framework.db.execute("SELECT * FROM METADATA.DATASET_COLUMN WHERE config_release_id=:r AND dataset_id=:d ORDER BY column_sequence",
        r=release_id, d=dataset_id)
    validate_columns(columns)
    return columns


def producer(framework, release_id, dataset_id):
    rows = framework.db.execute("""SELECT task_id FROM METADATA.TASK_DATASET
        WHERE config_release_id=:r AND dataset_id=:d AND dataset_role='OUTPUT' AND is_enabled='Y'""",
        r=release_id, d=dataset_id)
    if len(rows) != 1:
        raise ValueError("Internal dataset requires exactly one enabled producer in the pinned release.")
    return rows[0]["task_id"]


def output_path(framework, batch, dataset):
    if dataset["storage_type"] != "PARQUET":
        raise ValueError("Oracle MAIN has no Parquet output path.")
    location = str(dataset["physical_object_name"] or "").rstrip("/")
    if not object_address(location)[2] or any(c in location for c in "*[]{}"):
        raise ValueError("Parquet DATASET requires a full OCI dataset prefix.")
    return location + f"/batch_{batch['batch_id']}"


def resolve_plan(framework, ctx, custom_steps):
    """Resolve ordered handlers and boundary rules from the batch-pinned release.

    Mutate ctx.step_code while validating; return (step, callable, parameters)
    tuples. Reject missing handlers/unsupported plans before any source or sink I/O."""
    builtins = BUILTINS
    if not isinstance(custom_steps, dict):
        raise ValueError("custom_steps must be a dictionary of named functions.")
    if builtins.keys() & custom_steps.keys():
        raise ValueError("BUILTIN names cannot be overridden by custom_steps.")
    steps = framework.db.execute("SELECT * FROM METADATA.TASK_STEP WHERE config_release_id=:r AND task_id=:t ORDER BY step_sequence_number",
        r=ctx["batch"]["config_release_id"], t=ctx["task"]["task_id"])
    if not steps:
        raise ValueError("Task has no configured steps.")
    plan = []
    for step in steps:
        ctx["step_code"] = code = step["step_code"]
        if step["is_required"] != "Y" or step["on_failure_action"] != "FAIL_TASK":
            raise ValueError("POC uses required steps and FAIL_TASK only.")
        if step["step_type"] not in ("BUILTIN", "CUSTOM_PYTHON"):
            raise ValueError(f"Unsupported step_type for {code}.")
        handler = (builtins if step["step_type"] == "BUILTIN" else custom_steps).get(code)
        if not callable(handler):
            raise ValueError(f"Missing callable {step['step_type']} handler: {code}")
        params = _json_object(step.get("parameter_json"), f"Step {code} parameter_json")
        if step["step_type"] == "BUILTIN" and params:
            raise ValueError(f"BUILTIN {code} uses empty parameters in this POC.")
        plan.append((step, handler, params))
    # Generic boundaries, not a second per-task execution recipe.
    codes = [s["step_code"] if s["step_type"] == "BUILTIN" else None for s in steps]
    if codes.count('VALIDATE_DQ') > 1:
        raise ValueError('Business DQ may run only once per task attempt.')
    readers = {"READ_SOURCE", "READ_PARQUET"}
    sinks = {"WRITE_PARQUET", "LOAD_MAIN"}
    if codes[0] not in readers or any(c in readers for c in codes[1:]):
        raise ValueError("Plan must start with one read step.")
    if codes[-1] not in sinks or any(c in sinks for c in codes[:-1]):
        raise ValueError("Plan must end with one final sink step.")
    ctx["step_code"] = None
    return plan


def source_path(framework, batch, config, dataset, input_count):
    """Resolve one exact CSV URI under the configured landing prefix.

    Use the pinned cycle date for {YYYYMMDD}; no clock fallback, globbing or listing.
    Multiple inputs need exact per-dataset filenames. Invalid paths raise ValueError."""
    def expand(value):
        result = str(value or "").replace("{YYYYMMDD}",
            date.fromisoformat(str(batch["cycle_date"])[:10]).strftime("%Y%m%d"))
        if any(c in result for c in "*[]{}"):
            raise ValueError("Source locations support only the {YYYYMMDD} date token; no wildcards.")
        return result.rstrip("/")

    root = expand(config["landing_path"])
    allowed = object_address(root)
    location = expand(dataset["physical_object_name"])
    if not location.lower().endswith(".csv"):
        if input_count != 1 or not config["file_pattern"]:
            raise ValueError("Multiple CSV inputs require an exact filename template on each DATASET.")
        filename = expand(config["file_pattern"])
        if "/" in filename or "@" in filename:
            raise ValueError("SOURCE_CONFIG.file_pattern must be a filename, not a path.")
        location += "/" + filename
    actual = object_address(location)
    if (not allowed[2] or actual[:2] != allowed[:2] or
            not actual[2].startswith(allowed[2] + "/") or
            not actual[2].lower().endswith(".csv")):
        raise ValueError("Source must be an exact CSV within SOURCE_CONFIG.landing_path.")
    return location


def prepare_dataflow(framework, ctx, plan):
    """Populate ctx inputs/outputs with pinned schemas, policies and exact locations.

    Validate RAW receipt pairing, producer ownership, policy scope and nonoverlapping
    paths before external data I/O. This resolves contracts; it neither reads Spark
    data nor writes Oracle business rows."""
    batch, task = ctx["batch"], ctx["task"]
    for role in ("INPUT", "OUTPUT"):
        specs = {}
        for dataset in framework._datasets(batch, task, role):
            code = dataset["dataset_code"]
            if code in specs:
                raise ValueError("Duplicate task/dataset association.")
            specs[code] = dict(dataset=dataset,
                columns=framework._columns(batch["config_release_id"], dataset["dataset_id"]))
        ctx["inputs" if role == "INPUT" else "outputs"] = specs
    if set(ctx["inputs"]) & set(ctx["outputs"]):
        raise ValueError("Input and output must be distinct datasets.")
    reader, sink = plan[0][0]["step_code"], plan[-1][0]["step_code"]
    if reader == "READ_SOURCE":
        config = framework.db.one("SELECT * FROM METADATA.SOURCE_CONFIG WHERE config_release_id=:r AND source_config_id=:s",
            r=batch["config_release_id"], s=task["source_config_id"])
        if (task["task_type"] != "INGESTION" or not config or config["source_type"] != "FILE" or
                config["ingestion_mode"] != "SINGLE_FILE" or
                config["expected_input_count"] not in (None, len(ctx["inputs"]))):
            raise ValueError("READ_SOURCE requires an INGESTION FILE task; expected_input_count must match its CSV inputs.")
        ctx["source_config"] = config
        if sink == "WRITE_PARQUET" and all(s["dataset"]["layer"] == "RAW" for s in ctx["outputs"].values()):
            # Explicit pairing applies only to source-preserving CSV -> RAW copies.
            paired = {}
            for role in ("inputs", "outputs"):
                by_sequence = {}
                for code, spec in ctx[role].items():
                    sequence = spec["dataset"]["usage_sequence"]
                    if sequence is None or sequence <= 0 or sequence in by_sequence:
                        raise ValueError("RAW pairing requires unique positive usage_sequence values per INPUT/OUTPUT role.")
                    by_sequence[sequence] = code
                paired[role] = by_sequence
            if paired["inputs"].keys() != paired["outputs"].keys():
                raise ValueError("RAW INPUT/OUTPUT usage_sequence sets must match.")
            ctx["raw_pairs"] = {paired["outputs"][n]: code for n, code in paired["inputs"].items()}
            if len(ctx['inputs']) > 1 and any(s['step_type'] == 'CUSTOM_PYTHON' for s, _, _ in plan):
                raise ValueError('Multi-source RAW must preserve source receipt pairing; move custom transformations to STAGE.')
            fields = ("column_name", "column_sequence", "data_type", "length_precision_scale", "is_nullable")
            for output, source in ctx["raw_pairs"].items():
                a, b = ctx["inputs"][source]["columns"], ctx["outputs"][output]["columns"]
                if ([tuple(c.get(f) for f in fields) for c in a] !=
                        [tuple(c.get(f) for f in fields) for c in b] or
                        any(c["data_type"] != "VARCHAR2" for c in a)):
                    raise ValueError("Paired LANDING/RAW schemas must match and preserve string representation.")
    for spec in ctx["inputs"].values():
        source = spec["dataset"]
        if reader == "READ_SOURCE":
            if source["storage_type"] != "CSV":
                raise ValueError("READ_SOURCE requires CSV input datasets.")
            spec["location"] = framework.source_path(batch, config, source, len(ctx["inputs"]))
        else:
            if source["storage_type"] != "PARQUET" or source["layer"] not in ("RAW", "STAGE"):
                raise ValueError("READ_PARQUET requires RAW/STAGE Parquet inputs.")
            spec["producer_task_id"] = framework._producer(batch["config_release_id"], source["dataset_id"])
            spec["location"] = framework.output_path(batch, source)
    for spec in ctx["outputs"].values():
        target = spec["dataset"]
        if framework._producer(batch["config_release_id"], target["dataset_id"]) != task["task_id"]:
            raise ValueError("Output producer does not match the requested task.")
        if sink == "LOAD_MAIN":
            if target["storage_type"] != "ADB_TABLE" or target["layer"] != "GOLD":
                raise ValueError("LOAD_MAIN requires GOLD ADB_TABLE outputs.")
            spec["location"] = sql_identifier(target["physical_object_name"], qualified=True)
        else:
            if target["storage_type"] != "PARQUET" or target["layer"] not in ("RAW", "STAGE"):
                raise ValueError("WRITE_PARQUET requires RAW/STAGE Parquet outputs.")
            if target['layer'] == 'RAW' and 'raw_pairs' not in ctx:
                raise ValueError('RAW audit lineage requires paired READ_SOURCE inputs.')
            spec["location"] = framework.output_path(batch, target)
        if target["layer"] in ("STAGE", "GOLD") and (len(plan) < 2 or
                plan[-2][0]["step_type"] != "BUILTIN" or plan[-2][0]["step_code"] != "VALIDATE_DQ"):
            raise ValueError("VALIDATE_DQ must immediately precede the final sink for STAGE/GOLD output.")
        spec["policies"] = framework.db.execute("SELECT * FROM METADATA.POLICY_DEFINITION WHERE config_release_id=:r AND dataset_id=:d AND is_enabled='Y' ORDER BY policy_id",
            r=batch["config_release_id"], d=target["dataset_id"])
        definitions = {c["dataset_column_id"]: c for c in spec["columns"]}
        for policy in spec["policies"]:
            if (policy.get('task_id') is not None or policy['threshold_value'] != '0' or
                    (policy['policy_severity'], policy['failure_action']) not in (('ERROR', 'FAIL_TASK'), ('WARN', 'WARN')) or
                    target['layer'] not in ('STAGE', 'GOLD')):
                raise ValueError('Policies require STAGE/MAIN output scope, threshold 0 and matching FAIL or WARN severity/action.')
            params = _json_object(policy.get('parameter_json'), f"Policy {policy['policy_code']} parameter_json")
            if params.get('check') == 'ROW_COUNT':
                validate_dq_parameters(params)
                source = ctx['inputs'].get(params['source_dataset'])
                if (policy['policy_scope_type'] != 'DATASET' or policy['policy_type'] != 'RECONCILIATION' or
                        policy.get('dataset_column_id') is not None or not source or
                        source['dataset']['layer'] != ('RAW' if target['layer'] == 'STAGE' else 'STAGE')):
                    raise ValueError('ROW_COUNT requires dataset RECONCILIATION scope and an explicit adjacent-layer task input.')
                if target['layer'] == 'STAGE' and len(ctx['inputs']) != 1:
                    raise ValueError('ROW_COUNT supports row-preserving mappings, not joins/multiple input aggregation.')
                if target['layer'] == 'GOLD' and policy['failure_action'] != 'FAIL_TASK':
                    raise ValueError('MAIN ROW_COUNT reconciliation cannot be WARN.')
            else:
                column = definitions.get(policy.get('dataset_column_id'))
                if (not column or policy['policy_scope_type'] != 'DATASET_COLUMN' or policy['policy_type'] != 'DQ' or
                        target['layer'] != 'STAGE'):
                    raise ValueError('Business column DQ belongs to STAGE; MAIN enforces Oracle contracts and insert reconciliation.')
                policy['column_name'] = column['column_name']
                validate_dq_parameters(params, column)
            policy['parameters'] = params
    inputs = {s["location"] for s in ctx["inputs"].values()}
    outputs = [s["location"] for s in ctx["outputs"].values()]
    if len(set(outputs)) != len(outputs) or inputs & set(outputs):
        raise ValueError("Physical output targets must be distinct from each other and all inputs.")
    if sink == "WRITE_PARQUET":
        for index, location in enumerate(outputs):
            for other in outputs[index+1:] + list(inputs):
                if location.startswith(other + "/") or other.startswith(location + "/"):
                    raise ValueError("Parquet output prefixes must not overlap inputs or other outputs.")
    if reader == 'READ_SOURCE' and config.get('quarantine_path'):
        prefix = config['quarantine_path']
        if (not isinstance(prefix, str) or prefix.endswith('/') or
                not object_address(prefix)[2] or any(c.isspace() or c in '*[]{}' for c in prefix)):
            raise ValueError('quarantine_path must be an exact OCI prefix without trailing slash.')
        roots = [s['location'].rsplit('/', 1)[0] for s in ctx['inputs'].values()]
        roots += [s['dataset']['physical_object_name'].rstrip('/') for s in ctx['outputs'].values()]
        if any(prefix == root or prefix.startswith(root + '/') or root.startswith(prefix + '/') for root in roots):
            raise ValueError('Quarantine prefix must not overlap landing or RAW output paths.')
        for code, spec in ctx['inputs'].items():
            destination = (f"{prefix}/batch_{batch['batch_id']}/run_{ctx['run_id']}/"
                           f"{code}/{spec['location'].rsplit('/', 1)[-1]}")
            if len(destination.encode('utf-8')) > 1000:
                raise ValueError('Quarantine location exceeds 1000 bytes.')
            spec['quarantine_location'] = destination
