
import pytest
import yaml
from oci.exceptions import ServiceError

from conftest import ROOT, MemoryOCI
from mdpf_onboarding.onboard import (generate, load_config, object_client, oci_uri,
                                     output_uri, sample_uri, validate_config)


def test_resource_principal_client(monkeypatch):
    import oci
    signer=object();calls=[]
    monkeypatch.setattr(oci.auth.signers,'get_resource_principals_signer',lambda:signer)
    monkeypatch.setattr(oci.object_storage,'ObjectStorageClient',lambda config,**kw:calls.append((config,kw)) or 'client')
    assert object_client()=='client' and calls==[({},dict(signer=signer))]


def test_relative_and_absolute_sample_paths():
    cfg='oci://artifacts@ns/onboarding/loan/config.yaml'
    assert sample_uri(cfg,'samples/input.csv')=='oci://artifacts@ns/onboarding/loan/samples/input.csv'
    assert sample_uri(cfg,'oci://samples@other/input.csv')=='oci://samples@other/input.csv'


@pytest.mark.parametrize('path',['/tmp/input.csv','../input.csv','file:///tmp/input.csv',
                                 'https://example.com/input.csv','samples/*.csv','samples/input.parquet'])
def test_invalid_sample_paths(path):
    with pytest.raises(ValueError):sample_uri('oci://artifacts@ns/onboarding/config.yaml',path)


def test_conditional_upload_preserves_existing_sql(spark,oci_setup):
    config,uri,client,_=oci_setup;client.objects[uri]=yaml.safe_dump(config).encode()
    target=generate(uri,spark=spark,client=client)
    original=client.objects[target]
    with pytest.raises(ServiceError) as error:generate(uri,spark=spark,client=client)
    assert error.value.status==412 and client.objects[target]==original
    assert client.puts[-1][1]['if_none_match']=='*'
    assert client.gets==[uri,uri]  # No existence-check race and no SDK sample download.


def test_explicit_overwrite(spark,oci_setup):
    config,uri,client,_=oci_setup;config['sql_output']['overwrite']=True
    client.objects[uri]=yaml.safe_dump(config).encode();target=output_uri(config)
    client.objects[target]=b'old artifact'
    assert generate(uri,spark=spark,client=client)==target
    assert client.objects[target].startswith(b'-- MDPF SQL Generator 1.0')
    assert 'if_none_match' not in client.puts[-1][1]


def test_invalid_config_stops_before_sample_io(spark,oci_setup,monkeypatch):
    import mdpf_onboarding.onboard as module
    config,uri,client,_=oci_setup;config['pipeline']['template']='ONE_TO_ONE'
    client.objects[uri]=yaml.safe_dump(config).encode()
    monkeypatch.setattr(module,'read_sample',lambda *a:pytest.fail('No sample read expected'))
    with pytest.raises(ValueError):generate(uri,spark=spark,client=client)
    assert not client.puts


@pytest.mark.parametrize('mutate',[
    lambda out:out.update(overwrite='false'),lambda out:out.update(filename='../draft.sql'),
    lambda out:out.update(path='../generated'),lambda out:out.update(path='/generated'),
    lambda out:out.update(filename='draft.txt'),lambda out:out.update(namespace='bad@namespace')])
def test_invalid_output_config(mutate):
    config=yaml.safe_load((ROOT/'examples/one_to_one.yaml').read_text())
    mutate(config['sql_output'])
    with pytest.raises(ValueError):validate_config(config)


def test_no_local_config_fallback():
    client=MemoryOCI()
    with pytest.raises(ValueError):load_config('/tmp/config.yaml',client=client)
    assert not client.gets
