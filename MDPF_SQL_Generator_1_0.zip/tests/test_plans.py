from copy import deepcopy

import pytest
import yaml

from conftest import ROOT,prepare_execution
from mdpf_onboarding.metadata_generator import relationship,resolve_steps,build_metadata
from mdpf_onboarding.onboard import validate_config


@pytest.mark.parametrize('name,shape',[('one_to_one','ONE_TO_ONE'),('many_to_one','MANY_TO_ONE'),('one_to_many','ONE_TO_MANY')])
def test_automatic_relationship_and_three_tasks(models,name,shape):
    model=models[name]
    assert relationship(model['config'])==shape
    assert [t['role'] for t in model['tasks']]==['RAW','STAGE','MAIN']
    assert len(model['tables']['SOURCE_CONFIG'])==1
    assert model['tables']['SOURCE_CONFIG'][0]['expected_input_count']==len(model['config']['inputs'])
    raw=model['tasks'][0];links=[r for r in model['tables']['TASK_DATASET'] if r['task_id']==raw['row']['task_id']]
    assert {r['usage_sequence'] for r in links if r['dataset_role']=='INPUT'}=={r['usage_sequence'] for r in links if r['dataset_role']=='OUTPUT'}


def test_many_to_many_rejected():
    config=yaml.safe_load((ROOT/'examples/many_to_one.yaml').read_text())
    config['outputs'].append(dict(config['outputs'][0],code='SECOND',target_table='SECOND'))
    with pytest.raises(ValueError,match='Multiple inputs'):validate_config(config)


@pytest.mark.parametrize('field,value',[('source_system','OTHER'),('bucket_ref','other'),('landing_key_prefix','landing/other')])
def test_incompatible_combined_source_configs_rejected(field,value):
    config=yaml.safe_load((ROOT/'examples/many_to_one.yaml').read_text())
    config['inputs'][1][field]=value
    with pytest.raises(ValueError,match='Combined RAW'):validate_config(config)


@pytest.mark.parametrize('plan',[
    [],['DIRECT_MAP','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET','DIRECT_MAP','WRITE_PARQUET'],
    ['READ_PARQUET','VALIDATE_DQ','DIRECT_MAP','WRITE_PARQUET'],
    ['READ_PARQUET','READ_PARQUET','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET','WRITE_PARQUET','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET','VALIDATE_DQ','LOAD_MAIN'],
    ['READ_PARQUET','DIRECT_MAP','DIRECT_MAP','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQET','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET',{'code':'CUSTOM','parameters':[]},'VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET',{'code':'DIRECT_MAP','parameters':{'override':True}},'VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET',{'code':'CUSTOM','parameters':{'bad':float('nan')}},'VALIDATE_DQ','WRITE_PARQUET']])
def test_invalid_plans(plan):
    with pytest.raises(ValueError):resolve_steps({'task_steps':plan},'STAGE')


@pytest.mark.parametrize('legacy', [{'custom_steps':[]},{'output_is_typed':True}])
def test_explicit_and_legacy_options_cannot_be_merged(legacy):
    opt=dict(task_steps=['READ_PARQUET','VALIDATE_DQ','WRITE_PARQUET'],**legacy)
    with pytest.raises(ValueError,match='replaces'):resolve_steps(opt,'STAGE')


def test_explicit_order_and_parameters():
    opt={'task_steps':['READ_PARQUET',{'code':'CLEAN','parameters':{'column':'ID'}},'DIRECT_MAP',
                       {'code':'DERIVE'},'VALIDATE_DQ','WRITE_PARQUET']}
    result=resolve_steps(opt,'STAGE')
    assert [code for code,_,_ in result]==['READ_PARQUET','CLEAN','DIRECT_MAP','DERIVE','VALIDATE_DQ','WRITE_PARQUET']
    assert result[1]==('CLEAN','CUSTOM_PYTHON',{'column':'ID'})


def test_legacy_custom_steps_still_supported():
    opt={'custom_steps':[{'code':'CLEAN','parameters':{'column':'ID'}}]}
    assert [code for code,_,_ in resolve_steps(opt,'STAGE',mapping=True)]==[
        'READ_PARQUET','CLEAN','DIRECT_MAP','VALIDATE_DQ','WRITE_PARQUET']


def test_explicit_plan_cannot_hide_required_conversion(models,spark):
    model=models['one_to_one'];config=deepcopy(model['config'])
    config['task_overrides']={'STAGE':{'task_steps':['READ_PARQUET','VALIDATE_DQ','WRITE_PARQUET']}}
    source=spark.read.option('header',True).csv(str(ROOT/'examples/samples/loan_input.csv'))
    target=spark.read.option('header',True).csv(str(ROOT/'examples/samples/loan_output.csv'))
    profiles={'DEMO_LOAN_LOAN_LANDING':(source,model['datasets']['DEMO_LOAN_LOAN_LANDING']['columns']),
              'DEMO_LOAN_LOAN_MAIN':(target,model['datasets']['DEMO_LOAN_LOAN_MAIN']['columns'])}
    with pytest.raises(ValueError,match='types do not match'):build_metadata(config,profiles)
