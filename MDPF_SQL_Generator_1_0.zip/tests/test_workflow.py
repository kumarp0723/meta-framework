from copy import deepcopy
import sqlite3

import pytest
import yaml

from conftest import CatalogDb, ROOT
from test_cleanup import profiles_for
from mdpf_onboarding.metadata_generator import build_metadata, render_sql
from mdpf_onboarding.onboard import generate, main_ddl_uri, output_uri, validate_config


MAIN = 'DEMO_LOAN_LOAN_MAIN'
STAGE = 'DEMO_LOAN_LOAN_STAGE'


@pytest.mark.parametrize('column,override', [
    ('loan_id', {}), ('BATCH_ID', {}), ('LOAN_ID', []),
    ('LOAN_ID', {'nullable': 'N'}), ('LOAN_ID', {'data_type': 'INTEGER'}),
    ('LOAN_ID', {'data_type': None}), ('LOAN_ID', {'is_nullable': True}),
    ('LOAN_ID', {'is_pii': 'YES'}), ('LOAN_ID', {'length_precision_scale': 20}),
    ('LOAN_ID', {'length_precision_scale': ' '}),
    ('LOAN_ID', {'data_type': 'NUMBER', 'length_precision_scale': '2,3'}),
    ('LOAN_ID', {'data_type': 'DATE', 'length_precision_scale': '20'}),
])
def test_bad_override_fails_before_sample_io(oci_setup, monkeypatch, column, override):
    import mdpf_onboarding.onboard as module
    config, uri, client, _ = oci_setup
    config['inference']['column_overrides'] = {MAIN: {column: override}}
    client.objects[uri] = yaml.safe_dump(config).encode()
    monkeypatch.setattr(module, 'read_sample', lambda *args: pytest.fail('Invalid YAML must not read samples'))
    with pytest.raises(ValueError):
        generate(uri, client=client)
    assert not client.puts


@pytest.mark.parametrize('options', [
    {'STAGE': {'task_code': 'DEMO_LOAN_RAW_LOAD'}},
    {'RAW': {'task_code': 'SHARED'}, 'MAIN': {'task_code': 'SHARED'}},
])
def test_duplicate_task_codes_fail_config_preflight(options):
    config = yaml.safe_load((ROOT / 'examples/one_to_one.yaml').read_text())
    config['task_overrides'] = options
    with pytest.raises(ValueError, match='distinct task codes'):
        validate_config(config)


def test_partial_overrides_still_use_sample_inference():
    config = yaml.safe_load((ROOT / 'examples/one_to_one.yaml').read_text())
    partial = {'LOAN_ID': {'is_pii': 'Y'}, 'BALANCE': {'data_type': 'NUMBER'}}
    config['inference']['column_overrides'] = {MAIN: partial}
    assert validate_config(config)['inference']['column_overrides'][MAIN] == partial
    config['inference']['column_overrides'] = {'DEMO_LOAN_LOAN_LANDING': {
        'BALANCE': {'data_type': 'NUMBER', 'length_precision_scale': '18,2'}}}
    with pytest.raises(ValueError, match='preserve VARCHAR2'):
        validate_config(config)


@pytest.mark.parametrize('with_dq', [False, True])
def test_complete_summary_is_printed_before_first_upload(oci_setup, spark, capsys, monkeypatch, with_dq):
    config, uri, client, _ = oci_setup
    config['sql_output']['generate_main_ddl'] = True
    if with_dq:
        config['dq_rules'] = [{'datasets': [STAGE, MAIN], 'column': 'CLIENT_ID', 'check': 'NOT_NULL'}]
    client.objects[uri] = yaml.safe_dump(config).encode()
    put = client.put_object
    snapshots = []

    def inspect_before_put(*args, **kwargs):
        if not client.puts:
            output = capsys.readouterr().out
            snapshots.append(output)
            assert 'Generation summary: DEMO_LOAN, release 1.0, DRAFT, ONE_TO_ONE' in output
            assert f'4 datasets, 20 columns, 3 tasks, 9 steps, {2 if with_dq else 0} DQ rules' in output
            assert 'LOAN_ID VARCHAR2 20 CHAR NOT NULL' in output
            assert 'DEMO_LOAN_STAGE_LOAD: DEMO_LOAN_LOAN_RAW -> '+STAGE in output
            assert 'steps: READ_PARQUET -> DIRECT_MAP -> VALIDATE_DQ -> WRITE_PARQUET' in output
            assert main_ddl_uri(config) in output and output_uri(config) in output
            assert 'Generated ' not in output
            if with_dq:
                assert f'DQ: {STAGE}.CLIENT_ID NOT_NULL -> FAIL_TASK' in output
                assert f'DQ: {MAIN}.CLIENT_ID NOT_NULL -> FAIL_TASK' in output
            else:
                assert '  DQ:' not in output
        return put(*args, **kwargs)

    monkeypatch.setattr(client, 'put_object', inspect_before_put)
    assert generate(uri, spark=spark, client=client) == output_uri(config)
    assert len(snapshots) == 1
    assert 'Generated '+output_uri(config) in capsys.readouterr().out


def test_missing_sample_column_still_blocks_all_publication(oci_setup, spark):
    config, uri, client, _ = oci_setup
    config['inference']['column_overrides'][MAIN]['UNKNOWN'] = {'is_nullable': 'Y'}
    config['sql_output']['generate_main_ddl'] = True
    client.objects[uri] = yaml.safe_dump(config).encode()
    with pytest.raises(ValueError, match='missing CSV columns'):
        generate(uri, spark=spark, client=client)
    assert not client.puts


def test_new_yaml_version_inserts_complete_draft_without_updating_original(models, spark):
    original = models['one_to_one']
    config = deepcopy(original['config'])
    config['pipeline']['release_version'] = '1.1'
    config['dq_rules'] = [{'datasets': [MAIN], 'column': 'CLIENT_ID', 'check': 'NOT_NULL'}]
    regenerated = build_metadata(validate_config(config), profiles_for(original, spark))
    db = CatalogDb()
    try:
        db.deploy(render_sql(original, b'1.0'), release=900)
        db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE' WHERE config_release_id=900")
        before = {table: db.execute(f'SELECT * FROM METADATA.{table} WHERE config_release_id=900')
                  for table in original['tables']}
        db.deploy(render_sql(regenerated, b'1.1'), release=901)
        assert db.one('SELECT release_status FROM METADATA.CONFIG_RELEASE WHERE config_release_id=901')['release_status'] == 'DRAFT'
        for table, rows in regenerated['tables'].items():
            assert db.one(f'SELECT COUNT(*) n FROM METADATA.{table} WHERE config_release_id=901')['n'] == len(rows)
            assert db.execute(f'SELECT * FROM METADATA.{table} WHERE config_release_id=900') == before[table]
        with pytest.raises(sqlite3.IntegrityError):
            db.deploy(render_sql(regenerated, b'1.1'), release=902)
        assert db.one('SELECT COUNT(*) n FROM METADATA.CONFIG_RELEASE')['n'] == 2
    finally:
        db.close()
