from copy import deepcopy
import hashlib
import json

import pytest
import yaml

from conftest import ROOT,prepare_execution
from test_templates import handlers
from mdpf_onboarding.metadata_generator import build_metadata,dataset_codes
from mdpf_onboarding.onboard import generate,load_config,main_ddl_uri,validate_config
from mdpf_onboarding.schema_discovery import read_sample


def profiles_for(model,spark):
    config=model['config'];codes=dataset_codes(config);profiles={}
    for role in ('inputs','outputs'):
        for item,names in zip(config[role],codes[role]):
            code=names['landing' if role=='inputs' else 'main']
            profiles[code]=(read_sample(spark,str(ROOT/'examples'/item['sample_csv'])),model['datasets'][code]['columns'])
    return profiles


def test_shared_loading_preserves_api_and_original_yaml_hash(spark,oci_setup):
    config,uri,client,_=oci_setup;config['sql_output']['generate_main_ddl']=True
    original=('# Original bytes: café\r\n'+yaml.safe_dump(config,sort_keys=False).replace('\n','\r\n')).encode('utf-8')
    client.objects[uri]=original
    loaded=load_config(uri,client=client)
    assert loaded==validate_config(config) and isinstance(loaded,dict)
    target=generate(uri,spark=spark,client=client)
    digest=hashlib.sha256(original).hexdigest().encode()
    assert b'-- YAML SHA256: '+digest in client.objects[target]
    assert b'-- YAML SHA256: '+digest in client.objects[main_ddl_uri(config)]
    assert client.gets==[uri,uri]


@pytest.mark.parametrize('entrypoint',[load_config,generate])
def test_invalid_config_uri_fails_without_auth_or_io(entrypoint,monkeypatch):
    import mdpf_onboarding.onboard as module
    monkeypatch.setattr(module,'object_client',lambda:pytest.fail('No authentication expected for invalid input'))
    with pytest.raises(ValueError):entrypoint('oci://artifacts@ns/config.txt')


@pytest.mark.parametrize('name,role,mapping',[('many_to_one','STAGE',False),('one_to_many','MAIN',True)])
def test_explicit_custom_plans_preserve_conversion_choice(models,spark,name,role,mapping):
    original=models[name];config=deepcopy(original['config'])
    steps=config['task_overrides'][role]['task_steps']
    steps[:]=[s for s in steps if s!='DIRECT_MAP']
    if mapping:steps.insert(-2,'DIRECT_MAP')
    config=validate_config(config)
    regenerated=build_metadata(config,profiles_for(original,spark))
    task=next(t for t in regenerated['tasks'] if t['role']==role)
    expected=[s if isinstance(s,str) else s['code'] for s in steps]
    assert task['steps']==expected
    rows=[r for r in regenerated['tables']['TASK_STEP'] if r['task_id']==task['row']['task_id']]
    assert [r['step_code'] for r in rows]==expected
    assert [r['step_sequence_number'] for r in rows]==list(range(10,10*len(steps)+1,10))
    assert [json.loads(r['parameter_json']) for r in rows]==[
        {} if isinstance(s,str) else s.get('parameters',{}) for s in steps]
    for table in ('DATASET','DATASET_COLUMN','TASK','TASK_DATASET'):
        assert regenerated['tables'][table]==original['tables'][table]


@pytest.mark.parametrize('reverse_outputs',[False,True])
def test_mixed_output_contracts_use_one_consistent_stage_plan(models,spark,tmp_path,reverse_outputs):
    original=models['one_to_many'];config=deepcopy(original['config']);profiles=profiles_for(original,spark)
    source_code=dataset_codes(config)['inputs'][0]['landing']
    source,columns=profiles[source_code]
    first=dataset_codes(config)['outputs'][0]['main']
    # First output matches the whole string input; the other requires projection.
    profiles[first]=(source,[dict(c,length_precision_scale='50 CHAR') for c in columns])
    if reverse_outputs:config['outputs'].reverse()
    model=build_metadata(config,profiles)
    stage=next(task for task in model['tasks'] if task['role']=='STAGE')
    assert stage['steps']==['READ_PARQUET','DIRECT_MAP','VALIDATE_DQ','WRITE_PARQUET']
    fw,db=prepare_execution(model,tmp_path,spark)
    batch=fw.start_batch('mixed-'+str(reverse_outputs),'2026-10-15','MANUAL')['batch_id']
    for task in model['tasks']:fw.execute_task(batch,task['row']['task_code'],custom_steps=handlers())
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='COMPLETED'
    for names in dataset_codes(config)['outputs']:
        target=model['datasets'][names['main']]['row']['physical_object_name']['DEV']
        assert db.one(f'SELECT COUNT(*) n FROM {target}')['n']==2
    db.close()
