from copy import deepcopy
import json

import pytest
import yaml
from pyspark.sql import functions as F

from conftest import prepare_execution
from test_templates import handlers
from mdpf.pipeline import _json_object
from mdpf_onboarding.metadata_generator import build_metadata, dataset_codes
from mdpf_onboarding.onboard import generate, main, main_ddl_uri, output_uri
from mdpf_onboarding.schema_discovery import SchemaOverridesRequired, discover


@pytest.mark.parametrize('value,expected', [
    (None, {}), ('', {}), (' \n ', {}), ({}, {}), ('{}', {}),
    ({'column': 'LOAN_ID'}, {'column': 'LOAN_ID'}),
    ('{"column":"LOAN_ID"}', {'column': 'LOAN_ID'}),
])
def test_metadata_json_accepts_text_objects_and_missing_values(value, expected):
    assert _json_object(value, 'Test parameter_json') == expected


@pytest.mark.parametrize('value', [False, 0, [], ['x'], b'{}', '[]', 'null',
                                  'false', '0', '""', '{broken'])
def test_metadata_json_rejects_invalid_values_without_defaulting(value):
    with pytest.raises(ValueError, match='Test parameter_json'):
        _json_object(value, 'Test parameter_json')


@pytest.mark.parametrize('fail_policy', [False, True])
def test_native_json_step_and_policy_objects_preserve_execution(models, spark, tmp_path, monkeypatch, fail_policy):
    model = models['many_to_one']
    fw, db = prepare_execution(model, tmp_path, spark)
    names = dataset_codes(model['config'])['outputs'][0]
    column = db.one('''SELECT dc.* FROM METADATA.DATASET_COLUMN dc JOIN METADATA.DATASET d
        ON dc.config_release_id=d.config_release_id AND dc.dataset_id=d.dataset_id
        WHERE d.dataset_code=:code AND dc.column_name='LOAN_ID' ''', code=names['stage'])
    db.insert('METADATA.POLICY_DEFINITION', dict(config_release_id=900, policy_id=1,
        policy_code='LOAN_NOT_NULL', policy_name='Loan must exist', policy_type='DQ',
        policy_scope_type='DATASET_COLUMN', dataset_id=column['dataset_id'],
        dataset_column_id=column['dataset_column_id'], policy_severity='ERROR',
        threshold_value='0', parameter_json='{"check":"NOT_NULL"}',
        failure_action='FAIL_TASK', is_enabled='Y'))
    original = db.execute

    def native_json(sql, **params):
        rows = original(sql, **params)
        for row in rows:
            if isinstance(row.get('parameter_json'), str):
                row['parameter_json'] = json.loads(row['parameter_json'])
        return rows

    monkeypatch.setattr(db, 'execute', native_json)
    combine = handlers()['JOIN_CLIENT']

    def join(frames, context, params):
        assert params == {'join_key': 'CLIENT_ID'}
        result = combine(frames, context, params)
        if fail_policy:
            result[names['stage']] = result[names['stage']].withColumn('LOAN_ID', F.lit(None).cast('string'))
        return result

    try:
        batch = fw.start_batch('native-json', '2026-10-15', 'MANUAL')['batch_id']
        fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
        stage = model['tasks'][1]['row']['task_code']
        if fail_policy:
            with pytest.raises(ValueError, match='Blocking policy'):
                fw.execute_task(batch, stage, custom_steps={'JOIN_CLIENT': join})
            assert db.one("SELECT error_code FROM RUNTIME.TASK_RUN WHERE status='FAILED'")['error_code'] == 'POLICY_FAILED'
            assert db.one('SELECT result_status FROM RUNTIME.POLICY_RESULT')['result_status'] == 'FAIL'
            assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 1
            assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        else:
            fw.execute_task(batch, stage, custom_steps={'JOIN_CLIENT': join})
            fw.execute_task(batch, model['tasks'][2]['row']['task_code'])
            assert db.one('SELECT result_status FROM RUNTIME.POLICY_RESULT')['result_status'] == 'PASS'
            assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
    finally:
        db.close()


def test_invalid_step_json_fails_before_data_io(models, spark, tmp_path):
    model = models['one_to_one']
    fw, db = prepare_execution(model, tmp_path, spark)
    try:
        db.execute("UPDATE METADATA.TASK_STEP SET parameter_json='[]' WHERE step_code='READ_SOURCE'")
        batch = fw.start_batch('invalid-json', '2026-10-15', 'MANUAL')['batch_id']
        fw.storage.read_csv = lambda *args: pytest.fail('Invalid step JSON must fail before reads')
        with pytest.raises(ValueError, match='READ_SOURCE parameter_json must be a JSON object'):
            fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
        assert db.one('SELECT COUNT(*) n FROM RUNTIME.INGESTION_ITEM')['n'] == 0
        assert db.one('SELECT status FROM RUNTIME.TASK_RUN')['status'] == 'FAILED'
    finally:
        db.close()


def test_typed_stage_decimal_is_validated_without_reconversion(models, spark):
    config = deepcopy(models['one_to_one']['config'])
    config['inference']['column_overrides'] = {}
    frame = spark.createDataFrame([('0.00000001',)], ['VALUE'])
    source = discover(frame, source=True, overrides={})
    target = discover(frame, source=False, overrides={
        'VALUE': {'data_type': 'NUMBER', 'length_precision_scale': '18,8'}})
    names = dataset_codes(config)
    model = build_metadata(config, {
        names['inputs'][0]['landing']: (frame, source),
        names['outputs'][0]['main']: (frame, target),
    })
    assert model['datasets'][names['outputs'][0]['main']]['columns'][0]['length_precision_scale'] == '18,8'
    assert 'DIRECT_MAP' not in model['tasks'][-1]['steps']


def test_main_validation_still_rejects_oracle_empty_strings(models, spark):
    config = deepcopy(models['one_to_one']['config'])
    source = spark.createDataFrame([('',)], ['VALUE'])
    sample = spark.createDataFrame([('X',)], ['VALUE'])
    names = dataset_codes(config)
    with pytest.raises(ValueError, match='Oracle empty strings'):
        build_metadata(config, {
            names['inputs'][0]['landing']: (source, discover(source, source=True, overrides={})),
            names['outputs'][0]['main']: (sample, discover(sample, source=False, overrides={})),
        })


def test_empty_column_discovery_lists_every_missing_contract(spark):
    frame = spark.createDataFrame([(None, None, None)], 'FIRST string, SECOND string, THIRD string')
    with pytest.raises(SchemaOverridesRequired) as caught:
        discover(frame, source=False, overrides={
            'SECOND': {'data_type': 'VARCHAR2'}, 'THIRD': {'data_type': 'NUMBER'}})
    assert set(caught.value.columns) == {'FIRST', 'SECOND', 'THIRD'}
    assert caught.value.columns['SECOND']['data_type'] == 'VARCHAR2'
    assert caught.value.columns['THIRD']['data_type'] == 'NUMBER'


def test_generation_reports_all_outputs_without_publishing(spark, tmp_path, oci_setup, capsys):
    config, uri, client, samples = oci_setup
    config['outputs'].append(dict(config['outputs'][0], code='OTHER', target_table='OTHER', sample_csv='samples/other.csv'))
    config['task_overrides'] = {'MAIN': {'task_steps': [
        'READ_PARQUET', {'code': 'ROUTE_MAIN'}, 'VALIDATE_DQ', 'LOAD_MAIN']}}
    config['inference']['column_overrides'] = {}
    config['sql_output'].update(generate_main_ddl=True, overwrite=True)
    first = tmp_path / 'first.csv'
    second = tmp_path / 'second.csv'
    first.write_text('LOAN_ID,EMPTY_A,EMPTY_B\n0001,,\n')
    second.write_text('LOAN_ID,EMPTY_C\n0001,\n')
    samples[next(p for p in samples if 'loan_output' in p)] = first
    samples[uri.rsplit('/', 1)[0] + '/samples/other.csv'] = second
    client.objects[uri] = yaml.safe_dump(config).encode()
    client.objects[output_uri(config)] = b'previous metadata'
    client.objects[main_ddl_uri(config)] = b'previous ddl'
    assert generate(uri, spark=spark, client=client) is None
    out = capsys.readouterr().out
    assert 'no SQL or DDL was uploaded' in out
    overrides = yaml.safe_load('inference:' + out.split('\ninference:', 1)[1])['inference']['column_overrides']
    assert set(overrides['DEMO_LOAN_LOAN_MAIN']) == {'EMPTY_A', 'EMPTY_B'}
    assert set(overrides['DEMO_LOAN_OTHER_MAIN']) == {'EMPTY_C'}
    assert client.objects[output_uri(config)] == b'previous metadata'
    assert client.objects[main_ddl_uri(config)] == b'previous ddl'
    assert client.puts == []


def test_generation_resumes_after_empty_column_overrides(spark, tmp_path, oci_setup, capsys):
    config, uri, client, samples = oci_setup
    sample = tmp_path / 'nullable.csv'
    sample.write_text('LOAN_ID,AMOUNT,WHEN_DATE,COMMENT\n0001,,,\n')
    for path in samples:
        samples[path] = sample
    config['inference']['column_overrides'] = {}
    config['sql_output']['generate_main_ddl'] = True
    client.objects[uri] = yaml.safe_dump(config).encode()
    assert generate(uri, spark=spark, client=client) is None
    assert not client.puts
    config['inference']['column_overrides'] = {'DEMO_LOAN_LOAN_MAIN': {
        'AMOUNT': {'data_type': 'NUMBER', 'length_precision_scale': '18,2'},
        'WHEN_DATE': {'data_type': 'DATE'},
        'COMMENT': {'data_type': 'VARCHAR2', 'length_precision_scale': '50 CHAR'},
    }}
    client.objects[uri] = yaml.safe_dump(config).encode()
    assert generate(uri, spark=spark, client=client) == output_uri(config)
    assert {uri for uri, _ in client.puts} == {output_uri(config), main_ddl_uri(config)}
    assert b'<VARCHAR2' not in client.objects[output_uri(config)]


def test_cli_missing_overrides_is_a_clean_action_required_result(monkeypatch, capsys):
    import mdpf_onboarding.onboard as onboard
    monkeypatch.setattr(onboard, 'generate', lambda *args: None)
    assert main(['--config', 'oci://artifacts@ns/config.yaml']) == 2
    assert 'Traceback' not in capsys.readouterr().err
