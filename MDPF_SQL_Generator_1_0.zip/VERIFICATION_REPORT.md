# MDPF SQL Generator 1.0 verification

Verified 2026-10-17 UTC: **243 tests passed in 121.92 seconds; no skips**.
Focused plan/configuration checks: **68 passed in 39.66 seconds**.
Python 3.12, Spark 3.5.7, Java 17, pytest 8.3.5 and OCI SDK 2.161.1.

## Changes in this build

- Removed YAML custom_steps/output_is_typed support and the legacy merge/typing
  branches. Task options are task_code and optional task_steps only.
- Missing task_steps generates standard RAW/STAGE/MAIN plans. Default STAGE
  conversion remains schema-driven. Explicit plans preserve their exact sequence,
  including whether DIRECT_MAP is present; custom parameters remain unchanged.
- Kept one plan parser and existing validation. No replacement setting or new
  abstraction was added; generator code is 14 lines shorter.
- Shipped YAMLs already use supported defaults/task_steps. The README explains
  converting older YAML before upgrading. Notebook custom_steps registries and
  CUSTOM_PYTHON support remain unchanged. Software remains version **1.0**.

## Test evidence

The 243-test suite replaces legacy-compatibility tests with rejection, default-plan
and exact-plan checks. Both removed YAML keys fail before sample I/O/uploads,
with or without task_steps. Explicit custom plans can omit conversion for typed
output or include DIRECT_MAP without automatic augmentation.

Actual framework execution verifies missing/non-callable custom handlers and
BUILTIN override attempts fail before data reads, retain failure history and
populate WORK_QUEUE. Registered custom handlers still execute the example flows.

Strict override/reference validation, pre-upload summaries and complete DRAFT
release regeneration remain covered. Earlier ACTIVE releases remain unchanged;
duplicate release versions fail transactionally in the test catalog.

All three pipeline relationships, optional MAIN DDL, actual sample conversion,
empty-column guidance, JSON text/object handling, DQ failure/Repair, immutable
attempt/error history, pinned metadata, MAIN rollback, OCI overwrite protection
and grouped/compact INSERTs remain covered.

Generated SQL executes in a CI SQLite catalog using translated metadata
constraints. Spark transformations use real Spark; OCI and database access use
test adapters. These tests do not execute Oracle PL/SQL, grants or triggers,
prove Oracle transaction/concurrency behavior, or exercise live cloud services.

## Package and deployment

The rebuilt **1.0** wheel matches all four source modules. Compilation, wheel
RECORD hashes, ZIP integrity and file manifests pass. Source tests are included;
caches, old builds, dependencies and temporary files are excluded.

SQL rendering functions, SQL/DDL previews and example YAMLs are unchanged. The
companion framework code/wheel and 17-table / 232-column Oracle DDL are unchanged.
Credential handling is unchanged. No new module, table or runtime feature was added.

- Generator wheel SHA256: `022f3378bf76a538674f71dd1c55f5ba563f11dde7ab313f9af9b24803c73c71`
- Companion MDPF wheel SHA256: `f05c1a48fecf39a277735e018b61b5b81322480d520766181c8c42f3cbad8f7c`

Generation neither contacts Oracle nor automatically increments release versions.
Metadata remains DRAFT until reviewed/approved/activated. Real Oracle deployment
and the AIDP/OCI success, failure and Repair demonstration remain outstanding.

Before installing this wheel, migrate external YAMLs using the removed options
to complete task_steps sequences. Existing published Oracle metadata is unaffected.
