# MDPF SQL Generator 1.0 verification

Documentation refresh: the README now follows onboarding through generation,
deployment and verification, with concise troubleshooting and module descriptions.
Source, wheel, SQL, samples and tests are unchanged. Documentation examples/paths
and package manifests were checked; the existing 162-test result below was not
rerun for this documentation-only update.

Verified 2026-10-16 UTC: **162 tests passed in 563.35 seconds; no skips**.
Python 3.12, real Spark 3.5.7, Java 17, pytest 8.3.5 and OCI SDK 2.161.1.

## Cleanup scope

Only onboard.py and metadata_generator.py change in the generator implementation.

- load_config() and generate() share one OCI YAML read/decode/validation path. The public
  return values remain a configuration dictionary and metadata SQL URI, respectively.
  Original YAML bytes, including comments, Unicode and line endings, remain the source
  of metadata/DDL hashes. A call still reads YAML once; no extra download is introduced.
- Early configuration validation reuses its custom-handler findings for required-role
  checks. Metadata construction resolves each role once, then reuses plans for handler
  classification, task rows and warnings. Schema-driven DIRECT_MAP decisions finalize
  defaults without altering explicit task_steps.
- No persistent plan cache, new class/module, configuration option or dependency is added.
  Legacy custom_steps/output_is_typed and the notebook function registry remain supported.
  Framework runtime, DDL, wheel and notebooks are byte-identical to the upload.

## Before/after output equivalence

A separate comparison against the actual uploaded implementation verified identical
metadata SQL, MAIN DDL, task definitions and warnings for **11 configurations**:

| Generation case | Previous build plan resolutions | Cleaned build |
|---|---:|---:|
| ONE_TO_ONE | 7 | 3 |
| MANY_TO_ONE | 7 | 3 |
| ONE_TO_MANY | 9 | 3 |

The remaining comparisons cover legacy plans with both typed settings, a RAW custom
reference, mixed output contracts in both orders, and matching-string schemas without
mapping. Configuration dictionaries are not mutated. The shipped metadata_draft.sql and
main_ddl.sql remain byte-identical; no sample or YAML changes were needed. Baseline source
copies and the one-off comparison harness are excluded from both deliverables.

These counts describe metadata construction only, not a Spark runtime speedup.

## Regression evidence

All previous 155 tests remain passing, plus seven functional regressions covering:
shared loading/public API shape, original-byte hashing, URI rejection before authentication,
legacy/explicit plan equivalence, and complete flows with mixed output contracts in both
orders. Actual framework execution still covers the three supported relationships,
combined RAW pairing, partial RAW failure/Repair, stable receipts, pinned metadata,
immutable failed attempts, retained OPEN errors, MAIN routing and multi-target rollback.

Schema conversion, metadata PK/FKs, SQL escaping/environment selection, OCI overwrite
protection, custom-plan validation and the read-only Oracle compatibility gate remain
covered. Optional generate_main_ddl defaults false. True still creates a separate review-only
artifact with the same MAIN schema and three lineage columns. Independent uploads retain
their existing error behavior and overwrite protection; no DDL is executed by generation.

## Package integrity

Both software versions and distribution metadata remain **1.0**. The rebuilt generator
wheel matches all four source modules; the framework's original matching wheel is retained.
The generator still has three implementation modules plus an initializer. Oracle framework
DDL remains **17 tables / 232 columns**. Source/notebook compilation and final manifests
pass. Old wheels, caches, build trees and baseline/comparison copies are excluded.

- MDPF wheel SHA256: `8777a56580700803cd4ba80bc1fd1c4f52c9cab81be2f9f0cfc7405e96bf7bd7`
- Generator wheel SHA256: `807aed66abdb80faf8618c1ca372fc1024e559126f6f505b70ed683359bcb758`

## Environment validation remains outstanding

No real Oracle database, OCI bucket or AIDP job was contacted. Spark transformations and
Parquet I/O are real; OCI URIs and SDK calls use CI doubles, and Oracle runtime/catalog
checks use SQLite/fixtures. These do not prove Oracle PL/SQL syntax, grants, transactions,
implicit commits, concurrency or Resource Principal/Spark connector access. A CI-only
launcher workaround for missing /dev/fd is not shipped.

Run the reviewed MAIN DDL manually only for new targets, provision owners/runtime grants,
deploy metadata DRAFT and run verify_main_targets before activation. The sample DDL retains
its conservative STANDARD/AL32UTF8 limit (4000 BYTE or 1000 CHAR); wider contracts need
separately reviewed DDL. Oracle DDL commits independently. Confirm AIDP success/failure/Repair
and stable job.run_id in the actual environment. Keep active-run wheel/notebooks unchanged.
