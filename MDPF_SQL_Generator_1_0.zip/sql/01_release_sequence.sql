-- One-time DBA prerequisite. Run only after checking the existing sequence/publishers.
-- Run in a maintenance window with metadata publishers paused.
-- MAX is used ONCE to bootstrap a real sequence, never for per-release allocation.
SET DEFINE OFF
SET SERVEROUTPUT ON
WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK
DECLARE
  v_exists NUMBER;
  v_start NUMBER;
BEGIN
  SELECT COUNT(*) INTO v_exists FROM ALL_SEQUENCES
    WHERE sequence_owner='METADATA' AND sequence_name='SEQ_CONFIG_RELEASE';
  IF v_exists<>0 THEN
    RAISE_APPLICATION_ERROR(-20002,'SEQ_CONFIG_RELEASE already exists; DBA must verify its range, not recreate/reset it');
  END IF;
  SELECT NVL(MAX(config_release_id),0)+1 INTO v_start FROM METADATA.CONFIG_RELEASE;
  EXECUTE IMMEDIATE 'CREATE SEQUENCE METADATA.SEQ_CONFIG_RELEASE START WITH ' ||
    TO_CHAR(v_start,'FM99999999999999999999') || ' INCREMENT BY 1 MAXVALUE 9999999999999999999 NOCYCLE CACHE 20';
  DBMS_OUTPUT.PUT_LINE('Created sequence starting at ' || v_start);
END;
/
-- DBA: grant SELECT on METADATA.SEQ_CONFIG_RELEASE to the deployment login.
-- All release publishers must use this sequence; do not mix future hardcoded IDs.
