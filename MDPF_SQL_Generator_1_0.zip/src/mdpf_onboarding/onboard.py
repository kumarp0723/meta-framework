"""OCI YAML input, Spark samples, metadata SQL and optional MAIN DDL."""
import argparse
from copy import deepcopy
import re
import sys

import yaml
from pyspark.sql import SparkSession

from .schema_discovery import discover, read_sample
from mdpf.storage import object_address
from .metadata_generator import (build_metadata, dataset_codes, physical_locations,
                                 relationship, render_main_ddl, render_sql, resolve_steps)


class UniqueLoader(yaml.SafeLoader):
    pass


def _mapping(loader, node):
    result = {}
    for key, value in node.value:
        name = loader.construct_object(key, deep=True)
        if not isinstance(name, str) or name in result:
            raise ValueError(f'YAML keys must be unique strings: {name!r}')
        result[name] = loader.construct_object(value, deep=True)
    return result


UniqueLoader.add_constructor(yaml.resolver.BaseResolver.DEFAULT_MAPPING_TAG, _mapping)


def keys(obj, required, optional, label):
    if not isinstance(obj, dict) or set(required)-set(obj) or set(obj)-set(required)-set(optional):
        raise ValueError(f'{label}: required keys {sorted(required)}; optional keys {sorted(optional)}.')


def text(value, label, limit):
    if not isinstance(value, str) or not value.strip() or len(value.encode('utf-8')) > limit or any(ord(c)<32 for c in value):
        raise ValueError(f'{label} must be nonempty text, at most {limit} UTF-8 bytes, without control characters.')
    return value


def validate_config(config):
    """Validate this utility's fixed input format; unknown keys fail instead of being ignored."""
    from mdpf.schema import sql_identifier
    c = deepcopy(config)
    keys(c, {'pipeline','inputs','outputs','storage','environments','sql_output'}, {'inference','task_overrides','created_by'}, 'config')
    keys(c['pipeline'], {'code','name','release_version'}, set(), 'pipeline')
    for field, length in [('code',100),('name',200),('release_version',50)]:
        text(c['pipeline'][field], 'pipeline.'+field, length)
    sql_identifier(c['pipeline']['code'])
    for role in ('inputs','outputs'):
        if not isinstance(c[role], list) or not c[role]:
            raise ValueError(f'{role} must be a nonempty list.')
        seen = set()
        for item in c[role]:
            required = {'code','sample_csv'} | ({'source_system','landing_key_prefix','file_name'} if role=='inputs' else {'target_table'})
            optional = {'bucket_ref'} if role=='inputs' else set()
            keys(item, required, optional, role)
            sql_identifier(text(item['code'], role+'.code', 100))
            if item['code'] in seen:
                raise ValueError(f'Duplicate {role} code: {item["code"]}')
            seen.add(item['code'])
            text(item['sample_csv'], 'sample_csv', 2000)
            if role=='inputs':
                text(item['source_system'], 'source_system', 200)
                item.setdefault('bucket_ref','landing')
                text(item['bucket_ref'], 'bucket_ref', 100)
            else:
                sql_identifier(item['target_table'])
    shape = relationship(c)
    roots = {(i['source_system'],i['bucket_ref'],i['landing_key_prefix']) for i in c['inputs']}
    if len(roots) != 1:
        raise ValueError('Combined RAW requires one source_system, landing bucket reference and landing_key_prefix.')
    keys(c['storage'], {'raw_key_prefix','stage_key_prefix'}, set(), 'storage')
    keys(c['environments'], {'DEV','STAGE','PROD'}, set(), 'environments')
    for name, env in c['environments'].items():
        keys(env, {'namespace','buckets','oracle_main_owner'}, set(), name)
        sql_identifier(env['oracle_main_owner'])
        if not isinstance(env['buckets'], dict) or not {'landing','raw','stage'} <= set(env['buckets']):
            raise ValueError(f'{name} requires landing/raw/stage bucket references.')
    inf = c.setdefault('inference', {})
    keys(inf, set(), {'varchar_growth_percent','default_nullable','column_overrides'}, 'inference')
    growth = inf.setdefault('varchar_growth_percent',25)
    if isinstance(growth,bool) or not isinstance(growth,(int,float)) or not 0<=growth<=1000:
        raise ValueError('varchar_growth_percent must be between 0 and 1000.')
    if inf.setdefault('default_nullable','Y') not in ('Y','N'):
        raise ValueError('default_nullable must be Y or N.')
    overrides = inf.setdefault('column_overrides',{})
    if not isinstance(overrides,dict) or any(not isinstance(v,dict) for v in overrides.values()):
        raise ValueError('column_overrides must map LANDING/MAIN dataset codes to column overrides.')
    codes = dataset_codes(c)
    allowed = {p['landing'] for p in codes['inputs']} | {p['main'] for p in codes['outputs']}
    if set(overrides)-allowed:
        raise ValueError('Use LANDING/MAIN dataset codes for overrides; paired RAW/STAGE schemas are copied automatically.')
    c.setdefault('created_by','MDPF_ONBOARD')
    text(c['created_by'],'created_by',100)
    roles = {'RAW','STAGE','MAIN'}
    task_options = c.setdefault('task_overrides',{})
    if not isinstance(task_options,dict) or set(task_options)-roles:
        raise ValueError('task_overrides keys must be RAW, STAGE or MAIN.')
    custom_roles=set()
    for role, opt in task_options.items():
        keys(opt,set(),{'task_code','task_steps','custom_steps','output_is_typed'},role)
        if 'task_code' in opt:
            sql_identifier(text(opt['task_code'],'task_code',100))
        if not isinstance(opt.get('output_is_typed',False),bool):
            raise ValueError('output_is_typed must be boolean.')
        plan=resolve_steps(opt,role)
        if any(kind=='CUSTOM_PYTHON' for _,kind,_ in plan):
            custom_roles.add(role)
    required_role = 'STAGE' if shape=='MANY_TO_ONE' else 'MAIN' if shape=='ONE_TO_MANY' else None
    if required_role and required_role not in custom_roles:
        raise ValueError(f'{shape} requires declared {required_role} custom steps for explicit frame combination/routing.')
    physical_locations(c,codes)  # Validate every environment before reading samples.
    output_uri(c)
    return c


def oci_uri(value):
    """Exact object URI only; samples and artifacts never use local path fallback."""
    text(value,'OCI URI',2000)
    namespace,bucket,key=object_address(value)
    if (not key or not all(re.fullmatch(r'[A-Za-z0-9_.-]+',s) for s in (namespace,bucket)) or
            any(c.isspace() or c in '*[]{}\\' for c in key) or
            any(p in ('','.','..') for p in key.split('/'))):
        raise ValueError('Use an exact oci://bucket@namespace/object-key without wildcards or path traversal.')
    return value


def sample_uri(config_uri, value):
    if '://' in value:
        result=value
    else:
        if value.startswith('/'):
            raise ValueError('Sample paths must be relative to the OCI YAML, or full OCI URIs.')
        result=config_uri.rsplit('/',1)[0]+'/'+value
    result=oci_uri(result)
    if not result.lower().endswith('.csv'):
        raise ValueError('Sample must reference one exact OCI .csv file.')
    return result


def output_uri(config):
    out=config['sql_output']
    keys(out,{'namespace','bucket','path','filename'},{'overwrite','generate_main_ddl'},'sql_output')
    if not isinstance(out.setdefault('overwrite',False),bool):
        raise ValueError('sql_output.overwrite must be boolean.')
    if not isinstance(out.setdefault('generate_main_ddl',False),bool):
        raise ValueError('sql_output.generate_main_ddl must be boolean.')
    for name in ('namespace','bucket','path','filename'):
        text(out[name],'sql_output.'+name,1000)
    if out['path'] != out['path'].strip('/'):
        raise ValueError('sql_output.path must not have surrounding slashes.')
    if '/' in out['filename'] or not out['filename'].lower().endswith('.sql'):
        raise ValueError('sql_output.filename must be a .sql filename without directories.')
    return oci_uri(f"oci://{out['bucket']}@{out['namespace']}/{out['path']}/{out['filename']}")


def main_ddl_uri(config):
    prefix,filename=output_uri(config).rsplit('/',1)
    stem=re.sub(r'_metadata(?:_draft)?$','',filename[:-4])
    return oci_uri(prefix+'/'+stem+'_main_ddl.sql')


def object_client():
    import oci
    return oci.object_storage.ObjectStorageClient({},signer=oci.auth.signers.get_resource_principals_signer())


def _load_config(uri, client):
    """One YAML read/validation path; retain original bytes and client for generation."""
    uri=oci_uri(uri)
    if not uri.lower().endswith(('.yaml','.yml')):
        raise ValueError('Config must be an OCI .yaml or .yml object.')
    namespace,bucket,key=object_address(uri)
    client=client or object_client()
    data=client.get_object(namespace,bucket,key).data.content
    return validate_config(yaml.load(data.decode('utf-8'),Loader=UniqueLoader)),data,client


def load_config(uri, *, client=None):
    return _load_config(uri,client)[0]


def generate(config_uri, *, spark=None, client=None):
    """Notebook/CLI API. Requires the existing MDPF wheel; never connects to Oracle."""
    config,config_bytes,client=_load_config(config_uri,client)
    sql_uri=output_uri(config)
    sample_paths={i['sample_csv']:sample_uri(config_uri,i['sample_csv']) for i in config['inputs']+config['outputs']}
    if sql_uri==config_uri or sql_uri in sample_paths.values():
        raise ValueError('SQL output must be separate from YAML and sample objects.')
    existing = spark or SparkSession.getActiveSession()
    session = existing or SparkSession.builder.appName('MDPF metadata onboarding').getOrCreate()
    profiles, codes = {}, dataset_codes(config)
    try:
        for role in ('inputs','outputs'):
            for item, names in zip(config[role], codes[role]):
                path = sample_paths[item['sample_csv']]
                code = names['landing' if role=='inputs' else 'main']
                df = read_sample(session,path)
                columns = discover(df,source=role=='inputs',
                    overrides=config['inference']['column_overrides'].get(code,{}),
                    growth=config['inference']['varchar_growth_percent'], nullable=config['inference']['default_nullable'])
                profiles[code] = (df, columns)
        model = build_metadata(config,profiles)
        sql = render_sql(model,config_bytes)
        artifacts=[]
        if config['sql_output']['generate_main_ddl']:
            artifacts.append((main_ddl_uri(config),render_main_ddl(model,config_bytes)))
        artifacts.append((sql_uri,sql))
        # Build both scripts before publication. Upload metadata last; uploads are independent.
        condition={} if config['sql_output']['overwrite'] else {'if_none_match':'*'}
        for uri,content in artifacts:
            namespace,bucket,key=object_address(uri)
            client.put_object(namespace,bucket,key,content.encode('utf-8'),content_type='application/sql',**condition)
            if uri!=sql_uri:
                print(f'Generated {uri}: MAIN DDL for manual review; no DDL has been executed.')
        print(f'Generated {sql_uri}: {relationship(config)}, three tasks, DRAFT only; Oracle has not been contacted.')
        for table, rows in model['tables'].items():print(f'  METADATA.{table}: {len(rows)} rows')
        for code, definition in model['datasets'].items():
            print(code+': '+', '.join(c['column_name']+' '+c['data_type']+' '+str(c['length_precision_scale'] or '') for c in definition['columns']))
        for task in model['tasks']:
            print(task['row']['task_code']+': '+', '.join(task['inputs'])+' -> '+', '.join(task['outputs']))
            print('  steps: '+', '.join(task['steps']))
        for warning in model['warnings']:print('NOTE: '+warning)
        return sql_uri
    finally:
        if existing is None:session.stop()


def main(argv=None):
    parser=argparse.ArgumentParser(description='Generate DRAFT metadata SQL and optional MAIN table DDL.')
    parser.add_argument('--config',required=True)
    args=parser.parse_args(argv)
    try:
        generate(args.config)
        return 0
    except Exception as exc:
        print(f'ERROR: {exc}',file=sys.stderr)
        return 1


if __name__=='__main__':
    raise SystemExit(main())
