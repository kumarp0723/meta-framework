"""Three-task metadata, release-local IDs and Oracle SQL rendering."""
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import re

from mdpf import schema as mdpf_schema
from mdpf.schema import sql_identifier, spark_type
from mdpf.storage import object_address

from . import __version__
from .schema_discovery import validate_conversion

ID_COLUMNS = dict(SOURCE_CONFIG='source_config_id', DATASET='dataset_id',
    DATASET_COLUMN='dataset_column_id', TASK='task_id', TASK_DATASET='task_dataset_id',
    TASK_STEP='task_step_id', POLICY_DEFINITION='policy_id')
TABLES = ('CONFIG_RELEASE', *ID_COLUMNS)


def relationship(config):
    inputs, outputs = len(config['inputs']), len(config['outputs'])
    if inputs > 1 and outputs > 1:
        raise ValueError('Multiple inputs and multiple outputs are not supported in this POC.')
    return 'MANY_TO_ONE' if inputs > 1 else 'ONE_TO_MANY' if outputs > 1 else 'ONE_TO_ONE'


def resolve_steps(options, role, *, mapping=False):
    """Use the complete supplied recipe, or generate the standard built-in plan."""
    from mdpf.steps import BUILTINS
    if not isinstance(options, dict) or set(options)-{'task_code', 'task_steps'}:
        raise ValueError(f'{role}: only task_code and optional task_steps are supported; '
                         'replace YAML custom_steps/output_is_typed with a complete task_steps sequence.')
    reader = 'READ_SOURCE' if role == 'RAW' else 'READ_PARQUET'
    sink = 'LOAD_MAIN' if role == 'MAIN' else 'WRITE_PARQUET'
    defaults = [reader] + (['DIRECT_MAP'] if mapping else []) + (['VALIDATE_DQ'] if role != 'RAW' else []) + [sink]
    entries = options.get('task_steps', defaults)
    if not isinstance(entries, list) or not entries:
        raise ValueError('task_steps must be a nonempty list when provided.')
    resolved = []
    for entry in entries:
        if isinstance(entry, str):
            if entry not in BUILTINS:
                raise ValueError('Use exact BUILTIN names; declare a custom step with {code: NAME, parameters: {}}.')
            code, params = entry, {}
        elif isinstance(entry, dict) and 'code' in entry and not set(entry)-{'code','parameters'}:
            code, params = entry['code'], entry.get('parameters', {})
        else:
            raise ValueError('A step must be a BUILTIN name or a code/parameters mapping.')
        identifier(code)
        kind = 'BUILTIN' if code in BUILTINS else 'CUSTOM_PYTHON'
        if not isinstance(params, dict) or (kind == 'BUILTIN' and params):
            raise ValueError('Custom parameters must be a JSON object; BUILTIN parameters must be empty.')
        json.dumps(params, allow_nan=False)
        resolved.append((code, kind, params))
    codes = [code for code, _, _ in resolved]
    if len(set(codes)) != len(codes):
        raise ValueError('Step codes must be unique within a task.')
    if (codes[0] != reader or codes[-1] != sink or
            any(c in {'READ_SOURCE','READ_PARQUET','WRITE_PARQUET','LOAD_MAIN'} for c in codes[1:-1])):
        raise ValueError(f'{role} requires {reader} first and {sink} as its only final sink.')
    if role != 'RAW' and (len(codes) < 3 or codes[-2] != 'VALIDATE_DQ'):
        raise ValueError('VALIDATE_DQ must immediately precede the STAGE/MAIN sink.')
    return resolved


def identifier(value, limit=100):
    sql_identifier(value)
    if len(value.encode('utf-8'))>limit:
        raise ValueError(f'Generated identifier exceeds {limit} bytes: {value}')
    return value


def dataset_codes(config):
    p = config['pipeline']['code']
    return dict(inputs=[dict(landing=identifier(f"{p}_{i['code']}_LANDING"),raw=identifier(f"{p}_{i['code']}_RAW")) for i in config['inputs']],
        outputs=[dict(stage=identifier(f"{p}_{o['code']}_STAGE"),main=identifier(f"{p}_{o['code']}_MAIN")) for o in config['outputs']])


def physical_locations(config, codes):
    def key(value, *, filename=False):
        if not isinstance(value,str) or not value or value!=value.strip('/') or any(c.isspace() for c in value):
            raise ValueError('Object keys must be nonempty, without surrounding slashes or whitespace.')
        test=value.replace('{YYYYMMDD}','20000101') if filename else value
        if any(c in test for c in '*[]{}?#') or any(x in ('','.','..') for x in test.split('/')):
            raise ValueError('Unsupported object key or token; only source {YYYYMMDD} is allowed.')
        if filename and ('/' in value or len(value.encode('utf-8'))>500 or not test.lower().endswith('.csv')):
            raise ValueError('file_name must be an exact .csv filename/template, without directories.')
        return value
    def uri(env,bucket_ref,path):
        namespace, bucket = env['namespace'], env['buckets'].get(bucket_ref)
        if any(not isinstance(v,str) or not re.fullmatch(r'[A-Za-z0-9_.-]+',v) for v in (namespace,bucket)):
            raise ValueError('Invalid namespace, bucket name, or missing bucket reference.')
        result=f'oci://{bucket}@{namespace}/{path}'
        object_address(result)
        if len(result.encode('utf-8'))>1000:
            raise ValueError('OCI location exceeds the metadata 1000-byte field.')
        return result
    locations={}
    for name, env in config['environments'].items():
        loc={}
        for i,names in zip(config['inputs'],codes['inputs']):
            prefix=key(i['landing_key_prefix']);filename=key(i['file_name'],filename=True)
            loc['SOURCE:'+i['code']]=uri(env,i['bucket_ref'],prefix)
            loc[names['landing']]=uri(env,i['bucket_ref'],prefix+'/'+filename)
            loc[names['raw']]=uri(env,'raw',key(config['storage']['raw_key_prefix'])+'/'+i['code'].lower())
        for o,names in zip(config['outputs'],codes['outputs']):
            loc[names['stage']]=uri(env,'stage',key(config['storage']['stage_key_prefix'])+'/'+o['code'].lower())
            loc[names['main']]=sql_identifier(env['oracle_main_owner']+'.'+o['target_table'],qualified=True)
        outputs=[loc[n['raw']] for n in codes['inputs']]+[loc[n['stage']] for n in codes['outputs']]
        landings=[loc[n['landing']].replace('{YYYYMMDD}','20000101') for n in codes['inputs']]
        if len(set(landings))!=len(landings):
            raise ValueError(f'{name}: duplicate landing delivery URI.')
        for j,path in enumerate(outputs):
            for other in outputs[j+1:]+landings:
                if path==other or path.startswith(other+'/') or other.startswith(path+'/'):
                    raise ValueError(f'{name}: overlapping data locations: {path}, {other}')
        targets=[loc[n['main']] for n in codes['outputs']]
        if len(set(targets))!=len(targets):
            raise ValueError(f'{name}: Oracle outputs must use distinct target tables.')
        locations[name]=loc
    return locations


def needs_map(source, target):
    a={c['column_name']:spark_type(c) for c in source}
    b={c['column_name']:spark_type(c) for c in target}
    return a!=b


def build_metadata(config, profiles):
    """Profiles are supplied by discovery. Custom implementations are never imported/executed."""
    codes=dataset_codes(config);locations=physical_locations(config,codes)
    options={role:config['task_overrides'].get(role,{}) for role in ('RAW','STAGE','MAIN')}
    plans={role:resolve_steps(opt,role) for role,opt in options.items()}
    custom={role:any(kind=='CUSTOM_PYTHON' for _,kind,_ in plan) for role,plan in plans.items()}
    rows={table:[] for table in TABLES};registry={table:{} for table in ID_COLUMNS}
    datasets, tasks, warnings = {}, [], []
    def add(table, logical, **values):
        if logical in registry[table]:raise ValueError(f'Duplicate {table} identity: {logical}')
        number=len(rows[table])+1
        registry[table][logical]=number
        row={ID_COLUMNS[table]:number,**values};rows[table].append(row)
        return row
    def location(logical):return {env:values[logical] for env,values in locations.items()}
    def dataset(code, columns, layer, storage, source_object=None):
        row=add('DATASET',code,dataset_code=code,dataset_name=code,source_object_code=source_object,
                physical_object_name=location(code),layer=layer,storage_type=storage)
        datasets[code]=dict(row=row,columns=deepcopy(columns))
        for column in columns:
            add('DATASET_COLUMN',code+':'+column['column_name'],dataset_id=row['dataset_id'],**column)
    rows['CONFIG_RELEASE'].append(dict(pipeline_code=config['pipeline']['code'],pipeline_name=config['pipeline']['name'],
        release_version=config['pipeline']['release_version'],release_desc='Generated by MDPF SQL Generator '+__version__,
        release_status='DRAFT',created_by=config['created_by']))
    first = config['inputs'][0]
    source_config = add('SOURCE_CONFIG','RAW',source_system_name=first['source_system'],source_type='FILE',
        ingestion_mode='SINGLE_FILE',landing_path=location('SOURCE:'+first['code']),
        file_pattern=first['file_name'] if len(config['inputs']) == 1 else None,
        expected_input_count=len(config['inputs']))
    for item,names in zip(config['inputs'],codes['inputs']):
        columns=profiles[names['landing']][1]
        dataset(names['landing'],columns,'RAW','CSV',item['code'])
        dataset(names['raw'],columns,'RAW','PARQUET')
    for names in codes['outputs']:
        columns=profiles[names['main']][1]
        dataset(names['stage'],columns,'STAGE','PARQUET')
        dataset(names['main'],columns,'GOLD','ADB_TABLE')
    p=config['pipeline']['code']
    def task(role,inputs,outputs, *, source_id=None):
        opt=options[role]
        default=f'{p}_{role}_LOAD'
        code=identifier(opt.get('task_code',default))
        row=add('TASK',code,task_code=code,task_name=code,
            task_type='INGESTION' if source_id else 'TRANSFORMATION',source_config_id=source_id,
            close_batch_on_success='Y' if role=='MAIN' else 'N')
        for ds_role, names in [('INPUT',inputs),('OUTPUT',outputs)]:
            for order,name in enumerate(names,1):
                add('TASK_DATASET',code+':'+ds_role+':'+name,task_id=row['task_id'],
                    dataset_id=registry['DATASET'][name],dataset_role=ds_role,is_required='Y',is_enabled='Y',usage_sequence=order)
        sequence=plans[role]
        for order,(step,kind,params) in enumerate(sequence,1):
            add('TASK_STEP',code+':'+step,task_id=row['task_id'],step_code=step,step_name=step,
                step_sequence_number=order*10,step_type=kind,parameter_json=json.dumps(params,sort_keys=True,ensure_ascii=False,allow_nan=False),
                is_required='Y',on_failure_action='FAIL_TASK')
        tasks.append(dict(role=role,row=row,inputs=inputs,outputs=outputs,steps=[s[0] for s in sequence]))
    task('RAW',[n['landing'] for n in codes['inputs']],[n['raw'] for n in codes['inputs']],
         source_id=source_config['source_config_id'])
    stage_options=options['STAGE']
    stage_custom=custom['STAGE'] or custom['RAW']
    source_frame,source_columns=profiles[codes['inputs'][0]['landing']]
    mapping=stage_custom or any(
        needs_map(source_columns,datasets[n['stage']]['columns']) for n in codes['outputs'])
    if mapping and 'task_steps' not in stage_options:
        plans['STAGE']=resolve_steps(stage_options,'STAGE',mapping=True)
    stage_maps=any(code=='DIRECT_MAP' for code,_,_ in plans['STAGE'])
    stage_frames={}
    for names in codes['outputs']:
        target=datasets[names['stage']]['columns']
        if stage_custom:
            # The approved output sample declares the final contract; it cannot prove custom code.
            stage_frames[names['stage']]=validate_conversion(profiles[names['main']][0],target)
        elif stage_maps:
            stage_frames[names['stage']]=validate_conversion(source_frame,target)
        else:
            mdpf_schema.validate_frame(source_frame,target,'Stage sample without DIRECT_MAP')
            stage_frames[names['stage']]=source_frame
    task('STAGE',[n['raw'] for n in codes['inputs']],[n['stage'] for n in codes['outputs']])
    for names in codes['outputs']:
        mdpf_schema.validate_frame(stage_frames[names['stage']],datasets[names['main']]['columns'],'MAIN sample',oracle=True)
    task('MAIN',[n['stage'] for n in codes['outputs']],[n['main'] for n in codes['outputs']])
    for rule in config.get('dq_rules', []):
        for name in rule['datasets']:
            column_id = registry['DATASET_COLUMN'].get(name + ':' + rule['column'])
            if column_id is None:
                raise ValueError(f'DQ column does not exist: {name}.{rule["column"]}')
            code = identifier(f'{name}_{rule["column"]}_{rule["check"]}')
            add('POLICY_DEFINITION', code, policy_code=code,
                policy_name=f'{name}.{rule["column"]} {rule["check"]}', policy_type='DQ',
                policy_scope_type='DATASET_COLUMN', dataset_id=registry['DATASET'][name],
                dataset_column_id=column_id, policy_severity='ERROR', threshold_value='0',
                parameter_json=json.dumps({'check': rule['check']}, sort_keys=True),
                failure_action='FAIL_TASK', is_enabled='Y')
    for role in config['task_overrides']:
        if custom[role]:
            warnings.append(f'{role}: custom handler behavior/registration is not tested by sample discovery; return all configured output keys and contracts.')
    warnings.append('Inferred limits describe samples plus headroom; review production bounds and Oracle targets before activation.')
    return dict(config=config,tables=rows,datasets=datasets,tasks=tasks,warnings=warnings)


def literal(value):
    if value is None:return 'NULL'
    if isinstance(value,int) and not isinstance(value,bool):return str(value)
    return "'"+str(value).replace("'","''")+"'"


def clob_literal(value):
    # Bound SQL*Plus lines and Oracle literal sizes for JSON and DDL text.
    chunks=[value[i:i+400] for i in range(0,len(value),400)] or ['']
    return 'TO_CLOB('+literal(chunks[0])+')'+''.join(' ||\n      '+literal(c) for c in chunks[1:])


def expression(name,value,compact=False):
    if isinstance(value,dict):
        parts=['CASE v_env', *('WHEN '+literal(env)+' THEN '+literal(value[env]) for env in ('DEV','STAGE','PROD')), 'END']
        if compact and len(' '.join(parts).encode('utf-8')) < 2000:
            return ' '.join(parts)
        return '\n      '.join(parts)
    if name=='parameter_json':
        return clob_literal(value)
    return literal(value)


def render_sql(model, config_bytes):
    schema_hash=hashlib.sha256(Path(mdpf_schema.__file__).read_bytes()).hexdigest()
    lines=[f'-- MDPF SQL Generator {__version__}; business schemas: LANDING=RAW, STAGE=MAIN.',
        '-- YAML SHA256: '+hashlib.sha256(config_bytes).hexdigest(), '-- mdpf.schema SHA256: '+schema_hash,
        '-- Caller must set bind :target_env to DEV, STAGE or PROD. This script creates DRAFT only.',
        'SET DEFINE OFF','SET AUTOCOMMIT OFF','SET SERVEROUTPUT ON','WHENEVER OSERROR EXIT FAILURE ROLLBACK',
        'WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK','DECLARE',
        '  v_env VARCHAR2(10) := :target_env;', '  v_release_id NUMBER(19);','BEGIN',
        "  IF v_env IS NULL OR v_env NOT IN ('DEV','STAGE','PROD') THEN",
        "    RAISE_APPLICATION_ERROR(-20001, 'target_env must be DEV, STAGE or PROD');",'  END IF;',
        '  SELECT METADATA.SEQ_CONFIG_RELEASE.NEXTVAL INTO v_release_id FROM DUAL;']
    for table,rows in model['tables'].items():
        if not rows:
            continue
        lines.append('\n  -- '+table)
        if table=='DATASET_COLUMN':
            groups={}
            for row in rows:
                groups.setdefault(row['dataset_id'],[]).append(row)
            for group in groups.values():
                columns=['config_release_id',*group[0]]
                lines.append(f'  INSERT INTO METADATA.{table} ({", ".join(columns)})')
                for index,row in enumerate(group):
                    values=['v_release_id',*[expression(k,v,compact=True) for k,v in row.items()]]
                    prefix='  SELECT ' if index==0 else '  UNION ALL SELECT '
                    lines.append(prefix+', '.join(values)+' FROM DUAL'+(';' if index==len(group)-1 else ''))
            continue
        for row in rows:
            columns=['config_release_id',*row]
            values=['v_release_id',*[expression(k,v,compact=True) for k,v in row.items()]]
            if table=='CONFIG_RELEASE':columns.append('effective_from');values.append('SYSTIMESTAMP')
            header=f'  INSERT INTO METADATA.{table} ({", ".join(columns)})'
            statement=header+' VALUES ('+', '.join(values)+');'
            if '\n' not in statement and len(statement.encode('utf-8')) < 2400:
                lines.append(statement)
            else:
                values=['v_release_id',*[expression(k,v) for k,v in row.items()]]
                if table=='CONFIG_RELEASE':values.append('SYSTIMESTAMP')
                lines += [header, '  VALUES (', '    '+',\n    '.join(values)+');']
    lines += ['  COMMIT;',"  DBMS_OUTPUT.PUT_LINE('Created DRAFT release ' || v_release_id || ' for ' || v_env);",
              'EXCEPTION','  WHEN OTHERS THEN ROLLBACK; RAISE;','END;','/','']
    return '\n'.join(lines)


def render_main_ddl(model, config_bytes):
    """Review-only CREATE TABLE script from the same MAIN contracts as metadata."""
    lines=[f'-- MDPF SQL Generator {__version__}; MAIN table DDL for review.',
        '-- YAML SHA256: '+hashlib.sha256(config_bytes).hexdigest(),
        '-- Run manually for NEW tables only; owners and runtime INSERT grants are DBA responsibilities.',
        '-- No DROP, ALTER, business keys, indexes, foreign keys or automatic execution.',
        '-- Oracle DDL commits independently; a later failure does not undo earlier CREATEs.',
        'SET DEFINE OFF', 'SET SERVEROUTPUT ON', 'WHENEVER OSERROR EXIT FAILURE',
        'WHENEVER SQLERROR EXIT SQL.SQLCODE', 'DECLARE',
        '  v_env VARCHAR2(10) := :target_env;', 'BEGIN',
        "  IF v_env IS NULL OR v_env NOT IN ('DEV','STAGE','PROD') THEN",
        "    RAISE_APPLICATION_ERROR(-20001, 'target_env must be DEV, STAGE or PROD');", '  END IF;']
    for spec in model['datasets'].values():
        row=spec['row']
        if row['layer']!='GOLD' or row['storage_type']!='ADB_TABLE':
            continue
        targets={env:sql_identifier(row['physical_object_name'][env],qualified=True)
                 for env in ('DEV','STAGE','PROD')}
        columns=sorted(spec['columns'],key=lambda c:c['column_sequence'])
        mdpf_schema.validate_columns(columns)
        definitions=[]
        for column in columns:
            kind=column['data_type']
            if kind=='VARCHAR2':
                length,unit=mdpf_schema.string_limit(column)
                if length*(4 if unit=='CHAR' else 1)>4000:
                    raise ValueError('Sample MAIN DDL uses STANDARD/AL32UTF8 capacity: at most 4000 BYTE or 1000 CHAR. Provide reviewed DDL separately for larger contracts.')
                kind=f'VARCHAR2({length} {unit})'
            elif kind=='NUMBER':
                kind=f"NUMBER({column['length_precision_scale']})"
            definitions.append(column['column_name']+' '+kind+(' NOT NULL' if column['is_nullable']=='N' else ''))
        definitions += [name+' NUMBER(19) NOT NULL' for name in ('BATCH_ID','TASK_RUN_ID','ROW_NUMBER')]
        body=' (\n    '+',\n    '.join(definitions)+'\n)'
        lines += ['\n  -- '+row['dataset_code'],
            "  EXECUTE IMMEDIATE TO_CLOB('CREATE TABLE ') || "+expression('target',targets)+' ||\n    '+clob_literal(body)+';']
    lines += ['END;', '/', '']
    return '\n'.join(lines)


def verify_main_targets(db, *, pipeline_code, release_version):
    """Explicit read-only deployment gate. Caller supplies an existing MDPF OracleDb.

    This is separate from offline generation; it never changes or activates metadata.
    """
    release=db.one('SELECT config_release_id FROM METADATA.CONFIG_RELEASE WHERE pipeline_code=:p AND release_version=:v',
        p=pipeline_code,v=release_version)
    if not release:raise ValueError('Unknown pipeline/release for Oracle verification.')
    charset=db.one("SELECT value FROM NLS_DATABASE_PARAMETERS WHERE parameter='NLS_CHARACTERSET'")
    if not charset or charset['value']!='AL32UTF8':
        raise ValueError('This POC gate requires AL32UTF8, matching MDPF UTF-8 byte validation; other database character sets need DBA review.')
    targets=db.execute("SELECT * FROM METADATA.DATASET WHERE config_release_id=:r AND layer='GOLD' AND storage_type='ADB_TABLE'",
        r=release['config_release_id'])
    if not targets:raise ValueError('Release has no Oracle MAIN targets.')
    checked=[]
    for target in targets:
        full=sql_identifier(target['physical_object_name'],qualified=True)
        owner,table=full.split('.')
        if not db.one('SELECT table_name FROM ALL_TABLES WHERE owner=:o AND table_name=:t',o=owner,t=table):
            raise ValueError(f'{full}: physical Oracle table is missing or inaccessible.')
        actual=db.execute('''SELECT c.column_name,c.data_type,c.data_length,c.char_length,c.char_used,
            c.data_precision,c.data_scale,c.nullable,c.data_default,c.identity_column,c.virtual_column,
            c.user_generated,i.generation_type FROM ALL_TAB_COLS c
            LEFT JOIN ALL_TAB_IDENTITY_COLS i ON i.owner=c.owner AND i.table_name=c.table_name AND i.column_name=c.column_name
            WHERE c.owner=:o AND c.table_name=:t''',o=owner,t=table)
        actual={c['column_name']:c for c in actual}
        expected=db.execute('SELECT * FROM METADATA.DATASET_COLUMN WHERE config_release_id=:r AND dataset_id=:d ORDER BY column_sequence',
            r=release['config_release_id'],d=target['dataset_id'])
        mdpf_schema.validate_columns(expected)
        expected += [dict(column_name=n,data_type='NUMBER',length_precision_scale='19,0',is_nullable='N')
                     for n in ('BATCH_ID','TASK_RUN_ID','ROW_NUMBER')]
        for e in expected:
            name=e['column_name'];a=actual.get(name)
            if not a or a['data_type']!=e['data_type']:
                raise ValueError(f'{full}.{name}: missing column or incompatible datatype.')
            if a.get('virtual_column')=='YES' or a.get('generation_type')=='ALWAYS':
                raise ValueError(f'{full}.{name}: column cannot accept the framework INSERT value.')
            if a['nullable']=='N' and e['is_nullable']=='Y':
                raise ValueError(f'{full}.{name}: Oracle NOT NULL requires metadata is_nullable=N.')
            if e['data_type']=='VARCHAR2':
                limit,unit=mdpf_schema.string_limit(e)
                # AL32UTF8 uses up to four bytes per character. Check both limits.
                bytes_required=limit*4 if unit=='CHAR' else limit
                if a['data_length']<bytes_required or (a['char_used']=='C' and a['char_length']<limit):
                    raise ValueError(f'{full}.{name}: insufficient character/byte capacity for the metadata contract.')
            elif e['data_type']=='NUMBER' and not (a['data_precision'] is None and a['data_scale'] is None):
                typ=spark_type(e);precision=int(a['data_precision'] or 38);scale=int(a['data_scale'] or 0)
                if scale<typ.scale or precision-scale<typ.precision-typ.scale:
                    raise ValueError(f'{full}.{name}: insufficient precision/scale; Oracle could overflow or round.')
        supplied={e['column_name'] for e in expected}
        for name,a in actual.items():
            if name in supplied or a['nullable']=='Y' or a.get('virtual_column')=='YES' or a.get('identity_column')=='YES' or a.get('user_generated')=='NO':
                continue
            default=str(a.get('data_default') or '').strip()
            if not default or default.upper() in ('NULL','(NULL)'):
                raise ValueError(f'{full}.{name}: required extra column has no usable default or generated value.')
        checked.append(full)
    return checked
