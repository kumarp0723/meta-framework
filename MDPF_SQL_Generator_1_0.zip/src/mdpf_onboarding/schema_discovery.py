"""Profile string CSV samples and reuse MDPF's exact schema/conversion checks."""
import math
import re

from pyspark.sql import functions as F
from mdpf.schema import convert_frame, validate_columns, validate_frame


def read_sample(spark, path):
    # Keep these options identical to mdpf.storage.ObjectStorage.read_csv.
    df = spark.read.options(header=True, inferSchema=False, mode='FAILFAST',
                            multiLine=True, escape='"').csv(path)
    if not df.columns or len({c.upper() for c in df.columns}) != len(df.columns):
        raise ValueError(f'Duplicate or missing CSV headers: {path}')
    return df


def discover(df, *, source, overrides, growth=25, nullable='Y'):
    """Return DATASET_COLUMN definitions. Source columns always remain strings."""
    unknown = set(overrides) - set(df.columns)
    if unknown:
        raise ValueError(f'Column overrides reference missing CSV columns: {sorted(unknown)}')
    measures = [F.count('*').alias('rows')]
    for i, name in enumerate(df.columns):
        # Validate identifiers before using them in quoted Spark expressions.
        validate_columns([dict(column_name=name, column_sequence=1, data_type='VARCHAR2',
                               length_precision_scale='1 CHAR', is_nullable='Y')])
        v = F.col(name)
        number = v.rlike(r'^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)$')
        whole = F.regexp_replace(F.regexp_extract(v, r'^[+-]?([0-9]*)', 1), '^0+', '')
        fraction = F.regexp_extract(v, r'\.([0-9]*)$', 1)
        iso = v.rlike(r'^[0-9]{4}-[0-9]{2}-[0-9]{2}$') & ~v.startswith('0000')
        as_date = F.expr(f'try_cast(`{name}` AS DATE)')
        measures += [F.count(v).alias(f'n{i}'), F.max(F.length(v)).alias(f'l{i}'),
            F.sum(F.when(v.isNotNull() & ~number, 1).otherwise(0)).alias(f'badnum{i}'),
            F.max(F.length(whole)).alias(f'p{i}'), F.max(F.length(fraction)).alias(f's{i}'),
            F.sum(F.when(v.rlike(r'^[+-]?0[0-9]+(?:\.|$)'), 1).otherwise(0)).alias(f'zero{i}'),
            F.sum(F.when(v.isNotNull() & (~iso | as_date.isNull()), 1).otherwise(0)).alias(f'baddate{i}')]
    stats = df.agg(*measures).first().asDict()
    if not stats['rows']:
        raise ValueError('CSV sample must contain at least one data row.')
    result = []
    for i, name in enumerate(df.columns):
        override = overrides.get(name, {})
        if not isinstance(override, dict) or set(override) - {
                'data_type', 'length_precision_scale', 'is_nullable', 'is_pii'}:
            raise ValueError(f'Invalid column override: {name}')
        if not source and not stats[f'n{i}'] and 'data_type' not in override:
            raise ValueError(f'All-null target column {name} requires an explicit datatype override.')
        size = max(1, math.ceil((stats[f'l{i}'] or 0) * (1 + growth / 100)))
        kind, spec = 'VARCHAR2', f'{size} CHAR'
        identifier = re.search(r'(^|_)(ID|NO|CODE|CD|ZIP|PHONE|ACCOUNT|NUMBER)$', name)
        if not source and stats[f'n{i}'] and not identifier and not stats[f'zero{i}']:
            if not stats[f'baddate{i}']:
                kind, spec = 'DATE', None
            elif not stats[f'badnum{i}']:
                scale = int(stats[f's{i}'] or 0)
                precision = max(1, int(stats[f'p{i}'] or 0) + scale)
                if precision <= 38:
                    kind, spec = 'NUMBER', f'{precision},{scale}'
        inferred = kind
        kind = override.get('data_type', kind)
        if kind != inferred:
            spec = f'{size} CHAR' if kind == 'VARCHAR2' else None
        if kind == 'DATE':spec = None
        spec = override.get('length_precision_scale', spec)
        if spec is not None and (not isinstance(spec,str) or len(spec.encode('utf-8'))>100):
            raise ValueError(f'length_precision_scale must be text of at most 100 bytes: {name}')
        if not source and not stats[f'n{i}'] and kind=='VARCHAR2' and 'length_precision_scale' not in override:
            raise ValueError(f'All-null target VARCHAR2 column {name} also requires a length override.')
        if source and kind != 'VARCHAR2':
            raise ValueError('LANDING/RAW overrides must preserve VARCHAR2 source representation.')
        column = dict(column_sequence=i+1, column_name=name, data_type=kind,
            length_precision_scale=spec, is_nullable=override.get('is_nullable', nullable),
            is_pii=override.get('is_pii', 'N'))
        if column['is_pii'] not in ('Y', 'N'):
            raise ValueError(f'is_pii must be Y or N: {name}')
        result.append(column)
    validate_columns(result)
    # The same two functions used by MDPF, including nullability, lengths and conversion loss.
    converted = convert_frame(df, result)
    validate_frame(converted, result, 'Sample', source=source, oracle=not source)
    return result


def validate_conversion(df, columns, *, oracle=False):
    converted = convert_frame(df, columns)
    validate_frame(converted, columns, 'Built-in sample conversion', oracle=oracle)
    return converted
