-- MDPF SQL Generator 1.0; MAIN table DDL for review.
-- YAML SHA256: 9f4e806bb444d5e9bff0f1792aa39e01e8228556f675201efa03f410b55db9bf
-- Run manually for NEW tables only; owners and runtime INSERT grants are DBA responsibilities.
-- No DROP, ALTER, business keys, indexes, foreign keys or automatic execution.
-- Oracle DDL commits independently; a later failure does not undo earlier CREATEs.
SET DEFINE OFF
SET SERVEROUTPUT ON
WHENEVER OSERROR EXIT FAILURE
WHENEVER SQLERROR EXIT SQL.SQLCODE
DECLARE
  v_env VARCHAR2(10) := :target_env;
BEGIN
  IF v_env IS NULL OR v_env NOT IN ('DEV','STAGE','PROD') THEN
    RAISE_APPLICATION_ERROR(-20001, 'target_env must be DEV, STAGE or PROD');
  END IF;

  -- DEMO_LOAN_LOAN_MAIN
  EXECUTE IMMEDIATE TO_CLOB('CREATE TABLE ') || CASE v_env
      WHEN 'DEV' THEN 'DMI_MAIN_DEV.LOAN'
      WHEN 'STAGE' THEN 'DMI_MAIN_STAGE.LOAN'
      WHEN 'PROD' THEN 'DMI_MAIN_PROD.LOAN'
    END ||
    TO_CLOB(' (
    LOAN_ID VARCHAR2(20 CHAR) NOT NULL,
    CLIENT_ID VARCHAR2(5 CHAR),
    BALANCE NUMBER(18,2),
    AS_OF_DATE DATE,
    STATUS VARCHAR2(8 CHAR),
    BATCH_ID NUMBER(19) NOT NULL,
    TASK_RUN_ID NUMBER(19) NOT NULL,
    ROW_NUMBER NUMBER(19) NOT NULL
)');
END;
/
