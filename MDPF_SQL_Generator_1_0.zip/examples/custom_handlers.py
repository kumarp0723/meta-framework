"""Handwritten illustrations for the shipped examples; the utility never generates code."""


def join_client(frames, context, params):
    """Register JOIN_CLIENT in the DEMO_JOIN Stage notebook."""
    result=frames['DEMO_JOIN_LOAN_RAW'].join(frames['DEMO_JOIN_CLIENT_RAW'],params['join_key'],'inner')
    return {'DEMO_JOIN_LOAN_STAGE':result}


def route_main(frames, context, params):
    """Register ROUTE_MAIN in the DEMO_SPLIT Main notebook. Data is already typed."""
    return {'DEMO_SPLIT_LOAN_FACT_MAIN':frames['DEMO_SPLIT_LOAN_FACT_STAGE'],
            'DEMO_SPLIT_LOAN_STATUS_MAIN':frames['DEMO_SPLIT_LOAN_STATUS_STAGE']}
