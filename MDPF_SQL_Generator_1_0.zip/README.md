# MDPF SQL Generator 1.0 — onboard a pipeline

Generate DRAFT metadata INSERTs and optional MAIN table DDL from YAML and sample
CSVs in OCI. Deploy the reviewed scripts to Oracle, then run the pipeline in
AIDP. This utility and its wheel are version **1.0**. The companion framework
README covers cluster setup, execution and Repair.

## Onboard your first pipeline

1. Use the configured AIDP Spark cluster from the framework README. Install the
   **companion** `mdpf-1.0-py3-none-any.whl`, then
   `dist/mdpf_onboarding-1.0-py3-none-any.whl` and its PyYAML/OCI SDK dependencies.
   Use cluster PySpark. Replacing a build also labelled 1.0 requires
   `pip install --force-reinstall --no-deps <wheel-path>`.
2. Copy `examples/one_to_one.yaml` as `config.yaml`. Replace these values; keep
   the three environment entries because deployment selects one:

| YAML section | What to supply |
|---|---|
| `pipeline` | Code, name and new metadata `release_version` |
| `inputs` / `outputs` | Dataset codes, sample paths, source/file details and MAIN table names |
| `storage` / `environments` | Separate landing/RAW/STAGE buckets, namespaces, prefixes and MAIN owners |
| `inference` | Approved type/length/nullability overrides where needed |
| `task_overrides` | Custom step references when defaults are insufficient |
| `sql_output` | Artifact destination; `generate_main_ddl: true` for new MAIN tables |

3. Upload YAML and representative, nonempty CSV samples to OCI. For the supplied
   one-to-one example, place these below the same artifact prefix:

   ```text
   onboarding/demo_loan/config.yaml
   onboarding/demo_loan/samples/loan_input.csv
   onboarding/demo_loan/samples/loan_output.csv
   ```

   Relative sample paths resolve from the YAML directory; full OCI URIs also
   work. Sample locations are separate from production landing paths.
4. Generate from an AIDP notebook:

   ```python
   from mdpf_onboarding.onboard import generate

   metadata_uri = generate(
       "oci://mdpf-dev-artifacts@devns/onboarding/demo_loan/config.yaml",
       spark=spark,
   )
   ```

   OCI SDK Resource Principal authentication reads YAML/uploads SQL; Spark's OCI
   connector reads CSVs. Configure **both** paths: YAML read, sample read/list
   and artifact create access. No local fallback. An existing SDK client can be
   supplied with `client=...`.
5. Review printed schemas/plans. Download the generated scripts from `sql_output`;
   the example produces `demo_loan_metadata_draft.sql` and `demo_loan_main_ddl.sql`.
6. Deploy/check/activate as below. Create the AIDP job using the framework README:
   pipeline `DEMO_LOAN`, tasks `DEMO_LOAN_RAW_LOAD`, `DEMO_LOAN_STAGE_LOAD`,
   `DEMO_LOAN_MAIN_LOAD`. With cycle date `2026-10-05`, put production input at
   `landing/demo_loan/loan_20261005.csv` in the selected landing bucket.

## What gets generated

INSERTs target seven METADATA tables: `CONFIG_RELEASE`, `SOURCE_CONFIG`,
`DATASET`, `DATASET_COLUMN`, `TASK`, `TASK_DATASET`, `TASK_STEP`.
The utility never executes scripts, creates AIDP jobs or activates metadata.

| Inputs / outputs | Flow | Required notebook function |
|---|---|---|
| 1 / 1 | ONE_TO_ONE; three tasks | Only for business transformations |
| 2+ / 1 | MANY_TO_ONE; three tasks | STAGE join/combiner |
| 1 / 2+ | ONE_TO_MANY; three tasks | MAIN routing |
| 2+ / 2+ | Rejected | Outside this POC |

Default plans: RAW reads/writes; STAGE reads, optionally direct-maps, validates
and writes; MAIN reads, optionally direct-maps, validates and loads Oracle.
Combined RAW creates one dataset per input, paired by `usage_sequence`; Repair
reruns all files. Inputs must share source system and landing root/bucket.

LANDING/RAW share input columns as VARCHAR2 strings. STAGE/MAIN share expected
output columns/types: VARCHAR2, exact NUMBER(p,s), date-only DATE. Review inferred
limits against production values. All-null target columns need explicit types;
VARCHAR2 also needs a length. Only `{YYYYMMDD}` is supported in delivery filenames.
Production delivery URIs must be immutable; receipts are automatic.

Dataset names are `<PIPELINE>_<INPUT>_LANDING/_RAW` and
`<PIPELINE>_<OUTPUT>_STAGE/_MAIN`; tasks use `_RAW_LOAD`, `_STAGE_LOAD`,
`_MAIN_LOAD`. Use uppercase identifiers; invalid/long names fail.

## Adjust schemas or steps

`inference.column_overrides` is keyed by generated LANDING or MAIN dataset code,
then column. LANDING overrides also apply to RAW; MAIN overrides to STAGE.
Allowed fields: `data_type`, `length_precision_scale`, `is_nullable`, `is_pii`.
Example:

```yaml
inference:
  column_overrides:
    DEMO_LOAN_LOAN_MAIN:
      BALANCE:
        data_type: NUMBER
        length_precision_scale: '18,2'
        is_nullable: 'N'
```

For custom plans, start with `examples/many_to_one.yaml` or `one_to_many.yaml`.
`task_overrides.STAGE.task_steps` (or RAW/MAIN) replaces that role's complete plan.
List order sets sequence. Strings name built-ins; `{code: MY_FUNCTION, parameters: {}}`
declares a custom function. Require one reader first, one sink last and DQ directly
before STAGE/MAIN sinks. Built-in parameters are empty; duplicate/unknown keys fail.

Register custom codes in task notebooks. Functions accept/return
`dict[dataset_code, Spark DataFrame]`; `examples/custom_handlers.py` illustrates
joins/routing. Samples validate built-in conversions, not custom implementation.
Legacy `custom_steps`/`output_is_typed` remains supported only when `task_steps`
is absent. No mapping rows are needed.

## Deploy and verify in Oracle

1. Install framework tables/sequences/grants once, using its README. A DBA also
   runs `sql/01_release_sequence.sql` **once**, with publishers paused, to establish
   `METADATA.SEQ_CONFIG_RELEASE` above existing IDs. Do not reset it; all publishers
   must use it. Deployment needs sequence SELECT and INSERT on the seven tables.
2. Review optional MAIN DDL and provision owners/runtime INSERT grants. DDL adds
   business columns plus `BATCH_ID`, `TASK_RUN_ID`, `ROW_NUMBER` (NUMBER(19) NOT NULL).
   It infers no keys/indexes/grants and fails if a target exists. Existing tables
   use `generate_main_ddl: false` or omit the flag (default false).
3. Connect to the correct environment. Run downloaded scripts in SQLcl/SQL*Plus
   script mode, using the actual generated filenames:

   ```sql
   VARIABLE target_env VARCHAR2(10)
   EXEC :target_env := 'DEV';
   @demo_loan_main_ddl.sql
   @demo_loan_metadata_draft.sql
   ```

   Omit DDL when not generated. The same scripts serve STAGE/PROD: change the
   bind **and** connection. Oracle DDL commits independently; earlier CREATEs
   survive a later failure. Metadata INSERTs are transactional; duplicate releases fail.
4. Before activation, run the separate read-only MAIN check:

   ```python
   from mdpf.db import OracleDb
   from mdpf_onboarding.metadata_generator import verify_main_targets

   db = OracleDb()
   try:
       print(verify_main_targets(db, pipeline_code="DEMO_LOAN", release_version="1.0"))
   finally:
       db.close()
   ```

   It checks business/lineage columns, compatible capacity/types and required
   Oracle columns omitted from INSERTs. Also test real runtime permissions/constraints.
5. After checks, have the deployment owner promote the intended release
   DRAFT → APPROVED → ACTIVE, retiring the previous ACTIVE in the same transaction.
   Only one release per pipeline can be ACTIVE. Changes need a new metadata release;
   never edit published rows or rerun fresh-install DDL. Software version stays 1.0.

## Troubleshoot

| Problem | Check / next action |
|---|---|
| OCI denied | SDK Resource Principal access for YAML/SQL; Spark driver/worker sample access |
| Missing sample | Resolve its path relative to the YAML object's directory |
| Conversion fails | Check values/overrides; DATE uses `YYYY-MM-DD`; business parsing needs custom code |
| Invalid plan | Check full step sequence and required join/routing handler |
| Artifact already exists | Review it; use a new filename or explicitly `overwrite: true` |
| Duplicate Oracle release | Deploy a new metadata release version |
| MAIN check fails | Compare physical columns, capacity, defaults and lineage before activation |

`overwrite` defaults false. When enabled, DDL derives `<name>_main_ddl.sql` from
`<name>_metadata_draft.sql` (or `<name>_metadata.sql`); other stems get `_main_ddl.sql`.
Both artifacts use the same destination. DDL uploads first, metadata last; uploads
are independent. Failure can leave one script: inspect before retrying.

## Where the code lives

| Module in `src/mdpf_onboarding/` | Responsibility |
|---|---|
| `onboard.py` | Loads/validates OCI YAML, coordinates generation, publishes SQL and provides CLI |
| `schema_discovery.py` | Profiles CSV samples; reuses MDPF schema/conversion validation |
| `metadata_generator.py` | Builds tasks/datasets, renders SQL/DDL and checks MAIN compatibility |
| `__init__.py` | Identifies the package/version |

CLI: `python -m mdpf_onboarding.onboard --config <oci-yaml-uri>`.
Source tests stay in `tests/`; run `python -m pytest -q` with companion MDPF,
test dependencies, Java and compatible Spark installed.

POC limits: sample DDL assumes STANDARD/AL32UTF8, up to 4000 BYTE or 1000 CHAR
VARCHAR2; larger targets need reviewed DDL with the flag false. Policy rows are
not generated: schema/nullability checks still run, but policy-result audit needs
configured policies. Samples cannot prove production bounds/custom behavior.
See `VERIFICATION_REPORT.md` for tests and remaining live AIDP/Oracle/OCI checks.
