# MDPF SQL Generator 1.0 — onboard a pipeline

Generate DRAFT metadata INSERTs and optional MAIN table DDL from YAML and sample
CSVs in OCI. Deploy the reviewed scripts to Oracle, then run the pipeline in
AIDP. This utility and its wheel are version **1.0**. The companion
[framework README](../framework/README.md) covers cluster setup, execution and
Repair. For working links, extract the packages into sibling folders named
`framework/` and `generator/`.

## Onboarding flow

```mermaid
flowchart TD
    Y["Pipeline YAML in OCI"] --> G["SQL Generator"]
    S["Sample CSVs in OCI"] --> G
    G --> M["DRAFT metadata SQL"]
    G -->|When requested| D["MAIN table DDL"]
    M --> R["Review and deploy to Oracle"]
    D --> R
    R --> V["Verify and activate the release"]
    V --> A["Run the AIDP job"]
```

The generator uploads scripts. Review, Oracle deployment and activation are
separate actions; generation does not execute SQL.

## Onboard your first pipeline

1. Use the configured AIDP Spark cluster from the framework README. Install the
   **companion** `mdpf-1.0-py3-none-any.whl`, then
   `dist/mdpf_onboarding-1.0-py3-none-any.whl` and its PyYAML/OCI SDK dependencies.
   Use cluster PySpark. Replacing a build also labelled 1.0 requires
   `pip install --force-reinstall --no-deps <wheel-path>`.
2. Copy `examples/one_to_one.yaml` as `config.yaml`. Replace these values; keep
   the three environment entries because deployment selects one. Use the
   [field reference](#yaml-field-reference) to check required values and defaults.

3. Upload YAML and representative, nonempty CSV samples to OCI. For the supplied
   one-to-one example, place these below the same artifact prefix:

   ```text
   onboarding/demo_loan/config.yaml
   onboarding/demo_loan/samples/loan_input.csv
   onboarding/demo_loan/samples/loan_output.csv
   ```

   Relative sample paths resolve from the YAML directory; full OCI URIs also
   work. Sample locations are separate from production landing paths.
4. Generate from an AIDP notebook:

   ```python
   from mdpf_onboarding.onboard import generate

   metadata_uri = generate(
       "oci://mdpf-dev-artifacts@devns/onboarding/demo_loan/config.yaml",
       spark=spark,
   )
   ```

   OCI SDK Resource Principal authentication reads YAML/uploads SQL; Spark's OCI
   connector reads CSVs. Configure **both** paths: YAML read, sample read/list
   and artifact create access. No local fallback. An existing SDK client can be
   supplied with `client=...`.
5. Review the generation summary: datasets/columns, ordered task steps, expanded
   DQ rules and artifact paths. It prints before upload; generation then publishes
   the scripts automatically. Download them from `sql_output`;
   the example produces `demo_loan_metadata_draft.sql` and `demo_loan_main_ddl.sql`.
6. Deploy/check/activate as below. Create the AIDP job using the framework README:
   pipeline `DEMO_LOAN`, tasks `DEMO_LOAN_RAW_LOAD`, `DEMO_LOAN_STAGE_LOAD`,
   `DEMO_LOAN_MAIN_LOAD`. With cycle date `2026-10-05`, put production input at
   `landing/demo_loan/loan_20261005.csv` in the selected landing bucket.

## YAML field reference

`[]` means a list item; `<ROLE>` means RAW, STAGE or MAIN. Required fields have
no automatic value. Optional sections can be omitted.

| Field | Required? | Default / what to supply |
|---|---|---|
| `pipeline` | Yes | `code`, `name`, `release_version`; quote the version, for example `'1.0'`. |
| `inputs[]` | Yes | Each needs `code`, `source_system`, `sample_csv`, `landing_key_prefix`, `file_name`. At least one input. |
| `inputs[].bucket_ref` | No | `landing`; a bucket alias defined in every environment. |
| `outputs[]` | Yes | Each needs `code`, `sample_csv`, `target_table`. At least one output. |
| `storage` | Yes | `raw_key_prefix`, `stage_key_prefix`. |
| `environments` | Yes | All three sections: `DEV`, `STAGE`, `PROD`. |
| `environments.<ENV>` | Yes | `namespace`, `oracle_main_owner`, and `buckets` containing `landing`, `raw`, `stage`. |
| `inference.varchar_growth_percent` | No | `25`; extra percentage above sampled text lengths. |
| `inference.default_nullable` | No | `'Y'`; use `'N'` to make columns required unless overridden. |
| `inference.column_overrides` | No | `{}`; generated LANDING/MAIN dataset code → column → approved settings. RAW/STAGE inherit paired schemas. |
| `task_overrides` | No | `{}`; use defaults for RAW/STAGE/MAIN. |
| `task_overrides.<ROLE>.task_code` | No | `<PIPELINE>_<ROLE>_LOAD`. |
| `task_overrides.<ROLE>.task_steps` | Conditional | Standard sequence by default; supply the complete ordered list for a custom plan. |
| Custom entry in `task_steps[]` | If custom | Requires `code`; optional `parameters` defaults to `{}`. See [step examples](#configure-task-steps). |
| `dq_rules` | No | `[]`; no policy definitions are generated. Schema checks still apply. |
| Each `dq_rules[]` | If a rule exists | Requires `datasets` (nonempty list), `column`, `check: NOT_NULL`. |
| `created_by` | No | `MDPF_ONBOARD`. |
| `sql_output` | Yes | `namespace`, `bucket`, `path`, `filename` ending in `.sql`. |
| `sql_output.overwrite` | No | `false`; existing SQL/DDL objects are preserved. |
| `sql_output.generate_main_ddl` | No | `false`; set `true` to also generate review-only MAIN table DDL. |

MANY_TO_ONE requires a custom STAGE plan; ONE_TO_MANY requires a custom MAIN
plan. There is no template setting: input/output counts determine the relationship.
Use exact sample CSV paths; production `file_name` may contain `{YYYYMMDD}`.
The runtime takes `cycle_date` from AIDP, not this YAML.

## Team workflow for changes

- Keep one YAML per pipeline as the latest intended configuration. Version it
  with its sample CSVs in source control; use versioned sample locations in OCI.
- Edit YAML, choose a new `pipeline.release_version`, then regenerate the complete
  release. Unknown settings, invalid references and unsupported types fail;
  sample columns and conversions are checked before any scripts are uploaded.
- Use a release-specific `sql_output.path` or filename and keep `overwrite: false`.
  For example, release `1.1` can use `onboarding/demo_loan/releases/1.1`.
- Review SQL, deploy as DRAFT, verify Oracle targets, then approve/activate.
  Never update published rows. Existing batches keep their pinned release.

Metadata release versions change independently of the **1.0** software version.

## What gets generated

Base INSERTs target seven METADATA tables: `CONFIG_RELEASE`, `SOURCE_CONFIG`,
`DATASET`, `DATASET_COLUMN`, `TASK`, `TASK_DATASET`, `TASK_STEP`.
Optional DQ rules also populate `POLICY_DEFINITION`. Ordinary INSERT rows are
single-line; `DATASET_COLUMN` uses one INSERT per dataset, with one row per line
in a SELECT/UNION ALL block. Long values retain safe SQLcl/SQL*Plus wrapping.
The utility never executes scripts, creates AIDP jobs or activates metadata.

| Inputs / outputs | Flow | Required notebook function |
|---|---|---|
| 1 / 1 | ONE_TO_ONE; three tasks | Only for business transformations |
| 2+ / 1 | MANY_TO_ONE; three tasks | STAGE join/combiner |
| 1 / 2+ | ONE_TO_MANY; three tasks | MAIN routing |
| 2+ / 2+ | Rejected | Outside this POC |

See the framework's [default task sequences](../framework/README.md#default-task-sequences).
Combined RAW creates one dataset per input, paired by `usage_sequence`; Repair
reruns all files. Inputs must share source system and landing root/bucket.

LANDING/RAW share input columns as VARCHAR2 strings. STAGE/MAIN share expected
output columns/types: VARCHAR2, exact NUMBER(p,s), date-only DATE. Review inferred
limits against production values. All-null target columns need explicit types;
VARCHAR2 needs a length and NUMBER needs precision/scale. If these are missing,
generation lists every unresolved column and prints a YAML override template.
Merge it into your existing overrides, replace the placeholders and run again.
While input is required, `generate()` returns `None` and uploads no SQL/DDL;
the CLI returns exit code 2 without a traceback. Only `{YYYYMMDD}` is supported in delivery filenames.
Production delivery URIs must be immutable; receipts are automatic.

Dataset names are `<PIPELINE>_<INPUT>_LANDING/_RAW` and
`<PIPELINE>_<OUTPUT>_STAGE/_MAIN`; tasks use `_RAW_LOAD`, `_STAGE_LOAD`,
`_MAIN_LOAD`. Use uppercase identifiers; invalid/long names fail.

## Optional DQ rules

Use exact generated dataset codes; `datasets` is always a nonempty list:

```yaml
dq_rules:
  - datasets: [DEMO_LOAN_LOAN_STAGE, DEMO_LOAN_LOAN_MAIN]
    column: CLIENT_ID
    check: NOT_NULL
```

Each dataset gets its own column-scoped policy, named `<DATASET>_<COLUMN>_NOT_NULL`.
The generator resolves IDs and fixes threshold 0, severity ERROR and action FAIL_TASK.
Names must fit the existing 100-byte policy-code limit. Unknown datasets/columns,
unsupported checks and duplicate/overlapping rules fail. Only generated STAGE/MAIN
datasets are supported. Rules run in MDPF; schema nullability remains independent.
Omit `dq_rules` or use `[]` to generate no policies.
Only `NOT_NULL` is accepted; see [supported and unsupported checks](../framework/README.md#supported-dq-rules).

## Adjust schemas

`inference.column_overrides` is keyed by generated LANDING or MAIN dataset code,
then column. LANDING overrides also apply to RAW; MAIN overrides to STAGE.
Allowed fields: `data_type`, `length_precision_scale`, `is_nullable`, `is_pii`.
Types/sizes are inferred where possible. `is_nullable` inherits `default_nullable`;
`is_pii` defaults to `'N'`. Empty target columns need an explicit datatype, plus
a length for VARCHAR2 or precision/scale for NUMBER. Example:

```yaml
inference:
  column_overrides:
    DEMO_LOAN_LOAN_MAIN:
      BALANCE:
        data_type: NUMBER
        length_precision_scale: '18,2'
        is_nullable: 'N'
```

## Configure task steps

Omit `task_steps` to use defaults. Otherwise supply the **complete ordered list**
under `task_overrides.RAW`, `STAGE` or `MAIN`; an empty list is invalid.
For example, add this to `examples/one_to_one.yaml` to trim CLIENT_ID before
conversion and validation:

```yaml
task_overrides:
  STAGE:
    task_steps:
      - READ_PARQUET
      - code: CLEAN_LOAN
        parameters:
          column: CLIENT_ID
      - DIRECT_MAP
      - VALIDATE_DQ
      - WRITE_PARQUET
```

A string selects a built-in; a custom entry uses `code` and optional `parameters`
(default `{}`). Parameters must be an object of JSON-compatible values and are
passed to the function as `params`. Built-in parameters must be empty; dataset
locations and schemas come from metadata. Codes are uppercase and cannot repeat.

Keep one reader first and one sink last; `VALIDATE_DQ` must immediately precede
STAGE/MAIN output. Explicit plans are never augmented: include `DIRECT_MAP`
when projection/conversion is needed. See [Available Task Steps](../framework/README.md#available-task-steps)
for what each built-in needs and produces.

The generator writes a `CUSTOM_PYTHON` reference for CLEAN_LOAN. Implement and
register it using the [matching notebook example](../framework/README.md#custom-task-steps).
Samples validate built-in conversions, not custom code; the runtime verifies
handler registration before execution. `examples/many_to_one.yaml` and
`one_to_many.yaml` show join/routing plans; `examples/custom_handlers.py` supplies
their example functions. No mapping rows are needed.

The YAML options `custom_steps` and `output_is_typed` are rejected. Before upgrading,
copy each affected task's existing resolved plan into `task_steps`, preserving
custom parameters and any required `DIRECT_MAP`, then remove both old keys.
The notebook's `custom_steps` function registry remains supported.

## Deploy and verify in Oracle

1. Install framework tables/sequences/grants once, using its README. A DBA also
   runs `sql/01_release_sequence.sql` **once**, with publishers paused, to establish
   `METADATA.SEQ_CONFIG_RELEASE` above existing IDs. Do not reset it; all publishers
   must use it. Deployment needs sequence SELECT and INSERT on the seven base tables;
   configured DQ rules also require INSERT on `METADATA.POLICY_DEFINITION`.
2. Review optional MAIN DDL and provision owners/runtime INSERT grants. DDL adds
   business columns plus `BATCH_ID`, `TASK_RUN_ID`, `ROW_NUMBER` (NUMBER(19) NOT NULL).
   It infers no keys/indexes/grants and fails if a target exists. Existing tables
   use `generate_main_ddl: false` or omit the flag (default false).
3. Connect to the correct environment. Run downloaded scripts in SQLcl/SQL*Plus
   script mode, using the actual generated filenames:

   ```sql
   VARIABLE target_env VARCHAR2(10)
   EXEC :target_env := 'DEV';
   @demo_loan_main_ddl.sql
   @demo_loan_metadata_draft.sql
   ```

   Omit DDL when not generated. The same scripts serve STAGE/PROD: change the
   bind **and** connection. Oracle DDL commits independently; earlier CREATEs
   survive a later failure. Metadata INSERTs are transactional; duplicate releases fail.
4. Before activation, run the separate read-only MAIN check:

   ```python
   from mdpf.db import OracleDb
   from mdpf_onboarding.metadata_generator import verify_main_targets

   db = OracleDb()
   try:
       print(verify_main_targets(db, pipeline_code="DEMO_LOAN", release_version="1.0"))
   finally:
       db.close()
   ```

   It checks business/lineage columns, compatible capacity/types and required
   Oracle columns omitted from INSERTs. Also test real runtime permissions/constraints.
5. After checks, have the deployment owner promote the intended release
   DRAFT → APPROVED → ACTIVE, retiring the previous ACTIVE in the same transaction.
   Only one release per pipeline can be ACTIVE. Changes need a new metadata release;
   never edit published rows or rerun fresh-install DDL. Software version stays 1.0.

## Troubleshoot

| Problem | Check / next action |
|---|---|
| OCI denied | SDK Resource Principal access for YAML/SQL; Spark driver/worker sample access |
| Missing sample | Resolve its path relative to the YAML object's directory |
| Conversion fails | Check values/overrides; DATE uses `YYYY-MM-DD`; business parsing needs custom code |
| Invalid plan | Check full step sequence and required join/routing handler |
| Artifact already exists | Review it; use a new filename or explicitly `overwrite: true` |
| Duplicate Oracle release | Deploy a new metadata release version |
| MAIN check fails | Compare physical columns, capacity, defaults and lineage before activation |

`overwrite` defaults false. When enabled, DDL derives `<name>_main_ddl.sql` from
`<name>_metadata_draft.sql` (or `<name>_metadata.sql`); other stems get `_main_ddl.sql`.
Both artifacts use the same destination. DDL uploads first, metadata last; uploads
are independent. Failure can leave one script: inspect before retrying.

## Where the code lives

| Module in `src/mdpf_onboarding/` | Responsibility |
|---|---|
| `onboard.py` | Loads/validates OCI YAML, coordinates generation, publishes SQL and provides CLI |
| `schema_discovery.py` | Profiles CSV samples; reuses MDPF schema/conversion validation |
| `metadata_generator.py` | Builds tasks/datasets, renders SQL/DDL and checks MAIN compatibility |
| `__init__.py` | Identifies the package/version |

CLI: `python -m mdpf_onboarding.onboard --config <oci-yaml-uri>`.
Source tests stay in `tests/`; run `python -m pytest -q` with companion MDPF,
test dependencies, Java and compatible Spark installed.

POC limits: sample DDL assumes STANDARD/AL32UTF8, up to 4000 BYTE or 1000 CHAR
VARCHAR2; larger targets need reviewed DDL with the flag false. DQ generation
supports NOT_NULL only; without rules, schema/nullability checks still run but no
policy-result audit is created. Samples cannot prove production bounds/custom behavior.
See `VERIFICATION_REPORT.md` for tests and remaining live AIDP/Oracle/OCI checks.
