"""Local Spark execution; existing CI adapters stand in for OCI and Oracle."""
import json
from pathlib import Path
import runpy
from types import SimpleNamespace

import pytest
import yaml
from pyspark.sql import functions as F

from mdpf_runtime.runner import _run_task
from mdpf_onboarding.config import main_ddl_uri, output_uri, validate_config, yaml_uri
from mdpf_onboarding.onboard import generate
from mdpf_onboarding.config import sample_uri
from mdpf_onboarding.schema_discovery import read_sample
from provider_dmi.fee import custom_fee_transform


pytestmark = pytest.mark.integration
HANDLERS = {'CUSTOM_FEE_TRANSFORM': custom_fee_transform}


@pytest.mark.parametrize('platform', ['aidp', 'dataflow'])
def test_shared_and_custom_launchers_run_raw_stage_main(execution_case, spark, monkeypatch, platform, framework_entrypoints):
    from mdpf_runtime import aidp, dataflow
    fw, db, _ = execution_case
    monkeypatch.setattr('mdpf_runtime.runner.MetadataFramework', lambda *args, **kwargs: fw)
    for field in ('USER','PASSWORD','DSN'):monkeypatch.setenv('MDPF_MAIN_DB_'+field,'test-adw')
    if platform == 'aidp':
        monkeypatch.setattr(aidp, 'OracleDb', lambda: db)
        monkeypatch.setattr(db, 'close', lambda: None)
    else:
        monkeypatch.setattr(dataflow, 'run_task', lambda **kwargs: _run_task(db, main_db=fw.main_db, **kwargs))

    class Widgets:
        def __init__(self, values):
            self.values = values
        def text(self, *, name, defaultValue, label):
            self.values.setdefault(name, defaultValue)
        def get(self, name):
            return self.values[name]

    results = []
    for index, role in enumerate(('RAW', 'STAGE', 'MAIN'), 1):
        provider_root = Path(__file__).resolve().parents[3]
        framework_root = framework_entrypoints.parent
        root = provider_root if role == 'STAGE' else framework_root
        path = root / 'entrypoints' / platform / (role.lower() + ('.ipynb' if platform == 'aidp' else '.py'))
        if platform == 'aidp':
            values = dict(pipeline_code='DMI_FEE', job_run_id='synthetic-job', task_run_id=f'synthetic-aidp-{index}',
                          execution_count='1', cycle_date='2026-10-15' if index == 1 else '',
                          execution_mode='MANUAL' if index == 1 else '')
            scope = dict(aidputils=SimpleNamespace(widgets=Widgets(values)), spark=spark)
            for cell in json.loads(path.read_text())['cells']:
                if cell['cell_type'] == 'code':
                    exec(''.join(cell['source']), scope)
            result = scope['result']
        else:
            monkeypatch.setenv('DATAFLOW_RUN_ID', f'ocid1.dataflowrun.oc1.test.synthetic{index}')
            argv = ['--execution-key', 'synthetic-provider-workflow']
            if index == 1:
                argv += ['--cycle-date', '2026-10-15', '--execution-mode', 'MANUAL']
            if role != 'STAGE':
                argv += ['--pipeline-code', 'DMI_FEE']
            result = runpy.run_path(str(path))['main'](argv, spark=spark)
        results.append(result)
    assert len({r['task_run_id'] for r in results}) == 3
    assert all((r['status'], r['input_count'], r['output_count']) == ('COMPLETED', 2, 2) for r in results)
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
    rows = fw.main_db.execute('SELECT * FROM DMI_MAIN_DEV.DMI_FEE ORDER BY ROW_NUMBER')
    assert [r['client_no'] for r in rows] == ['C001', 'C002']
    assert all(r['created_at'] and r['updated_at'] and r['batch_id'] and r['task_run_id'] for r in rows)
    assert [r['result_status'] for r in db.execute('SELECT result_status FROM RUNTIME.POLICY_RESULT')] == ['PASS'] * 4
    with pytest.raises(ValueError, match='COMPLETED'):
        fw.execute_task(results[0]['batch_id'], 'DMI_FEE_MAIN_LOAD')
    assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.DMI_FEE')['n'] == 2


@pytest.mark.parametrize('platform', ['aidp', 'dataflow'])
def test_common_stage_rejects_custom_plan_before_read_and_custom_retry_succeeds(
        execution_case, spark, monkeypatch, platform, framework_entrypoints):
    fw, db, _ = execution_case
    batch = fw.start_batch('shared-stage-custom-plan', '2026-10-15', 'MANUAL')['batch_id']
    fw.execute_task(batch, 'DMI_FEE_RAW_LOAD')
    monkeypatch.setattr('mdpf_runtime.runner.MetadataFramework', lambda *args, **kwargs: fw)
    for field in ('USER','PASSWORD','DSN'):monkeypatch.setenv('MDPF_MAIN_DB_'+field,'test-adw')
    root = framework_entrypoints
    actual_read = fw.storage.read_parquet
    def unexpected_read(*args, **kwargs):
        pytest.fail('Missing custom handler must fail before reading data.')
    monkeypatch.setattr(fw.storage, 'read_parquet', unexpected_read)
    if platform == 'dataflow':
        monkeypatch.setattr('mdpf_runtime.dataflow.run_task', lambda **kw: _run_task(db, main_db=fw.main_db, **kw))
        monkeypatch.setenv('DATAFLOW_RUN_ID', 'ocid1.dataflowrun.oc1.test.syntheticsharedstage')
        with pytest.raises(ValueError, match='Missing callable CUSTOM_PYTHON handler'):
            runpy.run_path(str(root / 'dataflow/stage.py'))['main'](
                ['--pipeline-code', 'DMI_FEE', '--execution-key', 'shared-stage-custom-plan'], spark=spark)
    else:
        monkeypatch.setattr('mdpf_runtime.aidp.OracleDb', lambda: db)
        monkeypatch.setattr(db, 'close', lambda: None)
        class Widgets:
            def __init__(self):
                self.values = dict(pipeline_code='DMI_FEE', job_run_id='synthetic-job',
                                   task_run_id='synthetic-stage', execution_count='1',
                                   workflow_execution_key='shared-stage-custom-plan')
            def text(self, *, name, defaultValue, label): self.values.setdefault(name, defaultValue)
            def get(self, name): return self.values[name]
        scope = dict(aidputils=SimpleNamespace(widgets=Widgets()), spark=spark)
        with pytest.raises(ValueError, match='Missing callable CUSTOM_PYTHON handler'):
            for cell in json.loads((root / 'aidp/stage.ipynb').read_text())['cells']:
                if cell['cell_type'] == 'code': exec(''.join(cell['source']), scope)
    assert db.one("SELECT failed_step_code FROM RUNTIME.TASK_RUN WHERE status='FAILED'")['failed_step_code'] == 'CUSTOM_FEE_TRANSFORM'
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
    monkeypatch.setattr(fw.storage, 'read_parquet', actual_read)
    fw.execute_task(batch, 'DMI_FEE_STAGE_LOAD', custom_steps=HANDLERS)
    assert db.one("SELECT COUNT(*) n FROM RUNTIME.TASK_RUN WHERE status='FAILED'")['n'] == 1


@pytest.mark.parametrize('column', ['MSP_CYCLE_DATE', 'LN_NO'])
def test_not_null_failure_is_audited_before_stage_write(execution_case, column):
    fw, db, landing = execution_case
    # Materialize before replacing the Parquet fixture, so Spark never reads a
    # deleted input while writing the same local delivery path.
    frame = fw.spark.read.parquet(str(landing)).localCheckpoint(eager=True)
    frame.withColumn(column,F.lit(None).cast(frame.schema[column].dataType)).write.mode('overwrite').parquet(str(landing))
    frame.unpersist()
    batch = fw.start_batch('provider-null-' + column, '2026-10-15', 'MANUAL')['batch_id']
    fw.execute_task(batch, 'DMI_FEE_RAW_LOAD')
    with pytest.raises(ValueError):
        fw.execute_task(batch, 'DMI_FEE_STAGE_LOAD', custom_steps=HANDLERS)
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
    assert db.one("SELECT failed_step_code FROM RUNTIME.TASK_RUN WHERE status='FAILED'")['failed_step_code'] == 'VALIDATE_DQ'
    assert db.one("SELECT COUNT(*) n FROM RUNTIME.POLICY_RESULT WHERE result_status='FAIL'")['n'] == 1
    assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 1
    assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.DMI_FEE')['n'] == 0


def test_reconciliation_failure_rollback_and_retry(execution_case, monkeypatch):
    fw, db, _ = execution_case
    def lose_row(frames, context, params):
        return {code: frame.where(F.col('LN_NO') == '100000123')
                for code, frame in custom_fee_transform(frames, context, params).items()}
    batch = fw.start_batch('provider-reconciliation', '2026-10-15', 'MANUAL')['batch_id']
    fw.execute_task(batch, 'DMI_FEE_RAW_LOAD')
    with pytest.raises(ValueError):
        fw.execute_task(batch, 'DMI_FEE_STAGE_LOAD', custom_steps={'CUSTOM_FEE_TRANSFORM': lose_row})
    fw.execute_task(batch, 'DMI_FEE_STAGE_LOAD', custom_steps=HANDLERS)
    actual_insert = fw.main_db.insert_many
    def wrong_count(*args, **kwargs):
        return actual_insert(*args, **kwargs) - 1
    monkeypatch.setattr(fw.main_db, 'insert_many', wrong_count)
    with pytest.raises(ValueError, match='reconciliation'):
        fw.execute_task(batch, 'DMI_FEE_MAIN_LOAD')
    assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.DMI_FEE')['n'] == 0
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
    assert db.one("SELECT COUNT(*) n FROM RUNTIME.POLICY_RESULT WHERE result_status='FAIL'")['n'] == 2
    assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 2
    monkeypatch.setattr(fw.main_db, 'insert_many', actual_insert)
    failed_main=db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_id=3 ORDER BY task_run_id DESC')
    fw.execute_task(batch, 'DMI_FEE_MAIN_LOAD')
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
    assert fw.main_db.one('SELECT COUNT(*) n FROM DMI_MAIN_DEV.DMI_FEE')['n'] == 2
    # Prior failed facts survive the successful retry.
    assert db.one("SELECT COUNT(*) n FROM RUNTIME.TASK_RUN WHERE status='FAILED'")['n'] == 2
    assert db.one("SELECT COUNT(*) n FROM RUNTIME.POLICY_RESULT WHERE result_status='FAIL'")['n'] == 2


def test_public_generation_keeps_input_distinct_and_metadata_draft(
        fee_dir, fee_config, spark, ci_adapters, monkeypatch):
    import mdpf_onboarding.onboard as onboard
    from oci.exceptions import ServiceError
    uri = 'oci://mdpf-dev-artifacts@devns/onboarding/providers/dmi/fee/1.1/input/onboarding.yaml'
    original = (fee_dir / 'onboarding.yaml').read_bytes()
    client = ci_adapters.MemoryOCI()
    client.objects[uri] = original
    samples = {sample_uri(uri, item['sample_csv']): fee_dir / item['sample_csv']
               for item in fee_config['inputs'] + fee_config['outputs']}
    monkeypatch.setattr(onboard, 'read_sample', lambda session, path: read_sample(session, str(samples[path])))
    assert generate(uri, spark=spark, client=client) == output_uri(fee_config)
    targets = [yaml_uri(fee_config), main_ddl_uri(fee_config), output_uri(fee_config)]
    assert [path for path, _ in client.puts] == targets
    assert len({uri, *targets, *samples}) == 6
    assert client.objects[uri] == original
    complete = validate_config(yaml.safe_load(client.objects[yaml_uri(fee_config)]))
    assert len(complete['outputs'][0]['columns']) == 12
    assert complete['outputs'][0]['target_table'] == 'DMI_FEE' and len(complete['dq_rules']) == 4
    db = ci_adapters.CatalogDb()
    try:
        db.deploy(client.objects[output_uri(fee_config)].decode())
        assert db.one('SELECT release_status FROM METADATA.CONFIG_RELEASE')['release_status'] == 'DRAFT'
        assert db.one('SELECT COUNT(*) n FROM METADATA.POLICY_DEFINITION')['n'] == 4
    finally:
        db.close()
    before_retry = dict(client.objects)
    with pytest.raises(ServiceError) as error:
        generate(uri, spark=spark, client=client)
    assert error.value.status == 412
    assert client.objects == before_retry
