# DMI / FEE

The canonical production input configuration is [onboarding.yaml](onboarding.yaml).
It preserves the reviewed 12-column DMI_FEE schema, trim step and four policies.
Review its illustrative infrastructure values before generating deployment SQL.

`samples/` contains synthetic input and expected output. `tests/` pins this business
contract and exercises generation/execution using local test adapters. The Python
handler lives at `src/provider_dmi/fee.py` relative to the provider root.

See the [provider instructions](../../README.md) for setup, packaging and both
platform entry APIs. Utility examples remain independent reference fixtures.

DMI metadata release 1.1 explicitly uses FEE_TRAN_AM NUMBER(7,2) and
DMI_TIME_STAMP TIMESTAMP(6). Delivery DOUBLE values normalize before RAW writes.
Set Spark SQL timezone to UTC. Apply the [type migration plan](../../../../../common-utilities/framework/MIGRATION.md) before
using retained VARCHAR datasets/tables; MAIN remains APPEND without idempotency.
