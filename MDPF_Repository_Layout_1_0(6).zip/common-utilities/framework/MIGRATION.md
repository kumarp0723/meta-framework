# NUMBER/TIMESTAMP adoption and existing data

This build changes processing behavior, not deployed data. The 17-table ATP schema
is unchanged. No database, bucket, retained dataset or scheduler job is modified
by building/installing a wheel. The actual deployment schemas were not supplied;
run the checks below against the prepared environment before activation.

## Confirmed DMI contract

| Column | Delivered Parquet | RAW/STAGE processing | MAIN metadata / DDL |
|---|---|---|---|
| FEE_TRAN_AM | FLOAT or DOUBLE, preserved by the reader | DECIMAL(7,2), explicit HALF_UP | NUMBER(7,2) |
| DMI_TIME_STAMP | TIMESTAMP | TIMESTAMP, UTC, microseconds | TIMESTAMP(6), naive UTC |

NUMBER(7,2) is the user-confirmed future business limit, not a limit established
by sample magnitudes. FLOAT/DOUBLE rounding uses their canonical delivered text;
it cannot recover decimal precision already lost upstream. Values that round to
100000.00 or -100000.00, NaN/infinity and conversion-created NULLs fail.
Exact decimal/string conversions still reject precision/scale loss.

All Spark workers use spark.sql.session.timeZone=UTC. Offset timestamps normalize
to UTC; business TIMESTAMP has no retained zone identifier. Fractional seconds are
preserved through six digits. CSV values with greater precision are not silently
truncated. MAIN collection explicitly converts UTC timestamp text into Python
UTC wall-clock values before Oracle TIMESTAMP binding, independent of process TZ.

## Read-only checks before deployment

Inspect the actual landing Parquet schema with spark.read.parquet(uri).printSchema().
Confirm FEE_TRAN_AM is FLOAT/DOUBLE and DMI_TIME_STAMP is TIMESTAMP. Do not supply
the CSV-derived schema to the Parquet reader.

Generate a new DRAFT metadata release. DMI examples now use metadata release 1.1;
software/wheel versions remain 1.0. Use a different unused metadata version if
1.1 is already published. Published 1.0 metadata and prior attempts stay intact.

With separate ATP and ADW connections, compare retained files and live tables:

```python
from mdpf_onboarding.oracle_gate import verify_main_targets, verify_parquet_targets

verify_parquet_targets(atp, spark=spark, pipeline_code='DMI_FEE',
                       release_version='1.1', batch_id=retained_batch_id)
verify_main_targets(atp, pipeline_code='DMI_FEE', release_version='1.1', main_db=adw)
```

The Parquet gate reads schemas only and fails on missing/incompatible business or
system columns. A selected proposed release can be compared against paths from
an older retained batch. The Oracle gate checks live column types, capacity,
nullability and timestamp precision. It allows compatible wider NUMBER columns;
it does not silently change an existing wider physical column to NUMBER(7,2).
A VARCHAR timestamp column is incompatible. These gates do not execute DDL.

## Choose an explicit migration or rebuild

For development, prefer new output batch folders and a separate reviewed ADW
target table. Generate CREATE DDL for that target, provision grants, publish the
new DRAFT release and run a new workflow. Keep previous files/tables until count,
amount and timestamp verification passes. Never rerun fresh ATP installer DDL as
an upgrade or edit published metadata to match new files.

For retained production data, the DBA must preserve/back up the original target
and define a shadow-table or shadow-column migration. Convert existing strings
using explicit reviewed formats; validate numeric range, rounding decisions,
NULLs and timestamp offsets before backfill. Preserve all business/audit columns
and reconcile counts/amount totals. Switch readers/writers only after verification.
Do not assume ALTER VARCHAR to NUMBER/TIMESTAMP is safe for populated columns.

Use the previous complete YAML as the generator baseline for comparison. Generated
DDL labels datatype changes/narrowing as MANUAL REVIEW and does not execute them.
Retained VARCHAR RAW/STAGE files require explicit rewriting to new locations with
valid receipt/run lineage, or regeneration from the retained original delivery.
They cannot be relabeled as DECIMAL/TIMESTAMP files by changing metadata alone.

Before exercising quarantine retries, apply the dedicated-bucket connector policy
in [operations](OPERATIONS.md#oci-permissions). Some older OCI Hadoop connector
versions delete a prior destination before replacement; the quarantine-only manage
grant covers that behavior. The framework never deletes the Landing source.

## MAIN APPEND recovery

Set MAIN automatic task retries to 0 in AIDP/ActiveBatch. Also disable automatic
whole-job/workflow resubmission that could repeat MAIN. Release manifests record
that setting, but deployed scheduler configuration must be applied separately.
There is no review argument or automatic reconciliation engine.

After a failed append, stop the exact writer, inspect ADW by BATCH_ID/TASK_RUN_ID,
and reconcile committed rows before manually launching a new attempt under the
original workflow key. A failed ATP completion can follow a successful ADW commit.
Preserve FAILED attempts and work items. Terminal batches cannot reopen.
Duplicate protection remains unresolved until idempotency is implemented.
