"""Oracle connection, named binds, and explicit transactions."""
from contextlib import contextmanager
import os

import oracledb

from .schema import sql_identifier


def require_main_database(db, main_db=None):
    """Require a distinct caller-owned ADW adapter or complete ADW credentials.

    Validate without opening ADW, so RAW/STAGE need settings but no ADW session.
    The supplied control adapter already represents the required ATP connection.
    """
    if main_db is not None:
        if main_db is db or (getattr(main_db, 'conn', None) is not None and
                             main_db.conn is getattr(db, 'conn', None)):
            raise ValueError('ATP and ADW must not use the same connection.')
        return
    missing = [f'MDPF_MAIN_DB_{name}' for name in ('USER', 'PASSWORD', 'DSN')
               if not os.environ.get(f'MDPF_MAIN_DB_{name}', '').strip()]
    if missing:
        raise ValueError('Separate ADW connection required. Missing connection settings: '+', '.join(missing))


class OracleDb:
    def __init__(self, *, prefix='MDPF_DB', user=None, password=None, dsn=None,
                 config_dir=None, wallet_location=None, wallet_password=None):
        """Open one connection; explicit values override only this prefix's settings.

        MDPF_DB is the ATP/control connection. MDPF_MAIN_DB is the required ADW
        connection. Explicit keyword values can come directly from Vault.
        """
        if prefix not in ('MDPF_DB', 'MDPF_MAIN_DB'):
            raise ValueError('Connection prefix must be MDPF_DB or MDPF_MAIN_DB.')
        values = dict(user=user, password=password, dsn=dsn, config_dir=config_dir,
                      wallet_location=wallet_location, wallet_password=wallet_password)
        for name, value in values.items():
            if value is None:
                values[name] = os.environ.get(prefix+'_'+name.upper())
        missing = [name for name in ('user','password','dsn') if not values[name]]
        if missing:
            raise ValueError('Missing connection settings: '+', '.join(prefix+'_'+name.upper() for name in missing))
        if any(value is not None and (not isinstance(value,str) or not value) for value in values.values()):
            raise ValueError('Connection settings must be nonempty strings.')
        self.conn = oracledb.connect(**{name:value for name,value in values.items() if value is not None})

    @contextmanager
    def transaction(self):
        """Commit the connection on normal exit; roll back and re-raise any BaseException.

        This wraps the existing connection, not a savepoint or nested transaction.
        Facade lifecycle methods choose transaction scopes; runtime SQL helpers
        participate in that scope without independently committing or rolling back.
        Database errors propagate to the caller."""
        try:
            yield
            self.conn.commit()
        except BaseException:
            self.conn.rollback()
            raise

    def execute(self, sql, **params):
        return self._query(sql, params, False)

    def one(self, sql, **params):
        return self._query(sql, params, True)

    def _query(self, sql, params, one):
        cursor = self.conn.cursor()
        try:
            cursor.execute(sql, params)
            if not cursor.description:
                return None if one else []
            names = [d[0].lower() for d in cursor.description]
            records = [cursor.fetchone()] if one else cursor.fetchall()
            mapped = [dict(zip(names, [v.read() if hasattr(v, "read") else v for v in row]))
                      for row in records if row is not None]
            return (mapped[0] if mapped else None) if one else mapped
        finally:
            cursor.close()

    def insert_many(self, table, columns, records, types):
        """Return actual affected rows; the caller owns commit/rollback."""
        sql_identifier(table, qualified=True)
        for name in columns:
            sql_identifier(name)
        if not records:
            return 0
        binds = ",".join(":" + name for name in columns)
        sql = f"INSERT INTO {table} ({','.join(columns)}) VALUES ({binds})"
        cursor = self.conn.cursor()
        try:
            mapping = {"DATE": oracledb.DB_TYPE_DATE, "NUMBER": oracledb.DB_TYPE_NUMBER,
                       "VARCHAR2": oracledb.DB_TYPE_VARCHAR, "TIMESTAMP": oracledb.DB_TYPE_TIMESTAMP,
                       "TIMESTAMP WITH TIME ZONE": oracledb.DB_TYPE_TIMESTAMP_TZ}
            cursor.setinputsizes(**{name: mapping[kind] for name, kind in types.items()})
            cursor.executemany(sql, records)
            return cursor.rowcount
        finally:
            cursor.close()

    def insert(self, table, values):
        # Identifiers are supplied by this package.
        columns = ",".join(values)
        binds = ",".join(":" + key for key in values)
        self.execute(f"INSERT INTO {table} ({columns}) VALUES ({binds})", **values)

    def next_id(self, table, column):
        schema, _ = table.split(".")
        return int(self.one(f"SELECT {schema}.SEQ_{column.upper()}.NEXTVAL id FROM DUAL")["id"])

    def close(self):
        self.conn.close()
