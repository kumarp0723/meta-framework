"""Explicit Spark processing contracts, separate from delivered Parquet schemas."""
from decimal import Decimal, InvalidOperation, ROUND_HALF_UP, localcontext
import re

from pyspark.sql import functions as F, types as T


class DataValidationError(ValueError):
    """A proven data/contract violation, distinct from storage/database failures."""


RESERVED = {"_BATCH_ID", "_RUN_ID", "BATCH_ID", "TASK_RUN_ID", "ROW_NUMBER",
            "_INGESTION_ITEM_ID", "_INGESTED_AT", "_PROCESSED_AT", "CREATED_AT", "UPDATED_AT"}


def sql_identifier(value, qualified=False):
    pattern = r"[A-Z][A-Z0-9_]{0,127}"
    if qualified:
        pattern += r"\." + pattern
    if not isinstance(value, str) or not re.fullmatch(pattern, value):
        raise ValueError("Use uppercase, unquoted SQL identifiers" + (" in OWNER.TABLE form." if qualified else "."))
    return value


def string_limit(column):
    match = re.fullmatch(r"([1-9][0-9]*)(?: (BYTE|CHAR))?", str(column.get("length_precision_scale") or ""))
    if not match:
        raise ValueError("VARCHAR2 requires a positive length, optionally followed by BYTE or CHAR.")
    return int(match[1]), match[2] or "BYTE"


def spark_type(column):
    kind, spec = column["data_type"], column.get("length_precision_scale")
    if kind == "VARCHAR2":
        string_limit(column)
        return T.StringType()
    if kind == "DATE" and not spec:
        return T.DateType()
    if kind == "TIMESTAMP" and spec in (None, "6"):
        return T.TimestampType()
    if kind == "NUMBER":
        match = re.fullmatch(r"([1-9][0-9]*)(?:,([0-9]+))?", str(spec or ""))
        if match:
            precision, scale = int(match[1]), int(match[2] or 0)
            if 1 <= precision <= 38 and 0 <= scale <= precision:
                return T.DecimalType(precision, scale)
    raise ValueError("Supported types: VARCHAR2(length [BYTE|CHAR]), NUMBER(p[,s]) with 1<=p<=38 and 0<=s<=p, date-only DATE, and TIMESTAMP(6).")


def validate_columns(columns):
    if not columns:
        raise ValueError("Dataset columns are required.")
    names, sequences = set(), set()
    for column in columns:
        name, sequence = sql_identifier(column["column_name"]), column["column_sequence"]
        if name in RESERVED or name in names or sequence in sequences or sequence <= 0:
            raise ValueError("Duplicate/reserved column name or invalid column sequence in DATASET_COLUMN.")
        if column["is_nullable"] not in ("Y", "N"):
            raise ValueError("Column nullability must be Y or N.")
        spark_type(column)
        names.add(name)
        sequences.add(sequence)


def require_columns(df, columns, label, exact=True):
    names = [c["column_name"] for c in columns]
    folded = [n.upper() for n in df.columns]
    if len(set(folded)) != len(folded):
        raise DataValidationError(f"{label} columns contain duplicate or ambiguous names.")
    if not set(names) <= set(df.columns) or (exact and len(df.columns) != len(names)):
        raise DataValidationError(f"{label} columns do not match DATASET_COLUMN.")
    return names


def validate_frame(df, columns, label, check_nulls=True, source=False, oracle=False):
    """Validate normalized processing values; return null counts and row count."""
    require_columns(df, columns, label)
    checks = [F.count("*").alias("_rows")]
    for index, column in enumerate(columns):
        name, expected = column["column_name"], spark_type(column)
        incoming = df.schema[name].dataType
        if incoming != expected:
            raise DataValidationError(f"{label} type mismatch: {name}; incoming={incoming.simpleString()}, expected={expected.simpleString()}.")
        value = F.col(name)
        null = value.isNull()
        if column["data_type"] == "VARCHAR2":
            null = null | ((F.trim(value) == "") if source else (value == ""))
            length, unit = string_limit(column)
            size = F.length(F.encode(value, "UTF-8")) if unit == "BYTE" else F.length(value)
            checks.append(F.sum(F.when(size > length, 1).otherwise(0)).alias(f"length_{index}"))
            if oracle:
                checks.append(F.sum(F.when(value == "", 1).otherwise(0)).alias(f"empty_{index}"))
        checks.append(F.sum(F.when(null, 1).otherwise(0)).alias(f"null_{index}"))
    summary = df.agg(*checks).first().asDict()
    nulls = {}
    for index, column in enumerate(columns):
        name = column["column_name"]
        nulls[name] = int(summary[f"null_{index}"] or 0)
        if summary.get(f"length_{index}"):
            raise DataValidationError(f"{label} length constraint violated: {name}.")
        if summary.get(f"empty_{index}"):
            raise DataValidationError(f"Oracle empty strings become NULL; normalize explicitly in the notebook: {name}.")
        if check_nulls and column["is_nullable"] == "N" and nulls[name]:
            raise DataValidationError(f"Required {'source column is blank' if source else 'target column has nulls'}: {name}.")
    if source and not summary["_rows"]:
        raise DataValidationError("Source must contain data rows.")
    return nulls, int(summary["_rows"])


def _decimal_text(value, precision, scale, rounding):
    """Use canonical numeric text, never an intermediate binary float.

    FLOAT/DOUBLE inputs opt into HALF_UP. Strings/decimals must remain exact.
    Returning NULL is a failed conversion, checked even for nullable columns.
    """
    if value is None:
        return None
    try:
        text = value.strip()
        if not re.fullmatch(r"[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?", text):
            return None
        number = Decimal(text)
        if not number.is_finite() or (number and number.adjusted() > precision - scale):
            return None
        with localcontext() as context:
            context.prec = 400  # All finite IEEE DOUBLE values plus supported scale.
            rounded = number.quantize(Decimal(1).scaleb(-scale), rounding=ROUND_HALF_UP)
            if (not rounding and rounded != number) or abs(rounded) >= Decimal(10) ** (precision - scale):
                return None
            return format(rounded, 'f')
    except (InvalidOperation, ValueError):
        return None


def convert_frame(df, columns):
    """Normalize embedded Parquet types before enforcing processing contracts."""
    names = require_columns(df, columns, "DIRECT_MAP", exact=False)
    expressions, checks, types = [], [], []
    for index, column in enumerate(columns):
        name, target = column["column_name"], spark_type(column)
        original, incoming = F.col(name), df.schema[name].dataType
        text = original.cast("string")
        converted = F.expr(f"try_cast(`{name}` AS {target.simpleString()})")
        invalid = original.isNotNull() & converted.isNull()
        description = f"{name}; incoming={incoming.simpleString()}, expected={target.simpleString()}"
        if isinstance(target, T.DecimalType):
            if not isinstance(incoming, (T.StringType, T.DecimalType, T.ByteType, T.ShortType, T.IntegerType, T.LongType, T.FloatType, T.DoubleType, T.NullType)):
                raise DataValidationError(f"Unsupported numeric conversion: {description}.")
            if incoming == target:
                converted = original
            elif isinstance(incoming, (T.StringType, T.FloatType, T.DoubleType)):
                rounding = isinstance(incoming, (T.FloatType, T.DoubleType))
                normalized = F.udf(_decimal_text, T.StringType())(
                    text, F.lit(target.precision), F.lit(target.scale), F.lit(rounding))
                converted = normalized.cast(target)
                invalid = original.isNotNull() & converted.isNull()
            elif isinstance(incoming, T.DecimalType):
                invalid = invalid | (original.isNotNull() & (original != converted))
        elif isinstance(target, T.TimestampType):
            if df.sparkSession.conf.get('spark.sql.session.timeZone') not in ('UTC', 'Etc/UTC', 'Z'):
                raise DataValidationError(f"TIMESTAMP processing requires spark.sql.session.timeZone=UTC: {description}.")
            if not isinstance(incoming, (T.StringType, T.TimestampType, T.TimestampNTZType, T.NullType)):
                raise DataValidationError(f"Unsupported timestamp conversion: {description}.")
            if isinstance(incoming, T.TimestampType):
                converted = original
            if isinstance(incoming, T.StringType):
                valid_text = F.trim(text).rlike(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?(?:Z|[+-][0-9]{2}:[0-9]{2})?$")
                invalid = invalid | (original.isNotNull() & ~valid_text)
        elif isinstance(target, T.DateType):
            if not isinstance(incoming, (T.StringType, T.DateType, T.NullType)):
                raise DataValidationError(f"DIRECT_MAP DATE is date-only: {description}.")
            invalid = invalid | (original.isNotNull() & (
                ~text.rlike(r"^[0-9]{4}-[0-9]{2}-[0-9]{2}$") |
                (F.substring(text, 1, 4) == "0000") | (F.date_format(converted, "yyyy-MM-dd") != text)))
        elif not isinstance(incoming, (T.StringType, T.DateType, T.TimestampType, T.DecimalType, T.ByteType, T.ShortType, T.IntegerType, T.LongType, T.NullType)):
            raise DataValidationError(f"Unsupported string conversion: {description}.")
        checks.append(F.sum(F.when(invalid, 1).otherwise(0)).alias(str(index)))
        types.append(description)
        expressions.append(converted.alias(name))
    failures = df.agg(*checks).first().asDict()
    if any(failures.values()):
        details = '; '.join(types[int(i)] + f"; invalid_rows={count}" for i, count in failures.items() if count)
        raise DataValidationError("Input conversion loss or precision/scale violations: " + details + ".")
    return df.select(*expressions).select(*names)
