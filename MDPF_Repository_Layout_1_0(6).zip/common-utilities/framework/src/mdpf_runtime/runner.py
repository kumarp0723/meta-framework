"""Platform-neutral task entry point; schedulers supply workflow and attempt identity."""
import json

from .db import OracleDb, require_main_database
from .pipeline import MetadataFramework


def _run_task(db, *, pipeline_code, task_code, execution_key, task_run_id,
              cycle_date=None, execution_mode=None, orchestrator_run_id=None,
              orchestrator_attempt_number=None, triggered_by='SCHEDULER', custom_steps=None, spark=None,
              main_db=None):
    for name,value,limit in (('execution_key',execution_key,300),('task_run_id',task_run_id,200)):
        if not isinstance(value,str) or not value.strip() or '{{' in value or len(value.encode('utf-8'))>limit:
            raise ValueError(f'{name} must be a resolved identity of at most {limit} UTF-8 bytes.')
    require_main_database(db, main_db)
    fw=MetadataFramework(db,pipeline_code,spark=spark,**({'main_db':main_db} if main_db is not None else {}))
    batch=fw.get_batch_by_execution_key(execution_key)
    if batch is None:
        release=db.one("SELECT * FROM METADATA.CONFIG_RELEASE WHERE pipeline_code=:p AND release_status='ACTIVE'",p=pipeline_code)
        if not release:
            raise ValueError('Pipeline requires an ACTIVE metadata release.')
        task=fw._task(release,task_code)
        if task['task_type']!='INGESTION':
            raise ValueError('An INGESTION task must create the batch before downstream tasks run.')
    else:
        task=fw._task(batch,task_code)
    if task['task_type']=='INGESTION':
        batch=fw.start_batch(execution_key,cycle_date,execution_mode,
            orchestrator_run_id=orchestrator_run_id,triggered_by=triggered_by)
    else:
        if cycle_date and str(batch['cycle_date'])[:10]!=cycle_date:
            raise ValueError('Cycle date conflicts with the pinned batch.')
        if execution_mode and batch['batch_type']!=execution_mode:
            raise ValueError('Execution mode conflicts with the pinned batch.')
    return fw.execute_task(batch['batch_id'],task_code,custom_steps=custom_steps,
        orchestrator_task_run_id=task_run_id,orchestrator_attempt_number=orchestrator_attempt_number)


def execute_task(**settings):
    """Run one task using DB environment variables; always close its connection."""
    db=OracleDb()
    try:
        result=_run_task(db,**settings)
        print(json.dumps({k:result[k] for k in ('batch_id','task_run_id','status','input_count','output_count')},default=str))
        return result
    finally:
        db.close()


def finalize_failed_batch(*, pipeline_code, execution_key):
    """Call after scheduler retries are abandoned and all active writers have stopped."""
    db=OracleDb()
    try:
        fw=MetadataFramework(db,pipeline_code)
        batch=fw.get_batch_by_execution_key(execution_key)
        if not batch:
            raise ValueError('No batch exists for this pipeline/execution_key.')
        fw.fail_batch(batch['batch_id'])
    finally:
        db.close()
