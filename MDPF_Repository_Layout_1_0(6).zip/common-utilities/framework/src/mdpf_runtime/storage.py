"""OCI paths and I/O through the Spark session's configured Hadoop connector."""
import hashlib
from pathlib import PurePosixPath
from urllib.parse import urlsplit


def object_address(uri):
    parts = urlsplit(str(uri))
    if parts.scheme != "oci" or "@" not in parts.netloc or parts.query or parts.fragment:
        raise ValueError("Use oci://bucket@namespace/object-key (no query or fragment).")
    bucket, namespace = parts.netloc.split("@", 1)
    key = parts.path.lstrip("/")
    if not bucket or not namespace or ".." in PurePosixPath(key).parts:
        raise ValueError("Invalid OCI object address.")
    return namespace, bucket, key


class ObjectStorage:
    def __init__(self, spark=None):
        self.spark = spark

    def _filesystem(self, uri):
        from pyspark.sql import SparkSession
        session = self.spark or SparkSession.getActiveSession()
        if session is None:
            raise RuntimeError('Quarantine requires the configured active Spark storage connector.')
        path = session._jvm.org.apache.hadoop.fs.Path(uri)
        return path.getFileSystem(session.sparkContext._jsc.hadoopConfiguration()), path

    @staticmethod
    def _stream_digest(stream, output=None):
        checksum, size = hashlib.sha256(), 0
        while True:
            chunk = bytes(stream.readNBytes(1024 * 1024))
            if not chunk:
                break
            checksum.update(chunk)
            size += len(chunk)
            if output is not None:
                output.write(bytearray(chunk))
        return size, checksum.hexdigest()

    def quarantine_file(self, source, destination):
        """Stream original bytes, retain Landing and verify the complete destination.

        The same connector/authentication as Parquet I/O is used. No server-side
        copy, OCI CLI or independent OCI SDK client. A retry replaces its own object.
        """
        src_ns, src_bucket, source_key = object_address(source)
        dst_ns, dst_bucket, dest_key = object_address(destination)
        if not source_key or not dest_key or (src_ns, src_bucket) == (dst_ns, dst_bucket):
            raise ValueError('Quarantine requires an exact object in a dedicated bucket.')
        source_fs, source_path = self._filesystem(source)
        dest_fs, dest_path = self._filesystem(destination)
        before = source_fs.getFileStatus(source_path)
        reader = source_fs.open(source_path)
        try:
            writer = dest_fs.create(dest_path, True)
            try:
                size, checksum = self._stream_digest(reader, writer)
            finally:
                writer.close()
        finally:
            reader.close()
        after = source_fs.getFileStatus(source_path)
        if (size != before.getLen() or before.getLen() != after.getLen() or
                before.getModificationTime() != after.getModificationTime()):
            raise RuntimeError('Landing object changed or the source stream was incomplete during quarantine.')
        if dest_fs.getFileStatus(dest_path).getLen() != size:
            raise RuntimeError('Quarantine size verification failed.')
        reader = dest_fs.open(dest_path)
        try:
            verified_size, verified_checksum = self._stream_digest(reader)
        finally:
            reader.close()
        if (verified_size, verified_checksum) != (size, checksum):
            raise RuntimeError('Quarantine checksum verification failed.')
        return dict(size_bytes=size, checksum_sha256=checksum)

    def read_parquet(self, spark, location):
        if not object_address(location)[2]:
            raise ValueError("An exact OCI object prefix is required.")
        return spark.read.parquet(location)

    def write_parquet(self, location, df):
        if not object_address(location)[2]:
            raise ValueError("An exact OCI object prefix is required.")
        df.write.mode("overwrite").parquet(location)
