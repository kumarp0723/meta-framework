"""Connector byte streaming, verification and failure paths; no OCI server copy."""
import hashlib
from io import BytesIO
from types import SimpleNamespace

import pytest

from mdpf_runtime.storage import ObjectStorage

SOURCE='oci://landing@ns/feed.parquet'
DEST='oci://quarantine@ns/raw/fee/batch_id=1/fee/feed.parquet'


class Reader(BytesIO):
    def readNBytes(self, count):return self.read(count)


class Writer(BytesIO):
    def __init__(self, fs, path):super().__init__();self.fs=fs;self.path=path
    def close(self):
        if not self.closed:
            data=self.getvalue()
            if self.fs.fault=='size':data=data[:-1]
            if self.fs.fault=='checksum':data=bytes([data[0]^1])+data[1:]
            self.fs.objects[self.path]=data
        super().close()


class Connector:
    def __init__(self,data,fault=None):
        self.objects={SOURCE:data,DEST:b'old-object'};self.fault=fault;self.opened=[];self.created=[]
    def getFileStatus(self,path):
        return SimpleNamespace(getLen=lambda:len(self.objects[path]),getModificationTime=lambda:1)
    def open(self,path):self.opened.append(path);return Reader(self.objects[path])
    def create(self,path,overwrite):
        assert overwrite;self.created.append(path)
        if self.fault=='write':raise RuntimeError('Connector denied write')
        return Writer(self,path)


@pytest.mark.parametrize('size',[0,1,2*1024*1024+17])
def test_original_bytes_are_streamed_verified_and_landing_retained(monkeypatch,size):
    data=(bytes(range(256))*((size+255)//256))[:size]
    fs=Connector(data);storage=ObjectStorage()
    monkeypatch.setattr(storage,'_filesystem',lambda uri:(fs,uri))
    proof=storage.quarantine_file(SOURCE,DEST)
    assert fs.objects[SOURCE]==fs.objects[DEST]==data
    assert proof==dict(size_bytes=size,checksum_sha256=hashlib.sha256(data).hexdigest())
    assert fs.opened==[SOURCE,DEST] and fs.created==[DEST]


@pytest.mark.parametrize('fault,match',[('size','size verification'),('checksum','checksum verification'),('write','denied write')])
def test_failed_copy_never_returns_success_evidence(monkeypatch,fault,match):
    data=b'original bytes\x00\xff';fs=Connector(data,fault);storage=ObjectStorage()
    monkeypatch.setattr(storage,'_filesystem',lambda uri:(fs,uri))
    with pytest.raises(RuntimeError,match=match):storage.quarantine_file(SOURCE,DEST)
    assert fs.objects[SOURCE]==data


def test_same_bucket_is_rejected_before_io(monkeypatch):
    storage=ObjectStorage();monkeypatch.setattr(storage,'_filesystem',lambda uri:pytest.fail('No I/O'))
    with pytest.raises(ValueError,match='dedicated bucket'):
        storage.quarantine_file(SOURCE,'oci://landing@ns/rejected/feed.parquet')
