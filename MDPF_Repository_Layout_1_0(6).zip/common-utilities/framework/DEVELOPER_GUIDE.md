# MDPF developer guide

Start here, then follow the [production DMI_FEE walkthrough](../../data-pipelines/providers/dmi/README.md).
This guide covers local setup and how the code fits together. The walkthrough
covers generation, deployment and one real pipeline run.

MDPF executes one task per call. A scheduler launches RAW, STAGE and MAIN in order.
The generator prepares configuration/SQL; it does not execute the pipeline.

## Vocabulary and overall flow

| Term | Meaning |
|---|---|
| Pre-onboarding builder | Optional catalog/profile tool that prepares input YAMLs |
| SQL Generator | Reads YAML and samples, then prepares complete YAML and deployment SQL |
| Metadata release | A versioned pipeline definition; a batch keeps its selected release |
| Batch | One workflow execution, identified by a stable execution key and internal batch ID |
| Attempt | One task execution; each retry gets a new task-run ID |
| RAW | Source-preserving Parquet, with receipt/attempt lineage |
| STAGE | Transformed and validated Parquet |
| MAIN | ADW business tables; metadata calls this dataset layer GOLD |

This diagram shows dependencies and artifacts. The tables below show actual calls.

```mermaid
flowchart TD
    B["Optional profile and catalog"] --> Y["Input YAML"]
    E["Existing input YAML"] --> Y
    Y --> G["Generator"]
    G --> A["Complete YAML and deployment SQL"]
    A --> D["Manual review and deployment"]
    D --> M["ATP metadata and ADW targets"]
    S["Scheduler task"] --> F["Framework"]
    M --> F
    F --> O["Parquet and MAIN outputs"]
    F --> R["ATP execution history"]
```

Existing YAML and the catalog builder are alternative starting points. The
provider owns business configuration and transformations; the shared utilities
own execution, validation and history.

## What you can run

| Environment | Actions |
|---|---|
| Local Python/Java | Install dependencies, review YAML and run Spark tests with SQLite/OCI adapters |
| OCI notebook | Read profile/catalog/config/samples and generate artifacts; requires SDK and Spark bucket access |
| ATP and ADW | Install control schemas, deploy generated SQL, inspect targets and activate metadata |
| OCI + databases + chosen platform | Run the complete DMI_FEE workflow |

Without provisioned infrastructure, run local tests and read the walkthrough.
The public generator takes OCI URIs; it has no local-file execution mode. Local
tests use adapters. The full example does not run offline.

## Local setup and checks

Use Python 3.10+ and Java 17. Start in **`common-utilities/`** with the three
repository roots side by side, as in the delivered ZIP:

```bash
python -m venv .venv
source .venv/bin/activate
python --version
java -version
python -m pip install -e './framework[test]' -e './generator[test]' -e './test-support' -e '../data-pipelines/providers/dmi[test]'
python -m pip check
python -c "import mdpf_runtime, mdpf_onboarding, provider_dmi; print(mdpf_runtime.__version__, mdpf_onboarding.__version__, provider_dmi.__version__)"
mdpf-onboard --help
python -m pip wheel --no-deps --wheel-dir framework/dist ./framework
python -m pip wheel --no-deps --wheel-dir test-support/dist ./test-support
python -m pip wheel --no-deps --wheel-dir ../data-pipelines/providers/dmi/dist ../data-pipelines/providers/dmi
MDPF_CHECK_DIR=$(mktemp -d)
export MDPF_FRAMEWORK_BUNDLE="$MDPF_CHECK_DIR/mdpf_runtime-1.0-release.zip"
python framework/scripts/package_release.py --output "$MDPF_FRAMEWORK_BUNDLE"
python -m pytest -q framework/tests
python -m pytest -q generator/tests
python -m pytest -q ../data-pipelines/providers/dmi
```

Expected: three `1.0` versions, CLI help, no broken dependencies and passing local
tests. Live Oracle setup tests skip unless explicitly enabled. The test profile
uses PySpark 3.5.7; installation needs an approved dependency source. Use the
supplied sources and approved wheels for these exact package versions.

The repository `.gitignore` excludes test files, development test support and `dist/` outputs.
They remain in the downloadable ZIP for local validation; use that complete source copy
for the test commands below. A Git clone alone does not contain those ignored assets.
Build wheels before packaging tests. Keep one
wheel per package there. The temporary Framework bundle above is for local tests;
production packaging uses an approved release and trusted checksum. The supplied
ZIP already includes wheels/review bundles. A new output path avoids overwrite
errors when repeating a check.

For a focused source change, run relevant test files from the same working directory:

```bash
python -m pytest -q generator/tests/test_dmi_fee.py generator/tests/test_two_databases.py
```

Local tests exercise Spark and adapters, not real Oracle transactions or platform
permissions. See [VALIDATION.txt](../../VALIDATION.txt) for actual build evidence.

## Standalone provider checkout

Without utility source, start in **`data-pipelines/providers/dmi/`** and use approved
downloads. Set the path below to your local approved artifact directory:

```bash
python -m venv .venv
source .venv/bin/activate
DOWNLOADS="/path/to/approved/downloads"
python -m pip install "$DOWNLOADS/mdpf_runtime-1.0-py3-none-any.whl" "$DOWNLOADS/mdpf_onboarding-1.0-py3-none-any.whl" "$DOWNLOADS/mdpf_test_support-1.0-py3-none-any.whl" -e '.[test]'
python -m pip check
python -m pip wheel --no-deps --wheel-dir dist .
export MDPF_FRAMEWORK_BUNDLE="$DOWNLOADS/mdpf_runtime-1.0-release.zip"
python -m pytest -q
```

Expected: all provider checks pass using installed packages and the approved Framework bundle.
No sibling utility checkout is needed. Missing required test packages or a bundle fail the
check; they do not silently skip integration. Use `-m 'not integration'` only when deliberately
selecting a smaller test run. `mdpf-test-support` is a development dependency, excluded from
platform release bundles.

## Prepare for the live walkthrough

Use [Framework installation](README.md#fresh-atp-installation) for ATP and the
[connection reference](REFERENCE.md#separate-atp-and-adw-connections) for both
required database configurations. The application runs with separate ATP and ADW
accounts. Wallet settings are independent. Owner accounts are schema-only.

The Python OCI SDK and Spark connector need access separately. The SDK defaults
to Resource Principal authentication; `client=` accepts an approved existing SDK
client. Check a sample HEAD using the SDK and a sample read using Spark. Use the
[OCI permissions guide](OPERATIONS.md#oci-permissions) for the required operations.
Both source and generated artifact paths must match the reviewed environment.

Install the approved utility/provider wheels on the platform, use its Spark/Java,
and restart Python sessions when replacing version 1.0. `--no-deps` is appropriate
only when dependencies are already installed. Follow the DMI_FEE walkthrough once
connectivity and installation are ready.

## Generation call flow

| Caller / function | Next action |
|---|---|
| `bulk_builder.build_catalog()` (optional) | Read profile/catalog, call builder/config helpers, check conflicts/sample existence and optionally save input YAMLs |
| `onboard.generate()` → `_load_config()` | Read input YAML and normalize it with `config.validate_config()` |
| `generate()` baseline handling | Compile the previous complete schema without reading its samples |
| `generate()` → `schema_discovery.read_sample()` | Spark reads current samples; infer missing definitions or validate explicit ones |
| `generate()` → `metadata_generator.build_metadata()` | Build dataset/task/step/policy rows and validate sample conversions |
| `generate()` → `complete_config()` / `sql_renderer` | Render complete YAML, metadata SQL and enabled MAIN DDL |
| `generate()` → `client.put_object()` | Upload YAML, optional DDL and metadata SQL last; return the metadata SQL URI |

`onboard.py` coordinates the workflow. `config.py` already calls model helpers for
plan/location checks, so this is not simply a three-module sequential chain.
Import rendering from sql_renderer.py, verification from oracle_gate.py and validators
from config.py. Removed compatibility re-exports are not available to old callers.

`oracle_gate.verify_main_targets()` is a separate read-only check after SQL
deployment. Generation never calls it. OCI uploads are independent; earlier
artifacts can remain after a later upload fails. Template-only mode exits before
sample/Spark work and produces incomplete YAML only.

## Execution call flow

1. The launcher calls `mdpf_runtime.aidp.execute_task()` or `mdpf_runtime.dataflow.execute_task()`.
   A prepared manual notebook can instead call `mdpf_runtime.runner.execute_task()`.
2. `runner._run_task()` checks identities/settings and constructs `MetadataFramework`.
   RAW creates/resolves the batch and pins the ACTIVE release. Downstream tasks
   reuse that batch and reject conflicting date/mode overrides.
3. `MetadataFramework.execute_task()` records an attempt. `_resolve_plan()` delegates
   to `metadata.resolve_plan()`; `_prepare_dataflow()` delegates to
   `metadata.prepare_dataflow()`. Required handlers/paths/schemas are checked before I/O.
4. The loop calls a `steps.BUILTINS` handler or a registered custom callable.
   Built-ins receive internal context; custom functions receive read-only public
   context and return dataset-keyed Spark DataFrames.
5. `READ_SOURCE` records the receipt through `_receive_source()` before reading.
   `READ_PARQUET` checks producer completion/lineage. Mapping/custom functions
   prepare frames; DQ calculates and persists policy results.
6. `WRITE_PARQUET` writes output/audit fields. `LOAD_MAIN` prepares bounded rows;
   `_complete()` inserts/reconciles them in ADW, then records completion in ATP.
7. The outer failure path records failed attempts and work items. The scheduler
   retries using the same workflow key and a new attempt identity.

See [platform launchers](../README.md#shared-launchers),
[handler/API definitions](REFERENCE.md#public-api-contracts) and
[recovery](OPERATIONS.md#atpadw-setup-and-controlled-main-recovery) for exact inputs.

## Transaction ownership

| Module | Responsibility |
|---|---|
| `pipeline.py` | Execution decisions, locks, lifecycle checks and transaction boundaries |
| `db.py` | Connections, binds and commit/rollback context manager |
| `runtime.py` | Runtime/policy/event/work-item persistence inside the caller's transaction; no independent commits |
| `steps.py` / `storage.py` | Spark/OCI I/O, outside Oracle transactions |
| `dq.py` | Rule calculation and result formatting |

MAIN's ADW commit and ATP completion are separate. An ATP failure cannot undo
committed ADW rows; see the operational recovery procedure before retry. Parquet
writes are also outside ATP transactions. Use facade lifecycle methods rather
than calling internal persistence helpers as independent operations.

## Which module should I change?

| Change | Starting files | Focused tests under generator/tests unless noted |
|---|---|---|
| DQ | Framework `dq.py`, `steps.py`; Generator `config.py`, `metadata_generator.py` | `test_dq_basic.py`, `test_dq_sql.py`, `test_enhancements.py` |
| Audit persistence | `runtime.py`, caller in `pipeline.py` | `test_modularization.py`, `test_enhancements.py` |
| Task execution/retry | `pipeline.py`, `runner.py`, platform adapter | `test_raw_repair.py`, `test_platforms.py` |
| Metadata lookup | `metadata.py` | `test_plans.py`, `test_raw_repair.py` |
| YAML field or upstream JSON | `config.py`, builders and `metadata_generator.py` | `test_config.py`, `test_bulk_builder.py`, `test_upstream_config.py` |
| SQL/DDL | `sql_renderer.py` and model inputs | `test_templates.py`, `test_main_ddl.py`, `test_baseline.py` |
| Oracle target check | `oracle_gate.py` | `test_oracle_gate.py`, `test_two_databases.py` |
| Parquet paths/templates | Generator config/model; Framework `metadata.py`, `steps.py` | `test_parquet_templates.py` |
| Vault | Framework `vault.py` | Framework `tests/test_vault.py` |
| Business transform | Provider `src/`, registration in its `entrypoints/`, provider YAML | Provider `tests/` and `datasets/fee/tests/` |
| Installer/lifecycle SQL | Framework `sql/`, matching generator DDL fixture | Framework `test_sql_setup.py`, opt-in `test_oracle_setup.py` |

A persisted field needs matching DDL/model/renderer/tests. Keep published metadata
immutable. Prefer the existing validation/rendering/persistence helper instead of
adding a second rule engine or a service for each table.

## Oracle-only setup tests

Ordinary local tests need no credentials. On a **dedicated disposable ATP only**,
set these through the secure test environment:

```text
MDPF_TEST_ORACLE_RESET=DROP_MDPF_DEV_SCHEMAS
MDPF_TEST_ORACLE_DSN=<dedicated ATP service>
MDPF_TEST_ORACLE_PASSWORD=<securely injected ADMIN password>
MDPF_TEST_ORACLE_DB_NAME=<exact SYS_CONTEXT USERENV DB_NAME>
```

Optional settings use that prefix with CONFIG_DIR, WALLET_LOCATION and
WALLET_PASSWORD. From `common-utilities/framework/`, run
`python -m pytest -q tests/test_oracle_setup.py`. The explicit opt-in permits removal
of the four dedicated ATP accounts before/after tests. It never uses normal
MDPF_DB credentials or connects to ADW. Coverage includes installation, application
access, lifecycle/terminal guards, constraint failures and reset/reinstall.
SQLcl's masked password prompt still needs a manual smoke test. Concurrent Oracle
sessions and live platform behavior need separate environment checks.

## Learning-path acceptance

Have someone unfamiliar with MDPF follow local setup and the production walkthrough
in a prepared environment without verbal help. Fix any step needing explanation.
That human walkthrough remains pending; automated checks do not replace it. See
[environment validation](OPERATIONS.md#live-validation-checklist) and
[VALIDATION.txt](../../VALIDATION.txt).

## Basic logging

Libraries use Python logging without configuring the root logger on import.
The supplied AIDP/Data Flow launchers, bulk notebook and onboarding CLI enable
INFO messages for their package. For direct notebook/API calls, configure once:

```python
import logging
logging.basicConfig(format='%(asctime)s %(levelname)s %(name)s %(message)s')
logging.getLogger('mdpf_runtime').setLevel(logging.INFO)
logging.getLogger('mdpf_onboarding').setLevel(logging.INFO)
```

Runtime INFO covers task start and committed completion with batch/run IDs and
counts. Errors record task/step and exception type; quarantine copies are warnings.
Task plans and individual steps are DEBUG only. Onboarding logs catalog start and
counts, failed row IDs, created configurations and generated artifacts. Review the
returned row message or propagated exception for error details. Logs do not dump
credentials, upstream JSON, sample rows or full exception text. Existing generation
summaries and machine-readable platform results remain available. Database audit
records remain authoritative; console logs are diagnostic.

Builder destinations and prefix/template precedence are explained in the
[generator reference](../generator/REFERENCE.md#builder-artifact-locations).


## Before adopting the strict path build

Regenerate old configurations and review new metadata under a new release before
using these wheels. CSV landing, prefix-only outputs, batch_<id> appending,
.parquet output folder names are rejected. Quarantine mirrors the paired RAW folder. Complete
in-flight old batches with the previous runtime. CSV catalogs and onboarding samples
remain supported. Quarantine mirrors the paired RAW folder, preserves the source filename, and
replaces the same-batch destination only with verified original bytes. Import utilities from their owner modules.
Keep approved prior release artifacts for recovery. No data relocation is automatic.
