"""Offline Oracle metadata SQL and reviewed MAIN DDL rendering."""

from mdpf_runtime import schema as mdpf_schema
from mdpf_runtime.schema import sql_identifier, spark_type

from . import __version__


def literal(value):
    if value is None:return 'NULL'
    if isinstance(value,int) and not isinstance(value,bool):return str(value)
    return "'"+str(value).replace("'","''")+"'"


def clob_literal(value):
    # Bound SQL*Plus lines and Oracle literal sizes for JSON and DDL text.
    chunks=[value[i:i+400] for i in range(0,len(value),400)] or ['']
    return 'TO_CLOB('+literal(chunks[0])+')'+''.join(' ||\n      '+literal(c) for c in chunks[1:])


def expression(name,value,compact=False):
    if isinstance(value,dict):
        parts=['CASE v_env', *('WHEN '+literal(env)+' THEN '+literal(value[env]) for env in ('DEV','STAGE','PROD')), 'END']
        if compact and len(' '.join(parts).encode('utf-8')) < 2000:
            return ' '.join(parts)
        return '\n      '.join(parts)
    if name in ('parameter_json', 'upstream_config') and value is not None:
        return clob_literal(value)
    return literal(value)


def render_sql(model, config_bytes):
    """Return an Oracle script inserting a complete new DRAFT release from model tables.

    config_bytes is retained as an API argument; no hash comments are emitted.
    The script uses :target_env and a release sequence. Rendering is offline
    and never executes SQL, activates metadata or changes an existing release."""
    lines=[f'-- MDPF SQL Generator {__version__}; business schemas: LANDING=RAW, STAGE=MAIN.',
        '-- Caller must set bind :target_env to DEV, STAGE or PROD. This script creates DRAFT only.',
        'SET DEFINE OFF','SET AUTOCOMMIT OFF','SET SERVEROUTPUT ON','WHENEVER OSERROR EXIT FAILURE ROLLBACK',
        'WHENEVER SQLERROR EXIT SQL.SQLCODE ROLLBACK','DECLARE',
        '  v_env VARCHAR2(10) := :target_env;', '  v_release_id NUMBER(19);','BEGIN',
        "  IF v_env IS NULL OR v_env NOT IN ('DEV','STAGE','PROD') THEN",
        "    RAISE_APPLICATION_ERROR(-20001, 'target_env must be DEV, STAGE or PROD');",'  END IF;',
        '  SELECT METADATA.SEQ_CONFIG_RELEASE.NEXTVAL INTO v_release_id FROM DUAL;']
    for table,rows in model['tables'].items():
        if not rows:
            continue
        lines.append('\n  -- '+table)
        if table=='DATASET_COLUMN':
            groups={}
            for row in rows:
                groups.setdefault(row['dataset_id'],[]).append(row)
            for group in groups.values():
                columns=['config_release_id',*group[0]]
                lines.append(f'  INSERT INTO METADATA.{table} ({", ".join(columns)})')
                for index,row in enumerate(group):
                    values=['v_release_id',*[expression(k,v,compact=True) for k,v in row.items()]]
                    prefix='  SELECT ' if index==0 else '  UNION ALL SELECT '
                    lines.append(prefix+', '.join(values)+' FROM DUAL'+(';' if index==len(group)-1 else ''))
            continue
        for row in rows:
            columns=['config_release_id',*row]
            values=['v_release_id',*[expression(k,v,compact=True) for k,v in row.items()]]
            if table=='CONFIG_RELEASE':columns.append('effective_from');values.append('SYSTIMESTAMP')
            header=f'  INSERT INTO METADATA.{table} ({", ".join(columns)})'
            statement=header+' VALUES ('+', '.join(values)+');'
            if '\n' not in statement and len(statement.encode('utf-8')) < 2400:
                lines.append(statement)
            else:
                values=['v_release_id',*[expression(k,v) for k,v in row.items()]]
                if table=='CONFIG_RELEASE':values.append('SYSTIMESTAMP')
                lines += [header, '  VALUES (', '    '+',\n    '.join(values)+');']
    lines += ['  COMMIT;',"  DBMS_OUTPUT.PUT_LINE('Created DRAFT release ' || v_release_id || ' for ' || v_env);",
              'EXCEPTION','  WHEN OTHERS THEN ROLLBACK; RAISE;','END;','/','']
    return '\n'.join(lines)


def _column_ddl(column):
    kind=column['data_type']
    if kind=='VARCHAR2':
        length,unit=mdpf_schema.string_limit(column)
        if length*(4 if unit=='CHAR' else 1)>4000:
            raise ValueError('Sample MAIN DDL uses STANDARD/AL32UTF8 capacity: at most 4000 BYTE or 1000 CHAR. Provide reviewed DDL separately for larger contracts.')
        kind=f'VARCHAR2({length} {unit})'
    elif kind=='NUMBER':kind=f"NUMBER({column['length_precision_scale']})"
    elif kind=='TIMESTAMP':kind='TIMESTAMP(6)'
    return column['column_name']+' '+kind+(' NOT NULL' if column['is_nullable']=='N' else '')


def render_main_ddl(model, config_bytes, *, baseline=None):
    """Return reviewed MAIN CREATE/ALTER proposals from current and optional baseline models.

    Render supported additions/widening and mark unsafe/ambiguous changes for manual
    review. No Oracle inspection, DDL execution, automatic DROP or backfill occurs."""
    lines=[f'-- MDPF SQL Generator {__version__}; MAIN table DDL for review.',
        '-- PROPOSAL ONLY: no Oracle inspection; compare with actual tables before running.',
        '-- Owners/grants are DBA responsibilities. No automatic DROP, rename or execution.',
        '-- Oracle DDL commits independently; later failure does not undo earlier statements.',
        'SET DEFINE OFF', 'SET SERVEROUTPUT ON', 'WHENEVER OSERROR EXIT FAILURE',
        'WHENEVER SQLERROR EXIT SQL.SQLCODE', 'DECLARE',
        '  v_env VARCHAR2(10) := :target_env;', 'BEGIN',
        "  IF v_env IS NULL OR v_env NOT IN ('DEV','STAGE','PROD') THEN",
        "    RAISE_APPLICATION_ERROR(-20001, 'target_env must be DEV, STAGE or PROD');", '  END IF;']
    for spec in model['datasets'].values():
        row=spec['row']
        if row['layer']!='GOLD' or row['storage_type']!='ADB_TABLE':
            continue
        targets={env:sql_identifier(row['physical_object_name'][env],qualified=True)
                 for env in ('DEV','STAGE','PROD')}
        columns=sorted(spec['columns'],key=lambda c:c['column_sequence'])
        mdpf_schema.validate_columns(columns)
        definitions=[_column_ddl(c) for c in columns]
        code=row['dataset_code'];previous=baseline['datasets'].get(code) if baseline else None
        lines.append('\n  -- '+code)
        if baseline:
            lines.append('  -- Audit contract: existing MAIN must have CREATED_AT/UPDATED_AT TIMESTAMP(6) WITH TIME ZONE NOT NULL.')
            lines.append('  -- Missing audit columns require a reviewed ADW-only migration before this proposal; no ATP history lookup is performed.')
        if baseline and previous is None:
            old_targets=[s for s in baseline['datasets'].values() if s['row']['storage_type']=='ADB_TABLE']
            previous=next((s for s in old_targets if s['row']['physical_object_name']==targets),None)
            if previous is None and any(s['row']['physical_object_name'][e]==targets[e] for s in old_targets for e in targets):
                lines += ['  -- MANUAL REVIEW: target overlaps a previous dataset in some environments.', '  NULL;']
                continue
        statements=[]
        if previous is None:
            definitions += [name+' NUMBER(19) NOT NULL' for name in ('BATCH_ID','TASK_RUN_ID','ROW_NUMBER')]
            definitions += [name+' TIMESTAMP(6) WITH TIME ZONE NOT NULL' for name in ('CREATED_AT','UPDATED_AT')]
            statements.append(('CREATE TABLE ',' (\n    '+',\n    '.join(definitions)+'\n)'))
        elif previous['row']['physical_object_name']!=targets:
            lines.append('  -- MANUAL REVIEW: target name/owner changed; no automatic rename or CREATE.')
        else:
            before={c['column_name']:c for c in previous['columns']}
            after={c['column_name']:c for c in columns}
            for name in sorted(before.keys()-after.keys()):
                lines.append(f'  -- MANUAL REVIEW: {name} removed from metadata; no automatic DROP/rename.')
            for column in columns:
                name=column['column_name'];old=before.get(name)
                if old is None:
                    if column['is_nullable']=='N':
                        lines.append(f'  -- MANUAL REVIEW: adding NOT NULL {name} requires a data backfill/default decision.')
                    else:statements.append(('ALTER TABLE ',' ADD ('+_column_ddl(column)+')'))
                    continue
                old_type=spark_type(old);new_type=spark_type(column)
                same=(old_type==new_type and old.get('length_precision_scale')==column.get('length_precision_scale'))
                widening=(old['data_type']==column['data_type']=='VARCHAR2' and
                    mdpf_schema.string_limit(old)[1]==mdpf_schema.string_limit(column)[1] and
                    mdpf_schema.string_limit(old)[0]<=mdpf_schema.string_limit(column)[0])
                if not same and not widening:
                    lines.append(f'  -- MANUAL REVIEW: {name} datatype/capacity change; no automatic conversion or narrowing.')
                elif old['is_nullable']=='Y' and column['is_nullable']=='N':
                    lines.append(f'  -- MANUAL REVIEW: {name} becomes NOT NULL; validate/backfill existing rows.')
                elif not same or old['is_nullable']!=column['is_nullable']:
                    definition=_column_ddl(dict(column,is_nullable='Y'))
                    if old['is_nullable']=='N' and column['is_nullable']=='Y':definition+=' NULL'
                    statements.append(('ALTER TABLE ',' MODIFY ('+definition+')'))
        if not statements:lines.append('  NULL; -- No supported automatic table changes for this target.')
        for command,body in statements:
            lines.append('  EXECUTE IMMEDIATE TO_CLOB('+literal(command)+') || '+expression('target',targets)+' ||\n    '+clob_literal(body)+';')
    if baseline:
        for code in sorted(baseline['datasets'].keys()-model['datasets'].keys()):
            if baseline['datasets'][code]['row']['storage_type']=='ADB_TABLE':
                lines.append(f'  -- MANUAL REVIEW: {code} removed; retained physical table is not dropped.')
    lines += ['END;', '/', '']
    return '\n'.join(lines)
