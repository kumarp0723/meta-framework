"""Inspect all sample rows; CSV values and delivery schemas are separate contracts."""
from datetime import date, datetime
from decimal import Decimal, InvalidOperation
import logging
import math
import re

from pyspark.sql import functions as F, types as T
from mdpf_runtime.schema import RESERVED, convert_frame, spark_type, sql_identifier, validate_columns, validate_frame

logger = logging.getLogger(__name__)
CSV_OPTIONS = {'delimiter', 'quote', 'escape', 'encoding', 'multiLine',
               'ignoreLeadingWhiteSpace', 'ignoreTrailingWhiteSpace', 'nullValue',
               'emptyValue', 'timestampFormat'}
NUMBER_TEXT = re.compile(r'^[+-]?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[eE][+-]?[0-9]+)?$')
TIMESTAMP_TEXT = re.compile(r'^[0-9]{4}-[0-9]{2}-[0-9]{2}[T ][0-9]{2}:[0-9]{2}:[0-9]{2}(?:\.[0-9]{1,6})?(?:Z|[+-][0-9]{2}:[0-9]{2})?$')


class SchemaOverridesRequired(ValueError):
    """All empty columns that still need an explicit schema contract."""
    def __init__(self, columns):
        self.columns = columns
        super().__init__('All-null sample columns require datatype/length overrides: ' + ', '.join(columns))


def validate_csv_options(options, null_values):
    if not isinstance(options, dict) or set(options) - CSV_OPTIONS:
        raise ValueError('csv_options contains unsupported settings: ' + ', '.join(sorted(CSV_OPTIONS)))
    for name, value in options.items():
        if name in ('multiLine', 'ignoreLeadingWhiteSpace', 'ignoreTrailingWhiteSpace'):
            if not isinstance(value, bool):raise ValueError(name + ' must be boolean.')
        elif not isinstance(value, str) or (name not in ('nullValue', 'emptyValue', 'quote', 'escape') and not value):
            raise ValueError(name + ' must be text.')
        if name in ('quote', 'escape') and len(value) > 1:
            raise ValueError(name + ' must contain at most one character.')
    if not isinstance(null_values, (list, tuple)) or any(not isinstance(v, str) for v in null_values):
        raise ValueError('null_values must contain text tokens.')


def _nulls(df, null_values=()):
    tokens = ['', *[v.strip() for v in null_values]]
    return df.select(*[F.when(F.trim(F.col(n)).isin(tokens), F.lit(None)).otherwise(F.col(n)).alias(n)
                       if isinstance(df.schema[n].dataType, T.StringType) else F.col(n) for n in df.columns])


def read_sample(spark, path, *, csv_options=None, null_values=()):
    if path.lower().endswith('.parquet'):
        df = spark.read.parquet(path)
    else:
        options = {} if csv_options is None else csv_options
        validate_csv_options(options, null_values)
        settings = dict(header=True, inferSchema=False, mode='FAILFAST', multiLine=True, escape='"', unescapedQuoteHandling='RAISE_ERROR')
        settings.update(options)
        logger.info('CSV_SETTINGS path=%s options=%s null_values=%s', path, settings, list(null_values))
        df = _nulls(spark.read.options(**settings).csv(path), null_values)
    if not df.columns or len({c.upper() for c in df.columns}) != len(df.columns):
        raise ValueError(f'Duplicate or missing sample headers: {path}')
    return df


def validate_overrides(overrides, *, source):
    if not isinstance(overrides, dict):raise ValueError('Column overrides must be a mapping.')
    for name, override in overrides.items():
        sql_identifier(name)
        if name in RESERVED or not isinstance(override, dict) or set(override) - {
                'data_type', 'length_precision_scale', 'is_nullable', 'is_pii'}:
            raise ValueError(f'Invalid column override: {name}')
        for flag in ('is_nullable', 'is_pii'):
            if flag in override and override[flag] not in ('Y', 'N'):raise ValueError(f'{flag} must be Y or N: {name}')
        kind, spec = override.get('data_type'), override.get('length_precision_scale')
        if 'data_type' in override and kind not in ('VARCHAR2', 'NUMBER', 'DATE', 'TIMESTAMP'):
            raise ValueError(f'Unsupported override data_type: {name}')
        if spec is not None and (not isinstance(spec, str) or not spec.strip() or len(spec.encode('utf-8')) > 100):
            raise ValueError(f'length_precision_scale must be text of at most 100 bytes: {name}')
        if kind and (spec is not None or kind in ('DATE', 'TIMESTAMP')):spark_type(override)


def explicit_columns(entries, *, source):
    if not isinstance(entries, list) or not entries:raise ValueError('columns must be a nonempty ordered list.')
    result = []
    for index, entry in enumerate(entries, 1):
        if (not isinstance(entry, dict) or not {'column_name', 'data_type'} <= entry.keys() or
                set(entry) - {'column_name', 'data_type', 'length_precision_scale', 'is_nullable', 'is_pii'}):
            raise ValueError('columns entries require column_name/data_type; optional length_precision_scale/is_nullable/is_pii.')
        column = {'length_precision_scale': None, 'is_nullable': 'Y', 'is_pii': 'N', **entry}
        if column['is_pii'] not in ('Y', 'N'):raise ValueError('is_pii must be Y or N.')
        result.append(dict(column_sequence=index, **column))
    validate_columns(result)
    return result


def convert_sample(df, columns, *, timestamp_format=None):
    """Configured sample timestamp parsing; processing metadata stays TIMESTAMP(6)."""
    if timestamp_format:
        expressions = []
        for column in columns:
            name = column['column_name']
            value = F.col(name)
            if column['data_type'] == 'TIMESTAMP' and isinstance(df.schema[name].dataType, T.StringType):
                parsed = F.try_to_timestamp(F.trim(value), F.lit(timestamp_format))
                invalid = value.isNotNull() & (parsed.isNull() | value.rlike(r'\.[0-9]{7,}'))
                if df.where(invalid).limit(1).count():
                    raise ValueError(f'Sample timestamp conversion failed: {name}; incoming=string, expected=timestamp; pattern={timestamp_format}.')
                value = parsed
            expressions.append(value.alias(name))
        df = df.select(*expressions)
    return convert_frame(df, columns)


def validate_sample(df, columns, *, source, timestamp_format=None):
    from mdpf_runtime.schema import require_columns
    require_columns(df, columns, 'Sample schema')
    converted = convert_sample(_nulls(df), columns, timestamp_format=timestamp_format)
    validate_frame(converted, columns, 'Sample', source=source, oracle=not source)
    if not df.limit(1).count():raise ValueError('CSV sample must contain at least one data row.')
    return columns


def discover(df, *, source, overrides, growth=25, nullable='Y', parquet=False,
             timestamp_format=None, report=None):
    """The same all-row classification for input and output CSV samples.

    Numeric profiling uses Decimal directly from text. Profile state is bounded
    by the number of columns; toLocalIterator scans every supplied sample row.
    """
    validate_overrides(overrides, source=source)
    unknown = set(overrides) - set(df.columns)
    if unknown:raise ValueError(f'Column overrides reference missing CSV columns: {sorted(unknown)}')
    if parquet:
        merged = dict(overrides)
        for field in df.schema:
            kind = field.dataType
            native = None
            if isinstance(kind, T.StringType):native = dict(data_type='VARCHAR2')
            elif isinstance(kind, T.DecimalType) and kind.scale >= 0:
                native = dict(data_type='NUMBER', length_precision_scale=f'{kind.precision},{kind.scale}')
            elif isinstance(kind, (T.ByteType, T.ShortType, T.IntegerType, T.LongType)):
                precision = {T.ByteType:3, T.ShortType:5, T.IntegerType:10, T.LongType:19}[type(kind)]
                native = dict(data_type='NUMBER', length_precision_scale=f'{precision},0')
            elif isinstance(kind, T.DateType):native = dict(data_type='DATE')
            elif isinstance(kind, (T.TimestampType, T.TimestampNTZType)):native = dict(data_type='TIMESTAMP')
            elif not isinstance(kind, (T.FloatType, T.DoubleType)):
                raise ValueError(f'Unsupported Parquet type for {field.name}: {kind.simpleString()}.')
            if native:merged[field.name] = {**native, **overrides.get(field.name, {})}
        columns = discover(df.select(*[F.col(n).cast('string').alias(n) for n in df.columns]),
            source=source, overrides=merged, growth=growth, nullable=nullable, report=report)
        return validate_sample(df, columns, source=source)
    df = _nulls(df)
    stats = []
    for name in df.columns:
        validate_columns([dict(column_name=name, column_sequence=1, data_type='VARCHAR2', length_precision_scale='1 CHAR', is_nullable='Y')])
        stats.append(dict(count=0, length=0, numeric=True, integer=0, scale=0, leading_zero=False, date=True, timestamp=True))
    rows = 0
    for row in df.toLocalIterator():
        rows += 1
        for index, value in enumerate(row):
            if value is None:continue
            text = str(value);clean = text.strip();s = stats[index]
            s['count'] += 1;s['length'] = max(s['length'], len(text))
            s['leading_zero'] |= bool(re.match(r'^[+-]?0[0-9]+(?:\.|$)', clean))
            try:
                if not NUMBER_TEXT.fullmatch(clean):raise InvalidOperation
                number = Decimal(clean)
                if not number.is_finite():raise InvalidOperation
                s['integer'] = max(s['integer'], max(0, number.adjusted() + 1) if number else 0)
                s['scale'] = max(s['scale'], max(0, -number.as_tuple().exponent))
            except InvalidOperation:s['numeric'] = False
            try:
                if not re.fullmatch(r'[0-9]{4}-[0-9]{2}-[0-9]{2}', clean):raise ValueError
                date.fromisoformat(clean)
            except ValueError:s['date'] = False
            try:
                if not TIMESTAMP_TEXT.fullmatch(clean):raise ValueError
                datetime.fromisoformat(clean.replace('Z', '+00:00'))
            except ValueError:s['timestamp'] = False
    if not rows:raise ValueError('CSV sample must contain at least one data row.')
    result, missing = [], {}
    for index, (name, s) in enumerate(zip(df.columns, stats)):
        override = overrides.get(name, {})
        size = max(1, math.ceil(s['length'] * (1 + growth / 100)))
        kind, spec, pattern = 'VARCHAR2', f'{size} CHAR', None
        reason = 'mixed, nonnumeric or unrecognized date/timestamp values'
        identifier = re.search(r'(^|_)(ID|NO|CODE|CD|ZIP|PHONE|ACCOUNT|NUMBER)$', name)
        if not s['count']:
            if not override.get('data_type') or (override['data_type'] in ('VARCHAR2', 'NUMBER') and not override.get('length_precision_scale')):
                missing[name] = dict(data_type=override.get('data_type', '<VARCHAR2, NUMBER, DATE or TIMESTAMP>'),
                    length_precision_scale='<length override or precision,scale; omit for DATE/TIMESTAMP>')
                continue
            reason = 'all values are NULL/blank; explicit contract required'
        elif identifier or s['leading_zero']:
            reason = 'identifier name or significant leading zeroes retained as text'
        elif s['date']:
            kind, spec, reason = 'DATE', None, 'all non-NULL values are valid ISO dates'
        elif s['numeric']:
            precision = max(1, s['integer'] + s['scale'])
            if precision <= 38:
                kind, spec, reason = 'NUMBER', f"{precision},{s['scale']}", 'maximum integer digits + maximum fractional digits across all rows'
            else:reason = f'decimal precision {precision} exceeds 38'
        else:
            timestamp = s['timestamp']
            if timestamp_format:
                value = F.col(name)
                parsed = F.try_to_timestamp(F.trim(value), F.lit(timestamp_format))
                timestamp = not df.where(value.isNotNull() & (parsed.isNull() | value.rlike(r'\.[0-9]{7,}'))).limit(1).count()
            if timestamp:
                kind, spec, reason = 'TIMESTAMP', None, 'all non-NULL values match the timestamp pattern'
                pattern = timestamp_format or 'yyyy-MM-dd[T or space]HH:mm:ss[.1-6 fractional digits][Z or +/-HH:mm]'
        inferred, inferred_spec = kind, spec
        kind = override.get('data_type', kind)
        if kind != inferred:spec = f'{size} CHAR' if kind == 'VARCHAR2' else None
        if kind in ('DATE', 'TIMESTAMP'):spec = None
        spec = override.get('length_precision_scale', spec)
        column = dict(column_sequence=index+1, column_name=name, data_type=kind,
            length_precision_scale=spec, is_nullable=override.get('is_nullable', 'Y' if source else nullable), is_pii=override.get('is_pii', 'N'))
        result.append(column)
        detail = dict(column=name, inferred_type=inferred, inferred_length_precision_scale=inferred_spec, data_type=kind, length_precision_scale=spec,
            timestamp_pattern=pattern, reason=reason, overridden=bool(override), inspected_rows=rows, non_null_rows=s['count'])
        if report is not None:report.append(detail)
        logger.info('INFERRED_COLUMN %s', detail)
    if missing:raise SchemaOverridesRequired(missing)
    validate_columns(result)
    validate_sample(df, result, source=source, timestamp_format=timestamp_format)
    return result


def validate_conversion(df, columns, *, oracle=False):
    converted = convert_frame(df, columns)
    validate_frame(converted, columns, 'Built-in sample conversion', oracle=oracle)
    return converted
