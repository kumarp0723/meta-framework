"""Explicit read-only verification of deployed Oracle MAIN targets."""
import re

from mdpf_runtime import schema as mdpf_schema
from mdpf_runtime.schema import sql_identifier, spark_type
from mdpf_runtime.db import OracleDb, require_main_database


def verify_main_targets(db, *, pipeline_code, release_version, main_db=None):
    """Read contracts in ATP and check target tables in separate ADW.

    Explicit main_db is caller-owned. Otherwise MDPF_MAIN_DB_* supplies a
    separately opened/closed target connection. ATP is never a target fallback.
    No metadata activation, DDL or business inserts occur.
    """
    require_main_database(db, main_db)
    owned = OracleDb(prefix='MDPF_MAIN_DB') if main_db is None else None
    try:
        return _verify_main_targets(db, main_db if main_db is not None else owned,
                                    pipeline_code=pipeline_code,release_version=release_version)
    finally:
        if owned is not None:
            owned.close()


def _verify_main_targets(db, target_db, *, pipeline_code, release_version):
    """Read deployed MAIN contracts for one pipeline/release using the supplied db.

    Return verified qualified target names. Missing/incompatible columns, capacity,
    audit timestamps, extra required columns or character sets raise ValueError.
    Database/access errors propagate. No DDL, metadata activation or commit occurs;
    the caller owns the connection. This gate is explicitly separate from generate()."""
    release=db.one('SELECT config_release_id FROM METADATA.CONFIG_RELEASE WHERE pipeline_code=:p AND release_version=:v',
        p=pipeline_code,v=release_version)
    if not release:raise ValueError('Unknown pipeline/release for Oracle verification.')
    charset=target_db.one("SELECT value FROM NLS_DATABASE_PARAMETERS WHERE parameter='NLS_CHARACTERSET'")
    if not charset or charset['value']!='AL32UTF8':
        raise ValueError('This target gate requires AL32UTF8, matching MDPF UTF-8 byte validation; other database character sets need DBA review.')
    targets=db.execute("SELECT * FROM METADATA.DATASET WHERE config_release_id=:r AND layer='GOLD' AND storage_type='ADB_TABLE'",
        r=release['config_release_id'])
    if not targets:raise ValueError('Release has no Oracle MAIN targets.')
    checked=[]
    for target in targets:
        full=sql_identifier(target['physical_object_name'],qualified=True)
        owner,table=full.split('.')
        if not target_db.one('SELECT table_name FROM ALL_TABLES WHERE owner=:o AND table_name=:t',o=owner,t=table):
            raise ValueError(f'{full}: physical Oracle table is missing or inaccessible.')
        actual=target_db.execute('''SELECT c.column_name,c.data_type,c.data_length,c.char_length,c.char_used,
            c.data_precision,c.data_scale,c.nullable,c.data_default,c.identity_column,c.virtual_column,
            c.user_generated,i.generation_type FROM ALL_TAB_COLS c
            LEFT JOIN ALL_TAB_IDENTITY_COLS i ON i.owner=c.owner AND i.table_name=c.table_name AND i.column_name=c.column_name
            WHERE c.owner=:o AND c.table_name=:t''',o=owner,t=table)
        actual={c['column_name']:c for c in actual}
        expected=db.execute('SELECT * FROM METADATA.DATASET_COLUMN WHERE config_release_id=:r AND dataset_id=:d ORDER BY column_sequence',
            r=release['config_release_id'],d=target['dataset_id'])
        mdpf_schema.validate_columns(expected)
        expected += [dict(column_name=n,data_type='NUMBER',length_precision_scale='19,0',is_nullable='N')
                     for n in ('BATCH_ID','TASK_RUN_ID','ROW_NUMBER')]
        expected += [dict(column_name=n, data_type='TIMESTAMP WITH TIME ZONE', is_nullable='N')
                     for n in ('CREATED_AT','UPDATED_AT')]
        for e in expected:
            name=e['column_name'];a=actual.get(name)
            actual_type = re.sub(r'^TIMESTAMP\([0-9]+\)', 'TIMESTAMP', a['data_type']) if a else None
            if not a or actual_type!=e['data_type']:
                raise ValueError(f"{full}.{name}: missing column or incompatible datatype; incoming={actual_type or '<missing>'}, expected={e['data_type']}.")
            if e['data_type'] in ('TIMESTAMP', 'TIMESTAMP WITH TIME ZONE'):
                declared = re.fullmatch(r'TIMESTAMP\(([0-9]+)\)(?: WITH TIME ZONE)?', a['data_type'])
                precision = a.get('data_scale')
                if precision is None:
                    precision = int(declared[1]) if declared else 6
                if int(precision)<6:
                    raise ValueError(f'{full}.{name}: timestamp precision must be at least 6.')
            if a.get('virtual_column')=='YES' or a.get('generation_type')=='ALWAYS':
                raise ValueError(f'{full}.{name}: column cannot accept the framework INSERT value.')
            if a['nullable']=='N' and e['is_nullable']=='Y':
                raise ValueError(f'{full}.{name}: Oracle NOT NULL requires metadata is_nullable=N.')
            if e['data_type']=='VARCHAR2':
                limit,unit=mdpf_schema.string_limit(e)
                # AL32UTF8 uses up to four bytes per character. Check both limits.
                bytes_required=limit*4 if unit=='CHAR' else limit
                if a['data_length']<bytes_required or (a['char_used']=='C' and a['char_length']<limit):
                    raise ValueError(f'{full}.{name}: insufficient character/byte capacity for the metadata contract.')
            elif e['data_type']=='NUMBER' and not (a['data_precision'] is None and a['data_scale'] is None):
                typ=spark_type(e);precision=int(a['data_precision'] or 38);scale=int(a['data_scale'] or 0)
                if scale<typ.scale or precision-scale<typ.precision-typ.scale:
                    raise ValueError(f'{full}.{name}: insufficient precision/scale; Oracle could overflow or round.')
        supplied={e['column_name'] for e in expected}
        for name,a in actual.items():
            if name in supplied or a['nullable']=='Y' or a.get('virtual_column')=='YES' or a.get('identity_column')=='YES' or a.get('user_generated')=='NO':
                continue
            default=str(a.get('data_default') or '').strip()
            if not default or default.upper() in ('NULL','(NULL)'):
                raise ValueError(f'{full}.{name}: required extra column has no usable default or generated value.')
        checked.append(full)
    return checked


def verify_parquet_targets(db, *, spark, pipeline_code, release_version, batch_id):
    """Compare existing RAW/STAGE schemas with a selected proposed metadata release.

    Read only. batch_id supplies the retained date/path identity; it need not be
    pinned to the proposed release. No files, metadata or batch states are changed.
    """
    from pyspark.sql import types as T
    from mdpf_runtime.pipeline import MetadataFramework
    from mdpf_runtime.schema import require_columns
    release = db.one('SELECT config_release_id FROM METADATA.CONFIG_RELEASE WHERE pipeline_code=:p AND release_version=:v',
                     p=pipeline_code, v=release_version)
    batch = db.one('SELECT * FROM RUNTIME.BATCH WHERE batch_id=:b AND pipeline_code=:p', b=batch_id, p=pipeline_code)
    if not release or not batch:raise ValueError('Unknown metadata release or retained batch for Parquet verification.')
    datasets = db.execute("""SELECT d.* FROM METADATA.DATASET d
        WHERE d.config_release_id=:r AND d.layer IN ('RAW','STAGE') AND d.storage_type='PARQUET'
        AND EXISTS (SELECT 1 FROM METADATA.TASK_DATASET td WHERE td.config_release_id=d.config_release_id
          AND td.dataset_id=d.dataset_id AND td.dataset_role='OUTPUT' AND td.is_enabled='Y')""", r=release['config_release_id'])
    checked = []
    framework = MetadataFramework(db, pipeline_code, spark=spark)
    for dataset in datasets:
        columns = db.execute('SELECT * FROM METADATA.DATASET_COLUMN WHERE config_release_id=:r AND dataset_id=:d ORDER BY column_sequence',
                             r=release['config_release_id'], d=dataset['dataset_id'])
        mdpf_schema.validate_columns(columns)
        location = framework.output_path(batch, dataset)
        frame = spark.read.parquet(location)
        audit = {'_batch_id': T.LongType(), '_run_id': T.LongType()}
        audit.update({'_ingestion_item_id': T.LongType(), '_ingested_at': T.TimestampType()}
                     if dataset['layer']=='RAW' else {'_processed_at': T.TimestampType()})
        expected = {c['column_name']:spark_type(c) for c in columns} | audit
        if set(frame.columns) != set(expected):raise ValueError(f'{location}: columns differ; rebuild/migrate the retained dataset.')
        for name, target in expected.items():
            incoming = frame.schema[name].dataType
            if incoming != target:
                raise ValueError(f'{location}.{name}: incoming={incoming.simpleString()}, expected={target.simpleString()}; explicit migration/rebuild required.')
        checked.append(location)
    if not checked:raise ValueError('Release has no produced RAW/STAGE Parquet targets.')
    return checked
