import pytest
from pyspark.sql import types as T

from mdpf_onboarding.schema_discovery import discover,validate_conversion


def frame(spark,values,name='VALUE'):
    return spark.createDataFrame([(v,) for v in values],T.StructType([T.StructField(name,T.StringType(),True)]))


@pytest.mark.parametrize('values,kind,spec',[
    (['001234','001235'],'VARCHAR2','8 CHAR'),
    (['1','9'],'NUMBER','1,0'),(['1250.75','12.30'],'NUMBER','6,2'),
    (['0.00','0.00'],'NUMBER','2,2'),(['2026-10-15','2024-02-29'],'DATE',None),
    (['1e2','2e2'],'NUMBER','3,0'),(['A','B'],'VARCHAR2','2 CHAR'),
    (['123456789012345678901234567890123456789'],'VARCHAR2','49 CHAR')])
def test_inference(spark,values,kind,spec):
    columns=discover(frame(spark,values),source=False,overrides={})
    assert columns[0]['data_type']==kind and columns[0]['length_precision_scale']==spec
    assert columns[0]['is_nullable']=='Y'


def test_source_uses_same_inference_and_identifier_is_conservative(spark):
    assert discover(frame(spark,['1250.75']),source=True,overrides={})[0]['data_type']=='NUMBER'
    assert discover(frame(spark,['123','456'],'CLIENT_ID'),source=False,overrides={})[0]['data_type']=='VARCHAR2'


@pytest.mark.parametrize('value,override',[
    ('10/15/2026',dict(data_type='DATE',length_precision_scale=None)),
    ('1250.756',dict(data_type='NUMBER',length_precision_scale='8,2')),
    ('1000',dict(data_type='NUMBER',length_precision_scale='3,0')),
    ('LONG',dict(data_type='VARCHAR2',length_precision_scale='2 CHAR')),
    (None,dict(data_type='DATE',is_nullable='N'))])
def test_actual_conversion_and_constraints(spark,value,override):
    with pytest.raises(ValueError):discover(frame(spark,[value]),source=False,overrides={'VALUE':override})


def test_all_null_target_requires_explicit_contract(spark):
    df=frame(spark,[None,None])
    with pytest.raises(ValueError,match='All-null'):discover(df,source=False,overrides={})
    with pytest.raises(ValueError,match='length override'):discover(df,source=False,overrides={'VALUE':{'data_type':'VARCHAR2'}})
    result=discover(df,source=False,overrides={'VALUE':{'data_type':'DATE'}})
    assert result[0]['data_type']=='DATE'
    with pytest.raises(ValueError,match='All-null'):discover(df,source=True,overrides={})


def test_text_override_uses_text_headroom(spark):
    result=discover(frame(spark,['123']),source=False,overrides={'VALUE':{'data_type':'VARCHAR2'}})
    assert result[0]['data_type']=='VARCHAR2' and result[0]['length_precision_scale']=='4 CHAR'


@pytest.mark.parametrize('names',['BATCH_ID','TASK_RUN_ID','LOWERcase','A B'])
def test_invalid_headers(spark,names):
    with pytest.raises(ValueError):discover(frame(spark,['x'],names),source=True,overrides={})


def test_empty_sample(spark):
    with pytest.raises(ValueError,match='at least one'):discover(frame(spark,[]),source=True,overrides={})


def test_csv_sample_can_describe_typed_parquet_landing(spark):
    result=discover(frame(spark,['1']),source=True,overrides={'VALUE':{'data_type':'NUMBER','length_precision_scale':'5'}})
    assert result[0]['data_type']=='NUMBER'
