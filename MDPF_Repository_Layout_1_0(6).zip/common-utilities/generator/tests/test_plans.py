from copy import deepcopy

import pytest
import yaml

from conftest import ROOT,prepare_execution
from mdpf_onboarding.metadata_generator import relationship,resolve_steps,build_metadata
from mdpf_onboarding.config import validate_config


@pytest.mark.parametrize('name,shape',[('one_to_one','ONE_TO_ONE'),('many_to_one','MANY_TO_ONE'),('one_to_many','ONE_TO_MANY')])
def test_automatic_relationship_and_three_tasks(models,name,shape):
    model=models[name]
    assert relationship(model['config'])==shape
    assert [t['role'] for t in model['tasks']]==['RAW','STAGE','MAIN']
    assert len(model['tables']['SOURCE_CONFIG'])==1
    assert model['tables']['SOURCE_CONFIG'][0]['expected_input_count']==len(model['config']['inputs'])
    raw=model['tasks'][0];links=[r for r in model['tables']['TASK_DATASET'] if r['task_id']==raw['row']['task_id']]
    assert {r['usage_sequence'] for r in links if r['dataset_role']=='INPUT'}=={r['usage_sequence'] for r in links if r['dataset_role']=='OUTPUT'}


def test_many_to_many_rejected():
    config=yaml.safe_load((ROOT/'examples/many_to_one.yaml').read_text())
    config['outputs'].append(dict(config['outputs'][0],code='SECOND',target_table='SECOND'))
    with pytest.raises(ValueError,match='Multiple inputs'):validate_config(config)


@pytest.mark.parametrize('field,value',[('source_system','OTHER'),('bucket_ref','other'),('landing_key_prefix','landing/other')])
def test_incompatible_combined_source_configs_rejected(field,value):
    config=yaml.safe_load((ROOT/'examples/many_to_one.yaml').read_text())
    config['inputs'][1][field]=value
    with pytest.raises(ValueError,match='Combined RAW'):validate_config(config)


@pytest.mark.parametrize('plan',[
    [],['DIRECT_MAP','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET','DIRECT_MAP','WRITE_PARQUET'],
    ['READ_PARQUET','VALIDATE_DQ','DIRECT_MAP','WRITE_PARQUET'],
    ['READ_PARQUET','READ_PARQUET','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET','WRITE_PARQUET','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET','VALIDATE_DQ','LOAD_MAIN'],
    ['READ_PARQUET','DIRECT_MAP','DIRECT_MAP','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQET','VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET',{'code':'CUSTOM','parameters':[]},'VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET',{'code':'DIRECT_MAP','parameters':{'override':True}},'VALIDATE_DQ','WRITE_PARQUET'],
    ['READ_PARQUET',{'code':'CUSTOM','parameters':{'bad':float('nan')}},'VALIDATE_DQ','WRITE_PARQUET']])
def test_invalid_plans(plan):
    with pytest.raises(ValueError):resolve_steps({'task_steps':plan},'STAGE')


@pytest.mark.parametrize('legacy', [
    {'custom_steps': []}, {'output_is_typed': True}, {'output_is_typed': False},
    {'custom_steps': [{'code': 'CLEAN'}], 'output_is_typed': True},
])
@pytest.mark.parametrize('explicit', [False, True])
def test_removed_yaml_options_fail_before_sample_io(oci_setup, monkeypatch, legacy, explicit):
    import mdpf_onboarding.onboard as module
    config, uri, client, _ = oci_setup
    options = dict(legacy)
    if explicit:
        options['task_steps'] = ['READ_PARQUET', 'VALIDATE_DQ', 'WRITE_PARQUET']
    config['task_overrides'] = {'STAGE': options}
    client.objects[uri] = yaml.safe_dump(config).encode()
    monkeypatch.setattr(module, 'read_sample', lambda *args: pytest.fail('Removed YAML must fail before reading samples'))
    with pytest.raises(ValueError, match='replace YAML custom_steps/output_is_typed'):
        module.generate(uri, client=client)
    assert not client.puts


def test_explicit_order_and_parameters():
    opt={'task_steps':['READ_PARQUET',{'code':'CLEAN','parameters':{'column':'ID'}},'DIRECT_MAP',
                       {'code':'DERIVE'},'VALIDATE_DQ','WRITE_PARQUET']}
    result=resolve_steps(opt,'STAGE')
    assert [code for code,_,_ in result]==['READ_PARQUET','CLEAN','DIRECT_MAP','DERIVE','VALIDATE_DQ','WRITE_PARQUET']
    assert result[1]==('CLEAN','CUSTOM_PYTHON',{'column':'ID'})


@pytest.mark.parametrize('role,mapping,expected', [
    ('RAW', False, ['READ_SOURCE', 'WRITE_PARQUET']),
    ('STAGE', False, ['READ_PARQUET', 'VALIDATE_DQ', 'WRITE_PARQUET']),
    ('STAGE', True, ['READ_PARQUET', 'DIRECT_MAP', 'VALIDATE_DQ', 'WRITE_PARQUET']),
    ('MAIN', False, ['READ_PARQUET', 'VALIDATE_DQ', 'LOAD_MAIN']),
])
def test_automatic_defaults(role, mapping, expected):
    assert resolve_steps({}, role, mapping=mapping) == [(code, 'BUILTIN', {}) for code in expected]


def test_explicit_plan_is_not_augmented_by_mapping_hint():
    codes = ['READ_PARQUET', {'code': 'TYPED_TRANSFORM'}, 'VALIDATE_DQ', 'WRITE_PARQUET']
    assert [code for code, _, _ in resolve_steps({'task_steps': codes}, 'STAGE', mapping=True)] == [
        'READ_PARQUET', 'TYPED_TRANSFORM', 'VALIDATE_DQ', 'WRITE_PARQUET']


@pytest.mark.parametrize('registry,error', [
    ({}, 'Missing callable CUSTOM_PYTHON handler: JOIN_CLIENT'),
    ({'JOIN_CLIENT': None}, 'Missing callable CUSTOM_PYTHON handler: JOIN_CLIENT'),
    ({'READ_PARQUET': lambda *args: None}, 'BUILTIN names cannot be overridden'),
])
def test_runtime_registry_checks_remain_before_data_reads(models, spark, tmp_path, monkeypatch, registry, error):
    model = models['many_to_one']
    fw, db = prepare_execution(model, tmp_path, spark)
    monkeypatch.setattr(fw.storage, 'read_parquet', lambda *args: pytest.fail('Handler checks must precede data reads'))
    try:
        batch = fw.start_batch('registry-check', '2026-10-15', 'MANUAL')['batch_id']
        with pytest.raises(ValueError, match=error):
            fw.execute_task(batch, model['tasks'][1]['row']['task_code'], custom_steps=registry)
        assert db.one('SELECT status FROM RUNTIME.TASK_RUN')['status'] == 'FAILED'
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 1
    finally:
        db.close()


def test_explicit_plan_cannot_hide_required_conversion(models,spark):
    model=models['one_to_one'];config=deepcopy(model['config'])
    config['task_overrides']={'STAGE':{'task_steps':['READ_PARQUET','VALIDATE_DQ','WRITE_PARQUET']}}
    source=spark.read.option('header',True).csv(str(ROOT/'examples/samples/loan_input.csv'))
    target=spark.read.option('header',True).csv(str(ROOT/'examples/samples/loan_output.csv'))
    profiles={'DEMO_LOAN_LOAN_LANDING':(source,model['datasets']['DEMO_LOAN_LOAN_LANDING']['columns']),
              'DEMO_LOAN_LOAN_MAIN':(target,model['datasets']['DEMO_LOAN_LOAN_MAIN']['columns'])}
    with pytest.raises(ValueError,match='type mismatch'):build_metadata(config,profiles)
