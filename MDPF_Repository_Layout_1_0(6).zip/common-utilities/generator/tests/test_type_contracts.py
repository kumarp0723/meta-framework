"""All-row CSV inference and native Parquet normalization acceptance cases."""
from datetime import datetime, timezone
from decimal import Decimal
from pathlib import Path

import pytest
from pyspark.sql import functions as F, types as T

from mdpf_onboarding.schema_discovery import discover, read_sample, convert_sample
from mdpf_runtime.schema import convert_frame, DataValidationError


def contract(kind='NUMBER', spec='7,2', name='VALUE'):
    return [dict(column_name=name, column_sequence=1, data_type=kind,
                 length_precision_scale=spec, is_nullable='Y', is_pii='N')]


def strings(spark, values):
    return spark.createDataFrame([(v,) for v in values], 'VALUE string')


def test_input_output_use_every_csv_value_and_decimal_digit_maxima(spark):
    values = ['12.3', None, '', '0.001', '99999.9']
    report = []
    incoming = discover(strings(spark, values), source=True, overrides={}, report=report)
    outgoing = discover(strings(spark, values), source=False, overrides={})
    assert incoming == outgoing
    assert incoming[0]['data_type']=='NUMBER' and incoming[0]['length_precision_scale']=='8,3'
    assert report[0]['inspected_rows']==5 and report[0]['non_null_rows']==3
    assert 'maximum integer digits' in report[0]['reason']


def test_decimal_text_is_not_rounded_through_double(spark):
    value = '12345678901234567890123456789012345678'
    df = strings(spark, [value])
    columns = discover(df, source=True, overrides={})
    assert columns[0]['length_precision_scale']=='38,0'
    assert convert_frame(df, columns).first()[0]==Decimal(value)
    assert discover(strings(spark, ['1e2', '1.25e2']), source=False, overrides={})[0]['length_precision_scale']=='3,0'


def test_fallback_and_explicit_future_business_precision_are_reported(spark):
    report=[]
    assert discover(strings(spark,['1.2','bad']), source=True, overrides={}, report=report)[0]['data_type']=='VARCHAR2'
    assert report[0]['reason'] and report[0]['inferred_type']=='VARCHAR2'
    report=[]
    c=discover(strings(spark,['12.50','2.75']), source=True,
        overrides={'VALUE':{'data_type':'NUMBER','length_precision_scale':'7,2'}}, report=report)
    assert c[0]['length_precision_scale']=='7,2' and report[0]['overridden']


def test_csv_options_nulls_quotes_whitespace_and_timestamp_pattern(spark,tmp_path):
    p=tmp_path/'sample.csv'
    p.write_text('VALUE;STAMP;NOTE\n" 12.50 ";"11/08/2026 12:13:14.123456";"a;quoted value"\nNA;"11/08/2026 12:13:15.000001";"second"\n')
    options={'delimiter':';','quote':'"','ignoreLeadingWhiteSpace':True,
             'ignoreTrailingWhiteSpace':True,'timestampFormat':'MM/dd/yyyy HH:mm:ss.SSSSSS'}
    df=read_sample(spark,str(p),csv_options=options,null_values=['NA'])
    report=[]
    cols=discover(df,source=True,overrides={},timestamp_format=options['timestampFormat'],report=report)
    assert [c['data_type'] for c in cols]==['NUMBER','TIMESTAMP','VARCHAR2']
    assert report[1]['timestamp_pattern']==options['timestampFormat']
    result=convert_sample(df,cols,timestamp_format=options['timestampFormat']).collect()
    assert result[0]['VALUE']==Decimal('12.50') and result[1]['VALUE'] is None
    assert convert_sample(df,cols,timestamp_format=options['timestampFormat']).select(F.date_format('STAMP','yyyy-MM-dd HH:mm:ss.SSSSSS')).first()[0]=='2026-11-08 12:13:14.123456'
    assert result[0]['NOTE']=='a;quoted value'


def test_iso_timestamps_keep_fractions_and_normalize_offsets_to_utc(spark):
    df=strings(spark,['2026-11-08T12:13:14.123456+05:30','2026-11-08T06:43:14.123456Z'])
    cols=discover(df,source=True,overrides={})
    assert cols[0]['data_type']=='TIMESTAMP'
    assert [r[0] for r in convert_frame(df,cols).select(F.date_format('VALUE','yyyy-MM-dd HH:mm:ss.SSSSSS')).collect()]==['2026-11-08 06:43:14.123456']*2
    with pytest.raises(DataValidationError,match='incoming=string, expected=timestamp'):
        convert_frame(strings(spark,['2026-11-08T12:13:14.1234567Z']),cols)


@pytest.mark.parametrize('incoming',[T.FloatType(),T.DoubleType()])
def test_embedded_floating_type_is_normalized_with_half_up(spark,tmp_path,incoming):
    schema=T.StructType([T.StructField('VALUE',incoming,True),T.StructField('STAMP',T.TimestampType(),True)])
    df=spark.createDataFrame([(1.005,datetime(2026,11,8,1,2,3,456789,tzinfo=timezone.utc)),(-1.005,None),(None,None)],schema)
    p=str(tmp_path/'delivery.parquet');df.write.parquet(p)
    delivered=spark.read.parquet(p)
    assert delivered.schema['VALUE'].dataType==incoming
    cols=contract()+[dict(column_name='STAMP',column_sequence=2,data_type='TIMESTAMP',length_precision_scale=None,is_nullable='Y')]
    normalized=convert_frame(delivered,cols).collect()
    assert [r['VALUE'] for r in normalized]==[Decimal('1.01'),Decimal('-1.01'),None]
    assert convert_frame(delivered,cols).select(F.date_format('STAMP','yyyy-MM-dd HH:mm:ss.SSSSSS')).first()[0]=='2026-11-08 01:02:03.456789'


@pytest.mark.parametrize('value',[float('nan'),float('inf'),float('-inf'),99999.995,-99999.995,1e308])
def test_nonfinite_and_overflow_after_rounding_fail_even_when_nullable(spark,value):
    df=spark.createDataFrame([(value,)],'VALUE double')
    with pytest.raises(DataValidationError,match=r'incoming=double, expected=decimal\(7,2\)'):
        convert_frame(df,contract())


def test_number_boundary_and_conversion_created_null(spark):
    df=spark.createDataFrame([(99999.994,),(-99999.994,)],'VALUE double')
    assert [r[0] for r in convert_frame(df,contract()).collect()]==[Decimal('99999.99'),Decimal('-99999.99')]
    with pytest.raises(DataValidationError,match='incoming=string, expected=decimal'):
        convert_frame(strings(spark,['not-a-number']),contract())


def test_timestamp_requires_explicit_utc_processing(spark):
    old=spark.conf.get('spark.sql.session.timeZone')
    try:
        spark.conf.set('spark.sql.session.timeZone','America/Chicago')
        with pytest.raises(DataValidationError,match='timeZone=UTC'):
            convert_frame(strings(spark,['2026-11-08T00:00:00Z']),contract('TIMESTAMP',None))
    finally:spark.conf.set('spark.sql.session.timeZone',old)


def test_quarantine_stream_uses_real_hadoop_streams_without_reserializing(spark,tmp_path,monkeypatch):
    import hashlib
    from mdpf_runtime.storage import ObjectStorage
    source='oci://landing@ns/source.parquet';destination='oci://quarantine@ns/raw/source.parquet'
    data=bytes(range(256))*8193
    source_path=tmp_path/'source.parquet';dest_path=tmp_path/'copy.parquet'
    source_path.write_bytes(data)
    storage=ObjectStorage(spark)
    def fs(uri):
        local=spark._jvm.org.apache.hadoop.fs.Path(str(source_path if uri==source else dest_path))
        return local.getFileSystem(spark.sparkContext._jsc.hadoopConfiguration()),local
    monkeypatch.setattr(storage,'_filesystem',fs)
    assert storage.quarantine_file(source,destination)==dict(size_bytes=len(data),checksum_sha256=hashlib.sha256(data).hexdigest())
    assert dest_path.read_bytes()==source_path.read_bytes()==data


def test_retained_parquet_schema_gate_detects_legacy_varchar(spark,models,tmp_path,monkeypatch):
    from conftest import prepare_execution
    from mdpf_onboarding.oracle_gate import verify_parquet_targets
    from pyspark.sql.readwriter import DataFrameReader
    fw,db=prepare_execution(models['one_to_one'],tmp_path,spark)
    try:
        batch=fw.start_batch('schema-gate','2026-10-15')['batch_id']
        for task in models['one_to_one']['tasks'][:2]:fw.execute_task(batch,task['row']['task_code'])
        read=DataFrameReader.parquet
        def redirected(reader,path,*args,**kwargs):
            return read(reader,str(fw.storage.path(path)),*args,**kwargs)
        monkeypatch.setattr(DataFrameReader,'parquet',redirected)
        assert len(verify_parquet_targets(db,spark=spark,pipeline_code=fw.pipeline_code,release_version='1.0',batch_id=batch))==2
        def legacy(reader,path,*args,**kwargs):
            return redirected(reader,path,*args,**kwargs).withColumn('BALANCE',F.col('BALANCE').cast('string'))
        monkeypatch.setattr(DataFrameReader,'parquet',legacy)
        with pytest.raises(ValueError,match='incoming=string, expected=decimal.*migration/rebuild'):
            verify_parquet_targets(db,spark=spark,pipeline_code=fw.pipeline_code,release_version='1.0',batch_id=batch)
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status']=='RUNNING'
    finally:db.close()


def test_main_timestamp_binding_is_utc_independent_of_process_timezone(spark,models,tmp_path):
    from conftest import prepare_execution
    from mdpf_runtime.steps import load_main
    # Exercise the actual bounded MAIN collector and dictionary passed to Oracle.
    df=spark.createDataFrame([('2026-11-08T12:13:14.123456+05:30',)],'VALUE string')
    columns=contract('TIMESTAMP',None)
    frame=convert_frame(df,columns)
    ctx={'outputs':{'MAIN':{'columns':columns,'dataset':{'layer':'GOLD'},'policies':[]}},
         'state':{'validated_outputs':{'MAIN':frame}}}
    load_main({'MAIN':frame},ctx,{})
    assert ctx['state']['outputs']['MAIN']['rows'][0]['VALUE']==datetime(2026,11,8,6,43,14,123456)
