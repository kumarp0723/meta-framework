"""Metadata-selected Spark task loop and Oracle execution lifecycle."""
from datetime import date
import json
from types import MappingProxyType
import uuid

from pyspark.sql import DataFrame, SparkSession

from .storage import ObjectStorage, object_address
from .steps import BUILTINS
from .schema import sql_identifier, validate_columns


def _json_object(value, label):
    if value is None:
        return {}
    if isinstance(value, str):
        try:
            value = json.loads(value.strip() or "{}")
        except json.JSONDecodeError as exc:
            raise ValueError(f"{label} must contain valid JSON.") from exc
    if not isinstance(value, dict):
        raise ValueError(f"{label} must be a JSON object.")
    return value


class MetadataFramework:
    def __init__(self, db, pipeline_code, spark=None):
        if not isinstance(pipeline_code, str) or not pipeline_code.strip() or "{{" in pipeline_code:
            raise ValueError("Explicit pipeline_code is required.")
        self.db = db
        self.pipeline_code = pipeline_code.strip()
        self.spark = spark
        self.storage = ObjectStorage()

    def start_batch(self, job_run_id, cycle_date=None, execution_mode=None):
        if not job_run_id or not job_run_id.strip() or "{{" in job_run_id:
            raise ValueError("A resolved AIDP job.run_id is required.")
        execution_key = "AIDP:" + job_run_id
        if execution_mode is not None and execution_mode not in ("SCHEDULED", "MANUAL"):
            raise ValueError("POC supports SCHEDULED and MANUAL only.")
        mode = execution_mode or "SCHEDULED"
        with self.db.transaction():
            existing = self.db.one("SELECT * FROM RUNTIME.BATCH WHERE pipeline_code=:p AND execution_key=:k",
                p=self.pipeline_code, k=execution_key)
            if existing:
                if execution_mode is not None and existing["batch_type"] != mode:
                    raise ValueError("Execution mode conflicts with the existing batch.")
                if cycle_date and str(existing["cycle_date"])[:10] != cycle_date:
                    raise ValueError("Execution key already belongs to another cycle date.")
                if job_run_id and existing["orchestrator_run_id"] != job_run_id:
                    raise ValueError("Execution key already belongs to another scheduler job.")
                if existing["status"] == "FAILED":
                    raise ValueError("Terminal batches cannot restart; use a new execution key.")
                return existing
            release = self.db.one("SELECT * FROM METADATA.CONFIG_RELEASE WHERE pipeline_code=:p AND release_status='ACTIVE'", p=self.pipeline_code)
            if release is None:
                raise ValueError("Pipeline requires an ACTIVE metadata release.")
            if not cycle_date or date.fromisoformat(cycle_date).isoformat() != cycle_date:
                raise ValueError("A new batch requires cycle_date in YYYY-MM-DD format.")
            batch_id = self.db.next_id("RUNTIME.BATCH", "batch_id")
            self.db.insert("RUNTIME.BATCH", dict(batch_id=batch_id,
                config_release_id=release["config_release_id"], pipeline_code=self.pipeline_code,
                batch_type=mode,
                cycle_date=date.fromisoformat(cycle_date),
                execution_key=execution_key, correlation_id=str(uuid.uuid4()),
                orchestrator_run_id=job_run_id, status="RUNNING", triggered_by="AIDP"))
            self.db.execute("UPDATE RUNTIME.BATCH SET start_timestamp=SYSTIMESTAMP WHERE batch_id=:id", id=batch_id)
            batch = self._batch(batch_id)
            self._event(batch, None, "BATCH_STARTED", "Started pipeline " + self.pipeline_code)
            return batch

    def get_batch_by_job_run_id(self, job_run_id):
        rows = self.db.execute("SELECT * FROM RUNTIME.BATCH WHERE pipeline_code=:p AND orchestrator_run_id=:j",
            p=self.pipeline_code, j=job_run_id)
        if len(rows) > 1:
            raise ValueError("Ambiguous scheduler job-to-batch correlation.")
        return rows[0] if rows else None

    def _batch(self, batch_id):
        batch = self.db.one("SELECT * FROM RUNTIME.BATCH WHERE batch_id=:id FOR UPDATE", id=batch_id)
        if not batch or batch["pipeline_code"] != self.pipeline_code:
            raise ValueError("Batch does not belong to the requested pipeline.")
        return batch

    def _task(self, batch, task_code):
        if not isinstance(task_code, str) or not task_code.strip():
            raise ValueError("Explicit task_code is required.")
        task = self.db.one("SELECT * FROM METADATA.TASK WHERE config_release_id=:r AND task_code=:c",
            r=batch["config_release_id"], c=task_code)
        if not task:
            raise ValueError("Task is missing from the pinned release.")
        return task

    def _latest(self, batch_id, task_id):
        return self.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE batch_id=:b AND task_id=:t ORDER BY attempt_number DESC",
            b=batch_id, t=task_id)

    def _datasets(self, batch, task, role):
        rows = self.db.execute("""SELECT d.*, td.usage_sequence FROM METADATA.TASK_DATASET td JOIN METADATA.DATASET d
            ON d.config_release_id=td.config_release_id AND d.dataset_id=td.dataset_id
            WHERE td.config_release_id=:r AND td.task_id=:t AND td.dataset_role=:role AND td.is_enabled='Y' ORDER BY td.usage_sequence, d.dataset_id""",
            r=batch["config_release_id"], t=task["task_id"], role=role)
        if not rows:
            raise ValueError("Task requires at least one enabled dataset per input/output role.")
        return rows

    def _columns(self, release_id, dataset_id):
        columns = self.db.execute("SELECT * FROM METADATA.DATASET_COLUMN WHERE config_release_id=:r AND dataset_id=:d ORDER BY column_sequence",
            r=release_id, d=dataset_id)
        validate_columns(columns)
        return columns

    def _producer(self, release_id, dataset_id):
        rows = self.db.execute("""SELECT task_id FROM METADATA.TASK_DATASET
            WHERE config_release_id=:r AND dataset_id=:d AND dataset_role='OUTPUT' AND is_enabled='Y'""",
            r=release_id, d=dataset_id)
        if len(rows) != 1:
            raise ValueError("Internal dataset requires exactly one enabled producer in the pinned release.")
        return rows[0]["task_id"]

    def output_path(self, batch, dataset):
        if dataset["storage_type"] != "PARQUET":
            raise ValueError("Oracle MAIN has no Parquet output path.")
        location = str(dataset["physical_object_name"] or "").rstrip("/")
        if not object_address(location)[2] or any(c in location for c in "*[]{}"):
            raise ValueError("Parquet DATASET requires a full OCI dataset prefix.")
        return location + f"/batch_{batch['batch_id']}"

    def execute_task(self, batch_id, task_code, custom_steps=None,
                     orchestrator_task_run_id=None, orchestrator_attempt_number=None):
        if orchestrator_attempt_number is not None and (
                not orchestrator_task_run_id or orchestrator_attempt_number < 1):
            raise ValueError("External execution count requires its task-run ID and must be positive.")
        with self.db.transaction():
            batch = self._batch(batch_id)
            task = self._task(batch, task_code)
            latest = self._latest(batch_id, task["task_id"])
            if latest and latest["status"] == "COMPLETED":
                raise ValueError("Task already COMPLETED; select only failed/downstream tasks in AIDP Repair.")
            if batch["status"] != "RUNNING":
                raise ValueError("New attempts require a RUNNING batch.")
            if latest and latest["status"] == "RUNNING":
                raise ValueError("Attempt still RUNNING; stop its writer and fail that exact attempt before restarting.")
            run_id = self.db.next_id("RUNTIME.TASK_RUN", "task_run_id")
            self.db.insert("RUNTIME.TASK_RUN", dict(task_run_id=run_id, batch_id=batch_id,
                config_release_id=batch["config_release_id"], task_id=task["task_id"],
                attempt_number=int(latest["attempt_number"])+1 if latest else 1,
                original_task_run_id=latest["task_run_id"] if latest else None, status="RUNNING",
                orchestrator_task_run_id=orchestrator_task_run_id,
                orchestrator_attempt_number=orchestrator_attempt_number))
            self.db.execute("UPDATE RUNTIME.TASK_RUN SET start_timestamp=SYSTIMESTAMP WHERE task_run_id=:id", id=run_id)
            self._event(batch, run_id, "TASK_STARTED", task_code)
        ctx = dict(batch=batch, task=task, run_id=run_id, state={}, input_count=0, output_count=0,
                   step_code=None, framework=self)
        try:
            plan = self._resolve_plan(ctx, {} if custom_steps is None else custom_steps)
            self._prepare_dataflow(ctx, plan)
            public_context = MappingProxyType(dict(batch_id=batch_id, task_run_id=run_id,
                pipeline_code=self.pipeline_code, task_code=task_code,
                config_release_id=batch["config_release_id"], cycle_date=batch["cycle_date"],
                input_locations=MappingProxyType({k: v["location"] for k, v in ctx["inputs"].items()}),
                output_locations=MappingProxyType({k: v["location"] for k, v in ctx["outputs"].items()})))
            print(json.dumps(dict(event="TASK_PLAN", **public_context,
                steps=[dict(sequence=s["step_sequence_number"], code=s["step_code"], type=s["step_type"])
                       for s, _, _ in plan]), default=lambda v: dict(v) if isinstance(v, MappingProxyType) else str(v)), flush=True)
            if self.spark is None:
                self.spark = SparkSession.getActiveSession() or SparkSession.builder.getOrCreate()
            frames = None
            for step, handler, params in plan:
                ctx["step_code"] = step["step_code"]
                print(f"STEP_STARTED run={run_id} step={ctx['step_code']}", flush=True)
                frames = handler(frames, public_context if step["step_type"] == "CUSTOM_PYTHON" else ctx, params)
                if (not isinstance(frames, dict) or not frames or
                        any(not isinstance(k, str) or not k or not isinstance(v, DataFrame)
                            for k, v in frames.items())):
                    raise TypeError(f"Step {ctx['step_code']} must return a nonempty dict[dataset_code, Spark DataFrame].")
            self._complete(ctx)
            return self.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id", id=run_id)
        except Exception as exc:
            print(f"TASK_FAILED run={run_id} step={ctx['step_code']} error={type(exc).__name__}: {exc}", flush=True)
            self.fail_task_run(run_id, type(exc).__name__, str(exc), ctx["step_code"])
            raise

    def _resolve_plan(self, ctx, custom_steps):
        """Resolve every handler before source reads, business code, or writes."""
        builtins = BUILTINS
        if not isinstance(custom_steps, dict):
            raise ValueError("custom_steps must be a dictionary of named functions.")
        if builtins.keys() & custom_steps.keys():
            raise ValueError("BUILTIN names cannot be overridden by custom_steps.")
        steps = self.db.execute("SELECT * FROM METADATA.TASK_STEP WHERE config_release_id=:r AND task_id=:t ORDER BY step_sequence_number",
            r=ctx["batch"]["config_release_id"], t=ctx["task"]["task_id"])
        if not steps:
            raise ValueError("Task has no configured steps.")
        plan = []
        for step in steps:
            ctx["step_code"] = code = step["step_code"]
            if step["is_required"] != "Y" or step["on_failure_action"] != "FAIL_TASK":
                raise ValueError("POC uses required steps and FAIL_TASK only.")
            if step["step_type"] not in ("BUILTIN", "CUSTOM_PYTHON"):
                raise ValueError(f"Unsupported step_type for {code}.")
            handler = (builtins if step["step_type"] == "BUILTIN" else custom_steps).get(code)
            if not callable(handler):
                raise ValueError(f"Missing callable {step['step_type']} handler: {code}")
            params = _json_object(step.get("parameter_json"), f"Step {code} parameter_json")
            if step["step_type"] == "BUILTIN" and params:
                raise ValueError(f"BUILTIN {code} uses empty parameters in this POC.")
            plan.append((step, handler, params))
        # Generic boundaries, not a second per-task execution recipe.
        codes = [s["step_code"] if s["step_type"] == "BUILTIN" else None for s in steps]
        readers = {"READ_SOURCE", "READ_PARQUET"}
        sinks = {"WRITE_PARQUET", "LOAD_MAIN"}
        if codes[0] not in readers or any(c in readers for c in codes[1:]):
            raise ValueError("Plan must start with one read step.")
        if codes[-1] not in sinks or any(c in sinks for c in codes[:-1]):
            raise ValueError("Plan must end with one final sink step.")
        ctx["step_code"] = None
        return plan

    def source_path(self, batch, config, dataset, input_count):
        """Resolve one exact immutable delivery; no listing, globbing, or clock fallback."""
        def expand(value):
            result = str(value or "").replace("{YYYYMMDD}",
                date.fromisoformat(str(batch["cycle_date"])[:10]).strftime("%Y%m%d"))
            if any(c in result for c in "*[]{}"):
                raise ValueError("Source locations support only the {YYYYMMDD} date token; no wildcards.")
            return result.rstrip("/")

        root = expand(config["landing_path"])
        allowed = object_address(root)
        location = expand(dataset["physical_object_name"])
        if not location.lower().endswith(".csv"):
            if input_count != 1 or not config["file_pattern"]:
                raise ValueError("Multiple CSV inputs require an exact filename template on each DATASET.")
            filename = expand(config["file_pattern"])
            if "/" in filename or "@" in filename:
                raise ValueError("SOURCE_CONFIG.file_pattern must be a filename, not a path.")
            location += "/" + filename
        actual = object_address(location)
        if (not allowed[2] or actual[:2] != allowed[:2] or
                not actual[2].startswith(allowed[2] + "/") or
                not actual[2].lower().endswith(".csv")):
            raise ValueError("Source must be an exact CSV within SOURCE_CONFIG.landing_path.")
        return location

    def _prepare_dataflow(self, ctx, plan):
        """Resolve every schema, location and policy before external data I/O."""
        batch, task = ctx["batch"], ctx["task"]
        for role in ("INPUT", "OUTPUT"):
            specs = {}
            for dataset in self._datasets(batch, task, role):
                code = dataset["dataset_code"]
                if code in specs:
                    raise ValueError("Duplicate task/dataset association.")
                specs[code] = dict(dataset=dataset,
                    columns=self._columns(batch["config_release_id"], dataset["dataset_id"]))
            ctx["inputs" if role == "INPUT" else "outputs"] = specs
        if set(ctx["inputs"]) & set(ctx["outputs"]):
            raise ValueError("Input and output must be distinct datasets.")
        reader, sink = plan[0][0]["step_code"], plan[-1][0]["step_code"]
        if reader == "READ_SOURCE":
            config = self.db.one("SELECT * FROM METADATA.SOURCE_CONFIG WHERE config_release_id=:r AND source_config_id=:s",
                r=batch["config_release_id"], s=task["source_config_id"])
            if (task["task_type"] != "INGESTION" or not config or config["source_type"] != "FILE" or
                    config["ingestion_mode"] != "SINGLE_FILE" or
                    config["expected_input_count"] not in (None, len(ctx["inputs"]))):
                raise ValueError("READ_SOURCE requires an INGESTION FILE task; expected_input_count must match its CSV inputs.")
            ctx["source_config"] = config
            if sink == "WRITE_PARQUET" and all(s["dataset"]["layer"] == "RAW" for s in ctx["outputs"].values()):
                # Explicit pairing applies only to source-preserving CSV -> RAW copies.
                paired = {}
                for role in ("inputs", "outputs"):
                    by_sequence = {}
                    for code, spec in ctx[role].items():
                        sequence = spec["dataset"]["usage_sequence"]
                        if sequence is None or sequence <= 0 or sequence in by_sequence:
                            raise ValueError("RAW pairing requires unique positive usage_sequence values per INPUT/OUTPUT role.")
                        by_sequence[sequence] = code
                    paired[role] = by_sequence
                if paired["inputs"].keys() != paired["outputs"].keys():
                    raise ValueError("RAW INPUT/OUTPUT usage_sequence sets must match.")
                ctx["raw_pairs"] = {paired["outputs"][n]: code for n, code in paired["inputs"].items()}
                fields = ("column_name", "column_sequence", "data_type", "length_precision_scale", "is_nullable")
                for output, source in ctx["raw_pairs"].items():
                    a, b = ctx["inputs"][source]["columns"], ctx["outputs"][output]["columns"]
                    if ([tuple(c.get(f) for f in fields) for c in a] !=
                            [tuple(c.get(f) for f in fields) for c in b] or
                            any(c["data_type"] != "VARCHAR2" for c in a)):
                        raise ValueError("Paired LANDING/RAW schemas must match and preserve string representation.")
        for spec in ctx["inputs"].values():
            source = spec["dataset"]
            if reader == "READ_SOURCE":
                if source["storage_type"] != "CSV":
                    raise ValueError("READ_SOURCE requires CSV input datasets.")
                spec["location"] = self.source_path(batch, config, source, len(ctx["inputs"]))
            else:
                if source["storage_type"] != "PARQUET" or source["layer"] not in ("RAW", "STAGE"):
                    raise ValueError("READ_PARQUET requires RAW/STAGE Parquet inputs.")
                spec["producer_task_id"] = self._producer(batch["config_release_id"], source["dataset_id"])
                spec["location"] = self.output_path(batch, source)
        for spec in ctx["outputs"].values():
            target = spec["dataset"]
            if self._producer(batch["config_release_id"], target["dataset_id"]) != task["task_id"]:
                raise ValueError("Output producer does not match the requested task.")
            if sink == "LOAD_MAIN":
                if target["storage_type"] != "ADB_TABLE" or target["layer"] != "GOLD":
                    raise ValueError("LOAD_MAIN requires GOLD ADB_TABLE outputs.")
                spec["location"] = sql_identifier(target["physical_object_name"], qualified=True)
            else:
                if target["storage_type"] != "PARQUET" or target["layer"] not in ("RAW", "STAGE"):
                    raise ValueError("WRITE_PARQUET requires RAW/STAGE Parquet outputs.")
                spec["location"] = self.output_path(batch, target)
            if target["layer"] in ("STAGE", "GOLD") and (len(plan) < 2 or
                    plan[-2][0]["step_type"] != "BUILTIN" or plan[-2][0]["step_code"] != "VALIDATE_DQ"):
                raise ValueError("VALIDATE_DQ must immediately precede the final sink for STAGE/GOLD output.")
            spec["policies"] = self.db.execute("SELECT * FROM METADATA.POLICY_DEFINITION WHERE config_release_id=:r AND dataset_id=:d AND is_enabled='Y'",
                r=batch["config_release_id"], d=target["dataset_id"])
            definitions = {c["dataset_column_id"]: c for c in spec["columns"]}
            for policy in spec["policies"]:
                column = definitions.get(policy["dataset_column_id"])
                if (not column or policy["policy_scope_type"] != "DATASET_COLUMN" or policy["policy_type"] != "DQ" or
                        policy.get("task_id") not in (None, task["task_id"]) or
                        _json_object(policy.get("parameter_json"), f"Policy {policy['policy_code']} parameter_json") != {"check": "NOT_NULL"} or
                        policy["failure_action"] != "FAIL_TASK" or policy["threshold_value"] != "0"):
                    raise ValueError("Supported policies are output-column NOT_NULL checks with threshold 0 and FAIL_TASK.")
                policy["column_name"] = column["column_name"]
        inputs = {s["location"] for s in ctx["inputs"].values()}
        outputs = [s["location"] for s in ctx["outputs"].values()]
        if len(set(outputs)) != len(outputs) or inputs & set(outputs):
            raise ValueError("Physical output targets must be distinct from each other and all inputs.")
        if sink == "WRITE_PARQUET":
            for index, location in enumerate(outputs):
                for other in outputs[index+1:] + list(inputs):
                    if location.startswith(other + "/") or other.startswith(location + "/"):
                        raise ValueError("Parquet output prefixes must not overlap inputs or other outputs.")

    def _complete(self, ctx):
        batch, task, run_id = ctx["batch"], ctx["task"], ctx["run_id"]
        if set(ctx["state"].get("outputs", {})) != set(ctx["outputs"]):
            raise ValueError("Task did not prepare all required outputs.")
        with self.db.transaction():
            current_batch = self._batch(batch["batch_id"])
            run = self.db.one("SELECT status FROM RUNTIME.TASK_RUN WHERE task_run_id=:id FOR UPDATE", id=run_id)
            if current_batch["status"] != "RUNNING" or run["status"] != "RUNNING":
                raise ValueError("Completion requires a RUNNING batch and exact attempt.")
            for code, output in ctx["state"]["outputs"].items():
                spec = ctx["outputs"][code]
                if "rows" in output:
                    records = [dict(row, BATCH_ID=batch["batch_id"], TASK_RUN_ID=run_id, ROW_NUMBER=seq)
                               for seq, row in enumerate(output["rows"], 1)]
                    types = {c["column_name"]: c["data_type"] for c in spec["columns"]}
                    types.update(BATCH_ID="NUMBER", TASK_RUN_ID="NUMBER", ROW_NUMBER="NUMBER")
                    self.db.insert_many(spec["location"], list(types), records, types)
                self._event(batch, run_id, "MAIN_TABLE_LOADED" if "rows" in output else "PARQUET_WRITTEN",
                    "Output written", details={"dataset_code": code, "path": spec["location"], "rows": output["count"]})
            for spec in ctx["inputs"].values():
                if "ingestion_item_id" in spec:
                    self.db.execute("""UPDATE RUNTIME.INGESTION_ITEM SET status='PROCESSED', source_record_count=:count,
                        processed_timestamp=SYSTIMESTAMP WHERE ingestion_item_id=:id""",
                        count=spec["count"], id=spec["ingestion_item_id"])
            self.db.execute("""UPDATE RUNTIME.TASK_RUN SET status='COMPLETED', input_count=:ic, output_count=:oc,
                reject_count=0, end_timestamp=SYSTIMESTAMP WHERE task_run_id=:id""",
                ic=ctx["input_count"], oc=ctx["output_count"], id=run_id)
            self._event(batch, run_id, "TASK_COMPLETED", task["task_code"])
            if task["close_batch_on_success"] == "Y":
                self.db.execute("UPDATE RUNTIME.BATCH SET status='COMPLETED', end_timestamp=SYSTIMESTAMP WHERE batch_id=:id", id=batch["batch_id"])
                self._event(batch, run_id, "BATCH_COMPLETED", "Terminal AIDP task completed")

    def fail_task_run(self, run_id, code, message, failed_step=None):
        with self.db.transaction():
            run = self.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id", id=run_id)
            if not run:
                raise ValueError("Unknown exact task run ID.")
            batch = self._batch(run["batch_id"])
            run = self.db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id FOR UPDATE", id=run_id)
            if run["status"] != "RUNNING":
                return  # Delayed/duplicate callbacks never change terminal attempts.
            if batch["status"] != "RUNNING":
                raise ValueError("Cannot fail an attempt in a terminal batch.")
            self._fail_in_tx(run, batch, code, message, failed_step)

    def _fail_in_tx(self, run, batch, code, message, failed_step):
        run_id = run["task_run_id"]
        self.db.execute("""UPDATE RUNTIME.TASK_RUN SET status='FAILED', error_code=:c,
            error_message=:m, failed_step_code=:s, end_timestamp=SYSTIMESTAMP WHERE task_run_id=:id""",
            c=code[:100], m=message[:4000], s=failed_step, id=run_id)
        self.db.execute("UPDATE RUNTIME.INGESTION_ITEM SET status='FAILED' WHERE task_run_id=:id AND status<>'PROCESSED'", id=run_id)
        queue_id = self.db.next_id("OPERATIONS.WORK_QUEUE", "work_queue_id")
        self.db.insert("OPERATIONS.WORK_QUEUE", dict(work_queue_id=queue_id,
            target_config_release_id=run["config_release_id"], scope_type="TASK", batch_id=run["batch_id"],
            task_run_id=run_id, idempotency_key=f"EXCEPTION:{run['batch_id']}:{run_id}",
            reason_code=code[:100], description=message[:2000], status="OPEN", requested_by="MDPF"))
        self._event(batch, run_id, "TASK_FAILED", message, error_code=code)

    def fail_batch(self, batch_id):
        with self.db.transaction():
            batch = self._batch(batch_id)
            if batch["status"] == "FAILED":
                return
            if batch["status"] != "RUNNING":
                raise ValueError("Terminal batch cannot change status.")
            if self.db.one("SELECT task_run_id FROM RUNTIME.TASK_RUN WHERE batch_id=:b AND status='RUNNING'", b=batch_id):
                raise ValueError("Stop writers and terminalize exact active attempts first.")
            self.db.execute("UPDATE RUNTIME.BATCH SET status='FAILED', end_timestamp=SYSTIMESTAMP WHERE batch_id=:id", id=batch_id)
            self._event(batch, None, "BATCH_FAILED", "Scheduler declared retries exhausted", error_code="RETRIES_EXHAUSTED")

    def _event(self, batch, run_id, code, message, details=None, error_code=None):
        event_id = self.db.next_id("OPERATIONS.EVENT_LOG", "event_log_id")
        self.db.insert("OPERATIONS.EVENT_LOG", dict(event_log_id=event_id,
            config_release_id=batch["config_release_id"], batch_id=batch["batch_id"], task_run_id=run_id,
            event_code=code, event_type="ERROR" if error_code else "INFO", severity="HIGH" if error_code else "LOW",
            error_code=error_code[:100] if error_code else None, message=message[:4000],
            details_json=json.dumps(details) if details else None,
            correlation_id=batch["correlation_id"], created_by="MDPF"))
