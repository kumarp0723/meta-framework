# MDPF 1.0 verification

Documentation refresh: the README now focuses on setup, execution, Repair and
troubleshooting, with one-line module descriptions. Source, wheel, SQL and notebooks
are unchanged. Documentation examples/paths and package manifests were checked;
the existing 162-test result below was not rerun for this documentation-only update.

Verified with the cleaned SQL Generator on 2026-10-16 UTC:
**162 tests passed in 563.35 seconds; no skips** using real Spark 3.5.7 and Java 17,
with SQLite/catalog/OCI doubles. Tests are shipped in the generator package.

## Scope

The framework's seven source modules, wheel, four SQL scripts, notebooks and job-parameter
reference are byte-identical to the uploaded package. The **17-table / 232-column** schema
is unchanged. Both framework and generator software versions remain **1.0**.

The generator cleanup centralizes YAML loading and reuses resolved task plans. It preserves
original YAML-byte hashes, public APIs, legacy YAML options, the notebook custom registry,
explicit task steps and optional MAIN DDL. Eleven generation configurations produced
metadata SQL and MAIN DDL byte-identical to the uploaded implementation.

## Regression evidence

The suite covers ONE_TO_ONE, MANY_TO_ONE and ONE_TO_MANY execution, combined RAW sequence
pairing and schema preflight, partial RAW write failure and whole-task Repair, stable
receipts, pinned release/location reuse, immutable failed attempts and OPEN errors,
custom STAGE joins, MAIN routing and multi-target rollback/completion. Mixed output
contracts execute in either metadata order. Generated MAIN CREATE statements are translated
into CI-only tables and loaded through the actual framework. These are not live Oracle
DDL or transaction proofs.

Both package wheels retain version 1.0 and match source. The existing framework wheel is
retained without rebuilding unchanged runtime code. Source and notebook cells compile.
Manifests verify every delivered file; obsolete builds/caches are excluded.

MDPF wheel SHA256: `8777a56580700803cd4ba80bc1fd1c4f52c9cab81be2f9f0cfc7405e96bf7bd7`

## Live checks still required

No real Oracle, OCI or AIDP environment was contacted. Verify Oracle DDL/grants/wallet/network
and transaction behavior, Spark OCI driver/worker permissions, Resource Principal access
for onboarding, and normal -> notebook failure -> Repair in AIDP. Confirm job.run_id keeps
the original batch correlation. MAIN DDL generation is review-only and must be executed
manually for new tables; Oracle DDL commits independently.

The existing POC limits remain: driver-collected MAIN loading, immutable dated source
URIs, full RAW overwrite on Repair and independent Parquet writes. No REPROCESS, Iceberg
ledger, exactly-once claim, step checkpoint/retry engine, hard-timeout reconciliation or
new scheduler machinery is introduced. Active runs retain their original wheel/notebooks.
