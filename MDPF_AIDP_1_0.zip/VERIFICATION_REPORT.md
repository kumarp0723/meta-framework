# MDPF 1.0 verification

Verified 2026-10-17 UTC: **189 tests passed in 64.15 seconds; no skips**.
The suite is shipped in the companion SQL Generator package. It uses Python 3.12,
real Spark 3.5.7 and Java 17, with CI-only Oracle/catalog/OCI doubles.

## Changes verified

- One small JSON-object reader serves TASK_STEP and POLICY_DEFINITION parameters.
  It accepts decoded dictionaries or JSON text; missing/blank values become {}.
  Arrays, scalars, unsupported types and malformed JSON are rejected with context.
- Native decoded JSON is exercised through real framework execution, including
  notebook custom parameters and passing/blocking NOT_NULL policies. Blocking results
  still fail the attempt and create WORK_QUEUE history. Invalid step JSON fails before I/O.
- Companion generator regressions cover typed STAGE-to-MAIN validation and combined
  missing-type guidance for empty output sample columns. No SQL/DDL is uploaded while
  overrides are required; generation succeeds after valid overrides are supplied.

## Preserved behavior

The existing suite covers all three onboarding relationships, combined RAW inputs,
source receipts, schema checks, metadata pinning, failure/whole-task Repair, immutable
failed attempts, retained OPEN errors and multi-target MAIN rollback/completion.

Only pipeline.py changes in the runtime. Oracle DDL remains **17 tables / 232 columns**.
All SQL scripts, notebooks, job parameters, credential handling and other runtime modules
are byte-identical to the supplied ZIP. Package/wheel versions remain **1.0**.

Both wheels were rebuilt and checked against source; direct wheel imports, Python/notebook
compilation and final SHA-256 manifests pass. Old builds, caches and dependency downloads
are excluded from the ZIPs.

MDPF wheel SHA256: `f05c1a48fecf39a277735e018b61b5b81322480d520766181c8c42f3cbad8f7c`

## Environment checks outstanding

No real Oracle database, OCI bucket or AIDP job was contacted. Verify Oracle DDL/grants,
network/wallet/transactions, Spark OCI driver/worker access and actual AIDP success,
notebook failure and Repair with stable job.run_id. A CI-only Spark launcher adjustment
for unavailable /dev/fd is not shipped.

POC scope is unchanged: small-data driver-collected MAIN loading, immutable dated source
URIs, deterministic Parquet overwrite on Repair and independent object writes. No REPROCESS,
Iceberg, step checkpoints, exactly-once guarantee or automatic hard-timeout recovery.
