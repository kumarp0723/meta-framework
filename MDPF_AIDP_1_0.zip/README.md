# MDPF 1.0 — run and support a pipeline

MDPF runs metadata-defined Spark steps from OCI AIDP notebooks and records their
execution in Oracle. AIDP controls scheduling, dependencies and Repair.
This package and its wheel are version **1.0**.

## How it works

| Part | Responsibility |
|---|---|
| SQL Generator | Turns YAML and sample CSVs into DRAFT metadata; its README covers onboarding |
| Oracle metadata | Defines datasets, columns, task inputs/outputs and ordered `TASK_STEP` rows |
| Notebook | Registers custom business functions and calls `execute_task()` |
| MDPF | Resolves/runs the plan and records status, errors and lineage |
| Spark / OCI | Reads landing CSVs and writes RAW/STAGE Parquet to their separate buckets |
| Oracle MAIN | Stores final rows; inserts, task completion and batch closure share one transaction |

One AIDP `job.run_id` identifies one `BATCH`. Each task attempt gets a new
`TASK_RUN`. Repair retains the batch's pinned metadata release and cycle date.

## Set up once

1. Have a DBA provision `METADATA`, `RUNTIME`, `OPERATIONS`, the MAIN owner and
   runtime login. On a **fresh installation only**, run `sql/00_framework.sql`,
   then `sql/01_main_and_access.sql` in SQLcl/SQL*Plus script mode. The second
   script supplies sequences, runtime grants and example `DMI_MAIN.DMI_FEE`;
   adapt owner/login names before running it. Existing installations keep their tables.
2. Install `dist/mdpf-1.0-py3-none-any.whl` and its `oracledb>=2,<4` dependency
   on the AIDP cluster. Use cluster-provided PySpark. Replacing another build
   labelled 1.0 requires `pip install --force-reinstall --no-deps <wheel-path>`.
3. Configure Spark OCI access on **driver and workers**: landing read/list;
   RAW/STAGE read/list/write/overwrite/delete and required multipart permissions.
   Each layer can use its own bucket/namespace. Quarantine movement is outside scope.
4. Give every notebook driver Oracle network access and these environment variables
   through secure configuration:

   ```text
   MDPF_DB_USER
   MDPF_DB_PASSWORD
   MDPF_DB_DSN
   ```

   Wallets may also need `MDPF_DB_CONFIG_DIR`, `MDPF_DB_WALLET_LOCATION` and
   `MDPF_DB_WALLET_PASSWORD`. A catalog connection does not configure this direct
   connection. Keep credentials out of notebooks, YAML and job parameters.

## Run the supplied DMI example

1. Edit `sql/02_dmi_metadata.sql`: real landing/RAW/STAGE locations, MAIN target
   and column definitions. Use unused release ID/version values if already deployed.
   Review and execute it; its final statements approve and activate the example.
2. Upload a matching CSV to landing, for example `fee_20261005.csv`. Its header
   and values must match the LANDING columns. `fee_{YYYYMMDD}.csv` resolves from
   the explicit `cycle_date=2026-10-05`; there is no current-date fallback.
3. Import the three `notebooks/Task_*.ipynb` files and attach them to the configured
   cluster. Create `Job_DMI` with RAW → STAGE → MAIN dependencies and downstream
   condition **All success**. Set retries **0** for the Repair demo; disable retry-on-timeout.
4. Enter these parameters using `notebooks/job_parameters.json` as a UI reference
   (it is not an API import file):

| Scope | Parameters |
|---|---|
| Job | `cycle_date=2026-10-05`, `fail_first_stage=false` |
| Every task | `job_run_id={{job.run_id}}`, `task_run_id={{task.run_id}}`, `execution_count={{task.execution_count}}` |
| RAW | `cycle_date={{job.parameters.cycle_date}}`, `execution_mode={{job.trigger.type}}` |
| STAGE | `fail_first_stage={{job.parameters.fail_first_stage}}` |

5. Run the job. Expect RAW/STAGE Parquet below each dataset's `/batch_<batch_id>`
   prefix, MAIN rows, three completed task runs and a completed batch.
   Use `sql/03_inspect.sql` to inspect the example.

For the failure demo, start a **new job run** with `fail_first_stage=true`.
RAW completes, STAGE attempt 1 fails and MAIN does not run. The batch stays
RUNNING and `WORK_QUEUE` retains an OPEN error.

Choose **Repair on that same job run**, selecting STAGE and MAIN only. Keep the
flag true: the notebook function succeeds when `execution_count > 1`. Expect
STAGE attempt 2 and MAIN completion in the original batch. The old failure/error
remain. Confirm Repair preserves `job.run_id` in your environment.
**Run Now creates a new batch; it is not Repair.**

## Use your own pipeline

Follow the SQL Generator README to deploy/activate metadata and prepare MAIN
tables. Copy the notebooks, replace pipeline/task codes, and remove the example
business function/failure flag unless your metadata references them.

```python
from mdpf.aidp import execute_task

result = execute_task(
    pipeline_code="DEMO_LOAN",
    task_code="DEMO_LOAN_STAGE_LOAD",
    aidputils=aidputils,
    custom_steps={},
)
```

Register custom functions under the exact `TASK_STEP.step_code`. Each takes
`(frames, context, params)` and returns `dict[dataset_code, Spark DataFrame]`.
Readers return INPUT keys; custom joins/routing return OUTPUT keys. Read-only
context supplies pipeline/task/batch/run/release IDs, cycle date and location
maps; `params` comes from step JSON. Business code stays in the notebook.

Built-ins: `READ_SOURCE`, `READ_PARQUET`, `DIRECT_MAP`, `VALIDATE_DQ`,
`WRITE_PARQUET`, `LOAD_MAIN`. They cannot be overridden and take empty parameters.
Metadata controls order: one reader first, one sink last, DQ immediately before
STAGE/MAIN writes. All steps use `FAIL_TASK`; Repair reruns the entire task.

`DATASET_COLUMN` controls names/order/types/constraints. LANDING/RAW preserve
input strings; STAGE/MAIN use the output contract. `DIRECT_MAP` projects matching
names and converts VARCHAR2, NUMBER(p,s) and date-only DATE (`YYYY-MM-DD`).
Notebooks handle renaming/business parsing. Invalid conversion, nulls and
size/precision violations fail before writes. Multiple CSV inputs pair with RAW
outputs by `usage_sequence`; joins and other multi-input routing need custom code.
MAIN tables need business columns plus `BATCH_ID`, `TASK_RUN_ID`, `ROW_NUMBER`.

## Find and resolve a failure

Start with the failed notebook log: MDPF prints `TASK_PLAN`, `STEP_STARTED` and
`TASK_FAILED`. Find `BATCH` by pipeline and AIDP job ID, then inspect the attempt's
`TASK_RUN.failed_step_code`, `error_code`, `error_message` and attempt number.
`WORK_QUEUE` retains failures; `EVENT_LOG` records lifecycle/output paths;
`INGESTION_ITEM` records source receipts. Adapt `sql/03_inspect.sql` filters for your pipeline.

| Symptom | Check / next action |
|---|---|
| Oracle connection fails | Driver environment, DSN, network, wallet and grants |
| Source missing / OCI denied | Pinned cycle date, resolved URI and Spark driver/worker access |
| Task/handler missing | Pinned release, `TASK_STEP` code and notebook registration |
| Schema/DQ failure | `DATASET_COLUMN`, source values and `POLICY_RESULT` evidence when configured |
| Parquet input rejected | Producer's completed attempt and object lineage; do not replace batch files manually |
| Attempt still RUNNING | Confirm the old writer stopped; operator must fail that exact run before Repair |
| Task already COMPLETED | Exclude it from Repair; select failed/downstream tasks only |

Keep wheel, notebooks, metadata and deliveries unchanged during Repair. Changed
business logic or published metadata needs a new release/job run. Terminal batches
never reopen. If restart is abandoned, after writers stop and active attempts are
terminalized, call `mdpf.aidp.finalize_failed_job(pipeline_code="...", job_run_id="...")`.

## Where the code lives

| Module in `src/mdpf/` | Responsibility |
|---|---|
| `aidp.py` | Reads notebook parameters; exposes execution/finalization entry points |
| `pipeline.py` | Resolves metadata, runs steps and records batch/task lifecycle |
| `steps.py` | Implements readers, direct mapping, DQ and output preparation |
| `schema.py` | Validates schemas/values and performs explicit conversions |
| `storage.py` | Validates OCI paths; uses Spark for CSV/Parquet I/O |
| `db.py` | Opens Oracle connections; handles binds, inserts and transactions |
| `__init__.py` | Identifies the package/version |

POC limits: MAIN collects small datasets on the driver. Parquet Repair overwrites
batch paths; multiple OCI writes are not atomic. Dated source URIs must be
immutable; automatic receipts provide lineage, not cross-batch deduplication.
Only simple NOT_NULL policies are implemented. The 17-table model retains unused
MAPPING_RULE, PIPELINE_STATE and OUTBOUND_CONFIG. REPROCESS, Iceberg and automatic
hard-timeout recovery are outside scope. See `VERIFICATION_REPORT.md` for tests
and outstanding live AIDP/Oracle/OCI validation.
