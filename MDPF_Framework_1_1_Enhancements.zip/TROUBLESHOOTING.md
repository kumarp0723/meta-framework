# Troubleshooting

| Symptom | Check/action |
|---|---|
| Bulk row FAILED for a sample | Check the exact OCI URI and HEAD access. Fix the object/permissions, then rerun; do not add schema checks to the builder. |
| Existing YAML skipped | Save is create-only. Edit a maintained configuration explicitly or choose a new release-specific destination. |
| Batch RUNNING after RAW success | Expected when Phase 2 is intentionally delayed. Reuse the same key; do not call a failure finalizer for waiting. |
| Phase 2 says INGESTION must create batch | Wrong/new execution key or wrong pipeline/environment. Use the original key. |
| Cycle conflicts | Use the original batch cycle date or omit the downstream override. |
| Completed task cannot restart | Retry only failed/downstream tasks. New intentional deliveries need new execution keys. |
| Attempt still RUNNING after worker loss | Stop its external writer; fail that exact internal task_run_id before retrying. Do not guess from elapsed time. |
| RAW technical validation failure | Inspect header/CSV/type/length/nonempty/source contract. Only proven data failures qualify for whole-file quarantine. |
| Quarantine copy failed | Inspect both original validation and copy errors; check region, ETag, bucket/service permissions and work request. Unconfirmed copies do not mark QUARANTINED. |
| STAGE DQ fails | Inspect POLICY_RESULT by task_run_id, correct deterministic business logic/configuration, retry STAGE and downstream with the same key. RAW remains intact. |
| WARN recorded but task fails | WARN cannot bypass required schema, conversion or Oracle constraints. Inspect the actual task error. |
| Parquet audit/lineage rejected | Check exact producer/run/batch/receipt fields and layer schema. Old-format files require the old runtime; see UPGRADE.md. |
| MAIN row limit exceeded | No rows inserted. Review input size/driver memory; configure a suitable cap and retry MAIN in the same batch. No truncation occurs. |
| MAIN insert reconciliation failed | All MAIN target inserts/completion were rolled back. Inspect expected/actual policy evidence and adapter row counts; fix and retry MAIN. |
| Oracle uniqueness/check error | Review actual target constraints and cross-batch data. STAGE UNIQUE does not guarantee cross-batch uniqueness. |
| Sample conversion fails during onboarding | Review explicit datatypes/capacity or custom parsing. Sample validation belongs to onboarding, not the pre-builder. |

Use existing RUNTIME.TASK_RUN, RUNTIME.POLICY_RESULT, RUNTIME.INGESTION_ITEM,
OPERATIONS.EVENT_LOG and OPERATIONS.WORK_QUEUE, filtered by batch/task attempt.
Retain failed attempts and error history after a successful retry. Inspect
framework `sql/03_inspect.sql`; no waiting dashboard or new operational tables exist.
