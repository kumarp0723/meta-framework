# Development rollout — 1.0 → 1.1

1. Stop launching new development batches. Finish existing batches with the older
   runtime, or deliberately abandon them after stopping writers. Keep the older
   runtime available for any retained old-format batch that must still finish.
   Configuration pinning does not pin Python application code.
2. Install both 1.1 wheels and restart notebook/worker sessions. Replace runtime
   dependency archives/wheels for Data Flow as well. The package version is 1.1;
   pipeline metadata release_version remains independently chosen text.
3. The 17-table framework schema is unchanged. **Do not rerun fresh-install DDL**
   against an existing framework. For new development MAIN tables, use regenerated
   CREATE proposals. Existing targets need CREATED_AT/UPDATED_AT TIMESTAMP(6) WITH
   TIME ZONE NOT NULL. Review framework `sql/04_main_audit_columns.sql`, a manual
   preserving proposal for one existing MAIN target. Historical timestamps use
   recorded attempt completion as an approximation, explicitly documented there.
   Review missing history/backfill cases before enforcing NOT NULL. DDL commits
   independently and is never run by the utility.
4. Move legacy MAIN column DQ entries to their matching STAGE dataset in a new
   DRAFT configuration. Use [FEATURES.md](FEATURES.md) for severity/rule syntax.
   Existing published metadata remains immutable. Complete-YAML baseline comparison
   remains strict: first make a reviewed 1.1-compatible configuration; do not
   silently rewrite published definitions. A legacy baseline containing MAIN column
   DQ needs a separately reviewed conversion before 1.1 comparison can validate it.
5. Generate/review/deploy/approve/activate the new release. Configure the MAIN worker's
   MDPF_MAIN_MAX_ROWS if a reviewed value above the 10,000-row default is necessary.
   Set Spark session timeZone=UTC for consistent audit display. Run the read-only
   Oracle target gate to check timestamp fields/types/precision as well as business
   columns and required grants.
6. Start a **new execution key/batch** for the new physical audit contract. Old RAW
   or STAGE Parquet lacks the new required fields and is rejected by 1.1 readers.
   Never manufacture receipt IDs or overwrite completed old-batch output to add
   fields. This development release intentionally does not infer missing lineage.
7. Verify same-day success, delayed continuation, warning/failure evidence, MAIN
   rollback and one real OCI quarantine test before enabling normal scheduling.

No deployment, schema migration or metadata activation is performed by these ZIPs.
