# MDPF Framework 1.1

Run metadata-defined Spark tasks on OCI Data Flow or AIDP, with Oracle execution
history and transactional MAIN loading. The 17-table framework model is unchanged.

Start with the [end-to-end quick start](QUICK_START.md). Existing installations
must follow [development rollout](UPGRADE.md) before switching runtimes.

- **Same-day or two-phase:** RAW can finish now and STAGE/MAIN later in the same
  batch and pinned release. Data Flow reuses its execution key; AIDP optionally
  accepts `workflow_execution_key` across separate jobs. [Scheduling](TWO_PHASE.md)
- **Business DQ at STAGE:** NOT_NULL, UNIQUE, RANGE and ALLOWED_VALUES with FAIL/WARN.
  MAIN verifies actual Oracle inserts before commit. [Rules](FEATURES.md)
- **Five audit fields:** RAW source receipt/time, STAGE processing time, MAIN
  creation/update times; populated and validated automatically. [Contract](FEATURES.md#five-framework-managed-audit-fields)
- **Bounded MAIN loading:** default `MDPF_MAIN_MAX_ROWS=10000` across all task outputs.
  Exceeding the limit fails before inserts; nothing is truncated.
- **Whole-file quarantine:** proven RAW technical validation failures only;
  the source stays in landing. STAGE business failures retain normal failure behavior.

Install `dist/mdpf-1.1-py3-none-any.whl` with its dependencies and restart workers.
Use cluster-provided Spark/Java. No runtime deployment or metadata activation is
performed by this package.

| Reference | Contents |
|---|---|
| [Detailed reference](REFERENCE.md) | Setup, built-in plans, custom handlers and recovery |
| [OCI permissions example](OCI_IAM_EXAMPLE.md) | Dedicated-compartment IAM example and official links |
| [Troubleshooting](TROUBLESHOOTING.md) | Phase waits, DQ, lineage, limits and failed counts |
| [Verification report](VERIFICATION_REPORT.md) | Current test evidence and environment limitations |

Fresh installs use `sql/00_framework.sql` and `sql/01_main_and_access.sql` with
reviewed owners/grants. `sql/04_main_audit_columns.sql` is an optional reviewed
proposal for adding audit timestamps to an existing MAIN table. It does not change
framework tables. Keep credentials outside YAML/notebooks.

Waiting-batch dashboard, archive, row rejection and MERGE remain outside this release.
