# Same-day and two-phase scheduling

The default remains RAW → STAGE → MAIN in one scheduled workflow. Two-phase
scheduling uses the same tasks and metadata, with a scheduling gap after RAW.
MDPF does not launch the second phase or introduce a PAUSED state.

## Data Flow / ActiveBatch

Phase 1 launches only RAW with these arguments (substitute actual identifiers):

```text
--execution-key ACTIVEBATCH:<unique-workflow-instance>
--cycle-date 2026-10-15
--execution-mode SCHEDULED
```

Persist the exact key in scheduler state across both phases. Later launch STAGE,
then MAIN only on STAGE success, each with the same `--execution-key`. Omit cycle
and mode overrides or pass their original values; a new business date does not
change the batch cycle date. Each actual Data Flow run supplies its own real run
OCID through DATAFLOW_RUN_ID or --run-id. Never generate a new workflow key per
phase or per retry. A date alone is not a unique workflow identity.

## AIDP across separate job runs

Keep real `job_run_id`, `task_run_id`, `execution_count` bindings for every task.
Add `workflow_execution_key` with one scheduler-supplied resolved workflow key
shared across Phase 1 RAW-only and Phase 2 STAGE → MAIN jobs. Do not use
`{{job.run_id}}` for that shared key: it changes between jobs. The key supports
up to 300 UTF-8 bytes and rejects unresolved templates/control characters.

The same `mdpf.aidp.execute_task(...)` API reads the additional widget. Empty/omitted
values retain `AIDP:<job_run_id>` for existing single-job workflows. The original
job correlation stays on BATCH; every task attempt keeps its real external task ID.
See framework `notebooks/two_phase_parameters.json` for a UI setup guide; it is
not an import payload. Platform bindings still need validation in your OCI setup.

## State and restart rules

RAW-only success leaves RAW COMPLETED and BATCH RUNNING. Phase 2 resolves the same
batch by key, uses its original pinned release and reads only retained RAW. Changing
the ACTIVE release while waiting does not change that batch. A wrong/new key cannot
start STAGE; changed cycle/mode overrides fail. Missing/malformed Parquet lineage,
audit fields or noncompleted producers fail safely. Completed RAW cannot rerun.

After STAGE/MAIN failure, retry failed/downstream tasks with the same key and fresh
attempt identities; earlier failed attempts/error history remain. MAIN success
closes the batch. Terminal batches cannot reopen. Keep RAW/STAGE files, pinned
metadata and compatible application code for the supported continuation period.

Only after writers stop and the execution is deliberately abandoned:

```python
from mdpf.aidp import finalize_failed_job
finalize_failed_job(pipeline_code='MY_PIPELINE', workflow_execution_key='MY_STABLE_KEY')
# Existing single-job workflows can still use job_run_id='...'. Supply one identity.
```

Data Flow uses `mdpf.runner.finalize_failed_batch(pipeline_code=..., execution_key=...)`.
These are failure finalizers, not phase-transition calls. No waiting-batch dashboard
or automatic timeout/finalization is implemented.
