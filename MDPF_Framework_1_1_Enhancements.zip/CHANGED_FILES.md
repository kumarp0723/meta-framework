# Changed files — 1.1

Compared with the attached MDPF_Framework_1_0_Whole_File_Quarantine.zip.

| Change | Package-relative file |
|---|---|
| Added | `CHANGELOG.md` |
| Added | `FEATURES.md` |
| Added | `OCI_IAM_EXAMPLE.md` |
| Added | `QUICK_START.md` |
| Changed | `README.md` |
| Added | `REFERENCE.md` |
| Added | `TROUBLESHOOTING.md` |
| Added | `TWO_PHASE.md` |
| Added | `UPGRADE.md` |
| Changed | `VERIFICATION_REPORT.md` |
| Changed | `dataflow/requirements.txt` |
| Added | `dist/mdpf-1.1-py3-none-any.whl` |
| Changed | `notebooks/job_parameters.json` |
| Added | `notebooks/two_phase_parameters.json` |
| Changed | `pyproject.toml` |
| Changed | `sql/01_main_and_access.sql` |
| Changed | `sql/02_dmi_metadata.sql` |
| Changed | `sql/03_inspect.sql` |
| Added | `sql/04_main_audit_columns.sql` |
| Changed | `src/mdpf/__init__.py` |
| Changed | `src/mdpf/aidp.py` |
| Changed | `src/mdpf/db.py` |
| Changed | `src/mdpf/pipeline.py` |
| Changed | `src/mdpf/schema.py` |
| Changed | `src/mdpf/steps.py` |
| Removed | `dist/mdpf-1.0-py3-none-any.whl` |

SHA256SUMS.txt is regenerated for the final package.
