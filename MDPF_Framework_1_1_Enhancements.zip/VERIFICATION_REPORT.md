# Release 1.1 verification — 2026-10-25

**498 tests passed in 124.64 seconds, without failures or skips.**
**9 installed-wheel checks passed in 27.09 seconds.**

Tests use actual Spark 3.5.7, Java 17 and Python 3.12.14. OCI SDK 2.189.0,
python-oracledb 3.4.2 and pytest 9.1.1 were used. SQL metadata and transactional
failure checks run against the existing CI-only SQLite adapter; OCI operations
use test doubles. This is offline validation, not a live Oracle/OCI deployment.
The combined regression suite is in the companion generator package's tests/.

## Verified behavior

- Original same-day RAW/STAGE/MAIN success and existing failure/retry guards.
- RAW-only completion leaves BATCH RUNNING; a fresh phase-2 framework instance
  reuses the exact key, batch and release, even after a new release becomes ACTIVE.
  Landing files are removed in that test; phase 2 succeeds without rereading them.
- Wrong workflow keys/cycle overrides, completed RAW reruns, malformed producer
  lineage and missing/wrong system audit fields fail safely.
- AIDP's explicit workflow_execution_key spans separate job-run identities;
  the original job correlation remains pinned and task attempts retain real IDs.
  Existing single-job defaults and stable-key failure finalization are tested.
- ALLOWED_VALUES exact case/whitespace/empty-string/null behavior, numeric/date
  typing, precision/length limits and invalid/duplicate configuration.
- Existing NOT_NULL/UNIQUE/RANGE checks remain at STAGE. Instrumented tests prove
  each business policy is evaluated once, without repeated MAIN business checks.
- WARN records WARN/WARNED, keeps task status COMPLETED and reject_count zero,
  permits downstream reads, and cannot bypass mandatory schema constraints.
- Explicit RAW-to-STAGE and STAGE-to-MAIN ROW_COUNT pairing, per-output fan-out,
  joins/aggregation rejection for STAGE equality, and STAGE checks before writes.
- MAIN compares validated STAGE input counts against actual adapter insert counts,
  not only collected/prepared size. Partial/unknown/negative/boolean counts and
  multi-target mismatches roll back target rows/load events/completion together.
  Durable failure policy results, error history and same-batch retry are tested.
- Empty append outputs reconcile zero correctly. Main row caps are task-wide,
  fail before insert without truncation, reject invalid settings, bound every
  collect by remaining+1 and permit a reviewed-cap retry.
- RAW source receipt IDs are correct for each source in combined ingestion;
  RAW/STAGE timestamp and lineage types are checked and removed from business
  frames. MAIN creation/update values are UTC and equal on insert.
- Reserved audit names are rejected as business columns. Target checks recognize
  Oracle TIMESTAMP(6/9) WITH TIME ZONE dictionary types, require at least six-digit
  precision, reject wrong/missing types and keep the gate read-only.
- Public onboarding generation preserves new rules/scopes/severity in complete
  YAML, renders dataset reconciliation SQL, and includes timestamp target DDL.
- Existing whole-file RAW quarantine, confirmed-copy conditions/terminal guards,
  independent catalog rows and existence-only OCI HEAD checks remain passing.

## Package checks

Both wheels were built from the final source, installed into a clean local target,
and tested there. Their source bytes match the packaged source; wheel RECORD
hashes/sizes, Python 3.10 syntax, local documentation links, ZIP integrity and
SHA256SUMS.txt were checked. Old wheels, build trees, caches and test dependencies
are excluded from the ZIPs. CHANGED_FILES.md lists differences from the supplied
whole-file quarantine package for each component.

Framework sql/00_framework.sql is byte-identical to the attached baseline and
still defines 17 framework tables. RAW/STAGE system fields are physical Parquet
fields; MAIN audit changes belong to business tables. No new framework columns
or tables were added. Source storage.py and generator builder.py/bulk_builder.py
are also byte-identical to that baseline.

The example metadata/DDL and complete YAML were regenerated. Framework DMI example
metadata inserts, including both new count policies, passed the offline SQL
adapter. The optional preserving MAIN audit-column SQL is a review proposal only;
it has not been executed or validated against a real Oracle server.

The local test-only Spark launcher uses a temporary file instead of process
substitution because /proc/self/fd is unavailable here; Java temp paths were also
redirected to the workspace. Neither workaround changes shipped product code.

## Rollout and limits

Install both version 1.1 wheels, restart workers/notebooks and deploy a new reviewed
metadata release. Read UPGRADE.md first. Existing MAIN targets need the two audit
timestamp columns. Old-format retained Parquet requires the old runtime; finish
those batches there or start a new development batch. Do not infer missing source
receipt IDs or overwrite completed files to add fields.

MDPF_MAIN_MAX_ROWS defaults to 10000 across all outputs of a MAIN task; it is a row
bound, not a byte-memory guarantee or distributed load implementation. Parquet
writes remain independent external writes and retries overwrite attempt/batch
outputs under the existing guards; no multi-object OCI transaction is claimed.
WARN never bypasses technical schema or Oracle constraints. MAIN column business
policies must move to STAGE in new configurations.

No deployment, metadata activation, credential change or live bucket operation
was performed. Validate real Oracle transactions/DDL/grants and concurrency,
Resource Principal and Object Storage service permissions/copy completion,
actual Data Flow/AIDP parameter bindings, and killed-worker writer-stop recovery
in the development environment before normal scheduling. There is no waiting
batch dashboard, archive, row rejection, MERGE or broad Spark optimization.

## Wheel SHA256

- mdpf-1.1-py3-none-any.whl: `66f5b27a7c4d3e974885336125925351406ac3c47d6e925689aa5c9d614e81b3`
- mdpf_onboarding-1.1-py3-none-any.whl: `1df4a14e45253a52e73b4e688b4fee53a90a4dac9caaf5f8fe4dfe8a458efbda`

Oracle affected-row behavior was checked against the official
[batch DML documentation](https://python-oracledb.readthedocs.io/en/v3.4.2/user_guide/batch_statement.html)
and [cursor API](https://python-oracledb.readthedocs.io/en/v3.4.2/api_manual/cursor.html).
See OCI_IAM_EXAMPLE.md for official OCI permissions references.
