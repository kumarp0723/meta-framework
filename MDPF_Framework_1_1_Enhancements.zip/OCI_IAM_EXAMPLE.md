# OCI permissions example

Example only: same tenancy/region, Oracle-managed encryption, dedicated development
compartment `MDPF_DEV`. Substitute actual compartment, group, region and bucket names.
A platform administrator must validate effective access in the deployment environment.
Do not reuse this dedicated-compartment example as tenancy-wide production policy.

For Data Flow, an example dynamic-group rule is:

```text
ALL {resource.type='dataflowrun', resource.compartment.id='<DATAFLOW_COMPARTMENT_OCID>'}
```

Create a separate dynamic group for the actual OCI notebook Resource Principal
according to that notebook service's identity model. Do not assume AIDP has the
same dynamic-group rule as Data Flow. In the example below both groups receive
read access; workers can write RAW/STAGE while notebooks write onboarding artifacts.
Read object-family also covers metadata and copy work-request inspection in this
single dedicated compartment; bucket-scoped policies alone may not cover work requests.

```text
Allow dynamic-group MDPF_NOTEBOOKS to read object-family in compartment MDPF_DEV
Allow dynamic-group MDPF_RUNS to read object-family in compartment MDPF_DEV
Allow dynamic-group MDPF_NOTEBOOKS to manage objects in compartment MDPF_DEV where target.bucket.name='mdpf-dev-artifacts'
Allow dynamic-group MDPF_RUNS to manage objects in compartment MDPF_DEV where any {target.bucket.name='dev-raw', target.bucket.name='dev-stage'}
Allow dynamic-group MDPF_RUNS to manage objects in compartment MDPF_DEV where all {target.bucket.name='dev-quarantine', request.permission='OBJECT_CREATE'}
```

Object Storage also needs permission to perform server-side copy on your behalf.
Adapt this Oracle service-policy example to the actual region/compartment:

```text
Allow service objectstorage-us-ashburn-1 to manage object-family in compartment MDPF_DEV where any {request.permission='OBJECT_READ', request.permission='OBJECT_INSPECT', request.permission='OBJECT_CREATE', request.permission='OBJECT_OVERWRITE', request.permission='OBJECT_DELETE'}
```

The runtime requests source ETag matching and create-only quarantine destinations;
landing is retained. Give notebook-run pipelines the corresponding runtime object
permissions only when they execute ingestion as well as generate YAML. OCI SDK
Resource Principal configuration and Spark driver/worker connector configuration
are separate. KMS, cross-tenancy/region access, extra compartments and platform
job-launch permissions need additional reviewed policies.

Official references:
- [Object Storage permissions](https://docs.oracle.com/en-us/iaas/Content/Identity/Reference/objectstoragepolicyreference.htm)
- [Object copy and service permissions](https://docs.oracle.com/en-us/iaas/Content/Object/Tasks/copyingobjects.htm)
- [Data Flow resource principals](https://docs.oracle.com/en-us/iaas/Content/data-flow/using/resource-principal-policies.htm)
