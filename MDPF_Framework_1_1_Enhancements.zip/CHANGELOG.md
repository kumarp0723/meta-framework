# Release 1.1

- Added optional AIDP workflow_execution_key and documented same-batch two-phase scheduling.
- Added ALLOWED_VALUES, FAIL/WARN and explicit dataset-level ROW_COUNT policies.
- Moved column business DQ to STAGE and evaluate it once at VALIDATE_DQ; retained boundary schema checks.
- Reconcile actual MAIN inserts and roll back all target/completion changes on mismatch; retain failure evidence.
- Added RAW receipt/time, STAGE processing time and MAIN creation/update audit fields.
- Restored the 10,000-row default task-wide MAIN cap and concise operational documentation.
- Kept RAW whole-file quarantine, immutable landing delivery identities, producer guards and OCI sample HEAD checks.
- No waiting-batch dashboard, archive, row rejection, new framework tables or broad Spark optimization.

Core framework changes: src/mdpf/{aidp,db,pipeline,schema,steps,__init__}.py.
Core generator changes: src/mdpf_onboarding/{onboard,metadata_generator,schema_discovery,__init__}.py.
Supporting changes: examples, SQL, notebook parameter guide, tests, wheels and documentation.
Read UPGRADE.md before switching runtimes; old Parquet audit contracts are not inferred.
