# DQ, reconciliation and audit fields — 1.1

## Layer ownership

RAW checks the exact source delivery, CSV/header/length/type contracts and nonempty
input. Proven technical failures still trigger optional whole-file quarantine.
LANDING/RAW inference now defaults to nullable strings even when the target default
is NOT NULL. An explicit source `is_nullable: N` remains a technical source contract;
do not use it for a business-only restriction. Put business DQ in STAGE.

STAGE supports `NOT_NULL`, `UNIQUE`, `RANGE` and `ALLOWED_VALUES`. Business policies
run once at `VALIDATE_DQ`. Conversion/type/length checks remain at boundaries;
required target nullability is enforced after DQ evidence and again at the sink.
MAIN checks the Oracle contract/constraints and actual insert counts. Column DQ
policies targeting MAIN are rejected; move them to the corresponding STAGE dataset
in a new DRAFT release. If MAIN custom code changes business values, move that
transformation and its business validation to STAGE. Do not load unvalidated
business changes under the assumption that prior STAGE DQ covers them.

## YAML

```yaml
dq_rules:
  - column: LOAN_ID       # Omitted datasets means all generated STAGE outputs.
    check: NOT_NULL
    severity: FAIL       # Default; ERROR / FAIL_TASK in Oracle metadata.
  - column: LOAN_ID
    check: UNIQUE
  - datasets: [DEMO_LOAN_LOAN_STAGE]
    column: STATUS
    check: ALLOWED_VALUES
    values: [ACTIVE, CLOSED]
  - datasets: [DEMO_LOAN_LOAN_STAGE]
    column: BALANCE
    check: RANGE
    min: 0
    max: 1000000
    severity: WARN       # WARN / WARN in Oracle metadata.
  - datasets: [DEMO_LOAN_LOAN_STAGE]
    check: ROW_COUNT
    source_dataset: DEMO_LOAN_LOAN_RAW
  - datasets: [DEMO_LOAN_LOAN_MAIN]
    check: ROW_COUNT
    source_dataset: DEMO_LOAN_LOAN_STAGE
```

`column` is required for column checks, forbidden for `ROW_COUNT`. Each output can
have one `ROW_COUNT` rule and must explicitly name an input of the adjacent layer.
The rule declares that this mapping preserves rows: equality is intended. STAGE
count rules support one RAW input with one or several independently paired STAGE
outputs. Multi-input joins/aggregation are rejected for count equality. Custom
filters, joins and aggregations need their own explicitly reviewed reconciliation
contract; do not configure equality for them. MAIN append count rules pair each
output with a configured STAGE input; never compare summed fan-out counts.

`ALLOWED_VALUES` uses case-sensitive, untrimmed equality. Values must be a nonempty,
unique list compatible with the column: strings for VARCHAR2, finite YAML numbers
that fit NUMBER precision/scale, ISO YYYY-MM-DD dates for DATE. NULL is ignored;
use `NOT_NULL` separately. Empty string is a real value for this check; MAIN still
rejects empty strings because Oracle converts them to NULL. Booleans, NULL entries,
nested values and duplicates are invalid. RANGE is inclusive; UNIQUE counts every
row sharing a duplicate non-null value. Neither repairs nor drops rows.

WARN failures record `WARN` / `WARNED` and continue. Tasks remain `COMPLETED`, so
existing producer reads work. `reject_count` remains zero. FAIL records durable
`FAIL` / `FAILED_TASK`, fails the exact attempt, retains RAW and leaves the batch
RUNNING for the scheduler. A WARN never bypasses required schema or Oracle constraints.
STAGE DQ never copies landing files to quarantine.

## MAIN transaction and row limit

STAGE `ROW_COUNT` runs before any STAGE write. MAIN `ROW_COUNT` runs after DML and
before COMMIT using `cursor.rowcount` returned by `OracleDb.insert_many()`. Inserts,
successful reconciliation results, load events, task completion and batch closure
share one Oracle transaction. A mismatch rolls back the entire transaction across
all outputs. Failure policy evidence and failed-attempt/error history are then
recorded in a separate transaction. Unknown/negative affected counts fail closed.
Even without a configured count policy, actual inserts must equal prepared rows.
MAIN reconciliation cannot be WARN.

`MDPF_MAIN_MAX_ROWS` defaults to `10000` **across all MAIN outputs in one task**.
Every driver collection uses `limit(remaining + 1)`. Exceeding the cap fails before
any insert, without truncation. The setting must be 1–2147483646; no unlimited
sentinel is supported. A row cap does not bound bytes for unusually wide rows.
After reviewing driver capacity, raise the cap in the MAIN worker environment and
retry only failed MAIN in the same batch. This remains a bounded driver-load POC.

Generated MAIN DDL does not infer business keys/unique/check/FK constraints from DQ.
STAGE UNIQUE cannot prevent duplicates already in MAIN; review required Oracle
constraints separately. Affected-row counts prove DML counts, not post-trigger
business values or cross-batch uniqueness.

## Five framework-managed audit fields

| Layer | Existing fields | Added fields |
|---|---|---|
| RAW | `_batch_id`, `_run_id` | `_ingestion_item_id` BIGINT; `_ingested_at` TIMESTAMP |
| STAGE | `_batch_id`, `_run_id` | `_processed_at` TIMESTAMP |
| MAIN | `BATCH_ID`, `TASK_RUN_ID`, `ROW_NUMBER` | `CREATED_AT`, `UPDATED_AT` TIMESTAMP(6) WITH TIME ZONE |

Timestamps represent UTC instants; set Spark `spark.sql.session.timeZone=UTC` for
consistent display. MAIN timestamps use an explicit Oracle timestamp-with-time-zone
bind and are equal on insert. There is no UPDATE/MERGE implementation; a future
upsert must preserve CREATED_AT and change UPDATED_AT only for actual updates.
RAW receives the exact source receipt associated through its validated input/output
pair. Multi-input RAW custom transformations are rejected: place combinations in
STAGE so the receipt ID is never assigned arbitrarily.

Parquet readers require exactly the business columns plus the layer's system fields,
validate their types/non-null values, batch and completed producer IDs, and verify
RAW receipt ownership against the paired PROCESSED input in that producer attempt.
System fields are removed before transformations and DQ. All system names are
reserved; never put them in business YAML columns/overrides or DQ rules.

No new framework tables, scheduler states, archive, row rejection, MERGE or waiting
batch dashboard are included. See [upgrade instructions](UPGRADE.md) before installing.
