# End-to-end quick start — 1.1

1. Extract the packages into sibling `framework/` and `generator/` folders. On an
   existing development installation, follow [UPGRADE.md](UPGRADE.md) first. Have
   a DBA provision Oracle owners, framework tables, sequences and grants using the
   framework SQL scripts on a fresh installation. Configure Spark OCI access and
   secure `MDPF_DB_USER`, `MDPF_DB_PASSWORD`, `MDPF_DB_DSN` (plus wallet settings
   when needed). See [OCI_IAM_EXAMPLE.md](OCI_IAM_EXAMPLE.md).

2. Install both wheels and dependencies in the OCI notebook and runtime workers;
   use the platform's Spark/Java. Restart notebook/worker Python sessions.

   ```bash
   pip install ./framework/dist/mdpf-1.1-py3-none-any.whl ./generator/dist/mdpf_onboarding-1.1-py3-none-any.whl
   ```

3. Edit/upload the generator's `examples/shared_profile.yaml`, `bulk_catalog.csv`
   and sample CSVs to OCI. The profile holds reusable environment/bucket settings;
   each catalog row describes one independent dataset pipeline. A ZIP containing
   unrelated CSV datasets becomes separate catalog rows using separately extracted
   samples. This builder does not unpack ZIP deliveries.

4. Preview, then create the small input YAML files:

   ```python
   from mdpf_onboarding.bulk_builder import build_catalog
   profile = 'oci://artifacts@namespace/profiles/shared.yaml'
   catalog = 'oci://artifacts@namespace/catalogs/pipelines.csv'
   preview = build_catalog(profile, catalog, dry_run=True)
   print(preview)
   results = build_catalog(profile, catalog, dry_run=False)
   print(results)
   ```

   Check failed rows before continuing. Preview/save both check sample existence
   using OCI HEAD; they do not read or validate sample schemas. Save creates only
   missing YAMLs. Rows remain independent; existing YAMLs are skipped.

5. Review each input YAML. Add contracts, custom steps or STAGE DQ when needed.
   See the generator's `examples/dq_and_reconciliation.yaml` and
   [FEATURES.md](FEATURES.md). Request `sql_output.generate_main_ddl: true` for
   initial MAIN table proposals. Generate one pipeline at a time:

   ```python
   from mdpf_onboarding.onboard import generate
   generate('oci://artifacts@namespace/onboarding/my_pipeline/1.1/input/config.yaml', spark=spark)
   ```

   Generation reads samples and writes complete YAML, DRAFT metadata SQL and
   optional reviewed MAIN DDL. It never deploys/activates metadata or executes DDL.

6. Review/deploy target DDL and metadata SQL with the correct environment binding.
   Verify MAIN contracts/grants with `verify_main_targets()` where applicable;
   approve/activate the new release through your controlled deployment process.
   Keep published releases immutable. Audit fields are framework-managed.

7. Run RAW → STAGE → MAIN using separate Data Flow applications or AIDP tasks.
   Share one execution key, use a real fresh external task-run identity for every
   attempt, and set the initial cycle date explicitly. MAIN success closes the
   batch. Default MAIN limit: 10,000 rows across all outputs per task.

8. Optionally stop scheduling after RAW and schedule STAGE → MAIN later with the
   same key/cycle/pinned batch. RAW stays COMPLETED and BATCH stays RUNNING.
   For separate AIDP jobs, pass the same `workflow_execution_key` to both jobs.
   See [TWO_PHASE.md](TWO_PHASE.md). Do not finalize a batch merely because it waits.

9. Verify TASK_RUN counts/status, POLICY_RESULT evidence and final MAIN rows. To
   test optional whole-file quarantine, enable its profile prefix/bucket aliases,
   publish a new release and use a new test delivery with a proven technical CSV
   error. Expect failed RAW, QUARANTINED receipt/location, SOURCE_QUARANTINED event,
   confirmed copied object and retained landing source. STAGE DQ does not quarantine.
   See [TROUBLESHOOTING.md](TROUBLESHOOTING.md).
