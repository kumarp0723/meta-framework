# Changed files — 1.1

Compared with the attached MDPF_SQL_Generator_1_0_Whole_File_Quarantine.zip.

| Change | Package-relative file |
|---|---|
| Added | `CHANGELOG.md` |
| Added | `FEATURES.md` |
| Added | `OCI_IAM_EXAMPLE.md` |
| Added | `QUICK_START.md` |
| Changed | `README.md` |
| Added | `REFERENCE.md` |
| Added | `TROUBLESHOOTING.md` |
| Added | `TWO_PHASE.md` |
| Added | `UPGRADE.md` |
| Changed | `VERIFICATION_REPORT.md` |
| Added | `dist/mdpf_onboarding-1.1-py3-none-any.whl` |
| Changed | `examples/bulk_pre_onboarding.ipynb` |
| Added | `examples/dq_and_reconciliation.yaml` |
| Added | `examples/dq_metadata_draft.sql` |
| Changed | `examples/main_ddl.sql` |
| Changed | `examples/metadata_draft.sql` |
| Changed | `examples/pipeline_complete.yaml` |
| Changed | `pyproject.toml` |
| Changed | `src/mdpf_onboarding/__init__.py` |
| Changed | `src/mdpf_onboarding/metadata_generator.py` |
| Changed | `src/mdpf_onboarding/onboard.py` |
| Changed | `src/mdpf_onboarding/schema_discovery.py` |
| Changed | `tests/conftest.py` |
| Changed | `tests/test_bulk_builder.py` |
| Changed | `tests/test_dq_basic.py` |
| Changed | `tests/test_dq_sql.py` |
| Added | `tests/test_enhancements.py` |
| Changed | `tests/test_main_ddl.py` |
| Changed | `tests/test_oci.py` |
| Changed | `tests/test_oracle_gate.py` |
| Changed | `tests/test_raw_repair.py` |
| Changed | `tests/test_release_comparison.py` |
| Changed | `tests/test_workflow.py` |
| Removed | `dist/mdpf_onboarding-1.0-py3-none-any.whl` |

SHA256SUMS.txt is regenerated for the final package.
