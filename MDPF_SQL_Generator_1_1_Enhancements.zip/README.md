# MDPF SQL Generator 1.1

Create onboarding input YAML from an OCI profile and CSV catalog, then generate
complete YAML, DRAFT metadata SQL and optional MAIN DDL from sample CSVs.

Start with the [end-to-end quick start](QUICK_START.md). Use the companion
`mdpf-1.1` wheel with `dist/mdpf_onboarding-1.1-py3-none-any.whl`, then restart sessions.
Extract both packages into sibling `framework/` and `generator/` folders.

```python
from mdpf_onboarding.bulk_builder import build_catalog

preview = build_catalog(profile_uri, catalog_uri, dry_run=True)
results = build_catalog(profile_uri, catalog_uri, dry_run=False)

from mdpf_onboarding.onboard import generate
generate(input_yaml_uri, spark=spark)
```

- One catalog row creates one independent pipeline's input YAML. Environment
  settings live in one reusable OCI profile. Existing YAML objects are skipped.
- Bulk preview and save check input/output sample existence with OCI HEAD.
  Sample schema checks remain in onboarding generation.
- STAGE DQ supports NOT_NULL, UNIQUE, RANGE and ALLOWED_VALUES with FAIL/WARN.
  ROW_COUNT uses explicit input/output pairs at STAGE and MAIN.
- MAIN DDL includes framework-managed CREATED_AT/UPDATED_AT timestamps alongside
  existing IDs. Audit fields never belong in business YAML schemas or DQ rules.
- Optional whole-file quarantine settings continue into SOURCE_CONFIG metadata.
  Generation never deploys SQL, changes Oracle tables or activates releases.

| Reference | Contents |
|---|---|
| [Complete example](examples/dq_and_reconciliation.yaml) | New rule/severity/count syntax |
| [Rules and audit contract](FEATURES.md) | Matching, severity, transactions and reserved fields |
| [Development rollout](UPGRADE.md) | Old metadata, MAIN table changes and retained Parquet |
| [Two-phase scheduling](TWO_PHASE.md) | Data Flow keys and AIDP workflow_execution_key |
| [Detailed reference](REFERENCE.md) | Catalog columns, APIs, schemas, baseline comparison and DDL |
| [Troubleshooting](TROUBLESHOOTING.md) | Configuration and operational failures |
| [OCI permissions example](OCI_IAM_EXAMPLE.md) | Concrete IAM example and official links |
| [Verification report](VERIFICATION_REPORT.md) | Test evidence and limitations |

Edit the maintained YAML for enhancements and choose a new metadata release.
`generate(..., baseline_yaml=previous_complete_yaml_uri)` compares compatible
complete configurations. Published metadata stays immutable. Review generated
DDL and actual Oracle constraints before deployment.
