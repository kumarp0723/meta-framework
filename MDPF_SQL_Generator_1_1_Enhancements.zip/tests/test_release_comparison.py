"""Full release differences without numeric-ID, formatting or default noise."""
from copy import deepcopy
import json

import pytest
import yaml

from conftest import ROOT
from mdpf_onboarding.metadata_generator import (ID_COLUMNS, contract_model,
    render_main_ddl, render_sql, schema_changes)
from mdpf_onboarding.onboard import generate, validate_config, yaml_uri
from test_baseline import frozen


NO_CHANGES=['No release metadata changes.']
STAGE='DEMO_LOAN_LOAN_STAGE'
MAIN='DEMO_LOAN_LOAN_MAIN'


@pytest.fixture
def config():
    return yaml.safe_load((ROOT/'examples/pipeline_complete.yaml').read_text())


def compiled(config):
    return contract_model(validate_config(config))


def stage_plan(config, custom=None):
    config['task_overrides']['STAGE']['task_steps']=[
        'READ_PARQUET',*(custom or []),'DIRECT_MAP','VALIDATE_DQ','WRITE_PARQUET']


@pytest.mark.parametrize('name',['one_to_one','many_to_one','one_to_many'])
def test_baseline_builder_resolves_exactly_the_same_metadata_as_generation(models,name):
    model=models[name]
    assert schema_changes(model,compiled(frozen(model)))==NO_CHANGES
    assert schema_changes(model,model)==NO_CHANGES


def test_automatic_plans_and_explicit_defaults_are_equivalent(config):
    explicit=compiled(config)
    config['task_overrides']={}
    assert schema_changes(compiled(config),explicit)==NO_CHANGES


def test_custom_step_parameters_default_to_empty_object(config):
    stage_plan(config,[{'code':'CLEAN'}]);implicit=compiled(config)
    stage_plan(config,[{'code':'CLEAN','parameters':{}}])
    assert schema_changes(compiled(config),implicit)==NO_CHANGES


def test_custom_handler_add_remove_and_rename_are_reported(config):
    original=compiled(config);stage_plan(config,[{'code':'CLEAN'}])
    new=compiled(config);changes=schema_changes(new,original)
    assert any('TASK_STEP DEMO_LOAN_STAGE_LOAD:CLEAN: added.'==c for c in changes)
    assert any('TASK_STEP DEMO_LOAN_STAGE_LOAD:CLEAN: removed.'==c for c in schema_changes(original,new))
    stage_plan(config,[{'code':'CLEAN_NEW'}])
    changes=schema_changes(compiled(config),new)
    assert any(':CLEAN: removed.' in c for c in changes) and any(':CLEAN_NEW: added.' in c for c in changes)


def test_step_order_changes_without_schema_changes_are_reported(config):
    stage_plan(config,[{'code':'FIRST'},{'code':'SECOND'}]);before=compiled(config)
    stage_plan(config,[{'code':'SECOND'},{'code':'FIRST'}]);after=compiled(config)
    changes=schema_changes(after,before)
    assert len(changes)==2 and all('TASK_STEP' in c and 'step_sequence_number' in c for c in changes)
    assert render_main_ddl(after,b'same',baseline=before)==render_main_ddl(before,b'same',baseline=before)
    assert 'EXECUTE IMMEDIATE' not in render_main_ddl(after,b'same',baseline=before)


def test_custom_parameter_values_are_compared_not_json_key_order(config):
    stage_plan(config,[{'code':'CLEAN','parameters':{'column':'LOAN_ID','options':{'trim':True,'upper':False}}}])
    original=compiled(config)
    config['task_overrides']['STAGE']['task_steps'][1]['parameters']={'options':{'upper':False,'trim':True},'column':'LOAN_ID'}
    assert schema_changes(compiled(config),original)==NO_CHANGES
    config['task_overrides']['STAGE']['task_steps'][1]['parameters']['options']['upper']=True
    changes=schema_changes(compiled(config),original)
    assert len(changes)==1 and 'TASK_STEP' in changes[0] and 'parameter_json' in changes[0] and '"upper": true' in changes[0]


@pytest.mark.parametrize('check,column,extra',[('NOT_NULL','LOAN_ID',{}),('UNIQUE','LOAN_ID',{}),('RANGE','BALANCE',{'min':0,'max':100})])
def test_policies_added_and_removed_are_reported(config,check,column,extra):
    old=compiled(config)
    config['dq_rules']=[dict(datasets=[STAGE],column=column,check=check,**extra)]
    new=compiled(config)
    added=schema_changes(new,old);removed=schema_changes(old,new)
    assert len(added)==len(removed)==1
    assert all('POLICY_DEFINITION' in c and 'added.' in c for c in added)
    assert all('POLICY_DEFINITION' in c and 'removed.' in c for c in removed)


def test_changed_range_bounds_and_default_scope_are_compared(config):
    config['dq_rules']=[dict(datasets=[STAGE],column='BALANCE',check='RANGE',min=0,max=100)]
    original=compiled(config)
    config['dq_rules']=[dict(column='BALANCE',check='RANGE',min=0,max=100)]
    assert schema_changes(compiled(config),original)==NO_CHANGES
    config['dq_rules'][0]['max']=200
    changes=schema_changes(compiled(config),original)
    assert len(changes)==1 and 'POLICY_DEFINITION '+STAGE in changes[0] and 'parameter_json' in changes[0]
    assert '"max": 100' in changes[0] and '"max": 200' in changes[0]


@pytest.mark.parametrize('field,value,expected',[
    ('source_system','NEW_SYSTEM','source_system_name'),
    ('file_name','loan_v2_{YYYYMMDD}.csv','file_pattern'),
    ('landing_key_prefix','landing/new_path','landing_path')])
def test_source_configuration_changes_are_reported(config,field,value,expected):
    old=compiled(config);config['inputs'][0][field]=value
    changes=schema_changes(compiled(config),old)
    assert any('SOURCE_CONFIG RAW_SOURCE: '+expected in c for c in changes)


def test_input_order_changes_usage_sequence_not_id_noise(models):
    config=frozen(models['many_to_one']);before=compiled(config)
    config['inputs'].reverse();changes=schema_changes(compiled(config),before)
    assert len(changes)==6
    assert all(c.startswith('TASK_DATASET ') and 'usage_sequence' in c for c in changes)


def test_added_input_reports_associations_and_source_input_count(models):
    config=frozen(models['many_to_one']);before=compiled(config)
    extra=deepcopy(config['inputs'][0]);extra.update(code='OTHER',file_name='other_{YYYYMMDD}.csv')
    config['inputs'].append(extra)
    changes=schema_changes(compiled(config),before)
    assert any('SOURCE_CONFIG RAW_SOURCE: expected_input_count 2 -> 3'==c for c in changes)
    assert sum(c.startswith('TASK_DATASET ') and 'added.' in c for c in changes)==3
    assert not any('TASK_STEP' in c for c in changes)


def test_task_code_changes_are_logical_removals_and_additions(config):
    before=compiled(config);config['task_overrides']['STAGE']['task_code']='NEW_STAGE'
    changes=schema_changes(compiled(config),before)
    assert 'TASK NEW_STAGE: added.' in changes and 'TASK DEMO_LOAN_STAGE_LOAD: removed.' in changes
    assert any(c.startswith('TASK_DATASET NEW_STAGE:') for c in changes)


@pytest.mark.parametrize('table,field,value',[
    ('TASK','close_batch_on_success','N'),('TASK','task_type','OTHER'),
    ('TASK_STEP','step_type','CUSTOM_PYTHON'),('TASK_STEP','is_required','N'),
    ('TASK_STEP','on_failure_action','SKIP_STEP'),
    ('TASK_DATASET','is_required','N'),('TASK_DATASET','is_enabled','N'),
    ('TASK_DATASET','usage_sequence',99),('SOURCE_CONFIG','expected_input_count',2),
    ('DATASET','storage_type','OTHER'),('DATASET','layer','GOLD'),
    ('DATASET_COLUMN','is_nullable','N'),('DATASET_COLUMN','is_pii','Y')])
def test_all_generated_execution_fields_are_in_comparison(config,table,field,value):
    original=compiled(config);changed=deepcopy(original)
    row=changed['tables'][table][-1] if field=='close_batch_on_success' else changed['tables'][table][0]
    assert row[field]!=value
    row[field]=value
    changes=schema_changes(changed,original)
    assert len(changes)==1 and changes[0].startswith(table+' ') and ': '+field+' ' in changes[0]


def test_policy_scope_action_and_threshold_fields_are_not_ignored(config):
    config['dq_rules']=[dict(datasets=[STAGE],column='LOAN_ID',check='NOT_NULL')]
    old=compiled(config)
    for field,value in [('failure_action','WARN'),('threshold_value','5'),('is_enabled','N'),
                         ('policy_scope_type','DATASET'),('policy_severity','WARN')]:
        new=deepcopy(old);new['tables']['POLICY_DEFINITION'][0][field]=value
        changes=schema_changes(new,old)
        assert len(changes)==1 and ': '+field+' ' in changes[0]


def test_generated_ids_row_order_and_provenance_do_not_create_changes(config):
    config['dq_rules']=[dict(datasets=[STAGE],column='LOAN_ID',check='NOT_NULL')]
    original=compiled(config);new=deepcopy(original)
    primary_keys=set(ID_COLUMNS.values())
    for rows in new['tables'].values():
        for row in rows:
            for field in list(row):
                if field in primary_keys and isinstance(row[field],int):row[field]+=1000
            row['config_release_id']=98765
        rows.reverse()
    release=new['tables']['CONFIG_RELEASE'][0]
    release.update(release_version='9.9',created_by='SOMEONE',release_status='ACTIVE',release_desc='A changed comment')
    assert schema_changes(new,original)==NO_CHANGES


def test_artifact_sample_and_inference_settings_do_not_create_runtime_changes(config):
    old=compiled(config)
    config['pipeline']['release_version']='1.1';config['created_by']='OTHER'
    config['sql_output'].update(filename='renamed.sql',main_ddl_filename='renamed_ddl.sql',yaml_filename='renamed.yaml',path='elsewhere')
    config['inputs'][0]['sample_csv']='oci://different@ns/source.csv'
    config['outputs'][0]['sample_csv']='oci://different@ns/target.csv'
    config['inference']['varchar_growth_percent']=50
    assert schema_changes(compiled(config),old)==NO_CHANGES


def test_equivalent_schema_and_json_representations_do_not_create_changes(config):
    stage_plan(config,[{'code':'CLEAN','parameters':{'a':1,'b':True}}])
    old=compiled(config);new=deepcopy(old)
    for row in new['tables']['TASK_STEP']:
        row['parameter_json']=json.loads(row['parameter_json'])
    for row in old['tables']['DATASET_COLUMN']:
        if row['data_type']=='VARCHAR2':row['length_precision_scale']='20'
        elif row['data_type']=='NUMBER':row['length_precision_scale']='18'
    for row in new['tables']['DATASET_COLUMN']:
        if row['data_type']=='VARCHAR2':row['length_precision_scale']='20 BYTE'
        elif row['data_type']=='NUMBER':row['length_precision_scale']='18,0'
    assert schema_changes(new,old)==NO_CHANGES


def test_baseline_compilation_never_reads_samples_or_executes_conversions(config,monkeypatch):
    import mdpf_onboarding.metadata_generator as module
    def forbidden(*a,**kw):pytest.fail('Baseline must not read samples or execute Spark transformations')
    monkeypatch.setattr(module,'validate_conversion',forbidden)
    monkeypatch.setattr(module.mdpf_schema,'validate_frame',forbidden)
    assert len(compiled(config)['tables']['TASK_STEP'])==9


def test_comparison_is_deterministic_and_does_not_mutate_models(config):
    old=compiled(config);stage_plan(config,[{'code':'CLEAN','parameters':{'trim':True}}]);new=compiled(config)
    original_old=deepcopy(old);original_new=deepcopy(new)
    first=schema_changes(new,old)
    assert first==schema_changes(new,old)
    assert old==original_old and new==original_new


def test_full_comparison_is_printed_before_first_artifact_upload(spark,oci_setup,capsys,monkeypatch):
    config,uri,client,_=oci_setup
    client.objects[uri]=yaml.safe_dump(config).encode();generate(uri,spark=spark,client=client)
    prior=yaml_uri(config);updated=yaml.safe_load(client.objects[prior])
    updated['pipeline']['release_version']='1.1';updated['sql_output']['path']+='-1.1'
    stage_plan(updated,[{'code':'CLEAN','parameters':{'column':'LOAN_ID'}}])
    updated['dq_rules']=[dict(datasets=[STAGE],column='LOAN_ID',check='UNIQUE')]
    client.objects[uri]=yaml.safe_dump(updated).encode();capsys.readouterr()
    previous_put=client.put_object;observed=[]
    def inspect(*args,**kwargs):
        if not observed:
            printed=capsys.readouterr().out
            assert 'TASK_STEP DEMO_LOAN_STAGE_LOAD:CLEAN: added.' in printed
            assert 'POLICY_DEFINITION '+STAGE+'_LOAN_ID_UNIQUE: added.' in printed
            assert 'Mode: COMPARISON; resolved release changes from baseline.' in printed
            observed.append(True)
        return previous_put(*args,**kwargs)
    monkeypatch.setattr(client,'put_object',inspect)
    generate(uri,baseline_yaml=prior,spark=spark,client=client)
    assert observed==[True]
