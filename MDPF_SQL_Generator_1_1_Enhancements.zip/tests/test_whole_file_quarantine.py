from copy import deepcopy
from pathlib import Path
from types import SimpleNamespace

import pytest
import yaml

from conftest import CatalogDb, ROOT, prepare_execution
from mdpf.schema import DataValidationError
from mdpf.storage import ObjectStorage, malformed_csv_error
from mdpf_onboarding.builder import build_config
from mdpf_onboarding.metadata_generator import build_metadata, contract_model, render_sql, schema_changes
from mdpf_onboarding.onboard import validate_config


def setup_quarantine(model, spark, tmp_path):
    fw, db = prepare_execution(model, tmp_path, spark)
    prefix = 'oci://quarantine@devns/rejected/' + fw.pipeline_code.lower()
    db.execute('UPDATE METADATA.SOURCE_CONFIG SET quarantine_path=:q', q=prefix)
    copies = []
    def copy(source, destination):
        copies.append((source, destination))
        target = fw.storage.path(destination)
        target.parent.mkdir(parents=True, exist_ok=True)
        with target.open('xb') as out:
            out.write(fw.storage.path(source).read_bytes())
    fw.storage.quarantine_file = copy
    source = next(d['row']['physical_object_name']['DEV'] for d in model['datasets'].values()
                  if d['row']['storage_type'] == 'CSV').replace('{YYYYMMDD}', '20261015')
    return fw, db, copies, source


@pytest.mark.parametrize('problem', ['header', 'empty', 'blank', 'length', 'malformed'])
def test_bad_source_is_copied_and_quarantined_without_raw_writes(models, spark, tmp_path, problem):
    model = models['one_to_one']
    fw, db, copies, source = setup_quarantine(model, spark, tmp_path)
    path = fw.storage.path(source)
    header = path.read_text().splitlines()[0]
    data = {'header': 'WRONG\nx\n', 'empty': header+'\n',
            'blank': header+'\n,C1,1,2026-10-15,A\n',
            'length': header+'\n'+('X'*200)+',C1,1,2026-10-15,A\n',
            'malformed': header+'\nL1,C1,1,2026-10-15,A,EXTRA\n'}[problem]
    if problem == 'blank':
        db.execute("UPDATE METADATA.DATASET_COLUMN SET is_nullable='N' WHERE column_name='LOAN_ID'")
    path.write_text(data)
    original = path.read_bytes()
    batch = fw.start_batch('bad-'+problem, '2026-10-15')['batch_id']
    fw.storage.write_parquet = lambda *a: pytest.fail('No RAW output for rejected source')
    with pytest.raises(Exception):
        fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
    receipt = db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
    assert receipt['status'] == 'QUARANTINED'
    assert len(copies) == 1 and copies[0] == (source, receipt['quarantine_location'])
    assert fw.storage.path(receipt['quarantine_location']).read_bytes() == original == path.read_bytes()
    assert db.one('SELECT status FROM RUNTIME.TASK_RUN')['status'] == 'FAILED'
    assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
    assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 1
    evidence = db.one("SELECT * FROM OPERATIONS.EVENT_LOG WHERE event_code='SOURCE_QUARANTINED'")
    assert evidence and receipt['quarantine_location'] in evidence['details_json']
    assert evidence['error_code'] == 'SOURCE_VALIDATION_FAILED'
    db.close()


@pytest.mark.parametrize('error', [RuntimeError('Network failed'), ValueError('Access denied')])
def test_source_io_failures_are_not_quarantined(models, spark, tmp_path, error):
    model = models['one_to_one']
    fw, db, copies, source = setup_quarantine(model, spark, tmp_path)
    def fail(*args):
        raise error
    fw.storage.read_csv = fail
    batch = fw.start_batch('io-failure', '2026-10-15')['batch_id']
    with pytest.raises(type(error), match=str(error)):
        fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
    assert not copies
    receipt = db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
    assert receipt['status'] == 'FAILED' and receipt['quarantine_location'] is None
    db.close()


def test_copy_failure_does_not_claim_quarantine_and_preserves_original_error(models, spark, tmp_path):
    model = models['one_to_one']
    fw, db, copies, source = setup_quarantine(model, spark, tmp_path)
    fw.storage.path(source).write_text('WRONG\nx\n')
    def denied(*args):
        raise RuntimeError('Copy permission denied')
    fw.storage.quarantine_file = denied
    batch = fw.start_batch('copy-failure', '2026-10-15')['batch_id']
    with pytest.raises(RuntimeError, match='quarantine copy failed'):
        fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
    receipt = db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
    run = db.one('SELECT * FROM RUNTIME.TASK_RUN')
    assert receipt['status'] == 'FAILED' and receipt['quarantine_location'] is None
    assert 'columns do not match' in run['error_message'] and 'Copy permission denied' in run['error_message']
    assert not db.one("SELECT * FROM OPERATIONS.EVENT_LOG WHERE event_code='SOURCE_QUARANTINED'")
    assert fw.storage.path(source).exists()
    db.close()


def test_repeated_rejection_preserves_prior_attempt_and_uses_distinct_destination(models, spark, tmp_path):
    model = models['one_to_one']
    fw, db, copies, source = setup_quarantine(model, spark, tmp_path)
    fw.storage.path(source).write_text('WRONG\nx\n')
    batch = fw.start_batch('reject-retry', '2026-10-15')['batch_id']
    for _ in range(2):
        with pytest.raises(DataValidationError):
            fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
    rows = db.execute('SELECT * FROM RUNTIME.INGESTION_ITEM ORDER BY ingestion_item_id')
    assert [r['status'] for r in rows] == ['QUARANTINED', 'QUARANTINED']
    assert len({r['quarantine_location'] for r in rows}) == 2
    assert len({r['source_item_key'] for r in rows}) == 1
    assert db.one('SELECT COUNT(*) n FROM OPERATIONS.WORK_QUEUE')['n'] == 2
    db.close()


def test_valid_source_and_downstream_failure_do_not_quarantine(models, spark, tmp_path):
    model = models['one_to_one']
    fw, db, copies, source = setup_quarantine(model, spark, tmp_path)
    batch = fw.start_batch('valid-source', '2026-10-15')['batch_id']
    fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
    assert not copies
    def fail(*a):
        raise DataValidationError('Downstream data failure')
    fw.storage.read_parquet = fail
    with pytest.raises(DataValidationError):
        fw.execute_task(batch, model['tasks'][1]['row']['task_code'])
    assert not copies
    assert db.one('SELECT status FROM RUNTIME.INGESTION_ITEM')['status'] == 'PROCESSED'
    db.close()


def test_only_offending_member_of_combined_raw_task_is_quarantined(models, spark, tmp_path):
    model = models['many_to_one']
    fw, db, copies, source = setup_quarantine(model, spark, tmp_path)
    paths = [d['row']['physical_object_name']['DEV'].replace('{YYYYMMDD}', '20261015')
             for d in model['datasets'].values() if d['row']['storage_type'] == 'CSV']
    fw.storage.path(paths[1]).write_text('WRONG\nx\n')
    batch = fw.start_batch('combined-source', '2026-10-15')['batch_id']
    with pytest.raises(DataValidationError):
        fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
    assert copies[0][0] == paths[1] and len(copies) == 1
    assert [r['status'] for r in db.execute('SELECT status FROM RUNTIME.INGESTION_ITEM ORDER BY ingestion_item_id')] == ['FAILED', 'QUARANTINED']
    db.close()


@pytest.mark.parametrize('prefix', ['oci://landing@ns/', 'oci://dev-landing@devns/landing/demo_loan',
                                    'oci://bucket@ns/quarantine/', 'oci://bucket@ns/bad/*'])
def test_bad_quarantine_prefix_fails_before_source_reads(models, spark, tmp_path, prefix):
    model = models['one_to_one']
    fw, db, copies, source = setup_quarantine(model, spark, tmp_path)
    db.execute('UPDATE METADATA.SOURCE_CONFIG SET quarantine_path=:q', q=prefix)
    fw.storage.read_csv = lambda *a: pytest.fail('Invalid quarantine metadata must fail before reads')
    batch = fw.start_batch('bad-prefix', '2026-10-15')['batch_id']
    with pytest.raises(ValueError):
        fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
    assert not copies and not db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
    db.close()


def test_onboarding_and_profile_propagate_optional_quarantine(models):
    profile = yaml.safe_load((ROOT/'examples/shared_profile.yaml').read_text())
    profile['storage']['quarantine_key_prefix'] = 'quarantine'
    for env in profile['environments'].values():
        env['buckets']['quarantine'] = 'rejected'
    config = build_config(profile, pipeline_code='DEMO_LOAN', dataset_code='LOAN',
        source_system='DMI', input_sample_csv='loan/input.csv', output_sample_csv='loan/output.csv')
    assert config['storage']['quarantine_key_prefix'] == 'quarantine/demo_loan'
    complete = deepcopy(models['one_to_one']['config'])
    complete['storage']['quarantine_key_prefix'] = 'quarantine/demo_loan'
    complete['environments'] = config['environments']
    profiles = {code: (None, ds['columns']) for code, ds in models['one_to_one']['datasets'].items()
                if code.endswith(('_LANDING', '_MAIN'))}
    compiled = build_metadata(complete, profiles, validate_samples=False)
    assert compiled['tables']['SOURCE_CONFIG'][0]['quarantine_path']['DEV'] == 'oci://rejected@devns/quarantine/demo_loan'
    db = CatalogDb()
    db.deploy(render_sql(compiled, b'quarantine configuration'))
    assert db.one('SELECT quarantine_path FROM METADATA.SOURCE_CONFIG')['quarantine_path'] == 'oci://rejected@devns/quarantine/demo_loan'
    db.close()
    old = deepcopy(complete)
    del old['storage']['quarantine_key_prefix']
    old['inference']['column_overrides'] = {}
    for role, suffix in [('inputs', '_LANDING'), ('outputs', '_MAIN')]:
        for item in old[role]:
            item['columns'] = [dict(c) for c in models['one_to_one']['datasets']['DEMO_LOAN_LOAN'+suffix]['columns']]
            for c in item['columns']:
                c.pop('column_sequence', None)
    previous = contract_model(validate_config(old))
    assert any('SOURCE' in change for change in schema_changes(compiled, previous))


@pytest.mark.parametrize('state', ['COMPLETED', 'FAILED', 'CANCELED', None])
def test_oci_copy_waits_and_preserves_source_with_conditions(monkeypatch, state):
    import oci
    heads, calls = [], []
    signer = SimpleNamespace(region='us-ashburn-1')
    def head(*address):
        heads.append(address)
        return SimpleNamespace(headers={'etag': 'source-etag'})
    client = SimpleNamespace(head_object=head)
    def copy(*args, **kwargs):
        calls.append((args, kwargs))
        return SimpleNamespace(data=SimpleNamespace(status=state))
    monkeypatch.setattr(oci.auth.signers, 'get_resource_principals_signer', lambda: signer)
    monkeypatch.setattr(oci.object_storage, 'ObjectStorageClient', lambda *a, **kw: client)
    monkeypatch.setattr(oci.object_storage, 'ObjectStorageClientCompositeOperations',
                        lambda c: SimpleNamespace(copy_object_and_wait_for_state=copy))
    operation = lambda: ObjectStorage().quarantine_file('oci://landing@ns/file.csv', 'oci://rejected@ns/quarantine/file.csv')
    if state == 'COMPLETED':
        operation()
        assert len(heads) == 2
    else:
        with pytest.raises(RuntimeError):
            operation()
        assert len(heads) == 1
    args, options = calls[0]
    details = args[2]
    assert details.source_object_if_match_e_tag == 'source-etag'
    assert details.destination_object_if_none_match_e_tag == '*'
    assert details.destination_region == signer.region
    assert details.destination_bucket == 'rejected'


def test_unclassified_exception_is_not_malformed_csv():
    assert not malformed_csv_error(ValueError('MALFORMED_CSV_RECORD text alone is not proof'))


def test_late_copy_does_not_change_terminal_attempt(models, spark, tmp_path):
    model = models['one_to_one']
    fw, db, copies, source = setup_quarantine(model, spark, tmp_path)
    fw.storage.path(source).write_text('WRONG\nx\n')
    batch = fw.start_batch('late-copy', '2026-10-15')['batch_id']
    actual_copy = fw.storage.quarantine_file
    def late(source, destination):
        actual_copy(source, destination)
        run = db.one("SELECT task_run_id FROM RUNTIME.TASK_RUN WHERE status='RUNNING'")
        fw.fail_task_run(run['task_run_id'], 'EXTERNAL_FAILURE', 'Exact-run callback')
    fw.storage.quarantine_file = late
    with pytest.raises(ValueError, match='exact attempt'):
        fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
    receipt = db.one('SELECT * FROM RUNTIME.INGESTION_ITEM')
    assert receipt['status'] == 'FAILED' and receipt['quarantine_location'] is None
    assert db.one('SELECT error_code FROM RUNTIME.TASK_RUN')['error_code'] == 'EXTERNAL_FAILURE'
    assert len(copies) == 1  # Physical evidence can exist without a committed quarantine audit.
    db.close()
