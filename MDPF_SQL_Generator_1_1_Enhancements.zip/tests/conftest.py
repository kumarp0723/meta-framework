"""CI-only DDL/OCI adapters; no deployable database or storage backend."""
from contextlib import contextmanager
from datetime import date,datetime
from decimal import Decimal
import importlib.util
import os
from pathlib import Path
import re
import sqlite3
import sys
from types import SimpleNamespace

import pytest
import yaml
from pyspark.sql import SparkSession

from mdpf.pipeline import MetadataFramework
from mdpf.storage import object_address
from mdpf_onboarding.onboard import validate_config
from mdpf_onboarding.metadata_generator import build_metadata,dataset_codes,render_sql
from mdpf_onboarding.schema_discovery import discover,read_sample

ROOT=Path(__file__).resolve().parents[1]


@pytest.fixture(scope='session')
def spark():
    os.environ['SPARK_LOCAL_IP']='127.0.0.1'
    os.environ['PYSPARK_PYTHON']=sys.executable
    session=(SparkSession.builder.master('local[1]').appName('mdpf-onboard-ci')
        .config('spark.ui.enabled','false').config('spark.sql.shuffle.partitions','1')
        .config('spark.sql.session.timeZone','UTC').getOrCreate())
    session.sparkContext.setLogLevel('ERROR')
    yield session
    session.stop()


def example_model(spark,name):
    path=ROOT/'examples'/(name+'.yaml');config=validate_config(yaml.safe_load(path.read_text()));profiles={}
    codes=dataset_codes(config)
    for role in ['inputs','outputs']:
        for item,names in zip(config[role],codes[role]):
            code=names['landing' if role=='inputs' else 'main']
            df=read_sample(spark,str(path.parent/item['sample_csv']))
            columns=discover(df,source=role=='inputs',overrides=config['inference']['column_overrides'].get(code,{}))
            profiles[code]=(df,columns)
    return build_metadata(config,profiles)


@pytest.fixture(scope='session')
def models(spark):
    return {name:example_model(spark,name) for name in ['one_to_one','many_to_one','one_to_many']}


class MemoryOCI:
    """CI-only SDK double. Samples still execute through actual Spark CSV reads."""
    def __init__(self):
        self.objects={};self.gets=[];self.puts=[]
    def get_object(self,namespace,bucket,key):
        uri=f'oci://{bucket}@{namespace}/{key}';self.gets.append(uri)
        return SimpleNamespace(data=SimpleNamespace(content=self.objects[uri]))
    def put_object(self,namespace,bucket,key,body,**options):
        from oci.exceptions import ServiceError
        uri=f'oci://{bucket}@{namespace}/{key}';self.puts.append((uri,options))
        if options.get('if_none_match')=='*' and uri in self.objects:
            raise ServiceError(412,'PreconditionFailed',{},'Object already exists')
        self.objects[uri]=body
        return SimpleNamespace(status=200)


@pytest.fixture
def oci_setup(spark,tmp_path,monkeypatch):
    import mdpf_onboarding.onboard as onboard
    client=MemoryOCI();uri='oci://onboarding@devns/config/one_to_one.yaml'
    config=yaml.safe_load((ROOT/'examples/one_to_one.yaml').read_text())
    config['sql_output']['generate_main_ddl']=False  # Baseline OCI tests exercise metadata-only mode.
    samples={onboard.sample_uri(uri,i['sample_csv']):ROOT/'examples'/i['sample_csv']
             for i in config['inputs']+config['outputs']}
    actual=read_sample
    monkeypatch.setattr(onboard,'read_sample',lambda session,path:actual(session,str(samples[path])))
    return config,uri,client,samples


class CatalogDb:
    """Actual generated SQL executed in SQLite, not a claim of Oracle PL/SQL validation."""
    def __init__(self):
        self.conn=sqlite3.connect(':memory:',isolation_level=None);self.conn.row_factory=sqlite3.Row
        self.conn.execute('PRAGMA foreign_keys=ON');self.ids={}
        self.conn.execute('CREATE TABLE DUAL (DUMMY TEXT)')
        self.conn.execute("INSERT INTO DUAL VALUES ('X')")
        for schema in ['METADATA','RUNTIME','OPERATIONS','DMI_MAIN_DEV','DMI_MAIN_STAGE','DMI_MAIN_PROD']:
            self.conn.execute(f"ATTACH DATABASE ':memory:' AS {schema}")
        self.conn.create_function('TO_CLOB',1,lambda s:s)
        ddl=(ROOT/'tests/fixtures/framework_1_0.sql').read_text()
        for table,body in re.findall(r'CREATE TABLE (\w+\.\w+) \(\n(.*?)\n\);',ddl,re.S):
            if table.startswith('METADATA.'):
                translated=re.sub(r'NUMBER\([^)]*\)','NUMERIC',body)
                translated=re.sub(r'TIMESTAMP\(6\) WITH TIME ZONE','TEXT',translated)
                translated=translated.replace('SYSTIMESTAMP','CURRENT_TIMESTAMP').replace('REFERENCES METADATA.','REFERENCES ')
                translated=translated.replace('parameter_json IS JSON','json_valid(parameter_json)')
                self.conn.execute(f'CREATE TABLE {table} ({translated})')
            else:
                columns=[]
                for line in body.splitlines():
                    match=re.match(r'    (\w+) (NUMBER|VARCHAR2|CHAR|CLOB|DATE|TIMESTAMP)\b',line)
                    if match:columns.append(match[1]+(' NUMERIC' if match[2]=='NUMBER' else ' TEXT'))
                self.conn.execute(f"CREATE TABLE {table} ({','.join(columns)})")
        self.conn.execute("CREATE UNIQUE INDEX METADATA.ONE_ACTIVE ON CONFIG_RELEASE (CASE WHEN release_status='ACTIVE' THEN pipeline_code END)")
        self.conn.execute("CREATE UNIQUE INDEX METADATA.ONE_CLOSER ON TASK (CASE WHEN close_batch_on_success='Y' THEN config_release_id END)")

    def deploy(self,sql,env='DEV',release=900):
        statements=[];current=[]
        for line in sql.splitlines():
            if line.startswith('  INSERT INTO'):current=[line]
            elif current:current.append(line)
            if current and sqlite3.complete_statement('\n'.join(current)):
                statements.append('\n'.join(current));current=[]
        assert statements
        def translate(m):
            token=m[0]
            return token if token.startswith("'") else {'v_release_id':':release','v_env':':env','SYSTIMESTAMP':'CURRENT_TIMESTAMP'}[token]
        with self.transaction():
            for statement in statements:
                statement=re.sub(r"'(?:''|[^'])*'|\bv_release_id\b|\bv_env\b|\bSYSTIMESTAMP\b",translate,statement)
                self.conn.execute(statement,dict(release=release,env=env))

    @staticmethod
    def value(v):return str(v) if isinstance(v,(date,datetime,Decimal)) else v
    def execute(self,sql,**params):
        sql=sql.replace(' FOR UPDATE','').replace('SYSTIMESTAMP','CURRENT_TIMESTAMP')
        cur=self.conn.execute(sql,{k:self.value(v) for k,v in params.items()})
        return [{k.lower():v for k,v in dict(r).items()} for r in cur.fetchall()] if cur.description else []
    def one(self,sql,**params):
        rows=self.execute(sql,**params);return rows[0] if rows else None
    def insert(self,table,values):
        self.execute(f"INSERT INTO {table} ({','.join(values)}) VALUES ({','.join(':'+k for k in values)})",**values)
    def insert_many(self,table,columns,records,types):
        for row in records:self.insert(table,row)
        return len(records)
    def next_id(self,table,column):
        self.ids[table]=self.ids.get(table,0)+1;return self.ids[table]
    @contextmanager
    def transaction(self):
        self.conn.execute('BEGIN')
        try:yield;self.conn.commit()
        except BaseException:self.conn.rollback();raise
    def close(self):self.conn.close()


class SparkTestStorage:
    def __init__(self,root):self.root=root
    def path(self,uri):
        ns,bucket,key=object_address(uri);return self.root/ns/bucket/key
    def read_csv(self,spark,path):
        return spark.read.options(header=True,inferSchema=False,mode='FAILFAST',multiLine=True,escape='"').csv(str(self.path(path)))
    def read_parquet(self,spark,path):return spark.read.parquet(str(self.path(path)))
    def write_parquet(self,path,df):df.write.mode('overwrite').parquet(str(self.path(path)))


def prepare_execution(model,tmp_path,spark):
    db=CatalogDb();db.deploy(render_sql(model,b'fixture'))
    db.execute("UPDATE METADATA.CONFIG_RELEASE SET release_status='ACTIVE'")
    for spec in model['datasets'].values():
        row=spec['row']
        if row['storage_type']=='ADB_TABLE':
            columns=[c['column_name']+' TEXT' for c in spec['columns']]
            db.conn.execute(f"CREATE TABLE {row['physical_object_name']['DEV']} ({','.join(columns)}, BATCH_ID INTEGER,TASK_RUN_ID INTEGER,ROW_NUMBER INTEGER,CREATED_AT TEXT,UPDATED_AT TEXT)")
    storage=SparkTestStorage(tmp_path)
    codes=dataset_codes(model['config'])
    for item,names in zip(model['config']['inputs'],codes['inputs']):
        path=model['datasets'][names['landing']]['row']['physical_object_name']['DEV'].replace('{YYYYMMDD}','20261015')
        target=storage.path(path);target.parent.mkdir(parents=True,exist_ok=True)
        target.write_bytes((ROOT/'examples'/item['sample_csv']).read_bytes())
    fw=MetadataFramework(db,model['config']['pipeline']['code'],spark=spark);fw.storage=storage
    return fw,db
