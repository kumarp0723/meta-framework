from copy import deepcopy
import json
import re
import sqlite3

import pytest
import yaml
from pyspark.sql import functions as F

from conftest import CatalogDb, prepare_execution
from test_cleanup import profiles_for
from mdpf_onboarding.metadata_generator import build_metadata, render_sql
from mdpf_onboarding.onboard import generate, validate_config


STAGE = 'DEMO_LOAN_LOAN_STAGE'
MAIN = 'DEMO_LOAN_LOAN_MAIN'


def dq_rule(datasets=None, column='CLIENT_ID'):
    return dict(datasets=[STAGE] if datasets is None else datasets, column=column, check='NOT_NULL')


def dq_model(models, spark, rules=None, custom=False):
    original = models['one_to_one']
    config = deepcopy(original['config'])
    config['dq_rules'] = [dq_rule()] if rules is None else rules
    if custom:
        config['task_overrides']['STAGE'] = {'task_steps': [
            'READ_PARQUET', {'code': 'PREPARE_CLIENT'}, 'DIRECT_MAP', 'VALIDATE_DQ', 'WRITE_PARQUET']}
    return build_metadata(validate_config(config), profiles_for(original, spark))


@pytest.mark.parametrize('rules', [
    None, {}, 'NOT_NULL', [{}],
    [dict(dataset=STAGE, column='CLIENT_ID', check='NOT_NULL')],
    [dq_rule([])], [dq_rule(STAGE)], [dq_rule(['UNKNOWN'])],
    [dq_rule(['DEMO_LOAN_LOAN_RAW'])], [dq_rule([STAGE, STAGE])],
    [dq_rule(), dq_rule([MAIN])], [dict(dq_rule(), check='REGEX')],
    [dict(dq_rule(), column='lowercase')], [dict(dq_rule(), failure_action='WARN')],
])
def test_invalid_dq_rules_fail_config_preflight(oci_setup, rules):
    config, _, _, _ = oci_setup
    config['dq_rules'] = rules
    with pytest.raises(ValueError):
        validate_config(config)


def test_dq_is_optional_and_expands_one_row_per_dataset(models, spark):
    assert models['one_to_one']['tables']['POLICY_DEFINITION'] == []
    assert 'POLICY_DEFINITION' not in render_sql(models['one_to_one'], b'no dq')
    model = dq_model(models, spark)
    policies = model['tables']['POLICY_DEFINITION']
    assert len(policies) == 1
    assert [p['policy_id'] for p in policies] == [1]
    datasets = {d['dataset_id']: d['dataset_code'] for d in model['tables']['DATASET']}
    columns = {c['dataset_column_id']: c for c in model['tables']['DATASET_COLUMN']}
    for policy in policies:
        column = columns[policy['dataset_column_id']]
        assert column['dataset_id'] == policy['dataset_id']
        assert column['column_name'] == 'CLIENT_ID'
        assert policy['policy_code'] == datasets[policy['dataset_id']] + '_CLIENT_ID_NOT_NULL'
        assert policy['policy_scope_type'] == 'DATASET_COLUMN' and policy.get('task_id') is None
        assert policy['failure_action'] == 'FAIL_TASK' and policy['threshold_value'] == '0'
        assert json.loads(policy['parameter_json']) == {'check': 'NOT_NULL'}
    db = CatalogDb()
    try:
        db.deploy(render_sql(model, b'dq'))
        assert db.one('SELECT COUNT(*) n FROM METADATA.POLICY_DEFINITION')['n'] == 1
        with pytest.raises(sqlite3.IntegrityError):
            db.execute('UPDATE METADATA.POLICY_DEFINITION SET dataset_column_id=999999')
    finally:
        db.close()


def test_missing_dq_column_blocks_publication(spark, oci_setup):
    config, uri, client, _ = oci_setup
    config['dq_rules'] = [dq_rule(column='MISSING')]
    config['sql_output']['generate_main_ddl'] = True
    client.objects[uri] = yaml.safe_dump(config).encode()
    with pytest.raises(ValueError, match='DQ column does not exist'):
        generate(uri, spark=spark, client=client)
    assert not client.puts


def test_generated_policies_record_failure_and_repair(models, spark, tmp_path):
    model = dq_model(models, spark, custom=True)
    fw, db = prepare_execution(model, tmp_path, spark)
    attempts = []

    def prepare(frames, context, params):
        attempts.append(context['task_run_id'])
        df = frames['DEMO_LOAN_LOAN_RAW']
        if len(attempts) == 1:
            df = df.withColumn('CLIENT_ID', F.lit(None).cast('string'))
        return {STAGE: df}

    try:
        batch = fw.start_batch('generated-dq', '2026-10-15', 'MANUAL')['batch_id']
        fw.execute_task(batch, model['tasks'][0]['row']['task_code'])
        stage = model['tasks'][1]['row']['task_code']
        custom = {'PREPARE_CLIENT': prepare}
        with pytest.raises(ValueError, match='Blocking policy'):
            fw.execute_task(batch, stage, custom_steps=custom)
        failed = db.one("SELECT * FROM RUNTIME.TASK_RUN WHERE status='FAILED'")
        assert db.one('SELECT result_status FROM RUNTIME.POLICY_RESULT')['result_status'] == 'FAIL'
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'RUNNING'
        repaired = fw.execute_task(batch, stage, custom_steps=custom)
        fw.execute_task(batch, model['tasks'][2]['row']['task_code'])
        assert repaired['attempt_number'] == 2
        assert db.one('SELECT status FROM RUNTIME.BATCH')['status'] == 'COMPLETED'
        assert db.one('SELECT * FROM RUNTIME.TASK_RUN WHERE task_run_id=:id', id=failed['task_run_id']) == failed
        assert db.one('SELECT status FROM OPERATIONS.WORK_QUEUE')['status'] == 'OPEN'
        assert [r['result_status'] for r in db.execute('SELECT result_status FROM RUNTIME.POLICY_RESULT ORDER BY policy_result_id')] == ['FAIL', 'PASS']
    finally:
        db.close()


@pytest.mark.parametrize('name', ['one_to_one', 'many_to_one', 'one_to_many'])
def test_sql_has_compact_rows_and_one_column_insert_per_dataset(models, name):
    model = models[name]
    sql = render_sql(model, b'format')
    blocks = re.findall(r'  INSERT INTO METADATA.DATASET_COLUMN .*?;', sql, re.S)
    assert len(blocks) == len(model['tables']['DATASET'])
    assert sum(block.count('SELECT ') for block in blocks) == len(model['tables']['DATASET_COLUMN'])
    for block in blocks:
        rows = block.splitlines()[1:]
        assert all(row.endswith(('FROM DUAL', 'FROM DUAL;')) for row in rows)
    ordinary = [line for line in sql.splitlines() if line.startswith('  INSERT INTO') and 'METADATA.DATASET_COLUMN ' not in line]
    assert all(' VALUES (' in line and line.endswith(';') for line in ordinary)
    assert max(len(line.encode('utf-8')) for line in sql.splitlines()) < 2499
    db = CatalogDb()
    try:
        db.deploy(sql)
        assert db.one('SELECT COUNT(*) n FROM METADATA.DATASET_COLUMN')['n'] == len(model['tables']['DATASET_COLUMN'])
    finally:
        db.close()


def test_grouped_columns_support_wide_and_interleaved_definitions(models):
    model = deepcopy(models['one_to_one'])
    rows = model['tables']['DATASET_COLUMN']
    template = rows[0]
    wide = [dict(template, dataset_column_id=10000+i, column_sequence=i, column_name=f'FIELD_{i:03d}') for i in range(1, 201)]
    other = [r for r in rows if r['dataset_id'] != template['dataset_id']]
    model['tables']['DATASET_COLUMN'] = [wide[0], *other, *wide[1:]]
    sql = render_sql(model, b'wide')
    assert sql.count('INSERT INTO METADATA.DATASET_COLUMN ') == len(model['tables']['DATASET'])
    db = CatalogDb()
    try:
        db.deploy(sql)
        assert db.one('SELECT COUNT(*) n FROM METADATA.DATASET_COLUMN WHERE dataset_id=:id', id=template['dataset_id'])['n'] == 200
    finally:
        db.close()


def test_long_environment_values_retain_safe_wrapping(models):
    model = deepcopy(models['one_to_one'])
    row = model['tables']['SOURCE_CONFIG'][0]
    row['landing_path'] = {env: "oci://bucket@ns/" + "x'"*450 for env in ('DEV', 'STAGE', 'PROD')}
    sql = render_sql(model, b'long')
    assert max(len(line.encode('utf-8')) for line in sql.splitlines()) < 2499
    db = CatalogDb()
    try:
        db.deploy(sql)
        assert db.one('SELECT landing_path FROM METADATA.SOURCE_CONFIG')['landing_path'] == row['landing_path']['DEV']
    finally:
        db.close()
