"""OCI onboarding for the MDPF 1.0 Spark/Oracle POC."""
__version__ = '1.1'
